Plugin_add("mime/type", MIME_type_add);
Plugin_add("mime/mtype",MIME_mtype_add);
Plugin_add("url/protocol",URL_
"url/open"
