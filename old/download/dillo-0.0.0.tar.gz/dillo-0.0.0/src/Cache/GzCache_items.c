#include "../gzillacache.h"

void* GzCache_Items=NULL;
int GzCache_NItems=0, GzCache_NAlloc=0;
