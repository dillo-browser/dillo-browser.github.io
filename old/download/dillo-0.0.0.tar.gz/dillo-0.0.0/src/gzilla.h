#ifndef __GZILLA_H__
#define __GZILLA_H__

#include "gzillabrowser.h"
#include "gzillaweb.h"
#include "MIME/MIME.h"

#define Gzilla_idle_add(a,b) gtk_idle_add((GtkFunction)a,b)

/* This header file describes stuff that's defined in gzilla.c but is
 * needed in other parts of the program. Probably, most of it should get
 * moved out into other modules. */


/* These functions are signal handlers, which interface.c attaches
   to newly created main web pages. Nothing really wrong with that,
   but perhaps these should be moved out.
   */
void redirect (char *url, BrowserWindow *bw);
void size_allocate (GtkWidget *widget, GtkAllocation * allocation);
void request_url_img (GzillaImgSink *imgsink, char *url, BrowserWindow *bw);

/* exported to gzilladicache.c */
void open_url (GzillaWeb*, const char *url, BrowserWindow *bw);

char *gzilla_user_home(void);
char *gzilla_prepend_user_home(char *file);

#define DILLO_HOME "http://academico.inf.utfsm.cl:81/~jcid/Dillo/project.html"

#endif /* __GZILLA_H__ */
