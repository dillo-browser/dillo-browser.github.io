#include <gtk/gtk.h>

#include <stdio.h>
#include "gzillaimgsink.h"

#undef DISABLE_ALL_IMGSINK

void
gzilla_imgsink_init (GzillaImgSink *imgsink)
{
  imgsink->close_handler = NULL;
  imgsink->RefCount=0;
  imgsink->gzw=NULL;
}

#define def_imgsink_write

void
gzilla_imgsink_close (GzillaImgSink *imgsink)
{
#ifdef DISABLE_ALL_IMGSINK
  return;
#endif
  if (!imgsink) return;
  if (imgsink->close_handler != NULL)
    (*imgsink->close_handler) (imgsink->close_data, imgsink);
  imgsink->close (imgsink);
}

void
gzilla_imgsink_set_parms (GzillaImgSink *imgsink,
			  gint width,
			  gint height,
			  GzillaImgType type)
{
#ifdef DISABLE_ALL_IMGSINK
  return;
#endif
  if (imgsink->set_parms)
  imgsink->set_parms (imgsink, width, height, type);
  else 
	fprintf(stderr,"set_parms error\n");
}

void
gzilla_imgsink_set_cmap (GzillaImgSink *imgsink,
			 const unsigned char *cmap,
			 gint num_colors,
			 gint bg_index)
{
#ifdef DISABLE_ALL_IMGSINK
  return;
#endif
  imgsink->set_cmap (imgsink, cmap, num_colors, bg_index);
}

void
gzilla_imgsink_set_close_handler (GzillaImgSink *imgsink,
				  void (*close_handler) (void *data, GzillaImgSink *imgsink),
				  void *data)
{
  imgsink->close_handler = close_handler;
  imgsink->close_data = data;
}
