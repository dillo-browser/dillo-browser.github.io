#include "tests.h"
#include "../IO/GzIO.h"
#include "../IO/LDL.h"

struct qelem L1_t = {&L1_t, &L1_t};
struct qelem L2_t = {&L2_t, &L2_t};
int t_LDL_append(void)
{
   struct qelem A;
   LDL_append(&A,&L1_t);
   if (L1_t.q_forw != &A) {tprintf("LDL_append failed\n"); return -1;}
   tprintf("LDL_append: successful\n");
   return 0;
}

int t_LDL_empty(void)
{
   if (!LDL_empty(&L2_t)) {tprintf("LDL_empty failed\n"); return -1;}
   tprintf("LDL_empty: successful\n");
   return 0;
}


