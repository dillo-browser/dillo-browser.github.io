#include <stdio.h>
# define tprintf(args...) do{\
	fprintf(stderr, "Test %d (%s:%d) " , TestNum++,__FILE__,__LINE__);\
	fprintf(stderr, ##args);}while(0)

# define PleaseHelp "Please volunteer to help write this test\n"

extern int TestNum;
# define TestSeq(a)\
   if (a() < 0) {exit(-1);} 

/* The number of times we cycle over an individual test routine: */
# define Num_ICycles (1000)
/* The number of times we cycle over the whole sequence of routines: */
# define Num_SCycles (50)
