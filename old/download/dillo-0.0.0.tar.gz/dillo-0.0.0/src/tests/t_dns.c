#include "tests.h"

// BUG: A dummy since the DNS module either inits or fails
int t_gzilla_dns_init()
{
   gzilla_dns_init();
   tprintf("gzilla_dns_init: " PleaseHelp);
   return 1;
}

// BUG: A dummy since the DNS module is hard to test 
int t_gzilla_dns_lookup()
{
   tprintf("gzilla_dns_lookup: " PleaseHelp);
   return 1;
}

