#include "tests.h"
#include "../URL/URL_protos.h"

int t_URL_init()
{
   /* Test 1: Initialize system */
   if (URL_init()) {tprintf("URL_init failed!\n"); return -1;}
   tprintf("URL_init succeeded!\n");
   return 1;
}

