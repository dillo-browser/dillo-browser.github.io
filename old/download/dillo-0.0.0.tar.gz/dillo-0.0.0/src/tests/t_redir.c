#include "tests.h"

// BUG: A dummy since the web redirect module is complex
int t_gzilla_web_redirect()
{
   tprintf("gzilla_web_redirect: " PleaseHelp);
   return 1;
}
