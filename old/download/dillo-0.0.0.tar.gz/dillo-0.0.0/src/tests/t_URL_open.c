#include "tests.h"
#include "../URL/URL_protos.h"

int t_URL_open()
{
   int FD,size;
   char buf[512];
#if 0
   /* Test 2: Try the file opener for a real directory 
  -- Can't distinguish in this way... foo!
*/
   FD = URL_open("file:/",NULL);
   if (FD < 0) {tprintf("Failed to open local directory\n",""); return -1;}
   while ((size=read(FD,buf,sizeof(buf)))>0) 
    write(1,buf,size);
   close(FD);
   tprintf("Open local directory successful\n","");

   /* Test 3: Try the file opener for a bogus directory */
   FD = URL_open("file:XYZdoesntExist/",NULL);
   if (FD >= 0)
     {tprintf("Failed  -- opened bogus directory\n",""); close(FD); return -1;}
   tprintf("Success -- did not open bogus local directory\n","");
 
   /* Test 4: Try the file opener for a real file */
   FD = URL_open("file:gztest.c",NULL);
   if (FD < 0) {tprintf("Failed to open local file\n",""); return -1;}
   while ((size=read(FD,buf,sizeof(buf)))>0) 
    write(1,buf,size);
   close(FD);
   tprintf ("Success --  open local file.\n","");

   /* Test 5: Try open a local file that doesn't exist */
   FD = URL_open("file:IdOntExist.c",NULL);
   if (FD >= 0) {tprintf("Failed -- opened bogus file\n",""); close(FD);return -1;}
   tprintf("Success -- did not open bogus file\n","");
#endif

#if 0
 /* Redirection doesn't occur at this level -- it occurs at the cache level */
   /* Test 6: Test a redirection */
   FD = URL_open("about:gzilla", NULL);
   if (FD < 0) {tprintf("failed to redirect\n",""); return -1;}
   close(FD);
   tprintf("Success -- redirection test\n","");
#endif

   /* Test 7: Test our home page */
   FD = URL_open("http://www.gzilla.com/", NULL);
   if (FD < 0) {tprintf("failed to connect to our home page\n"); return -1;}
   while ((size=read(FD,buf,sizeof(buf)))>0) 
    write(1,buf,size);
   close(FD);
   tprintf("Success -- connected to our home page\n");
   
   return 1;
}
