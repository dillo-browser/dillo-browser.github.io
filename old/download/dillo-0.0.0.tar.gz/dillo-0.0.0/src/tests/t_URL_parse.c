#include <ctype.h> /* for isalpha */
#include <stdlib.h> /* for atoi */
#include <string.h>

#include "../URL/gzillaurl.h"
#include "../URL/URL_protos.h"
#include "tests.h"

static char* Errs[]={"hostname mismatch", "port mismatch", "tail mismatch",
	"head mismatch", "unknown reason"};
static int parse_t(const char* Base, const char* Host, const int Port, const char* Tail)
{
   char hostname[80]="";
   int port=-1;
   const char* tail = gzilla_url_parse (Base, hostname, sizeof (hostname), &port);
   if (strncmp(hostname, Host, sizeof(hostname))) return 0;
   if (port != Port) return 1;
   if (tail == Tail) return -1;
   if (!(tail && Tail) || strcmp(tail, Tail)) return 2;
   return -1;
}

#define DoTest(P,a,b,c,d) do{\
	int R=P(a,b,c,d);\
	if (R < 0) {tprintf("Successful\n");}\
	else       {tprintf("Failed -- %s\n", Errs[R]); return -1;}\
	}while(0)
int t_gzilla_url_parse()
{
   DoTest(parse_t,"file:.",     "",-1,NULL);
   DoTest(parse_t,"file:.#fred","",-1,NULL);
   DoTest(parse_t,"file:/.#fred","",-1,NULL);
   DoTest(parse_t,"file://.#fred",      ".#fred",-1,""); // Technically a lie
   DoTest(parse_t,"file://./wilma#fred",".",-1,"/wilma#fred"); // Technically a lie
   DoTest(parse_t,"about:them", "",-1,NULL);
   DoTest(parse_t,"http:here",  "",-1,NULL);
   DoTest(parse_t,"http:/here", "",-1,NULL);
   DoTest(parse_t,"http://here","here",-1,"");
   DoTest(parse_t,"http://here:8041","here",8041,"");
   DoTest(parse_t,"http://here/","here",-1,"/");
   DoTest(parse_t,"http://here:123/","here",123,"/");
   return  1;
}

static int parseH_t(const char* URL, const char* Head, const char* Tail, int D)
{
   char* T = URL_parse_hash(URL);
   size_t Size =T?(unsigned long)T-(unsigned long)URL:strlen(URL);
   if ((!Head || strncmp(URL,Head,Size))) {return 3;}
   if ((T && (!Tail || strcmp(T,Tail))) || (!T && Tail))
     {fprintf(stderr,"(%s),(%s)\n",T,Tail); return 2;}
   
   return -1;
}

int t_URL_parse_hash()
{
   DoTest(parseH_t,"file:.",      "file:.", NULL,  0);
   DoTest(parseH_t,"file:.#fred", "file:.", "#fred",0);
   DoTest(parseH_t,"file:/.#fred","file:/.","#fred",0);
   DoTest(parseH_t,"file://.#fred","file://.","#fred",0);
   DoTest(parseH_t,"file://./wilma#fred","file://./wilma","#fred",0);
   DoTest(parseH_t,"about:them", "about:them", NULL,0);
   DoTest(parseH_t,"http:here",  "http:here",  NULL,0);
   DoTest(parseH_t,"http:/here", "http:/here", NULL,0);
   DoTest(parseH_t,"http://here","http://here",NULL,0);
   DoTest(parseH_t,"http://here:8041","http://here:8041", NULL,0);
   DoTest(parseH_t,"http://here/",    "http://here/",     NULL,0);
   DoTest(parseH_t,"http://here:123/","http://here:123/", NULL,0);
   return  1;
}

static int parseP_t(const char* URL, const char* Proto, int C, int D)
{
   const char* T;
   size_t Size = URL_proto_parse(URL, &T);
   if (!Proto) return !Size? -1: 4;

   if (strncasecmp(Proto, T, Size)) return 4;
   
   return -1;
}

int t_URL_proto_parse()
{
   DoTest(parseP_t,"file:.",          "file",0,0);
   DoTest(parseP_t,"file:.#fred",     "file",0,0);
   DoTest(parseP_t,"file:/.#fred",    "file",0,0);
   DoTest(parseP_t,"file://.#fred",   "file",0,0);
   DoTest(parseP_t,"file://./wilma#fred","file",0,0);
   DoTest(parseP_t,"about:them",  "about",0,0);
   DoTest(parseP_t,"http:here",   "http",0,0);
   DoTest(parseP_t,"http:/here",  "http",0,0);
   DoTest(parseP_t,"http://here", "http",0,0);
   DoTest(parseP_t,"http://here:8041","http",0,0);
   DoTest(parseP_t,"http://here/",    "http",0,0);
   DoTest(parseP_t,"http://here:123/","http",0,0);
   DoTest(parseP_t,".",       NULL,0,0);
   DoTest(parseP_t,".#fred",  NULL,0,0);
   DoTest(parseP_t,"/.#fred", NULL,0,0);
   DoTest(parseP_t,"//.#fred",NULL,0,0);
   DoTest(parseP_t,"//./wilma#fred",NULL,0,0);
   DoTest(parseP_t,"them",       NULL,0,0);
   DoTest(parseP_t,"here",       NULL,0,0);
   DoTest(parseP_t,"/here",      NULL,0,0);
   DoTest(parseP_t,"//here",     NULL,0,0);
   DoTest(parseP_t,"//here:8041",NULL,0,0);
   DoTest(parseP_t,"//here/",    NULL,0,0);
   DoTest(parseP_t,"//here:123/",NULL,0,0);
   return  1;
}


static int Abs_t (const char* URL, int X, int c, int d)
{
   int A= URL_is_absolute(URL);
   return ((A && X)||(!A && !X)) ? -1 : 4; 
}

int t_URL_is_absolute()
{
   DoTest(Abs_t,"file:.",       1,0,0);
   DoTest(Abs_t,"file:.#fred",  1,0,0);
   DoTest(Abs_t,"file:/.#fred", 1,0,0);
   DoTest(Abs_t,"file://.#fred",1,0,0);
   DoTest(Abs_t,"file://./wilma#fred",1,0,0);
   DoTest(Abs_t,"about:them", 1,0,0);
   DoTest(Abs_t,"http:here",  1,0,0);
   DoTest(Abs_t,"http:/here", 1,0,0);
   DoTest(Abs_t,"http://here",1,0,0);
   DoTest(Abs_t,"http://here:8041",1,0,0);
   DoTest(Abs_t,"http://here/",    1,0,0);
   DoTest(Abs_t,"http://here:123/",1,0,0);
   DoTest(Abs_t,".",       0,0,0);
   DoTest(Abs_t,".#fred",  0,0,0);
   DoTest(Abs_t,"/.#fred", 0,0,0);
   DoTest(Abs_t,"//.#fred",0,0,0);
   DoTest(Abs_t,"//./wilma#fred",0,0,0);
   DoTest(Abs_t,"them",  0,0,0);
   DoTest(Abs_t,"here",  0,0,0);
   DoTest(Abs_t,"/here", 0,0,0);
   DoTest(Abs_t,"//here",0,0,0);
   DoTest(Abs_t,"//here:8041",0,0,0);
   DoTest(Abs_t,"//here/",    0,0,0);
   DoTest(Abs_t,"//here:123/",0,0,0);
   return  1;
}

#if 0
/* Unit test as follows:

   gcc -g -I/usr/local/include/gtk -DUNIT_TEST gzillaurl.c -o gzillaurl
   ./gzillaurl base_url relative_url

*/

int main (int argc, char **argv) {
  char buf[80];
  char hostname[80];
  char *tail;
  int port;

  if (argc == 3) {
    if (gzilla_url_relative (argv[1], argv[2], buf, sizeof(buf))) {
      printf ("%s\n", buf);
      port = 80;
      tail = gzilla_url_parse (buf, hostname, sizeof (hostname), &port);
      if (tail != NULL) {
	printf ("hostname = %s, port = %d, tail = %s\n", hostname, port, tail);
      }
    } else {
      printf ("buffer overflow!\n");
    }
  } else {
    printf ("Usage: %s base_url relative_url\n", argv[0]);
  }
  return 0;
}
#endif
