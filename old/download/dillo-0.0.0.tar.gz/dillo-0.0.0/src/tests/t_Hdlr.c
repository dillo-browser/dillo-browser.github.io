#include "tests.h"

// BUG: A dummy
int t_Hdlr_add()
{
   tprintf("Hdlr_add: " PleaseHelp);
   return 1;
}

// BUG: A dummy
int t_Hdlr_cmp()
{
   tprintf("Hdlr_cmp: " PleaseHelp);
   return 1;
}

