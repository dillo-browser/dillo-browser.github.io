#Calling sequence graph
#This indicates what order the calls must be in (if any)
#URL_open: URL_init gzilla_dns_init
gzilla_dns_lookup: gzilla_dns_init

