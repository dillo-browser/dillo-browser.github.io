/* to be renamed gzillasocket.c */

/*

 gzilla

 Copyright 1997 Raph Levien <raph@acm.org>

 This code is free for commercial and non-commercial use,
 modification, and redistribution, as long as the source code release,
 startup screen, or product packaging includes this copyright notice.

 */


/* This module provides an API for asynchronously opening a client
   socket using the GTK framework.
   */

#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <stdio.h>

#include <netdb.h>		/* for gethostbyname, etc. */
#include <sys/socket.h>		/* for lots of socket stuff */
#include <netinet/in.h>		/* for ntohl and stuff */

#include <search.h>
#include <malloc.h>
#include "IO/LDL.h"
#include "gzilladns.h"

static void gzilla_socket_input_handler(gpointer data,
					gint source,
					GdkInputCondition condition);

typedef struct _GzillaSocket {
  struct _GzillaSocket* q_forw, *q_back;
  int dns_tag;
  int input_tag;
  int port;
  struct sockaddr_in sin;
  int fd;
  void (* callback) (int Op, int fd, void *callback_data);
  void *callback_data;
} GzillaSocket;

static struct qelem sockets, sockets_free={&sockets_free,&sockets_free};

/* Initialize the socket data structures. */
void
gzilla_socket_init (void)
{
   LDL_init(&sockets);
}


#if 0
static GzillaSocket* gzilla_socket_lookup(int fd)
{
   GzillaSocket* IPtr;
   LDL_foreach(IPtr, &sockets) {if (IPtr->fd==fd) return IPtr;}
   return NULL;
}
#endif


/* Try connecting the socket. On success or error, delete the socket
   structure, remove the input tag (if any), and call the callback. */

static void
gzilla_socket_try_connect (GzillaSocket* SPtr)
{
  int status;
  int fd = SPtr->fd;
  void (* callback) (int Op, int _fd, void *callback_data)= SPtr->callback;
  void *callback_data= SPtr->callback_data;
  
  status = connect(fd, (struct sockaddr *) &(SPtr->sin), sizeof(struct sockaddr_in));

/**/fprintf(stderr, "gzilla_socket_try_connect: status = %d\n", status);
/**/fprintf(stderr, "gzilla_socket_try_connect: errno  = %d\n", errno );
/**/fprintf(stderr, 
    "EISCONN=%d EINPROGRESS=%d EAGAIN=%d EINTR=%d\n", 
    EISCONN, EINPROGRESS, EAGAIN, EINTR);

  /* Note: handling of the EISCONN error condition was added by
	 Tristan Tarrant on 28 Nov 1997. This apparently fixes some
	 problems on Solaris 2.5.
	 
	 What's still totally unclear to me is why there would be an
	 EISCONN error return. Is it possible that this routine is
	 getting called to many times? */
  if (status < 0 && errno == EISCONN )
    {
      status = 0;
    }
  else if (status < 0 && !(errno == EINPROGRESS ||
		      errno == EAGAIN ||
		      errno == EINTR))
    {
      SPtr->callback_data=NULL;
      callback(1,fd,callback_data);
      close (fd);
      remque(SPtr);
      LDL_append(SPtr, &sockets_free);
      fd = -1;
      return;
    }

  if (status >= 0)
    {
      
      if (SPtr->input_tag)
	gdk_input_remove (SPtr->input_tag);
      
      remque(SPtr);
      SPtr->callback_data=NULL;
      LDL_append(SPtr, &sockets_free);
      
      /* Note: do the callback after changes to socket structure are
	 complete, just in case callback wants to allocate any new
	 sockets or abort any old ones. */
      
      callback (0, fd, callback_data);
    }
  else
    {
      if (SPtr->input_tag == 0)
	SPtr->input_tag =
	  gdk_input_add (fd,
			 GDK_INPUT_WRITE,
			 (GdkInputFunction) gzilla_socket_input_handler,
			 (void *)SPtr);
    }
}


/* The input handler. Try to connect the socket. */

static void
gzilla_socket_input_handler (gpointer data,
			     gint source,
			     GdkInputCondition condition)
{
  gzilla_socket_try_connect ((GzillaSocket*)data);
}

/* The DNS callback. Create the socket. Try connecting it if in
   DNS_WAIT state. If it's not in DNS_WAIT state, then it's in INIT
   state and the try_connect call will happen in gzilla_socket_new. */

static void
gzilla_socket_dns_callback (int Op, guint32 ip_addr, void *callback_data)
{
   GzillaSocket* SPtr=(GzillaSocket*) callback_data;
   
/**/fprintf(stderr, "gzilla_socket_dns_callback: IP = %x\n", ip_addr);
            
   if (Op)
     {
       /* DNS failed.. */
       void (* callback) (int _Op, int fd, void *callbackdata) = SPtr->callback;
       callback(Op,SPtr->fd, SPtr->callback_data);
       SPtr->callback_data=NULL;
       close(SPtr->fd);
       remque(SPtr);
       LDL_append(SPtr, &sockets_free);
       return;
     }
   
   /* Found the socket structure. */
   SPtr->sin.sin_addr.s_addr = htonl (ip_addr);
   
   gzilla_socket_try_connect (SPtr);
}


/* Create a new connection to (hostname, port). When the socket is
   created, call the callback with the file descriptor of the socket,
   or -1 on failure. The callback may be called inside the call to
   this function, or later from a GTK input handler. */

int
gzilla_socket_new (const char *hostname,
		   gint port,
		   void (* callback) (int op, int fd, void *callback_data),
		   void *callback_data)
{

   GzillaSocket* SPtr=NULL;
  
   if (LDL_empty(&sockets_free))
     {
       SPtr = (GzillaSocket*) malloc(sizeof(GzillaSocket));
     }
   else
     {
       SPtr=(GzillaSocket*) sockets_free.q_forw;
       remque((struct qelem*) SPtr);
     }
   
   SPtr->input_tag = 0;
   SPtr->port = port;
   SPtr->callback = callback;
   SPtr->callback_data = callback_data;
   SPtr->fd = socket (AF_INET, SOCK_STREAM, IPPROTO_TCP);
   if (SPtr->fd < 0)
     {
       /* Failed.. clean up */
       SPtr->callback_data=NULL;
       LDL_append(SPtr,&sockets_free);
       callback(1,-1,callback_data);
       return -1;
     }

   /* set up sin structure, in preparation for the connect call */
   SPtr->sin.sin_family = AF_INET;
   SPtr->sin.sin_port = htons (SPtr->port);

   /* set nonblocking */
  fcntl (SPtr->fd, F_SETFL, O_NONBLOCK | fcntl(SPtr->fd, F_GETFL));

  /* set close-on-exec */
  fcntl (SPtr->fd, F_SETFD, FD_CLOEXEC | fcntl(SPtr->fd, F_GETFD));

  LDL_append(SPtr, &sockets);
  /* Note: dns lookup is done after socket structure is already set up,
     in case callback is called immediately.

     Also note: the integer tag is casted to a void * so that it can
     pass through the dns callback mechanism. Allocating a new memory
     structure to hold the tag would have been cleaner from a type
     point of view, but less efficient.

     Final note: the socket_try_connect call is deferred until after
     the call to gzilla_dns_lookup, because (if successful), it might
     deallocate the socket structure, and it wouldn't be good to have
     that happen before the following assignment to it. */

/**/fprintf(stderr,"gzilla_socket_new: hostname = >%s<\n", hostname);
  SPtr->dns_tag = (int) gzilla_dns_lookup (hostname,
					  gzilla_socket_dns_callback,
					  (void *)SPtr);
  return SPtr->fd;
}

#ifdef use_me_later
/* Abort the connection. After an abort call, the callback associated
   with the tag will not be called. Also frees resources used in
   setting up the connection (aborting a pending dns request, closing
   the socket, and removing an input handler, depending on the state
   of the connection). */

void
gzilla_socket_abort (int fd)
{
   GzillaSocket* SPtr=gzilla_socket_lookup(fd);
   if (!SPtr)
     {
        g_warning ("trying to abort nonexistent socket tag!\n");
	return;
     }

   /* Found the socket structure. */
   
   if (SPtr->state == GZILLA_SOCKET_DNS_WAIT)
     gzilla_dns_abort (SPtr->dns_tag);
   else
     close (SPtr->fd);
   
   SPtr->callback(1,-1,SPtr->callback_data);
   SPtr->callback_data=NULL;
   if (SPtr->input_tag)
     gdk_input_remove (SPtr->input_tag);
   remque((struct qelem*) SPtr);
   LDL_append(SPtr, &sockets_free);
}
#endif
