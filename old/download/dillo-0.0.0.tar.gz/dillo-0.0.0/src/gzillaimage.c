#include <gtk/gtk.h>
#include <malloc.h>
#include <stdio.h>
#include <string.h>

#include "gzillaimgsink.h"

/* This file implements a gzilla_image module. It handles the transfer
   of data from an ImgSink to a gzw_image widget. */

/* todo: performance seems rather poor :(

   Need to add support for RGBA images */

static size_t linebuf_size=0;
static guchar* linebuf=NULL;

static void
gzilla_image_line (GzillaImgSink *image,
		   const unsigned char *buf,
		   const unsigned char* cmap,
		   gint y)
{
  gint width;
  gint in_width;
  gint x;
  gint byte;

  /* todo: handle image types other than indexed. */

  width = image->width;
  in_width = image->in_width;

  switch (image->in_type) {
  case GZILLA_IMG_TYPE_INDEXED:
    if (width == in_width) {
      for (x = 0; x < width; x++) {
	byte = ((unsigned char *)buf)[x];
	linebuf[x * 3] = cmap[byte * 3];
	linebuf[x * 3 + 1] = cmap[byte * 3 + 1];
	linebuf[x * 3 + 2] = cmap[byte * 3 + 2];
      }
    } else {
      /* could use DDA here if speed were an issue */
      for (x = 0; x < width; x++) {
	byte = ((unsigned char *)buf)[x * in_width / width];
	linebuf[x * 3] = cmap[byte * 3];
	linebuf[x * 3 + 1] = cmap[byte * 3 + 1];
	linebuf[x * 3 + 2] = cmap[byte * 3 + 2];
      }
    }
    break;
  case GZILLA_IMG_TYPE_GRAY:
    if (width == in_width) {
      for (x = 0; x < width; x++) {
	byte = ((unsigned char *)buf)[x];
	linebuf[x * 3] = byte;
	linebuf[x * 3 + 1] = byte;
	linebuf[x * 3 + 2] = byte;
      }
    } else {
      /* could use DDA here if speed were an issue */
      for (x = 0; x < width; x++) {
	byte = ((unsigned char *)buf)[x * in_width / width];
	linebuf[x * 3] = byte;
	linebuf[x * 3 + 1] = byte;
	linebuf[x * 3 + 2] = byte;
      }
    }
    break;
  case GZILLA_IMG_TYPE_RGB:
    if (width == in_width) {
      /* could avoid memcpy here, if clever. For example, return a boolean
	 to indicate whether to use linebuf or the input buf. */
      memcpy (linebuf, buf, in_width * 3);
    } else {
      /* could use DDA here if speed were an issue */
      for (x = 0; x < width; x++) {
	gint x0;

	x0 = (x * in_width / width) * 3;
	byte = ((unsigned char *)buf)[x * in_width / width];
	linebuf[x * 3] = ((unsigned char *)buf)[x0];
	linebuf[x * 3 + 1] = ((unsigned char *)buf)[x0 + 1];
	linebuf[x * 3 + 2] = ((unsigned char *)buf)[x0 + 2];
      }
    }
    break;
  }
}

void
_gzilla_image_write (GzillaImgSink *imgsink,
		    const unsigned char *buf,
		    gint x0,
		    gint y,
		    GzwImage** gzws, int NGzws)
{
  /* Convert buf to linebuf */
  /* Convert linebuf to Display Buffer */
  gint y_begin = (y*imgsink->height+imgsink->in_height-1) / imgsink->in_height;
  gint y_end = ((y+1)*imgsink->height+imgsink->in_height-1)/imgsink->in_height;
  gint y_new;

  if (y_end <= y_begin) return;

  gzilla_image_line (imgsink, buf, imgsink->cmap, y);

  for (y_new = y_begin; y_new < y_end && y_new < imgsink->in_height; y_new++)
    gzw_image_draw_row (gzws, NGzws, linebuf,
			0, y_new, imgsink->width);
}

static void
gzilla_image_write (GzillaImgSink *imgsink,
		    const unsigned char *buf,
		    gint x0, gint y)
{
   _gzilla_image_write(imgsink,buf,x0,y,&imgsink->gzw,1);
}

void
gzilla_image_close (GzillaImgSink *imgsink)
{
   if (imgsink->RefCount > 1) {imgsink->RefCount--; return;}
  if (imgsink->cmap)
    free (imgsink->cmap);
  if (imgsink->Parent) *(imgsink->Parent)=NULL;
  free (imgsink);
}

/* Implement the set_parms method of the image sink */
void
gzilla_image_set_parms (GzillaImgSink *imgsink,
			gint width,
			gint height,
			GzillaImgType type)
{
  gboolean resize;

  imgsink->in_type = type;
  imgsink->in_width = width;
  imgsink->in_height = height;
  resize = (imgsink->width ==0 || imgsink->height ==0);
  if (3*width > linebuf_size)
    {
       linebuf_size=3*width;
       linebuf=g_realloc(linebuf, linebuf_size);
    }
  if (imgsink->width == 0) {
    imgsink->width = width;
  }
  if (imgsink->height == 0)
    imgsink->height = height;
  if (resize) {
    gzw_image_size ((GzwImage *)imgsink->gzw,
		    imgsink->width, imgsink->height);
  }
   gzw_image_init_buffer ((GzwImage*)imgsink->gzw);
}

/* Implement the set_parms method of the image sink */
void
gzilla_image_set_cmap (GzillaImgSink* imgsink,		       
		       const unsigned char* cmap, /*size = 3*num_colors */
		       gint num_colors,
		       gint bg_index)
{
  if (!imgsink) return;
  imgsink->cmap = g_realloc (imgsink->cmap, 3 * 256); /*num_colors); */
  if (!imgsink->cmap) return;
  memcpy (imgsink->cmap, cmap, 3 * num_colors);
  if (bg_index >= 0 && bg_index < 256) { /*num_colors) { */
    imgsink->cmap[bg_index * 3] = (imgsink->bg_color >> 16) & 0xff;
    imgsink->cmap[bg_index * 3 + 1] = (imgsink->bg_color >> 8) & 0xff;
    imgsink->cmap[bg_index * 3 + 2] = (imgsink->bg_color) & 0xff;
  }
}

GzillaImgSink*
gzilla_image_new (gint width,
		  gint height,
		  const char *alt,
		  gint32 bg_color)
{
  GzillaImgSink *image;

  image = g_new (GzillaImgSink, 1);
  gzilla_imgsink_init (image);
  image->Parent  = NULL;
  image->width   = width;
  image->height  = height;
  image->bg_color= bg_color;
  image->gzw     = (GzwImage*) gzw_image_new(GZW_IMAGE_RGB);
  if (3*width > linebuf_size)
    {
       linebuf_size =3*width;
       linebuf=g_realloc(linebuf,linebuf_size);
    }

  image->cmap = NULL;

  image->write = gzilla_image_write;
  image->close = gzilla_image_close;
  image->set_cmap = gzilla_image_set_cmap;
  image->set_parms=gzilla_image_set_parms;
  image->RefCount++;

  return image;
}
