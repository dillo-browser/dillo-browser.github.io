/*

 gzilla

 Copyright 1997 Raph Levien <raph@acm.org>

 This code is free for commercial and non-commercial use,
 modification, and redistribution, as long as the source code release,
 startup screen, or product packaging includes this copyright notice.

 */

/* The decompressed image cache for Gzilla. This code has been reviewed
   28 Nov 1997 by RLL. */

/*
   Modifications by RCM:
    The stuff in gzillaimage.c expands each line directly into the cache here.
    The Decompressed Image cache is now uses an interface into gzillaimage.c
    (not imgsink anymore) that decodes the RGB/Colormap stuff right into the
    image cache.  When images are taken from the image cache, the are feed thru
    gzillaimage.c into gzwimage.  There is no copying, allocation or other
    processing
*/

#include <gtk/gtk.h>
#include <string.h>         /* for memset */
#include <malloc.h>
#include <stdio.h>
#include "IO/GzIO.h"

#include "gzillaimgsink.h"
#include "gzilla.h"         /* for open_url_raw */
#include "gzillaweb.h"      /* for gzilla_web_new_img_decoder */
#include "gzilladicache.h"
#include "gzillacache.h"
#include "interface.h"
static GzillaWeb* gzilla_web_new_img_decoder (GzillaImgSink *imgsink, const char* URL);

/* This was a list of things to be done, but now it's all done.

   register imgsinks in the browser_window structure. I think
   that can happen outside this particular module (I'm thinking
   request_url_img) and also (hopefully) move the existing
   BrowserWindow stuff out.

   Once imgsinks are registered, bytesinks feeding image decoders will
   _not_ be registered with the browser window.

   abort_all will go; instead, gzilla_bw_abort_all will simply call
   abort for each imgsink in the browser window.

   I'll have to add a second callback for the "close" method so that
   closing an imgsink causes the interface to remove it from the
   imgsinks list. This will require a "baby" version of the GTK+
   signal mechanism.

   These changes are needed to make multiple browser windows work.

   This interface no longer involves the browser window. */

/* Return the pos of the first bit set in the range [0..max), or max if
   all clear. */

static inline gint
gzilla_bitvec_scan (fd_set*bitvec, gint start, gint max)
{
  gint i;

  /* A more efficient implementation based on byte (or even word)
     scanning is possible. I'll do it if profiling tells me I need to. */

  for (i = start; i < max; i++) {
    if (FD_ISSET(i,bitvec)) return i;
  }
  return max;
}

typedef struct _GzillaDICacheLine GzillaDICacheLine;
typedef struct _GzillaDICacheCon {
  GzillaDICacheLine *line;
  size_t gzw_idx;
  int Used;
  gint start; /* invariant: bitvec[0..start) are all FALSE */
} GzillaDICacheCon;

struct _GzillaDICacheLine {
  char *url;
  int height;
  unsigned char *Image_Buffer;
  int in_height,in_width,width;
  int NRef;
  fd_set*bitvec; /* bit=TRUE says line is present */
  /* thise field is  only valid if */
  /*  type == GZILLA_IMG_TYPE_INDEXED     */
  gint last_use;
  int Used;
  gboolean eof;
  size_t   Total_Size;  /* amount of memory the image takes up */
  int NGzws;
  GzwImage** gzw;
  GzillaImgSink* imgsink;
  GzillaDICacheCon* con;
};

typedef struct _GzillaImgSinkDIC {
  GzillaImgSink imgsink;
  GzillaDICacheLine *line;
  BrowserWindow* bw;
  int FD;
} GzillaImgSinkDIC;

#define DICACHE_MAX 2000000

static GzillaDICacheLine **dicache;
static gint dicache_size;
static gint dicache_size_max;

static GzillaDICacheCon **diccons;
static gint num_diccons;
static gint num_diccons_max;

static gint dicache_size_total;	/* invariant: dicache_size_total is
				   the sum of the image sizes of all
				   cache lines in dicache. */
static gint dicache_counter;

void
gzilla_dicache_init (void)
{
  dicache_size = 0;
  dicache_size_max = 16;
  dicache = g_new(GzillaDICacheLine *, dicache_size_max);
	
  num_diccons = 0;
  num_diccons_max = 16;
  diccons = g_new(GzillaDICacheCon *, dicache_size_max);
	
  dicache_size_total = 0;
  dicache_counter = 0;
}

/* Write a scan line into the cached image. This is only called from
   gzilla_dicache_imgsink_write, so maybe the two should be combined. */

/* Implement the write method of the cache line's image sink */
static void
gzilla_dicache_imgsink_write (GzillaImgSink *imgsink,
			      const unsigned char *buf,
			      gint x,
			      gint Y)
{
  GzillaDICacheLine *line= ((GzillaImgSinkDIC *)imgsink)->line;

  if (!line->imgsink) return;
if (!line->width || !line->height) {fprintf(stderr,"write to badly sized image!\n");}

  _gzilla_image_write (line->imgsink, buf, x, Y, line->gzw, line->NGzws);
  FD_SET(Y,line->bitvec);

      /* Another possibility would be to write from the cached
	 image, guaranteeing a stride of 1 for downstream
	 imagesinks. Well, we can worry about that when we start
	 doing progressive png's. -Raph */
      
  line->con->start=Y+1;
}


/* Remove the dicache connection from the diccons table. */

static void
gzilla_dicache_delete_diccon (gint diccon_index)
{
  diccons[diccon_index]->line->Used--;
  diccons[diccon_index]->line->con=NULL;
  free (diccons[diccon_index]);
  diccons[diccon_index] = diccons[--num_diccons];
}

/* Implement the close method of the cache line's image sink */
static void
gzilla_dicache_imgsink_close (GzillaImgSink *imgsink)
{
  GzillaImgSinkDIC* DIC = (GzillaImgSinkDIC*) imgsink;
  GzillaDICacheLine *line= DIC->line;
  gint i;

  line->eof = TRUE;
  for (i = 0; i < num_diccons; i++)
    {
      if (diccons[i]->line == line && (!diccons[i]->line->bitvec ||
	  gzilla_bitvec_scan (diccons[i]->line->bitvec,
			      diccons[i]->start, 
			      line->height) == line->height))
	{
          if (diccons[i]->Used) {diccons[i]->Used=0; continue;}
	  gzilla_dicache_delete_diccon (i--);
	}
    }
  if (line->imgsink)
   gzilla_imgsink_close (line->imgsink);
  line->imgsink = NULL;
  if (DIC->bw && DIC->FD > 0)
    gzilla_bw_delete_FD(DIC->bw, DIC->FD);
#if 0
  if (imgsink->Parent) *(imgsink->Parent)=NULL;
  free (imgsink);
#endif
}

/* Remove an image from the cache */
static void gzilla_dicache_free(GzillaDICacheLine* DIPtr)
{
  if (DIPtr->imgsink) {gzilla_imgsink_close(DIPtr->imgsink);}
  if (DIPtr->Image_Buffer)
    {
      free (DIPtr->Image_Buffer);
      dicache_size_total -= DIPtr->Total_Size;
    }
  if (DIPtr->bitvec)       free (DIPtr->bitvec);
  if (DIPtr->gzw)
    {
       free (DIPtr->gzw);
    }
  free (DIPtr);
}

static void gzilla_dicache_remove (gint dicache_index) {
  gzilla_dicache_free(dicache[dicache_index]);
  dicache[dicache_index] = dicache[--dicache_size];
}

/* Expand the cache, throwing out old items to enforce the size limit. */
/* Profiling reaveals half our time is spent here for Microsofts web site... */
static void
gzilla_dicache_expand (gint size)
{
  gint dicache_index;
  gint best;
	
  dicache_size_total += size;
#ifdef VERBOSE
  g_print("dicache_size_total = %d\n", dicache_size_total);
#endif
	
  /* I know the algorithm is inefficient. I don't really think it matters. */
  while (dicache_size_total > DICACHE_MAX)
    {
      best = -1;
      for (dicache_index=0; dicache_index < dicache_size; dicache_index++)
       {
	  /* Skip the cache items that aren't finished being inserted or are
	     still referenced (the gzw field automatically goes to NULL when
	     things aren't being displayed any more). */
	  if (best != -1 &&
		 dicache[dicache_index]->last_use >= dicache[best]->last_use)
	    continue;
	  if (dicache[dicache_index]->Used) continue;
	  /* BUG: I don't like this since there is few ways to stop the incoming
		data, a slow server could clog us. */
	  if (dicache[dicache_index]->NRef) continue;
	  best = dicache_index;
       }
      if (best == -1)
	return;
      gzilla_dicache_remove (best);
    }
}

static void ImageBuffer_realloc(GzillaDICacheLine* line)
{
   size_t Size;
   unsigned char* b;
   Size= MAX(line->imgsink->gzw->buffer_width,
		 MAX(line->imgsink->width,MAX(line->width,line->in_width)))*
	MAX(line->imgsink->gzw->buffer_height,
		MAX(line->imgsink->height,MAX(line->height,line->in_height)))*
	image_info->bpp;
   Size=MAX(Size,line->Total_Size);
   if (!Size) return;
   line->Used++;
   gzilla_dicache_expand (Size);
   line->Used--;
   b= g_realloc (line->Image_Buffer,Size);
   if (!b) return;
   line->Image_Buffer=b;

   /* For giggles, make the background of the undrawn parts interesting */
   memset(b+line->Total_Size,0xdd, Size-line->Total_Size); 
   line->Total_Size=Size;
}

/* Implement the set_parms method of the cache line's image sink */
static void
gzilla_dicache_imgsink_set_parms (GzillaImgSink *imgsink,
				  gint width,
				  gint height,
				  GzillaImgType type)
{
  GzillaDICacheLine *line= ((GzillaImgSinkDIC *)imgsink)->line;
  int I;

  if (!line->imgsink) return;
  gzilla_image_set_parms (line->imgsink, width, height, type);
  line->in_height=line->imgsink->in_height;
  line->in_width=line->imgsink->in_width;
  line->width=line->imgsink->width;

  ImageBuffer_realloc(line);
  /* Update the buffer area for each of the displyed images */
  if (line->gzw)
  for (I = 0; I < line->NGzws; I++)
   {
      if (!line->gzw[I]) continue;
      line->gzw[I]->buffer=line->Image_Buffer;
      gzw_image_size ((GzwImage *)line->gzw[I],
		    line->imgsink->width, line->imgsink->height);
      gzw_image_init_buffer (line->gzw[I]);
   }
  line->height = height;
}

/* Implement the set_cmap method of the cache line's image sink */
static void
gzilla_dicache_imgsink_set_cmap (GzillaImgSink *imgsink,
				 const unsigned char *cmap,
				 int num_colors,
				 int bg_index)
{
  GzillaDICacheLine *line = ((GzillaImgSinkDIC *)imgsink)->line;
  gzilla_image_set_cmap(line->imgsink, cmap, num_colors,bg_index);
}

static int 
gzilla_dicache_idle_func (GzillaDICacheCon* DIPtr)
{
  gint y;
  GzillaDICacheLine* line=DIPtr->line;
  GzwRect rect;
  GzwImage* image=line->gzw[DIPtr->gzw_idx];
  if (!DIPtr->Used || !image) goto end;
  rect.x0 = image->gzw.allocation.x0;
  rect.x1 = image->gzw.allocation.x0 + line->width;

  /* Find out if there is a scanline in the cached image that hasn't
     been written to the imgsink.
     
     Note: maybe there should be a flag for an all-empty bitvec.
  */
  while(1)
    {
      gint y_begin,y_end,y_new;
      y = gzilla_bitvec_scan (line->bitvec,
			      DIPtr->start,
			      line->height);
      if (y >= line->height) break;
      y_begin = (y*line->height+line->in_height-1) / line->in_height;
      y_end = ((y+1)*line->height+line->in_height-1)/line->in_height;
      for (y_new = y_begin; y_new < y_end && y_new < line->in_height; y_new++)
	{
	   rect.y0 = image->gzw.allocation.y0 + y_new;
	   rect.y1 = image->gzw.allocation.y0 + y_new + 1;
	   gzw_request_paint (&image->gzw, &rect);
	}
      DIPtr->start = y + 1;
    }
  if (!line->eof) return FALSE;
end:
  /* We are done with it. */
  if (line->NRef) line->NRef--;
  DIPtr->Used=0;
    {
       /* all done writing cached image to imgsink */
       int i;
       if (line->imgsink) gzilla_imgsink_close (line->imgsink);
       line->imgsink=NULL;
       for (i = 0; i < num_diccons; i++)
        {
           if (diccons[i] != DIPtr) continue;
           gzilla_dicache_delete_diccon (i);
	   break;
        }	
    }

  return FALSE;
}

static void
gzilla_dicache_hit (GzillaImgSink *imgsink, GzillaDICacheLine *line)
{
   GzillaDICacheCon *diccon;
   int I;
   
   if (num_diccons == num_diccons_max)
     {
       num_diccons_max <<= 1;
       diccons = g_realloc (diccons, num_diccons_max *
			    sizeof(GzillaDICacheCon *));
     }
   diccon = g_new (GzillaDICacheCon, 1);
   diccon->line = line;
   line->Used++;
   diccon->Used=0;
   line->con = diccon;
   diccons[num_diccons++] = diccon;

   line->last_use = dicache_counter++;
   if (!line->bitvec)
    {
       line->bitvec = malloc(sizeof(*(line->bitvec)));
       FD_ZERO(line->bitvec);
    }
   /* Get a Gzilla Widget to display some stuff.  This pointer
      automatically goes to NULL when the object is no longer displayed */
   line->NRef++;
   imgsink->gzw->Counter=&line->NRef;
   diccon->gzw_idx=line->NGzws;
   line->gzw=g_realloc(line->gzw,sizeof(*line->gzw)*(++line->NGzws));
   line->gzw[line->NGzws-1]= imgsink->gzw;
   /* Now that the line->gzw may have moved.. update all of the back links*/
   for (I = 0; I < line->NGzws; I++)
    if (line->gzw[I]) line->gzw[I]->Parent=(Gzw**)&(line->gzw[I]);

   gzw_image_size (imgsink->gzw, imgsink->width, imgsink->height);
   if (!line->imgsink)
     {
        line->imgsink = imgsink;
        imgsink->Parent=&line->imgsink;
     }
    else {gzilla_imgsink_close(imgsink); imgsink=NULL;}

   if (!line->Image_Buffer || !line->height || !line->width)
     {
	ImageBuffer_realloc(line);
        diccon->start = 0;

	/* Update the buffer area for each of the displyed images */
	for (I = 0; I < line->NGzws; I++)
	 {
	    if (!line->gzw[I]) continue;
	    line->gzw[I]->buffer=line->Image_Buffer;
	    if (line->Image_Buffer) gzw_image_init_buffer (line->gzw[I]);
	 }
        return;
     }
   /* take this branch if gzilla_imgsink_set_parms () has already
      been called on the cache line, so we know the image size */
   line->gzw[diccon->gzw_idx]->buffer=line->Image_Buffer;
   if (line->Image_Buffer) gzw_image_init_buffer (line->gzw[diccon->gzw_idx]);
   diccon->start = gzilla_bitvec_scan (line->bitvec, 0, line->height);
   
   /* The idle function also references it... temporarily! */
   line->NRef++;
   diccon->Used=1;
   gtk_idle_add((GtkFunction)gzilla_dicache_idle_func,diccon);
/*   gzilla_dicache_idle_func(diccon); */
}


/* This handles aborts coming upstream from imgsinks.

   Generally, this routing gets invoked before the dispatch on the
   content type. After that, the image decoder is responsible for
   plumbing the status connection between the web bytesink and the
   imgsink. */

/* Create a new bytesink that decodes an image and feeds the decoded
   image into the given imgsink. */

static GzillaWeb* gzilla_web_new_img_decoder (GzillaImgSink *imgsink, const char* URL)
{
  /* todo: implement this. */
  GzillaWeb *web=gzilla_web_new(URL);
  web->imgsink = imgsink;
  
  return web;
}


/* The url missed in the cache.

   1. Create a new imgsink that will be used to feed the decompressed
      image data into the cache.
   2. Create a new image decoder bytesink.
   3. Request that the URL be opened and start feeding the new imgsink.
   4. Make a new cache line.
   5. Do a gzilla_dicache_hit to connect the cache line to the argument
      imgsink.
*/

GzillaImgSink* gzilla_dicache_insert(GzillaImgSink *imgsink, const char *url,
	BrowserWindow* bw)
{
  GzillaImgSink *new_imgsink;
  GzillaImgSinkDIC *new_imgsinkdic;
  GzillaDICacheLine *line;

  /* Step 1 */
  line = malloc(sizeof(GzillaDICacheLine)+strlen(url)+1);
  new_imgsinkdic = g_new (GzillaImgSinkDIC, 1);
  new_imgsink = (GzillaImgSink*) new_imgsinkdic;
  gzilla_imgsink_init (new_imgsink);
  new_imgsink->write = gzilla_dicache_imgsink_write;
  new_imgsink->close = gzilla_dicache_imgsink_close;
  new_imgsink->set_parms = gzilla_dicache_imgsink_set_parms;
  new_imgsink->set_cmap  = gzilla_dicache_imgsink_set_cmap;
  new_imgsink->Parent    = imgsink->Parent;
  new_imgsinkdic->line = line;
  new_imgsinkdic->bw = bw;
  new_imgsinkdic->FD = -1;

  /* Step 4 */
  line->url = strcpy((char*)line+sizeof(*line),url);
  line->bitvec = NULL;
  line->last_use = dicache_counter++;
  line->eof = FALSE;
  line->in_height=imgsink->height;
  line->in_width =imgsink->width;
  line->height=imgsink->height;
  line->width =imgsink->width;
  line->imgsink=NULL;
  line->Image_Buffer = NULL;
  line->Total_Size=0;
  line->NRef=0;
  line->NGzws=0;
  line->gzw=NULL;
  line->Used=0;

  if (dicache_size == dicache_size_max)
    {
      dicache_size_max <<= 1;
      dicache = g_realloc(dicache, dicache_size_max *
			  sizeof(GzillaDICacheLine *));
    }
  dicache[dicache_size++] = line;

  /* Step 5 */
  gzilla_dicache_hit (imgsink, line);
  return new_imgsink;
} 

static void 
gzilla_dicache_miss (GzillaImgSink *imgsink, const char *url,
		     BrowserWindow *bw)
{
   GzillaImgSink* new_imgsink=gzilla_dicache_insert(imgsink,url,bw);
  /* Step 2 */
  GzillaWeb* Web = gzilla_web_new_img_decoder (new_imgsink, url);

  /* Step 3 */
  /* This is done later so that any status signals generated by the
     open_url_raw get propagated. */
  if ((((GzillaImgSinkDIC*)new_imgsink)->FD = gzilla_cache_URL_open (url,Web)) < 0)
    gzilla_web_free(Web);
}

void
gzilla_dicache_open (GzillaImgSink *imgsink, const char *url,
		     BrowserWindow *bw)
{
   int i;
#undef DISABLE_DICACHE
#ifdef DISABLE_DICACHE
  {
    GzillaWeb *Web = gzilla_web_new_img_decoder (imgsink,url);
    Gzw* gzw = gzw_image_new (GZW_IMAGE_RGB, &imgsink->gzw,NULL);
    imgsink->gzw=gzw;
    gzw_image_size (imgsink->gzw, imgsink->width, imgsink->height);
   /*BUG: memleak? */
    imgsink->gzw->buffer=malloc(3*imgsink->width*imgsink->height+1);
    if (gzilla_cache_URL_open (url, Web) <0) gzilla_web_free(Web);
    return; 
  }
#else
  for (i = 0; i < dicache_size; i++)
    {
      if (!strcmp (url, dicache[i]->url)) {
	gzilla_dicache_hit (imgsink, dicache[i]);
	return;
      }
    }
  gzilla_dicache_miss (imgsink, url, bw);
#endif
}
