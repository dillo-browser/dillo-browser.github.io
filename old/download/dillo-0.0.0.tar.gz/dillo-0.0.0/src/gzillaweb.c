/*

 gzilla

 Copyright 1997 Raph Levien <raph@acm.org>

 This code is free for commercial and non-commercial use,
 modification, and redistribution, as long as the source code release,
 startup screen, or product packaging includes this copyright notice.

 */

#include <ctype.h> /* for tolower */
#include <stdio.h>
#include <malloc.h>
#include <stdlib.h>
#include <gtk/gtk.h>

#include "gzillaweb.h"
#include "IO/GzIO.h"
#include "gzillahtml.h"
#include "interface.h"

#include "gzw.h"
#include "gzwembedgtk.h"
#include "MIME/MIME.h"
#include "gzilla.h"
#include "gzillanav.h"

/* Extract a single field from the header, storing the value in field.
 Return TRUE if field found. */

static int
gzilla_web_parse_field (const char *header, char *field, size_t size_field,
			const char *fieldname) {
  int i, j;

  for (i = 0; header[i] != '\0'; i++) {
    for (j = 0; fieldname[j] != '\0'; j++) {
      if (tolower (fieldname[j]) != tolower (header[i + j]))
	break;
    }
    if (fieldname[j] == '\0' && header[i + j] == ':') {
      i += j + 1;
      while (header[i] == ' ') i++;
      for (j = 0; j + 1 < size_field && header[i] != '\n'; j++)
	field[j] = header[i++];
      field[j] = '\0';
      return 1;
    } 

      /* skip to next field */
      while (header[i] != '\0' && header[i] != '\n') i++;
      if (header[i] == '\0') i--;
  }
  return 0;
}

Gzw* gzilla_web_dispatch_by_Type(GzillaWeb* web, const char* Type,
				 __IOCallback_t* Call, void** Data)
{
   Gzw* gzw;
   if (!web) return NULL;
   gzw=MIME_view(Type, web, Call, Data);
   
   if (web->url  && web->child_linkblock)
     {
	if (web->child_linkblock->base_url)
		free(web->child_linkblock->base_url);
	web->child_linkblock->base_url=g_strdup(web->url);
   }
   if (!web->imgsink){
#ifdef USE_GZW
     /* todo: move creation of gzilla_image from dispatcher
	to here. */
     if (gzw) gzilla_bw_have_gzw(web->bw, gzw);
#else
     if (child_widget == NULL)
       child_widget = FD2Ptr(web->Child_FD)->widget;
     web->child_widget = child_widget;
     gtk_box_pack_start (GTK_BOX (web->bytesink.widget),
			 child_widget, TRUE, TRUE, 0);
     gtk_widget_show (child_widget);
#endif
   }
   
   if (web->Child_FD >= 0)
     {
       FD_bkgnd(web->Child_FD);
       
       /* Link the data to a new memory segment in the cache */
       gzilla_cache_insert(web->Child_FD, web->Cache_FD, web->url,Type);
     }
   return gzw;
}

void gzilla_web_redirect(GzillaWeb* Web, char* url)
{
   gzilla_nav_redirect(url, Web?Web->bw:NULL);
}
/* Parse the header for content-type, and create a new child based on
   that info. This is the main MIME dispatcher. */

static void gzilla_web_dispatch (GzillaWeb *web, __CacheFile_t* CPtr) {
  char content_buf[256];

  _FD2Ptr(CPtr->FD).Call = NULL;
  if (web->header[9] == '3' && web->header[10] == '0') {
    /* redirect */
    char url[1024];
    if (gzilla_web_parse_field (web->header, url, sizeof(url),
				"Location")) {
      /* First, add the redirect into our cache */
      GzCache_redirect(web->url, url);

      /* Now redirect the browser. */
      gzilla_nav_redirect (url,web->bw);
    }
    gzilla_web_free(web);
    _FD2Ptr(CPtr->FD).Data=NULL;
    _FD2Ptr(CPtr->FD).Call=NULL;
    close(CPtr->FD);
    return;
  }

  /* Overwrite the header portion of the cache */
  memmove((char*)CPtr->Data, ((char*)CPtr->Data)+web->Start_Ofs,
	    CPtr->Size-web->Start_Ofs);

  /* Update the cache's data segment size */
  CPtr->Size -= web->Start_Ofs;

  /* Stick it in the cache look up table*/
  CPtr->URL=strdup(web->url);
  GzCache_add(CPtr);

  web->child_linkblock = NULL;
  if (gzilla_web_parse_field (web->header, content_buf, sizeof(content_buf),
	"Content-Length"))
    {
       /* If there is a full size buffer, we will just allocate the stuff once
	*/
       long Size = atol(content_buf);
       void* Data;
       if (Size > 0 && (Data=g_realloc((void*)CPtr->Data,Size)))
         {
	     CPtr->Data = Data;

	     /* Fill out the paper work so that we get all of the data just right! */
	     CPtr->Total_Size = Size;
	     CPtr->Block_Size = Size;
         }
    }

  _FD2Ptr(CPtr->FD).Data=NULL;
  _FD2Ptr(CPtr->FD).Call=NULL;
  if (gzilla_web_parse_field (web->header, content_buf, sizeof(content_buf),
			      "Content-Type")) {
    gzilla_web_dispatch_by_Type(web, content_buf,&_FD2Ptr(CPtr->FD).Call,
				&_FD2Ptr(CPtr->FD).Data);
    /* Since we have data, do the first "update" notice. */
    if (_FD2Ptr(CPtr->FD).Call && _FD2Ptr(CPtr->FD).Call != gzilla_web_callback)
	_FD2Ptr(CPtr->FD).Call(0,_FD2Ptr(CPtr->FD).Data,CPtr);
    if (web->Child_FD < 0)
      {
         /* The cache thing is no longer autofree: we have the header! */
	 CPtr->Flags &= ~GZ_AUTOFREE;
	 CPtr->Type = strdup(content_buf);
      }
  }
   gzilla_web_free(web);
}

void gzilla_web_free(GzillaWeb* web)
{
   if (!web) return;
   if (web->url != NULL)
     {free (web->url); web->url=NULL;}
   /* We _could_ free the header right after dispatch. */
   if (web->header) {free (web->header);}
   free(web);
}

/* gzilla_web_write implements a state machine that (a) canonicalizes
   the line ends in the header to \n and (b) terminates when two line
   ends in a row have been detected.

   Here's the machine:
            \n      \r->\n
         1 -----> 2 -----> 3
         ^                 |
   \r->\n|                 | \n
         |                 v
           \n->\n   \n->\n _
         0 -----> 4 ----> (5)
                           -

   With the addition of c->c edges from nodes 0-4 to node 0. Also,
   node 6 is an error state that just consumes input.

   It would look a lot better if it weren't in ASCII art!

 */

void gzilla_web_callback (int Op, void *P, __CacheFile_t* CPtr)
{
  int i;
  GzillaWeb* web=(GzillaWeb*)P;
  int N=web->state;
  char* C=CPtr?((char*)CPtr->Data)+web->Start_Ofs:NULL;
  int num=CPtr?CPtr->Size-web->Start_Ofs:0;

  if (Op)
    {
      gzilla_web_free(web);
      return;
    }
  
    for (i = 0; i < num && N< 2; i++,C++) {
      if (web->size_header + 2 > web->size_header_max) {
	web->size_header_max <<= 1;
	web->header = realloc (web->header, web->size_header_max);
      }
      /* invariant: there is room for at least two more characters */
      if (*C) web->Start_Ofs++;
      if (*C=='\r' || !*C) continue;
      if (*C=='\n') N++; else N=0;
      web->header[web->size_header++] = *C;
      if (N>=2) break;
    }
    web->state = N;
    if (N>= 2) {
      /* Got header! Parse content-type and create a new child. */
      web->header[web->size_header] = '\0';
      gzilla_web_dispatch (web,CPtr);
    }
}

/* New behavior: when enough bytes have been written, create a Gzw
   to hold the real contents, and throw it to a handler of the
   "have_gzw" signal.
   */

GzillaWeb* gzilla_web_new (const char* url)
{
  GzillaWeb *web=malloc(sizeof(GzillaWeb));

  web->imgsink=NULL;
  web->gzw = NULL;

  web->bw=NULL;
  web->child_linkblock=NULL;
  web->Child_FD=-1;
  web->Cache_FD=-1;

  web->Start_Ofs=0;
  web->size_header_max = 1024;
  web->size_header = 0;
  web->header = malloc(web->size_header_max);

  web->state = 0;

  web->url = strdup (url);
  web->width = 0;
  web->height = 0;
  web->bg_color = 0xd6d6d6; /* hack! */

   return web;
}
