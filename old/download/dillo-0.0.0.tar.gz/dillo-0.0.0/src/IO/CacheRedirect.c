/*
   Cache a redirect message
   Randall Maas
   1999
*/

#include "GzIO.h"
void GzCache_redirect(const char* Orig_URL, const char* To_URL)
{
  /*
     Description
      This inserts the URL redirection into our cache
  */
   __CacheFile_t* CPtr= GzCache_new(Orig_URL);
   if (!CPtr) return;
   CPtr->Type=NULL;
   CPtr->Data=strdup(To_URL);
   CPtr->Flags|=GZ_REDIRECT;
}
