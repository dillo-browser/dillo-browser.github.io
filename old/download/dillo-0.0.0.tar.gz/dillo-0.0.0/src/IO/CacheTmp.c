/*
   Submit a temporary IO
   Randall Maas
   1999
*/

#include <malloc.h>
#include <sys/stat.h>
#include "GzIO.h"
#include "LDL.h"
#include "../URL/URL_protos.h"

__CacheFile_t CacheFree={&CacheFree, &CacheFree},
	CacheActive={&CacheActive,&CacheActive};

__CacheFile_t* gzilla_cache_tmp (int FD)
{
   __CacheFile_t* CPtr=GzCache_new(NULL);
   struct stat MyStat;

   /* Autotune: find out the prefferred transfer size */
   if (!fstat(FD, &MyStat)) CPtr->Block_Size=MyStat.st_blksize;

   /* Bug: check error conditions */
   CPtr->Data = malloc(CPtr->Block_Size);
   CPtr->Flags |= GZ_AUTOFREE;
   CPtr->Type =NULL;
   CPtr->FD = FD;
   LDL_append(CPtr, &CacheActive);
   FD2Cache(FD)=CPtr;

   GzIO_submit(FD,0,(void*)CPtr->Data,CPtr->Block_Size);
   return CPtr;
}
