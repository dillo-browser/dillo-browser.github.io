#ifndef __GzIO_h
#define __GzIO_h

#include <unistd.h>
#include <sys/time.h>
#include "IOQ.h"
#include "../gzillacache.h"

#define NUM_FDS (8*sizeof(fd_set))
extern fd_set Gz_FDs;

# define GZ_INPUTREAD  (1)
# define GZ_INPUTWRITE (2)
# define GZ_INPUTADDED (GZ_INPUTREAD|GZ_INPUTWRITE)
typedef struct
{
   __IO_req_t IO;
   struct iovec IOVec;
   int Cache_FD;
} __Gzilla_IO_t;

/* You may want to change this to separate tables in the future if lots of
   descriptors get used.... You will only need to change the macros...*/
typedef struct
{
   __IOCallback_t Call;
   void* Data;
   __CacheFile_t*  Cache;
   unsigned Flags;
   int Param[2]; /* Generic parameters... */
   __Gzilla_IO_t IO[2];
} __Gzilla_FD_t;

extern __Gzilla_FD_t _FD2Data[NUM_FDS];
#define _FD2Ptr(x)     _FD2Data[x]
#define FD2Ptr(x)      (GzillaByteSink*)_FD2Data[x].BS
#define FD2Priority(x) _FD2Data[x].Priority
#define FD2Cache(x)    _FD2Data[x].Cache

void GzIO_init(void);
void GzIO_submit(int FD, int Op, void* Data, size_t Size);
void GzIO_abort(int FD);
void GzIO_AddCache(int FD, int Cache_FD);
__CacheFile_t* GzCache_new(const char* URL);
void GzCache_redirect(const char* Orig_URL, const char* To_Url);
extern struct qelem Gz_SubmitQ;
#endif
