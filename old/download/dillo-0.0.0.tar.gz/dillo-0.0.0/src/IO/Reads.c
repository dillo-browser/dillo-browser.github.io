/*
   Randall Maas
   1999,

   This is from libvfs project.
   This modules allows IO to continue in the "background" on non-POSIX machines
   that support readv/writev.
*/

#include <sys/time.h>
#include <errno.h>
#include <stdio.h>
#include "IOQ.h"
#include "LDL.h"

/* See if GNU goodness is defined, if not, we won't bother.  Our routine
 below will do the same thing, just not as quickly */
#ifndef TEMP_FAILURE_RETRY
# define TEMP_FAILURE_RETRY(x) x
#endif

void FD_bkgnd(int FD)
{
   /* Set it up to be nonblocking and generate interrupts */
   fcntl (FD, F_SETFL, O_NONBLOCK | fcntl(FD, F_GETFL));
}

/*
   @node Submitting IO, IO
   @subheading Submitting background IO
   When you have a some IO to do, and would like it to occur in the background,
   you will need to fill out a IO request structure (@code{__IO_req_t}):

   @example
    __IO_req_t Req;
    struct iovec IOs[2];
    char BufA[256],BufB[512];

    Req.Op = 0;  // A read operation.  1 would be a write operation
    Req.FD = fd; // The file descriptor to read from 
    Req.Count=2; // We will read into two buffers: A and B 
    Req.IOReq=IOs;
    IOs[0].iov_base=(__ptr_t)BufA; // Read 256 bytes into buffer A
    IOs[0].iov_len = sizeof(BufA);
    IOs[1].iov_base=(__ptr_t)BufB; // Then read 512 bytes into buffer B 
    IOs[1].iov_len = sizeof(BufB);

   @end example

   @emph{Note 1:} The IO request structure is retained in the queue until it is
   completed.

   @subheading Handling completed IO
    Any IO request that is placed into the completion queue or the failed queue
    is done.  It is up to your program to manage those resources as
    appropriate.

    The @var{Status} field of each element is used to indicate:
    @table @asis
    @item > 0
     The number of bytes read

    @item == 0
     No data was read, the file descriptor has no more data (EOF).  It should
     be closed.

    @item < 0
     Significant error.  The value of @var{Status} the negative of the
     @var{errno}.
    @end table

   @node SIGIO, IO
   @subheading Setting up to recieve notification.

   If you would like to pause your program while waiting for any IO, use the
   @code{pause} system call.  Your program will continue after a signal has
   been received.
*/

/*
      The @var{Status} field of each element is used to indicate:
      @table @asis
      @item > 0
       The number of bytes read

      @item == 0
       No data was read, the file descriptor has no more data (EOF).  It should
       be closed.

      @item < 0
       Significant error.  The value of @var{Status} the negative of the
       @var{errno}.
      @end table

     @subheading Non-blocking IO

      Files that are opened should be use the @code{O_NONBLOCK} or
      @code{O_NDELAY} flags to allow execution to continue even if there is no
      data avaible (or can be sent).

      For file descriptors and IO streams that are already open, these can be
      set via a call like @code{fcntl(fd, F_SETFL, O_NONBLOCK);}

  */

ssize_t IO_Do(int FD, __IO_req_t* IPtr)
{
   ssize_t Status;
      if (!IPtr->Op) /* Read */
        {
           /* We use a macro to handle interrupted stuff, and retry the IO */
           Status =TEMP_FAILURE_RETRY(readv(FD,IPtr->IOReq,IPtr->Count));
        }
       else
        {
           /* Operation is Write */
           /* We use a macro to handle interrupted stuff, and retry the IO */
           Status=TEMP_FAILURE_RETRY(writev(FD,IPtr->IOReq,IPtr->Count));
        }

       if (Status >= 0) return Status;
       /* Handle errors! */
       switch (errno)
         {
            case EINTR:         /* Interrupt came in, and not handle above...?! */
# if defined(EWOULDBLOCK) && EWOULDBLOCK != EAGAIN
            case EWOULDBLOCK:
# endif
# ifdef EAGAIN
            case EAGAIN:
# endif
              return 0;

            case EIO:   /* Hardware error */
            case EBADF: /* Bogus file descriptor */
            case EFBIG: /* Write takes up way too much space on disk */
            case ENOSPC:/* Disk is full */
            case EPIPE: /* Pipe is not open on other end! */
            case EFAULT: /* Something points to bogus memory */
            case EINVAL: /*An invalid argument */
            case EISDIR: /* FD refers to a directory */
            case EOPNOTSUPP: /* FD doesn't support operation */

            default:    /* Not supposed to happen! */
                return -errno;
        }
}
