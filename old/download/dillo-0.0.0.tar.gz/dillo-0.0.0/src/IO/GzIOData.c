#include "GzIO.h"

__Gzilla_FD_t _FD2Data[NUM_FDS]={{NULL}};
fd_set Gz_FDs;
