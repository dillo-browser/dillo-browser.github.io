/*
   Gzilla's IO Queue Processor
   Randall Maas
   1999
*/

#include <malloc.h>
#include <stdio.h>
#include <sys/wait.h>
#include <signal.h>
#include <search.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <fcntl.h>
#include "LDL.h"
#include "IOQ.h"
#include "GzIO.h"
#include "../gzillacache.h"
#include "../gzilla.h"

static void IO_complete(int FD, __Gzilla_IO_t* IPtr);
static int IO_Clean    (int FD, __Gzilla_IO_t* IPtr);
static void GZBS_Input(gpointer Data, gint FD, GdkInputCondition Why)
{
   __Gzilla_IO_t* IPtr=(__Gzilla_IO_t*)Data;

   if (Why == GDK_INPUT_WRITE)
     {
        IPtr->IO.Status= IO_Do(FD,&IPtr->IO);
	if (IPtr->IO.Status >=1 && IPtr->IOVec.iov_len> IPtr->IO.Status)
	  {
	      IPtr->IOVec.iov_len -= IPtr->IO.Status;
	      IPtr->IOVec.iov_base+= IPtr->IO.Status;
	  }
	 else if (IPtr->IO.Status < 0 ||
		 IPtr->IOVec.iov_len >= IPtr->IO.Status)
          {
             /* Writes are single shot... */
             gdk_input_remove(_FD2Ptr(FD).Param[1]);
	     _FD2Ptr(FD).Flags &= ~ GZ_INPUTWRITE;
          }
	return;
     }
   if (_FD2Ptr(FD).Flags & GZ_INPUTWRITE) return;
   IPtr->IO.Status= IO_Do(FD, &IPtr->IO);
   IO_Clean(FD, IPtr);
}

void GzIO_abort(int FD)
{
   if (FD <0) return;
   if ((_FD2Ptr(FD).Flags & GZ_INPUTWRITE))
     gdk_input_remove(_FD2Ptr(FD).Param[1]);
   if ((_FD2Ptr(FD).Flags & GZ_INPUTREAD))
     gdk_input_remove(_FD2Ptr(FD).Param[0]);
   _FD2Ptr(FD).Flags &= ~ GZ_INPUTADDED;
   close(FD);
}

void GzIO_init(void)
{
   FD_ZERO(&Gz_FDs);
}

void GzIO_submit(int FD, int Op, void* Data, size_t Size)
{
   __Gzilla_IO_t* IPtr= &_FD2Ptr(FD).IO[Op];
   int Mask = Op?GZ_INPUTWRITE:GZ_INPUTREAD;
   IPtr->IO.Count=1;
   IPtr->IO.IOReq= &IPtr->IOVec;
   IPtr->IO.Op=Op; /*stupid */
   IPtr->Cache_FD=-1; /* There is no file to write the data to */
   IPtr->IOVec.iov_base = Data;
   IPtr->IOVec.iov_len  = Size;
   FD_SET(FD,&Gz_FDs);
   
   if (!(_FD2Ptr(FD).Flags & Mask))
     {
	_FD2Ptr(FD).Param[IPtr->IO.Op] = gdk_input_add(FD,
		IPtr->IO.Op?GDK_INPUT_WRITE:GDK_INPUT_READ, GZBS_Input,IPtr);
        _FD2Ptr(FD).Flags |= Mask;
     }
}

static int IO_NextRead(int FD, __Gzilla_IO_t* IPtr, __CacheFile_t* DPtr)
{
   /*
      Description
       This creates the next read on the IO channel into our cache memory
       buffers.

      Return Value
       0 == Ok, otherwise badness
   */
   size_t Transfer_Size; /*Bug: use fd block size */

   Transfer_Size = DPtr->Block_Size;
   if (!DPtr->Total_Size)
     {
        void *NewData;
        /* Allocate more memory chunks */
        if (!(NewData = g_realloc((void*)DPtr->Data, DPtr->Size+Transfer_Size)))
	  {
	     /* Bad things have happened... we didn't get any more space */
	     return -1;
	  }

	/* Update our pointer to the memory... */
	DPtr->Data = NewData;
     }
   else
     {
        /* Check to see if we are done...*/
        if (DPtr->Size >= DPtr->Total_Size) return -1;

	/* Figure out how to top the cache memory buffer off */
        if (DPtr->Block_Size+DPtr->Size > DPtr->Total_Size)
	 Transfer_Size = DPtr->Total_Size-DPtr->Size;
     }

   /* Indicate where our next read is going to in memory... */
   IPtr->IOVec.iov_base=((char*)DPtr->Data) + DPtr->Size;
   IPtr->IOVec.iov_len = Transfer_Size;

   return 0;
}

static void IO_complete(int FD, __Gzilla_IO_t* IPtr)
{
   /*
      Description
       This routine handles a successfully completed read.
   */
   __CacheFile_t* DPtr = FD2Cache(FD);
   void* Data = _FD2Ptr(FD).Data;
   int FreeMe=0;

   /* First update our cache memory stuff */
   /* Update the size of valid memory that we have */
   DPtr->Size+= IPtr->IO.Status;

   /* Next update our client */
   if (_FD2Ptr(FD).Call) _FD2Ptr(FD).Call(0, Data,DPtr);

   /* Third, create a new read */
   if (!IPtr->IO.Op)
     if (IO_NextRead(FD, IPtr, DPtr))
       {
	  /* Okay, something bad has happened, or we should otherwise close
	     this puppy */
	  shutdown(FD,2);
	  if (_FD2Ptr(FD).Call) _FD2Ptr(FD).Call(1,_FD2Ptr(FD).Data,DPtr);
	  GzIO_abort(FD);
	  _FD2Ptr(FD).Param[0]=0;
	  _FD2Ptr(FD).Param[1]=0;
	  _FD2Ptr(FD).Flags=0;
	  _FD2Ptr(FD).Call=NULL;
	  FreeMe=1;
       }
   
   /* Is this also supposed to go to the cache? */
   if (IPtr->Cache_FD < 0)
     {
       /* Queue up some more stuff read .... */
       if (FreeMe && (DPtr->Flags & GZ_AUTOFREE))
	 {
	    LDL_append(DPtr,&CacheFree);
	    free((void*)DPtr->Data);
	    DPtr->Data=NULL;
	 }
       return;
     }

   /* It /is/ also supposed to go to the cache... */
   /* Now queue this IO up for more fun... */
   GzIO_submit(IPtr->Cache_FD, 1, IPtr->IOVec.iov_base, IPtr->IOVec.iov_len);
}

static int IO_Clean(int FD, __Gzilla_IO_t* IPtr)
{
   __IOCallback_t Call = _FD2Ptr(FD).Call;
   void* Data     = _FD2Ptr(FD).Data;

   /* See if the thing is a dead one, and needs to be closed */
   if (IPtr->IO.Status <1)
     {
        /* Pass the notification on if this isn't an IO for writing to
	   the cache and there isn't another FD to chain to... */
        __CacheFile_t* FPtr = FD2Cache(FD);
	if (!IPtr->IO.Op)
	  {
	     if (Call) Call(1, Data,FPtr);
	     _FD2Ptr(FD).Call=NULL;
	     /* Close the cache channel too */
	     if (IPtr->Cache_FD)
	       {
		 GzIO_abort(IPtr->Cache_FD);
		 FD_CLR(FD, &Gz_FDs);
	       }
	     if (FPtr->Flags & GZ_AUTOFREE)
	       {
		 LDL_append(FPtr, &CacheFree);
		 free((void*)FPtr->Data);
	       }
	  }
	FD_CLR(FD, &Gz_FDs);
	shutdown(FD,2);
	GzIO_abort(FD);
	_FD2Ptr(FD).Data = NULL;
	_FD2Ptr(FD).Call = NULL;
	return 0;
     }
   
   /* Complete the IO. 
      Check to see if it is a completion of a write to cache
      (we do it here -- instead of in IO_complete) to speed processing..
   */
   if (IPtr->IO.Op) return 0;
   if (IPtr->IO.Status==0) return 0;
   
   IO_complete(FD, IPtr);
   return 1;
}

