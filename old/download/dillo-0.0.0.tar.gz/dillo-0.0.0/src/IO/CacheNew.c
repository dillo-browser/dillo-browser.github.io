/*
   Creates a new entry in the URL cache
   Randall Maas
   1999
*/

#include <malloc.h>
#include "GzIO.h"
#include "LDL.h"

__CacheFile_t* GzCache_new(const char* URL)
{
   __CacheFile_t* CPtr;
   if (!LDL_empty(&CacheFree))
     {
       CPtr=CacheFree.q_forw;
       remque(CPtr);
     }
    else
     {
       CPtr=malloc(sizeof(*CPtr));
       if (!CPtr) return NULL;
     }

   /* Insert it into the cache if it is defined */
   CPtr->URL=URL?strdup(URL):NULL;
   CPtr->Data=0;
   LDL_append(CPtr, &CacheActive);
   CPtr->Size=0;
   CPtr->Total_Size=0;
   CPtr->Block_Size=512;
   CPtr->last_use=0;
   CPtr->Flags=0;
   CPtr->FD=-1;
   if (URL) GzCache_add(CPtr);
   return CPtr;
}

