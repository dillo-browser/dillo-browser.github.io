/*
   Attachs an already open file to a write-behind file descriptor
   Randall Maas
   1999
*/

#include "GzIO.h"
#include "LDL.h"

void GzIO_AddCache(int FD, int Cache_FD)
{
   /*
      Description
       All of the pending IOs for the @var{FD} IO channel will be marked to
       write-behind to the @var{Cache_FD} IO channel.
   */

   _FD2Ptr(FD).IO[0].Cache_FD=Cache_FD;
}
