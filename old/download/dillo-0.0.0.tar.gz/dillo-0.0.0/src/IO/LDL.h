/*
   Doubly Linked lists
   1998, Randall Maas

   This uses the standard C qelem struct and insque/remque to perform its
   operations.  It adds a function called appque which will append the element
   to the very end of the list.
*/

#ifndef __LDL_h
# define __LDL_h
#include <stdlib.h>

/* --- Queue functions ----------------------------------------------------- */
# define que_foreach(IPtr,QPtr) \
        for(IPtr=QPtr;IPtr;IPtr=IPtr->q_forw)

/*
   Description
    Iterates IPtr from QPtr to the last item in the list
*/

# define que_free(Type,Ptr) do{\
    Type* Type##_Tmp = NULL;\
    que_foreach(IPtr,Ptr)   \
     {                      \
        if (Type##_Tmp) Type##_free(Type##_Tmp);\
        Type##_Tmp = IPtr; \
     } \
    if (Type##_Tmp) Type##_free(Type##_Tmp);\
   }while(0)

/*
   Description
    Each node on the list is free'd.  They are not unlinked from the rest of
    the list first...
 */

/* --- Doubly linked lists with a pointer to the tail ----------------------- */

/* Initializes a doubly linked list element */
# define LDL_init(X) do{(X)->q_back = (X); (X)->q_forw= (X);}while(0)
/*
   Description
    Initializes the head of the list
    This initializes the queue element referred to by QPtr.  This is done
    in such a way to allow insque, remque, and appque to work,
 */


# define LDL_empty(LDL) ((LDL)->q_forw == (LDL))
/*
   Description
    True if the doubly linked list is empty
*/

# define LDL_foreach(IPtr,LDL) \
        for(IPtr=(LDL)->q_forw; IPtr && IPtr != (LDL); IPtr = IPtr->q_forw)

/*
   Description
    This allows one to iterate over the doubly linked list, from first to 
    last.  The head of the list -- LDL -- is not covered as a member of the
    list.
*/


# define LDL_foreach_reverse(IPtr,LDL) \
        for(IPtr=(LDL)->q_back; IPtr && IPtr != (LDL); IPtr = IPtr->q_back)

/*
   Description
    This allows one to iterate over the doubly linked list, from last to 
    first.  The head of the list -- LDL -- is not covered as a member of the
    list.
*/


# ifndef def_LDL_cat
extern inline
# endif
void _LDL_cat(struct qelem* LMain, struct qelem* LSub, struct qelem* LTail)
{
   /* This appends the sub list onto the end of the main list */
   /* Have the main list continue onto the new list */
   LMain->q_back->q_forw = LSub;
   
   /* Have the new list refer back to the old list */
   LSub->q_back = LMain->q_back;
   
   /* Have the tail pointer for the main list updated */
   LMain->q_back = LTail;
   
   /* Have the tail pointer continue back to the head */
   LTail->q_forw = LMain;
}

# define LDL_cat(A,B) do{\
        if (!LDL_empty(B)) _LDL_cat(A,(B)->q_forw,(B)->q_back);}while(0)

# define LDL_append(Elem,LDL) insque(Elem, (LDL)->q_back)
   /*
      Description
       This appends the Element to the end of the list.  The q_back element
       of Head is used to point to the tail of the list.
    */


# ifndef def_LDL_length
extern inline
# endif
size_t LDL_length(struct qelem* L)
{
   size_t I=0;
   struct qelem* IPtr;
   LDL_foreach(IPtr, L) I++;
   return I;
}
#endif
