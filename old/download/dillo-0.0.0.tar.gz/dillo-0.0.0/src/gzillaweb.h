#ifndef __GTK_WEB_H__
#define __GTK_WEB_H__

#include <gtk/gtk.h>
#include "URL/URL_protos.h"
#include "gzillaimgsink.h"
#include "interface.h"
typedef struct _GzillaWeb GzillaWeb;
typedef struct _GzillaLinkBlock GzillaLinkBlock;

#include "gzw.h"
#include "gtkgzwscroller.h"
#include "gzillabrowser.h"
#include "IO/IOQ.h"

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

struct _GzillaLinkBlock {
  struct _BrowserWindow* bw;
  char *base_url;
};

struct _GzillaWeb {
  GzillaImgSink *imgsink;
  Gzw *gzw;

  char *header;        /* the (partial) HTTP response. */
  int Start_Ofs;
  int size_header;
  int size_header_max;

  int state;

  int Child_FD;
  int Cache_FD;

  char *url;

  int width, height;
  int bg_color;

  BrowserWindow* bw;
  GzillaLinkBlock *child_linkblock;
};

#define gzilla_web_FD(Web,fd) do{if (Web) ((GzillaWeb*)Web)->Child_FD = fd;\
   FD_bkgnd(fd);}while(0)
#define gzilla_web_status(Web,text) gzilla_status(text,Web?((GzillaWeb*)Web)->bw:NULL)
GzillaWeb* gzilla_web_new (const char* URL);
void       gzilla_web_free(GzillaWeb*);
extern void gzilla_web_redirect(GzillaWeb* Web, char* url);
Gzw*	gzilla_web_dispatch_by_Type(GzillaWeb* web, const char* Type,
	 __IOCallback_t* Call, void** Data);
extern void gzilla_web_callback (int Op, void*web, __CacheFile_t*);

#ifdef __cplusplus
}
#endif /* __cplusplus */


#endif /* __GTK_WEB_H__ */
