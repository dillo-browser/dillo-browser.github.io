#ifndef __GZILLA_IMG_SINK_H__
#define __GZILLA_IMG_SINK_H__

/* The GzillaImgSink data structure and methods. */

#include <gdk/gdk.h>
#include <gtk/gtk.h>
#include "gzw.h"
#include "gzwimage.h"
#include "gzwpage.h"

typedef struct _GzillaImgSink GzillaImgSink;

typedef enum {
  GZILLA_IMG_TYPE_INDEXED,
  GZILLA_IMG_TYPE_RGB,
  GZILLA_IMG_TYPE_GRAY
} GzillaImgType;

struct _GzillaImgSink {
  GzillaImgSink** Parent;
  GzwImage* gzw;
  /* parameters of the preview widget */
  gint width;
  gint height;
  /* parameters of the input imgsink */
  gint in_width;
  gint in_height;

  guchar *cmap;
  GzillaImgType in_type;

  /* alt goes here if we implement it */
  gint32 bg_color;

  int RefCount;
  void (* write) (GzillaImgSink *imgsink,
		  const unsigned char *buf,
		  int x,
		  int y);
  void (* close) (GzillaImgSink *imgsink);
  void (* set_parms) (GzillaImgSink *imgsink,
		      int width,
		      int height,
		      GzillaImgType type);
  void (* set_cmap) (GzillaImgSink *imgsink,
		     const unsigned char *cmap,
		     int num_colors,
		     int bg_index);

  void (*close_handler) (void *data, GzillaImgSink *imgsink);
  void *close_data;
};

void gzilla_imgsink_init      (GzillaImgSink *imgsink);
#ifndef def_imgsink_write
extern __inline__
#endif
void
gzilla_imgsink_write (GzillaImgSink *imgsink,
		      const unsigned char *buf,
		      gint x,
		      gint y)
{
#ifdef DISABLE_ALL_IMGSINK
  return;
#endif
  if (imgsink)
  imgsink->write (imgsink, buf, x, y);
else abort();
}

void gzilla_imgsink_close     (GzillaImgSink *imgsink);
void gzilla_imgsink_set_parms (GzillaImgSink *imgsink,
			       int width,
			       int height,
			       GzillaImgType type);
void gzilla_imgsink_set_cmap  (GzillaImgSink *imgsink,
			       const unsigned char *cmap,
			       int num_colors,
			       int bg_index);

/* low-tech signal handlers for close and abort signals */
void gzilla_imgsink_set_close_handler (GzillaImgSink *imgsink,
				       void (*close_handler) (void *data, GzillaImgSink *imgsink),
				       void *data);

GzillaImgSink *gzilla_image_new (gint width,
				 gint height,
				 const char *alt,
				 gint32 bg_color);
void
gzilla_image_set_parms (GzillaImgSink *imgsink,
			gint width,
			gint height,
			GzillaImgType type);
void
_gzilla_image_write (GzillaImgSink *imgsink,
		    const unsigned char* linebuf,
		    gint x0, gint y,
		    GzwImage** gzws, int NGzws);
void
gzilla_image_close (GzillaImgSink *imgsink);
void
gzilla_image_set_cmap (GzillaImgSink* imgsink,		       
		       const unsigned char *cmap,
		       gint num_colors,
		       gint bg_index);

/* Note: the imgsink methods are always called in the following order:
   set_parms
   set_cmap, iff type in set_parms call was GZILLA_IMG_TYPE_INDEXED
   write, any number of times
   close | abort

   The close and abort methods are responsible for freeing all
   internal state and the imgsink itself. */

#endif /* __GZILLA_IMG_SINK__ */
