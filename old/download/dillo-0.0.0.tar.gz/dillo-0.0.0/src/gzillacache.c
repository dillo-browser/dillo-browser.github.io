/*

 gzilla

 Copyright 1997 Raph Levien <raph@acm.org>

 This code is free for commercial and non-commercial use,
 modification, and redistribution, as long as the source code release,
 startup screen, or product packaging includes this copyright notice.

 */

#include <ctype.h>		/* for tolower */
#include <sys/types.h>
#include <sys/stat.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <malloc.h>
#include <netinet/in.h>		/* needed before including gzillasocket.h */

#include <search.h>
#include "IO/LDL.h"
#include "IO/GzIO.h"
#include "config.h"
#include "URL/gzillaurl.h"

/* has definitions for gzillaCacheCon and gzillaCacheLine structures.*/ 
#include "gzillacache.h"
#include "gzillasocket.h"
#include "gzillaweb.h"

#define CACHE_MAX 2000000

static size_t cache_size_total=0;
/* invariant: cache_size_total is the sum of the buf_size fields of
   all cache lines in cache. */

static int cache_counter;


static void gzilla_cache_remove (__CacheFile_t* CPtr);

static inline __CacheFile_t* Cache_fetch(const char* URL, size_t Size)
{
   return (__CacheFile_t*) Hdlr_fetch(GzCache_Items,GzCache_NItems, URL,Size);
}

/* Remove a line from the cache */
static void gzilla_cache_remove (__CacheFile_t* CPtr)
{
   remque(CPtr);
   if (CPtr->Type) {free((char*) CPtr->Type); CPtr->Type = NULL;}
   if (CPtr->Data) {free((void*) CPtr->Data); CPtr->Data = NULL;}
   LDL_append(CPtr, &CacheFree);

   if (CPtr->Total_Size)
     cache_size_total -= CPtr->Total_Size;
   else
     cache_size_total -= CPtr->Size;
}

typedef struct {__CacheFile_t* CPtr; void* Data;} CI_t;
static void gzilla_cache_hit (__CacheFile_t* CPtr, void* Data);
static int gzilla_cache_idle(CI_t* Ptr)
{
   /* BUG: This is probably bad: it exists for reading URLs that aren'y
	completely there yet... */
   if (Ptr->CPtr->Flags & GZ_REDIRECT)
     {
        /* The connection came thru... and it turned into a redirection */
	gzilla_cache_URL_open((char*)Ptr->CPtr->Data,Ptr->Data);
	return FALSE;
     }
   if ((Ptr->CPtr->Flags & GZ_AUTOFREE) || !Ptr->CPtr->Type) return TRUE;

   gzilla_cache_hit(Ptr->CPtr, Ptr->Data);
   free (Ptr);
   return FALSE;
}

/* Pipe the cache line contents to the bytesink. The implementation is
 to create a new cache connection, and start the cache idle process
 if needed. */
static void gzilla_cache_hit (__CacheFile_t* CPtr, void* Data)
{
   __IOCallback_t Call=NULL;
   void* DItsData=NULL;
   if (/*  (CPtr->Flags & GZ_AUTOFREE) ||  */
	 !CPtr->Type)
     {
	/* BUG: the actual thing isn't in the cache; we should add this to a 
	notification list to call when it is 
        CI_t *P=malloc(sizeof(*P)); P->CPtr=CPtr;P->Data=Data;
        gtk_idle_add((GtkFunction) gzilla_cache_idle, P);
abort();
	*/
        return;
     }
   gzilla_web_dispatch_by_Type(Data, CPtr->Type,&Call,&DItsData);

   /* Send out the type information of the cache item */
   if (Call)
     {
       Call(0, DItsData, CPtr);
       Call(1, DItsData, CPtr);
     }
   CPtr->last_use = cache_counter++;
}

/* Try finding the url in the cache. If it hits, pipe the cache contents
 to the bytesink. If it misses, set up a connection. */
int gzilla_cache_URL_open (const char *url, void* Data)
{
   /* todo: maybe do some canonicalization of the url here? */
   __CacheFile_t* CPtr = Cache_fetch(url, strlen(url));
   if (!CPtr)
     return URL_open(url, Data);

   if ((CPtr->Flags & GZ_REDIRECT))
     /* We have cached a redirect command.. open that instead */
     return gzilla_cache_URL_open((char*)CPtr->Data,Data);

   if (!(CPtr->Flags & GZ_AUTOFREE))
     {
       gzilla_cache_hit (CPtr, Data);
       return -1;
     }
   /* BUG: if the item hasn't been cached yet, we've got problems! */
   return URL_open(url,Data);
}

int gzilla_cache_URL_copy(const char* url, int Cache_FD)
{
   /*
      Description
       Saves the specified URL to the specifed IO channel (@var{Cache_FD}).
       If the URL is already downloaded, all of the data is written to the IO
       channel.
       If the URL is partly downloaded, all of the available data is written to
       the IO channel, and any future data is written as it arrives.
       If the URL is not even started downloading yet, a connection is opened,
       and all of the data will be written to the IO channel (as well as the
       memory cache

      Return Value
       -1 on error, otherwise success.
   */
   __CacheFile_t* CPtr = Cache_fetch(url, strlen(url));

   /* Is it an already open file? */
   if (!CPtr)
     {
        /* No, We have to open the remote URL */
        GzillaWeb* Web = gzilla_web_new(NULL);
        Web->Cache_FD=Cache_FD;
        return URL_open(url, Web);
     }

   if (!(CPtr->Flags & GZ_REDIRECT))
     {
        /* We have already started caching this file... we need to catch up */
        GzIO_submit(Cache_FD, 1, (char*)CPtr->Data, CPtr->Size);

	/* Have the current open IO channel send any further stuff to the cache
	 */
	if (CPtr->FD >=0)
	  GzIO_AddCache(CPtr->FD, Cache_FD);
	return 0;
     }

   /* Its a redirect... */
   return gzilla_cache_URL_copy((char*)CPtr->Data,Cache_FD);
}

/* BUG: Cache delete is bogus! */
__CacheFile_t* Cache_delete(const char* A, size_t Size) {return NULL;}
/* todo: the case where the URL is open in a different window is not
   handled well (I think we should abort the upstream bytesink if the
   cache line is not at eof). */
void
gzilla_cache_remove_url (char *url)
{
   __CacheFile_t* File = Cache_delete(url, strlen(url));
   if (File) gzilla_cache_remove(File);
}

void gzilla_cache_insert(int FD, int Cache_FD,const char* url, const char* type)
{
   /*
      Description
       This inserts the URL into the cache, and initializes the IO transfer
    */
   __CacheFile_t* CPtr = GzCache_new(url);
   struct stat MyStat;
   /* Autotune: find out the prefferred transfer size */
   if (!fstat(FD, &MyStat)) CPtr->Block_Size=MyStat.st_blksize;
  
   CPtr->Data=malloc(CPtr->Block_Size);
   CPtr->Type=strdup(type);
   if (FD>=0)
     {
        FD2Cache(FD)=CPtr;
        GzIO_AddCache(FD, Cache_FD);
     }
   GzIO_submit(FD, 0, (char*)CPtr->Data, CPtr->Block_Size);
}
