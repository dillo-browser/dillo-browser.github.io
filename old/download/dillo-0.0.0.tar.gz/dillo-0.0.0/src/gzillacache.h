#ifndef __GZILLA_CACHE_H__
#define __GZILLA_CACHE_H__
#include <unistd.h>

typedef struct __CacheFile_t
{
   struct __CacheFile_t* q_forw, *q_back;
   const char *URL;
   const char *Type;
   void* Data;
   size_t Size,  /* Actually size of valid range */
     Total_Size, /* Goal size of the memory block */
     Block_Size; /* The preferred transfer size */
   unsigned Flags;
   int last_use;
   int FD;
} __CacheFile_t;

# define GZ_AUTOFREE (1) /* Free the cache file on close */
# define GZ_REDIRECT (2) /* Data actually points to a redirect */
typedef void (*__IOCallback_t)(int,void*, __CacheFile_t*);

void gzilla_cache_init (void);
int gzilla_cache_URL_open(const char *url, void*);
int gzilla_cache_URL_copy(const char* url, int Cache_FD);
void gzilla_cache_remove_url (char *url);
void gzilla_cache_insert(int FD, int Cache_FD,const char* url, const char* type);
__CacheFile_t* gzilla_cache_tmp (int FD);

extern __CacheFile_t	CacheFree, CacheActive;
extern void* GzCache_Items;
extern int GzCache_NItems, GzCache_NAlloc;

#include "URL/URL_protos.h"
#ifndef def_GzCache_add
extern __inline__
#endif
int GzCache_add(__CacheFile_t* File)
{
   /*
      Description
       Adds the cache'd file structure into the cache table
    */
   return Hdlr_add(&GzCache_Items, &GzCache_NItems,&GzCache_NAlloc, File->URL,
		   File);
}

#endif /* __GZILLA_CACHE_H__ */
