/*

   gzilla

   Copyright 1997 Raph Levien <raph@acm.org>

   This code is free for commercial and non-commercial use,
   modification, and redistribution, as long as the source code release,
   startup screen, or product packaging includes this copyright notice.

 */

/* gzilla_plain: a bytesink for decoding a text/plain object into
   a gtk_page widget. */

#include <string.h>		/* for memcpy and memmove */

#include <gtk/gtk.h>
#include "gzw.h"
#ifdef USE_GZW
#include "gzwpage.h"
#else
#include "gtkpage.h"
#endif
#include <malloc.h>
#include "MIME/MIME.h"

typedef struct _GzillaPlain 
{
  Gzw *gzw;
  size_t Start_Next;  /* Offset of where to start reading next */
  int attr;
} GzillaPlain;

static void gzilla_plain_update(GzillaPlain * bytesink, __CacheFile_t* FPtr);
static void gzilla_plain_callback(int Op, void* P, __CacheFile_t* CPtr);

static void Plain_page(GzillaPlain* plain)
{
#ifdef USE_GZW
  Gzw *page;
  GzwPageFont font;
  GzwPageAttr attr;
#else
  GtkWidget *page;
  GtkPageFont font;
  GtkPageAttr attr;
#endif

   if (plain->gzw) return;
#ifdef USE_GZW
  page = gzw_page_new (&plain->gzw);
  plain->gzw = page;
#else
  page = gtk_page_new ();

  plain->bytesink.widget = page;
#endif

  /* Create the font and attribute for the page. */
#if 0
  font.font = NULL;
#endif
  font.name = "courier";
  font.size = 12;
  font.bold = FALSE;
  font.italic = FALSE;

#ifdef USE_GZW
  gzw_page_init_attr ((GzwPage *)page, &attr);
  attr.font = gzw_page_find_font ((GzwPage *)page, &font);

  plain->attr = gzw_page_find_attr ((GzwPage *)page, &attr);
#else
  gtk_page_init_attr (GTK_PAGE (page), &attr);
  attr.font = gtk_page_find_font (GTK_PAGE (page), &font);

  plain->attr = gtk_page_find_attr (GTK_PAGE (page), &attr);
#endif

}

Gzw* gzPlain(const char*type, void* d, __IOCallback_t* Call, void** Data)
{
  GzillaPlain *plain = malloc(sizeof(*plain));

   /* todo: this should probably be a function of gzw_page */
   *Call = (__IOCallback_t)gzilla_plain_callback;
   *Data = (void*)plain;
  plain->Start_Next = 0;
  plain->gzw=NULL;

  Plain_page(plain);
  return plain->gzw;
}

static void gzilla_plain_callback(int Op, void* P, __CacheFile_t* CPtr)
{
  GzillaPlain* plain=(GzillaPlain*) P;
#ifdef USE_GZW
  GzwPage *page;
#else
  GtkPage *page;
#endif

  Plain_page(plain);

#ifdef USE_GZW 
  page = (GzwPage *)plain->gzw;
  gzw_page_update_begin (page);
#else
  page = GTK_PAGE (bytesink->widget);

  gtk_page_update_begin (page);
#endif

  if (Op)
    {
      /* Do the last line: */
      if (plain->Start_Next < CPtr->Size)
	{
	  char* S = malloc(CPtr->Size-plain->Start_Next+1);
	  strncpy(S,((char*)CPtr->Data)+plain->Start_Next,
		  CPtr->Size-plain->Start_Next);
#ifdef USE_GZW
	  gzw_page_add_text ((GzwPage *)plain->gzw,S, plain->attr);
	  gzw_page_linebreak ((GzwPage *)plain->gzw);
#else
	  gtk_page_add_text (GTK_PAGE (plain->bytesink.widget), S,
			     plain->attr);
	  gtk_page_linebreak (GTK_PAGE (plain->bytesink.widget));
#endif
	}
      page->Parent=NULL;
      free(P);
    }
  else    gzilla_plain_update(plain, CPtr);


#ifdef USE_GZW
  gzw_page_update_end (page);
#else
  gtk_page_update_end (page);
#endif
}

static void gzilla_plain_update (GzillaPlain* plain, __CacheFile_t* FPtr)
{
  char *Start = ((char*)FPtr->Data)+plain->Start_Next, *End=Start;
  size_t MaxScan=FPtr->Size-plain->Start_Next;
  int Inc=0;

  for (; MaxScan>0; MaxScan--,End++,Inc++)
   {
      char C;
      if (*End !='\r' && *End!='\n' && *End) continue;

      /* Display the line */
      C=End[0];
      End[0]=0;
/* BUG: We /have/ to duplicate the string...  */
#ifdef USE_GZW
      gzw_page_add_text ((GzwPage *)plain->gzw,strdup(Start), plain->attr);
      gzw_page_linebreak ((GzwPage *)plain->gzw);
#else
      gtk_page_add_text (GTK_PAGE (plain->bytesink.widget), strdup(Start),
		plain->attr);
      gtk_page_linebreak (GTK_PAGE (plain->bytesink.widget));
#endif
      End[0]=C;
      plain->Start_Next+=Inc+1;
      if (!*End) break;
      Inc=-1;
      Start=End+1; /* Skip past the end of line marker */
      if (C=='\r' && *Start=='\n') {Start++; plain->Start_Next++;End++; MaxScan--;}

      /* Skip past DOSish junk */
      while (MaxScan>1&&*Start=='\r')
	{Start++; plain->Start_Next++;End++;MaxScan--;}
   }
}
