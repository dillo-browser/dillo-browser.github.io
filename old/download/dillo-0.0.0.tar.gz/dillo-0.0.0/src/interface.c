/*

gzilla

Copyright 1999 ? <??@??.??>
Some modification by Rota Luca <lrota@cclinf.polito.it>

This code is free for commercial and non-commercial use,
modification, and redistribution, as long as the source code release,
startup screen, or product packaging includes this copyright notice.

*/

/*
    User Interface (designed around you :) )
*/

#include <gtk/gtk.h>
#include <netinet/in.h>    /* needed before including gzillasocket.h */
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <malloc.h>

#include "gzilla.h"
#include "gzillaweb.h"
#include "URL/gzillaurl.h"
#include "IO/GzIO.h"
#include "gtkstatuslabel.h"
#include "gzillacache.h"
#include "gzillasocket.h"
#include "interface.h"
#include "gzilla.h"
#include "gzillanav.h"
#include "gzillabrowser.h"
#include "commands.h"
#include "menus.h"
#include "config.h"
#include "gzillabookmark.h"

#include "gzw.h"
#include "gtkgzwscroller.h"
#include "gzwborder.h"

#include "pixmaps.h"
#include <stdio.h>

#undef VERBOSE
#undef OLD_TOOLBAR

/* BrowserWindow holds all the widgets (and perhaps more) 
 * for each new_browser
 * 
 * delcared like this in interface.h:
 * BrowserWindow *browser_window[MAX_BROWSER_WINDOWS];
 *
 */


BrowserWindow **browser_window;
gint num_bw, num_bw_max;

void gzilla_bw_init (void)
{
   num_bw = 0;
   num_bw_max = 16;
   browser_window = malloc(sizeof(BrowserWindow *)* num_bw_max);
}

/* --- Stop control ---------------------------------------------------------------*/
void browse_stop_cmd_callback(GtkWidget * widget, gpointer client_data)
{
   gzilla_nav_cancel_last_waiting ((BrowserWindow *)client_data);
   gzilla_bw_abort_all ((BrowserWindow *)client_data);
}

static void NavStop_deref(BrowserWindow* bw)
{
   /*
      Description
   Dereferences the navigational Stop button.  In other words, indicates that
   there is one less thing to be stopped for this window.
    */

   /*
     If the number of bytesinks reaches zero, then
     make the stop button and menu entry insensitive.
   */
   if (bw->Num_FDs_Used || bw->num_imgsinks) return;
   gtk_widget_set_sensitive (bw->stop_button,   FALSE);
   gtk_widget_set_sensitive (bw->stop_menuitem, FALSE);
   gzilla_status ("", bw);
}

static void NavStop_ref(BrowserWindow* bw)
{
   /*
      Description
   References the navigational Stop button.  In other words, indicates that
   there is one more thing to be stopped for this window.
    */
   if (!bw->Num_FDs_Used && !bw->num_imgsinks) return;
   gtk_widget_set_sensitive (bw->stop_button,   TRUE);
   gtk_widget_set_sensitive (bw->stop_menuitem, TRUE);
}

/* Abort all active bytesinks and imgsinks in the window. */
void gzilla_bw_abort_all (BrowserWindow *bw)
{
   int I;

   /* Abort File Descriptor based transfers */
   for (I = 0; I < NUM_FDS && bw->Num_FDs_Used > 0; I++)
    {
       if (!FD_ISSET(I, &bw->FD_Set)) continue;
       GzIO_abort(I);
       if (_FD2Ptr(I).Call)
    _FD2Ptr(I).Call(1, _FD2Ptr(I).Data, NULL);
       _FD2Ptr(I).Call=NULL;
       _FD2Ptr(I).Data=NULL;
       gzilla_bw_delete_FD(bw,I);
    }

   /* Abort Image sink transfers */
   while (bw->num_imgsinks > 0)
    {
       gzilla_imgsink_close(bw->imgsinks[0]);
    }

   gzilla_status("stopped",bw);
   #ifdef VERBOSE
   g_print ("exit gzilla_bw_abort_all\n");
   #endif
}

/* --- Managing Browser Window Dependencies ---------------------------------------*/
/* Delete the bytesink from the bytesinks structure. */
void gzilla_bw_delete_FD (BrowserWindow *bw, int FD)
{
   if (FD < 0 || !bw->Num_FDs_Used) return;
   FD_CLR(FD, &bw->FD_Set);
   bw->Num_FDs_Used--;
   NavStop_deref(bw);
}

static gint gzilla_bw_sens_idle_func (BrowserWindow *bw)
{
   gboolean back_sensitive, forw_sensitive;

   /* todo: put stop sensitivity in here too */
   back_sensitive = bw->gzilla_nav_ptr > 1;
   gtk_widget_set_sensitive(bw->back_button, back_sensitive);
   gtk_widget_set_sensitive(bw->back_menuitem, back_sensitive);
   forw_sensitive = (bw->gzilla_nav_ptr < bw->size_gzilla_nav &&
      !bw->last_waiting);
   gtk_widget_set_sensitive(bw->forw_button, forw_sensitive);
   gtk_widget_set_sensitive(bw->forw_menuitem, forw_sensitive);

   bw->sens_idle_tag = 0;
   return FALSE;
}

/* Set the sensitivity on back/forw buttons and menu entries. */
void gzilla_bw_set_button_sens (BrowserWindow *bw)
{
   if (bw->sens_idle_tag != 0) return;
   bw->sens_idle_tag = gtk_idle_add
      ((GtkFunction) gzilla_bw_sens_idle_func, bw);
}

void gzilla_bw_have_gzw (BrowserWindow *bw, Gzw* gzw)
{
  gtk_gzw_scroller_set_gzw (GTK_GZW_SCROLLER (bw->docwin),
             gzw_border_new (gzw, 5));
  if (!bw->last_waiting) return;
  bw->gzilla_nav_ptr = bw->gzilla_nav_loading_ptr;
  gzilla_bw_set_button_sens (bw);
  gtk_entry_set_text (GTK_ENTRY(bw->location),
            bw->gzilla_nav[bw->gzilla_nav_ptr - 1].url);
  bw->last_waiting = 0;
}

/* Add a pointer to the bytesink to the browser window's bytesinks
   structure. This helps us keep track of which bytesinks are active
   in the window so that it's possible to abort them.

   Also connects the close handler to the close signal on the
   bytesink.

   Note: this function doesn't register the bytesink as active.

   If it's the first bytesink added, a number of additional signal
   handlers are added. This is a hack, I know.
*/
void gzilla_bw_add_bytesink (BrowserWindow *bw, int FD)
{
   if (FD < 0 || !_FD2Ptr(FD).Call) return;
   FD_SET(FD, &bw->FD_Set);
   bw->Num_FDs_Used++;
   NavStop_ref(bw);
  
#if 0
  gtk_signal_connect (GTK_OBJECT (_FD2Ptr(FD).Data), "close",
            (GtkSignalFunc) gzilla_bw_close_handler, bw);
  
  /* todo: this seems still not quite right, but it does seem to work. */
  if (bw->num_bytesinks == 1)
    gtk_signal_connect (GTK_OBJECT (gzilla_web_get_linkblock
                (GZILLA_WEB (bytesink))), "have_gzw",
         (GtkSignalFunc) gzilla_bw_have_gzw, bw);
#endif
}

/* And now for the imgsinks... */
static void gzilla_bw_img_close_handler (void *data, GzillaImgSink *imgsink)
{
   gint i;
   BrowserWindow *bw = data;

   for (i = 0; i < bw->num_imgsinks; i++)
      if (bw->imgsinks[i] == imgsink)
      break;
   if (i < bw->num_imgsinks)
      bw->imgsinks[i] = bw->imgsinks[--bw->num_imgsinks];
   else
      g_warning ("gzilla_bw_img_close_handler: trying to delete nonexistent imgsink\n");

   #ifdef VERBOSE
      g_print ("gzilla_bw_img_close_handler: num_imgsinks = %d\n", bw->num_imgsinks);
   #endif
   NavStop_deref(bw);
}

/* Add a pointer to the imgsink to the browser window's imgsinks
   structure. This helps us keep track of which imgsinks are active
   in the window so that it's possible to abort them.
*/
void gzilla_bw_add_imgsink (BrowserWindow *bw, GzillaImgSink *imgsink)
{
   if (!bw) return;
   NavStop_ref(bw);
   if (bw->num_imgsinks == bw->num_imgsinks_max)
    {
      bw->num_imgsinks_max <<= 1;
      bw->imgsinks = realloc (bw->imgsinks, bw->num_imgsinks_max *
         sizeof (GzillaImgSink *));
   }
   bw->imgsinks[bw->num_imgsinks++] = imgsink;

   gzilla_imgsink_set_close_handler (imgsink, gzilla_bw_img_close_handler, bw);
   #ifdef VERBOSE
      g_print ("gzilla_bw_add_imgsink: num_imgsinks = %d\n", bw->num_imgsinks);
   #endif
}

/* Remove a browser window. This includes destroying all open windows
   (except for the main browser window, which is presumed to be
   destroyed in the caller), freeing all resources associated with the
   browser window, and exiting gtk if no windows are left.
*/
static gboolean gzilla_bw_quit (GtkWidget *widget, BrowserWindow *bw)
{
   gint i;

   /* todo: should probably abort any open connections. */
   if (bw->open_dialog_window != NULL)
      gtk_widget_destroy (bw->open_dialog_window);
   if (bw->openfile_dialog_window != NULL)
      gtk_widget_destroy (bw->openfile_dialog_window);
   if (bw->quit_dialog_window != NULL)
      gtk_widget_destroy (bw->quit_dialog_window);

   if (bw->sens_idle_tag)
      gtk_idle_remove (bw->sens_idle_tag);

   for (i = 0; i < num_bw; i++)
      if (browser_window[i] == bw)
      {
         browser_window[i] = browser_window[--num_bw];
         break;
      }
   for (i = 0; i < bw->size_gzilla_nav; i++)
   {
      free (bw->gzilla_nav[i].url);
      if (bw->gzilla_nav[i].title != NULL)
      free (bw->gzilla_nav[i].title);
   }
   free (bw->gzilla_nav);
   free (bw->imgsinks);
   free (bw);
   if (num_bw == 0)
      gtk_main_quit ();

   return FALSE;
}

#if 0
/* Find the browser window that the bytesink belongs to. */
/* I'm not sure we need this. */
   BrowserWindow * gzilla_bw_find (GzillaByteSink *bytesink)
{
   gint i, j;

   for (i = 0; i < num_bw; i++)
      for (j = 0; j < browser_window[i]->num_bytesinks; j++)
         if (browser_window[i]->bytesinks[j] == bytesink)
            return browser_window[i];
   return NULL;
}

/* Find the browser window struct given some widget that's contained
   inside. */
/* I don't think we need this either. */
BrowserWindow * gzilla_bw_find_from_widget (GtkWidget *widget)
{
   GtkWidget *toplevel;
   gint i;

   toplevel = gtk_widget_get_toplevel (widget);
   for (i = 0; i < num_bw; i++)
      if (browser_window[i]->main_window == toplevel)
         return browser_window[i];
   return NULL;
}
#endif

#ifdef OLD_TOOLBAR
/*

 Creates a box with a pixmap and a label in it and returns it.

*/
GtkWidget *gzilla_xpm_label_box(GtkWidget *parent, gchar **data, gchar *lbltxt)
{
   GtkWidget *box;
   GtkWidget *label;
   GtkWidget *pixmapwid;
   GdkPixmap *pixmap;
   GdkBitmap *mask;
   GtkStyle *style;

   box = gtk_vbox_new(FALSE, 0);

   gtk_container_set_border_width(GTK_CONTAINER(box), 0);

   style = gtk_widget_get_style(parent);

   pixmap = gdk_pixmap_create_from_xpm_d(parent->window, &mask,
       &style->bg[GTK_STATE_NORMAL], data);

   pixmapwid = gtk_pixmap_new(pixmap, mask);

   label = gtk_label_new(lbltxt);

   gtk_box_pack_start(GTK_BOX(box), pixmapwid, FALSE, FALSE, 3);
   gtk_box_pack_start(GTK_BOX(box), label, FALSE, FALSE, 3);

   gdk_pixmap_unref(pixmap);
   gdk_pixmap_unref(mask);

   gtk_widget_show(pixmapwid);
   gtk_widget_show(label);

   return(box);
}
#else
/*

 Creates a pixmap and returns it.

*/
GtkWidget *gzilla_new_pixmap(GtkWidget *parent, gchar **data)
{
   GtkWidget *pixmapwid;
   GdkPixmap *pixmap;
   GdkBitmap *mask;
   GtkStyle *style;

   style = gtk_widget_get_style(parent);

   pixmap = gdk_pixmap_create_from_xpm_d(parent->window, &mask,
       &style->bg[GTK_STATE_NORMAL], data);

   pixmapwid = gtk_pixmap_new(pixmap, mask);

   return(pixmapwid);
}
#endif
/* this function creates a new browser window and returns the browser
   window struct. */

BrowserWindow * gzilla_new_browser_window (void)
{
   /* used to create new windows - index into browser_window[] 
   * not really implemented. */

   GtkWidget *toolbar;
   GtkWidget *box1;
   GtkWidget *box3;
   #ifdef OLD_TOOLBAR      
      GtkWidget *button;
      GtkWidget *box2;
      GtkWidget *button_box[6];
      int BtnCnt=0;
   #else
      GtkWidget *handlebox;      
   #endif     
   GtkWidget *menubar;
   BrowserWindow *bw;

   char buf[256];

   /* allocate and zero memory for new browser_window info */
   /* if I were to use g_malloc() would it zero the memory ?
   * is there a g_calloc() ? :) */
   /* -RL: Maybe you can use g_malloc0() to zero the memory */
   bw = malloc(sizeof(BrowserWindow));
   bw->Num_FDs_Used=0;
   bw->save_dialog_window=NULL;

   if (num_bw == num_bw_max)
   {
      num_bw_max <<= 1;
      browser_window = realloc (browser_window, num_bw_max *
         sizeof (BrowserWindow));
   }
   browser_window[num_bw] = bw;

   /* initialize gzilla_nav struct in browser_window struct */
   gzilla_nav_init (bw);

   bw->main_window = gtk_window_new (GTK_WINDOW_TOPLEVEL);

   gtk_window_set_policy (GTK_WINDOW (bw->main_window),
      TRUE, TRUE, FALSE);
   gtk_signal_connect (GTK_OBJECT (bw->main_window), "delete_event",
      GTK_SIGNAL_FUNC (gtk_object_destroy), bw);
   gtk_signal_connect (GTK_OBJECT (bw->main_window), "destroy",
      GTK_SIGNAL_FUNC (gzilla_bw_quit), bw);
   gtk_container_border_width (GTK_CONTAINER (bw->main_window), 0);

   gtk_window_set_wmclass (GTK_WINDOW (bw->main_window), "gzilla", "Gzilla");
   
   /* -RL :: I must realize the window to see it correctly */
   gtk_widget_realize (bw->main_window);

   /* set window title */
   sprintf (buf, "Version %s", VERSION);
   gzilla_set_page_title (bw, buf);

   /* todo: I think this should go. */
   /* set the browser_window url to none */
   bw->gzilla_nav->url = strdup ("none");

   box1 = gtk_vbox_new (FALSE, 0);

   /* setup the menus */
   #ifdef OLD_MENUS
      menus_get_gzilla_menubar (&menubar, &table);
   #else
      handlebox = gtk_handle_box_new ();
      gtk_box_pack_start (GTK_BOX (box1), handlebox, FALSE, FALSE, 0);   
      menubar = gzilla_menu_mainbar_new (bw);
      gtk_container_add (GTK_CONTAINER (handlebox), menubar);
   #endif
/*      gtk_box_pack_start (GTK_BOX (box1), menubar, FALSE, FALSE, 0);*/
   gtk_widget_show (menubar);
   gtk_widget_show (handlebox);
   #ifdef GTK_HAVE_FEATURES_1_1_0
      gtk_window_add_accel_group (GTK_WINDOW (bw->main_window),
         bw->accel_group);
   #else
      gtk_window_add_accelerator_table (GTK_WINDOW (bw->main_window),
         bw->accel_table);
   #endif
   bw->sens_idle_tag = 0;

   #ifdef OLD_TOOLBAR
      box2 = gtk_hbox_new (FALSE, 0);

      gtk_box_pack_start (GTK_BOX (box1), box2, FALSE, FALSE, 5);
      gtk_widget_show (box2);

      toolbar = gtk_hbox_new (TRUE, 0);
   
# define NewButton(b,c,d) do{\
   button=gtk_button_new();\
   button_box[BtnCnt]=gzilla_xpm_label_box(bw->main_window, b, c);\
   gtk_widget_show(button_box[BtnCnt]);\
   gtk_container_add(GTK_CONTAINER(button), button_box[BtnCnt++]);\
   gtk_signal_connect(GTK_OBJECT(button), "clicked",(GtkSignalFunc)d,bw);\
   gtk_box_pack_start(GTK_BOX(toolbar), button, TRUE, TRUE, 0);\
   gtk_widget_show(button);\
   }while(0)
     
      /* back button */
      NewButton(leftarrow_xpm, "Back", browse_back_cmd_callback);
      bw->back_button = button;

      /* todo: use sens callback? */
      gtk_widget_set_sensitive (bw->back_button, FALSE);
      gtk_widget_set_sensitive (bw->back_menuitem, FALSE);

      /* forward button */
      NewButton(rghtarrow_xpm, "Forward", browse_forw_cmd_callback);
      bw->forw_button = button;
      gtk_widget_set_sensitive (bw->forw_button, FALSE);
      gtk_widget_set_sensitive (bw->forw_menuitem, FALSE);

      /* home button */
      NewButton(home_xpm, "Home", browse_home_cmd_callback);

      /* reload button */
      NewButton(reload_xpm,"Reload", browse_reload_cmd_callback);

      /* save button */
      NewButton(save_xpm,  "Save", browse_save_cmd_callback);

      /* stop button */
      NewButton(stop_xpm, "Stop", browse_stop_cmd_callback);
      bw->stop_button = button;

      gtk_widget_set_sensitive (bw->stop_button, FALSE);
      gtk_widget_set_sensitive (bw->stop_menuitem, FALSE);

      /* pack the toolbar */
      gtk_box_pack_start (GTK_BOX (box2), toolbar, FALSE, FALSE, 3);
      gtk_widget_show (toolbar);
   #else
      /* We'll put the toolbar into the handle box so that it can be
         detached from the main window */
      handlebox = gtk_handle_box_new ();
      gtk_box_pack_start (GTK_BOX (box1), handlebox, FALSE, FALSE, 0);   
      
      toolbar = gtk_toolbar_new (GTK_ORIENTATION_HORIZONTAL, GTK_TOOLBAR_BOTH);
      gtk_container_set_border_width ( GTK_CONTAINER (toolbar), 5);
      gtk_toolbar_set_button_relief (GTK_TOOLBAR (toolbar), GTK_RELIEF_NONE);
      gtk_container_add (GTK_CONTAINER (handlebox), toolbar);
      
      /* back button */
      bw->back_button = gtk_toolbar_append_item (GTK_TOOLBAR (toolbar),
                "Back", "Go to previous page", "Toolbar/Back",
                gzilla_new_pixmap (bw->main_window, leftarrow_xpm),
                (GtkSignalFunc) browse_back_cmd_callback, bw);

      gtk_widget_set_sensitive (bw->back_button, FALSE);
      gtk_widget_set_sensitive (bw->back_menuitem, FALSE);

      /* forward button */
      bw->forw_button = gtk_toolbar_append_item (GTK_TOOLBAR (toolbar),
                "Forward", "Go to next page", "Toolbar/Forward",
                gzilla_new_pixmap (bw->main_window, rghtarrow_xpm),
                (GtkSignalFunc) browse_forw_cmd_callback, bw);

      gtk_widget_set_sensitive (bw->forw_button, FALSE);
      gtk_widget_set_sensitive (bw->forw_menuitem, FALSE);

      /* home button */
      gtk_toolbar_append_item (GTK_TOOLBAR (toolbar),
                "Home", "Go to the Home page", "Toolbar/Home",
                gzilla_new_pixmap (bw->main_window, home_xpm),
                (GtkSignalFunc) browse_home_cmd_callback, bw);

      /* reload button */
      gtk_toolbar_append_item (GTK_TOOLBAR (toolbar),
                "Reload", "Reload this page", "Toolbar/Reload",
                gzilla_new_pixmap (bw->main_window, reload_xpm),
                (GtkSignalFunc) browse_reload_cmd_callback, bw);
      
      /* save button */
      gtk_toolbar_append_item (GTK_TOOLBAR (toolbar),
                "Save", "Save this page", "Toolbar/Save",
                gzilla_new_pixmap (bw->main_window, save_xpm),
                (GtkSignalFunc) browse_save_cmd_callback, bw);

      /* stop button */
      bw->stop_button = gtk_toolbar_append_item (GTK_TOOLBAR (toolbar),
                "Stop", "Stop the current transfer", "Toolbar/Stop",
                gzilla_new_pixmap (bw->main_window, stop_xpm),
                (GtkSignalFunc) browse_stop_cmd_callback, bw);
 

      gtk_widget_set_sensitive (bw->stop_button, FALSE);
      gtk_widget_set_sensitive (bw->stop_menuitem, FALSE);

      gtk_widget_show (toolbar);
      gtk_widget_show (handlebox);
   #endif
   
   gtk_container_add (GTK_CONTAINER (bw->main_window), box1);
   gtk_widget_show (box1);

   /* location entry */
   handlebox = gtk_handle_box_new ();
   gtk_box_pack_start (GTK_BOX (box1), handlebox, FALSE, FALSE, 0); 
   bw->location = gtk_entry_new ();
   gtk_container_add (GTK_CONTAINER (handlebox), bw->location); 
/*      gtk_box_pack_start (GTK_BOX (box1), bw->location, FALSE, FALSE, 0);*/
   gtk_widget_show (bw->location);
   gtk_widget_show (handlebox); 
   gtk_signal_connect (GTK_OBJECT (bw->location), "activate",
      (GtkSignalFunc) entry_open_url, bw);

   /* the main document window */
   bw->docwin = gtk_gzw_scroller_new (NULL, NULL);
   gtk_gzw_scroller_set_policy (GTK_GZW_SCROLLER (bw->docwin),
      GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);
   gtk_box_pack_start (GTK_BOX (box1), bw->docwin, TRUE, TRUE, 0);
   gtk_widget_show (bw->docwin);
   bw->Num_FDs_Used = 0;
   FD_ZERO(&bw->FD_Set);

   bw->num_imgsinks = 0;
   bw->num_imgsinks_max = 1;
   bw->imgsinks = malloc(sizeof(GzillaImgSink *)* bw->num_imgsinks_max);

   #if 1
      /* -RL :: Maybe I'd change _widget_set_usize in 
      _window_default_set_size so the user can resize the window 
      with a --geometry command line switch when a command line 
      control will be implemented */
      gtk_widget_set_usize (bw->main_window, 500, 540);
   #endif

   /* status widget */
   bw->status = gtk_statuslabel_new ("");
   gtk_misc_set_alignment (GTK_MISC (bw->status), 0.0, 0.5);
   box3 = gtk_hbox_new (FALSE, 0);
   
   #if 1
      gtk_box_pack_start (GTK_BOX (box3), bw->status, TRUE, TRUE, 2);
      gtk_widget_show (bw->status);
      /* we could also put a key, a progress bar, and a mail icon here */
      /* I'd like to see a seperate thing for the link your mouse is on top
      * of.. seperated from the current status widget like.. -Ian*/
      gtk_box_pack_start (GTK_BOX (box1), box3, FALSE, FALSE, 2);
      gtk_widget_show (box3);
   #else
      gtk_box_pack_start (GTK_BOX (box1), bw->status, FALSE, FALSE, 2);
      gtk_widget_show (bw->status);
   #endif

   gtk_widget_show (bw->main_window);

   #if 0
      /* Accelerators can't be non-ASCII - looks like we'll have to do all
      our keypresses through the focus mechanism. */
      gtk_accelerator_table_install (table, GTK_OBJECT (location),
             "destroy", GDK_Return, 0);
   #endif

   /* Zero out a bunch of stuff in the bw struct. */
   bw->open_dialog_window = NULL;
   bw->openfile_dialog_window = NULL;
   bw->quit_dialog_window = NULL;
   num_bw++;
   return bw;
}

/* sets the title of the browser window to title with "Dillo: "
   prepended to it. Also sets the page_title member of the current
   gzilla_nav structure for use with the bookmarks. */
void gzilla_set_page_title (BrowserWindow *bw, char *title)
{
   char *buf;
   gint nav_index;

   if (!bw) return;
   /* free previously allocated string */
   nav_index = bw->gzilla_nav_ptr - 1;
   if (nav_index >= 0)
   {
      if (bw->gzilla_nav[nav_index].title)
         free (bw->gzilla_nav[nav_index].title);
      bw->gzilla_nav[nav_index].title = strdup (title);
   }

   buf = malloc(strlen (title) + 128);
   sprintf (buf, "Dillo: %s", title);
   gtk_window_set_title (GTK_WINDOW (bw->main_window), buf);
   free (buf);
}

/* sets the status string on the bottom of the gzilla window. 
 * TODO: add int win_num to this call */
void gzilla_status (const char *string, BrowserWindow *bw)
{
  if (bw)
   gtk_label_set (GTK_LABEL (bw->status), string);
}

/* hmm.. have to see where this is from */
void destroy_window (GtkWidget *widget, GtkWidget ** window)
{
   *window = NULL;
}

void gzilla_quit_all (void)
{
   BrowserWindow **bws;
   gint i, n_bw;

   n_bw = num_bw;
   bws = malloc(sizeof(BrowserWindow *)* n_bw);

   /* we copy into a new list because destroying the main window can
   modify the browser_window array. */
   for (i = 0; i < n_bw; i++)
      bws[i] = browser_window[i];

   for (i = 0; i < n_bw; i++)
      gtk_widget_destroy (bws[i]->main_window);

   free (bws);

   #ifdef VERBOSE
      g_print ("gzilla_quit_all: exit\n");
   #endif
}

static void push_help (GtkWidget *widget, char *url, BrowserWindow *bw)
{
   gzilla_nav_push (bw, url);
}

static void openfile_ok_callback (GtkWidget *widget, BrowserWindow *bw)
{
   char *fn;
   char url[1024];

   #ifdef VERBOSE
      g_print ("openfile_ok_callback: %s\n", fn);
   #endif
   fn = gtk_file_selection_get_filename
   (GTK_FILE_SELECTION (bw->openfile_dialog_window));
   if (strlen (fn) + 6 <= sizeof (url))
   {
      sprintf (url, "file:%s", fn);
      gzilla_nav_push (bw, url);
   }
   gtk_widget_destroy (bw->openfile_dialog_window);
}


void gzilla_entry_clear (GtkEntry *entry)
{
   gtk_entry_set_text (entry, "");
   gtk_widget_grab_focus (GTK_WIDGET (entry));
}

void entry_open_url (GtkWidget *widget, BrowserWindow *bw)
{
   char url[1024];
   GtkEntry *entry;

   /* Find which entry to get the URL from. This is a bit of a hack. */

   if (widget == bw->location)
      entry = GTK_ENTRY (bw->location);
   else
      entry = GTK_ENTRY (bw->open_dialog_entry);
   #ifdef VERBOSE
   g_print ("entry_open_url %s\n", gtk_entry_get_text (entry));
   #endif
   if (gzilla_url_relative ("http:/", gtk_entry_get_text (entry),
      url, sizeof (url)))
      gzilla_nav_push (bw, url);
   if (bw->open_dialog_window != NULL)
      gtk_widget_destroy (bw->open_dialog_window);
   /* todo: pull focus away from location widget probably by focusing
   to the page, but at the time this todo was added, the gtk_page
   widget wasn't really focusable. */
}

void create_openfile_dialog (BrowserWindow *bw)
{
   if (!bw->openfile_dialog_window)
   {
      bw->openfile_dialog_window = gtk_file_selection_new ("Open File");
      gtk_signal_connect (GTK_OBJECT (bw->openfile_dialog_window), "destroy",
         (GtkSignalFunc) destroy_window, &(bw->openfile_dialog_window));
      gtk_signal_connect (GTK_OBJECT (GTK_FILE_SELECTION
         (bw->openfile_dialog_window)->ok_button),
         "clicked", (GtkSignalFunc) openfile_ok_callback, bw);
      gtk_signal_connect_object (GTK_OBJECT (GTK_FILE_SELECTION
         (bw->openfile_dialog_window)->cancel_button),
         "clicked", (GtkSignalFunc) gtk_widget_hide,
         GTK_OBJECT (bw->openfile_dialog_window));
      gtk_signal_connect (GTK_OBJECT (GTK_FILE_SELECTION
         (bw->openfile_dialog_window)->help_button),
         "clicked", (GtkSignalFunc) push_help,
         "http://www.levien.com/gimp/");
   }
   if (!GTK_WIDGET_VISIBLE (bw->openfile_dialog_window))
      gtk_widget_show (bw->openfile_dialog_window);
   else
      gtk_widget_destroy (bw->openfile_dialog_window);
}

void create_open_dialog (GtkWidget *widget, BrowserWindow *bw)
{
   GtkWidget *button;
   GtkWidget *box1;
   GtkWidget *box2;
   GtkWidget *entry;

   if (!bw->open_dialog_window)
   {
      bw->open_dialog_window = gtk_window_new (GTK_WINDOW_DIALOG);
      #if 1
         gtk_signal_connect (GTK_OBJECT (bw->open_dialog_window), "destroy",
            (GtkSignalFunc) destroy_window, &(bw->open_dialog_window));
      #endif
      gtk_window_set_title (GTK_WINDOW (bw->open_dialog_window),
         "Dillo: Open URL");
      gtk_container_border_width (GTK_CONTAINER (bw->open_dialog_window), 5);

      box1 = gtk_vbox_new (FALSE, 5);
      gtk_container_add (GTK_CONTAINER (bw->open_dialog_window), box1);
      gtk_widget_show (box1);

      entry = gtk_entry_new ();
      bw->open_dialog_entry = entry;
      gtk_widget_set_usize (entry, 250, 0);
      gtk_box_pack_start (GTK_BOX (box1), entry, FALSE, FALSE, 0);
      gtk_widget_show (entry);

      gtk_signal_connect (GTK_OBJECT (entry), "activate", (GtkSignalFunc)
         entry_open_url, bw);

      box2 = gtk_hbox_new (TRUE, 5);
      gtk_box_pack_start (GTK_BOX (box1), box2, FALSE, FALSE, 0);
      gtk_widget_show (box2);

      button = gtk_button_new_with_label ("OK");
      gtk_signal_connect (GTK_OBJECT (button), "clicked", (GtkSignalFunc)
         entry_open_url, bw);
      GTK_WIDGET_SET_FLAGS (button, GTK_CAN_DEFAULT);
      gtk_box_pack_start (GTK_BOX (box2), button, FALSE, TRUE, 0);
      gtk_widget_grab_default (button);
      gtk_widget_show (button);
      gtk_signal_connect_object (GTK_OBJECT (entry), "focus_in_event",
         (GtkSignalFunc) gtk_widget_grab_default, GTK_OBJECT (button));

      button = gtk_button_new_with_label ("Clear");
      gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
         (GtkSignalFunc) gzilla_entry_clear, GTK_OBJECT (entry));
      GTK_WIDGET_SET_FLAGS (button, GTK_CAN_DEFAULT);
      gtk_box_pack_start (GTK_BOX (box2), button, FALSE, TRUE, 0);
      gtk_widget_show (button);

      button = gtk_button_new_with_label ("Cancel");
      gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
         (GtkSignalFunc) gtk_widget_destroy,
         GTK_OBJECT (bw->open_dialog_window));
      GTK_WIDGET_SET_FLAGS (button, GTK_CAN_DEFAULT);
      gtk_box_pack_start (GTK_BOX (box2), button, FALSE, TRUE, 0);
      gtk_widget_show (button);

      gtk_widget_grab_focus (entry);

    }

   /* todo: hiding vs. destroying leaves two problems open. First, the
   entry is not focussed when it's re-shown. Second, closing the
   window (from the window manager) really does destroy the contents.

   Perhaps a better solution is to keep a spare copy of the entry
   text around (updated only when the Ok button is clicked), and use
   it to initialize the entry. Also delete rather than hide the
   window.

   But it's ok for now.
   */
   /* if you take a look at the "OK" button, it calls entry_open_url which
   calls gtk_destroy_widget on your open_dialog_window.. maybe this is
   what's recking it for you ? -Ian */

   if (!GTK_WIDGET_VISIBLE (bw->open_dialog_window))
      gtk_widget_show (bw->open_dialog_window);
   else
      gtk_widget_hide (bw->open_dialog_window);
}



void entry_save_url (GtkWidget *widget, BrowserWindow *bw)
{
  char url[1024], name[1024];
  GtkEntry *entry, *entry_url;
  int Cache_FD;
 
  entry = GTK_ENTRY (bw->save_dialog_entry);
  entry_url = GTK_ENTRY (bw->location);

  strcpy(name, gtk_entry_get_text (entry));
  strcpy(url, gtk_entry_get_text (entry_url));
  if ( strlen(name) ){
#ifdef VERBOSE
     g_print ("Trying to save URL as %s\n", name);
     g_print ("(URL=%s)\n", url);
#endif

     /* Lets make a bytesink for retrieving data from cache */
     Cache_FD=creat(name,S_IRGRP|S_IWGRP|S_IRUSR|S_IWUSR);
     /* Now put the savename in a safe place */
     /* Here we go! */
     gzilla_cache_URL_copy(url, Cache_FD);
  }

  if (bw->save_dialog_window != NULL)
    gtk_widget_destroy (bw->save_dialog_window);
}

void make_save_name(BrowserWindow *bw, char *name)
/* Scan current URL and build a suggested local-filename for saving */
{
  char url[1024], *ptr;
  GtkEntry *entry_url;
  int i, len;
 
  entry_url = GTK_ENTRY (bw->location);
  strcpy(url, gtk_entry_get_text (entry_url));
  len = strlen(url);
  for ( i = len; i > 0; --i) /* search for last '/' caracter in url */
     if ( url[i] == '/' ){
   ++i; break;
     }
  ptr = url + i;
  if ( strlen(ptr) < 64 ) /* Common sense limit (I prefer 32 ;)*/
     strcpy(name, ptr);
  else
     *name = 0;      /* No suggested name */
}
 
void create_save_dialog (GtkWidget *widget, BrowserWindow *bw)
{
  GtkWidget *button;
  GtkWidget *box1;
  GtkWidget *box2;
  GtkWidget *entry;
  char suggested_name[1024];  /* Suggested save name */

  if (!bw->save_dialog_window)
    {
      bw->save_dialog_window = gtk_window_new (GTK_WINDOW_DIALOG);

      gtk_signal_connect (GTK_OBJECT (bw->save_dialog_window), "destroy",
      (GtkSignalFunc) destroy_window,
      &(bw->save_dialog_window));

      gtk_window_set_title (GTK_WINDOW (bw->save_dialog_window),
        "Dillo: Save URL as file");
      gtk_container_border_width (GTK_CONTAINER (bw->save_dialog_window), 5);

      box1 = gtk_vbox_new (FALSE, 5);
      gtk_container_add (GTK_CONTAINER (bw->save_dialog_window), box1);
      gtk_widget_show (box1);

      entry = gtk_entry_new ();
      gtk_widget_set_usize (entry, 250, 0);

      make_save_name(bw, suggested_name);
      gtk_entry_set_text (GTK_ENTRY (entry), suggested_name);
      gtk_widget_grab_focus (GTK_WIDGET (entry));
      gtk_box_pack_start (GTK_BOX (box1), entry, FALSE, FALSE, 0);
      bw->save_dialog_entry = GTK_WIDGET (entry);
      gtk_widget_show (entry);

      gtk_signal_connect (GTK_OBJECT (entry), "activate",
      (GtkSignalFunc) entry_save_url,
      bw);

      box2 = gtk_hbox_new (TRUE, 5);
      gtk_box_pack_start (GTK_BOX (box1), box2, FALSE, FALSE, 0);
      gtk_widget_show (box2);

      button = gtk_button_new_with_label ("OK");
      gtk_signal_connect (GTK_OBJECT (button), "clicked",
      (GtkSignalFunc) entry_save_url,
      bw);
      GTK_WIDGET_SET_FLAGS (button, GTK_CAN_DEFAULT);
      gtk_box_pack_start (GTK_BOX (box2), button, FALSE, TRUE, 0);
      gtk_widget_grab_default (button);
      gtk_widget_show (button);
      gtk_signal_connect_object (GTK_OBJECT (entry), "focus_in_event",
        (GtkSignalFunc) gtk_widget_grab_default,
        GTK_OBJECT (button));

      button = gtk_button_new_with_label ("Clear");
      gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
        (GtkSignalFunc) gzilla_entry_clear,
        GTK_OBJECT (entry));
      GTK_WIDGET_SET_FLAGS (button, GTK_CAN_DEFAULT);
      gtk_box_pack_start (GTK_BOX (box2), button, FALSE, TRUE, 0);
      gtk_widget_show (button);

      button = gtk_button_new_with_label ("Cancel");
      gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
        (GtkSignalFunc) gtk_widget_destroy,
        GTK_OBJECT (bw->save_dialog_window));
      GTK_WIDGET_SET_FLAGS (button, GTK_CAN_DEFAULT);
      gtk_box_pack_start (GTK_BOX (box2), button, FALSE, TRUE, 0);
      gtk_widget_show (button);

      gtk_widget_grab_focus (entry);

    }

  if (!GTK_WIDGET_VISIBLE (bw->save_dialog_window))
    gtk_widget_show (bw->save_dialog_window);
  else
    gtk_widget_hide (bw->save_dialog_window);
}


/* shouldn't all this stuff go in menu.c or something ? 
 * why do we need global window GtkWidgets for the windows ?? 
 * I see you use it in the destroy() function, but I don't 
 * really grasp it's use just yet :) */

/* The way gimp does it is to have a menus.c for the menus themselves
 * and a commands.c for the *_cmd callbacks. They also have an
 * interface.c where most of the interface stuff happens. We should
 * probably follow their lead.
 * 
 * We have globals for the windows so I can destroy all windows before
 * quitting. Some window managers (including fvwm2-95) really like
 * this. -Raph
 */

/* funny you say that, cause if you look at the quit_dialog_window I made, I just
 * gtk_destroy_widget(main_window).. it seems to work ok, but should we change
 * it ? -Ian
 */

/* No, the way it is now is fine. When you destroy the main window,
   that invokes the destroy signal handler, which destroys all of the
   other windows cleanly. 

   Anyway, I wrote the above explanation before we had multiple
   windows. Another reason to do it this way is that when you close
   one of several main windows, its various subsidiary windows go away
   too. -Raph */

void create_quit_dialog (BrowserWindow *bw)
{
   GtkWidget *button;
   GtkWidget *label;

   if (!bw->quit_dialog_window)
   {
      bw->quit_dialog_window = gtk_dialog_new ();
      gtk_signal_connect (GTK_OBJECT (bw->quit_dialog_window), "destroy",
         (GtkSignalFunc) destroy_window, &(bw->quit_dialog_window));
      gtk_window_set_title (GTK_WINDOW (bw->quit_dialog_window),
         "Really Quit ?");
      gtk_container_border_width (GTK_CONTAINER (bw->quit_dialog_window), 0);

      label = gtk_label_new ("Really Quit Gzilla ?");
      gtk_misc_set_padding (GTK_MISC (label), 10, 10);
      gtk_box_pack_start (GTK_BOX (GTK_DIALOG (bw->quit_dialog_window)->vbox),
         label, TRUE, TRUE, 0);
      gtk_widget_show (label);

      button = gtk_button_new_with_label ("OK");
      /* they said OK, is there some cleanup we have to do before
      destroying the main window ? - set it to call
      gzilla_quit_all which cleans things up a bit..
      hopefuly an improvement. -Ian
      */
      gtk_signal_connect (GTK_OBJECT (button), "clicked",
         (GtkSignalFunc) gzilla_quit_all, NULL);
      GTK_WIDGET_SET_FLAGS (button, GTK_CAN_DEFAULT);
      gtk_box_pack_start (GTK_BOX (GTK_DIALOG
         (bw->quit_dialog_window)->action_area), button, TRUE, TRUE, 0);
      gtk_widget_grab_default (button);
      gtk_widget_show (button);

      button = gtk_button_new_with_label ("Cancel");
      gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
         (GtkSignalFunc) gtk_widget_destroy,
         GTK_OBJECT (bw->quit_dialog_window));
      GTK_WIDGET_SET_FLAGS (button, GTK_CAN_DEFAULT);
      gtk_box_pack_start (GTK_BOX (GTK_DIALOG
         (bw->quit_dialog_window)->action_area), button, TRUE, TRUE, 0);
      gtk_widget_show (button);
   }

   if (!GTK_WIDGET_VISIBLE (bw->quit_dialog_window))
      gtk_widget_show (bw->quit_dialog_window);
   else
      gtk_widget_destroy (bw->quit_dialog_window);
   /* I much prefer it not to retain the last thing I typed in there
   you know that :)  I always have to clear  the  dumb netscape
   one.. I find it rather nice this way. */
}

