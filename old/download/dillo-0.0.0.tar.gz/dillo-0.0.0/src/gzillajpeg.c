/*

 gzilla

 Copyright 1997 Raph Levien <raph@acm.org>

 This code is free for commercial and non-commercial use,
 modification, and redistribution, as long as the source code release,
 startup screen, or product packaging includes this copyright notice.

 */

/* The jpeg decoder for gzilla. It is responsible for decoding JPEG data
   in a bytesink and transferring it to an imgsink. It uses libjpeg to
   do the actual decoding. */

/* Todo: install an error handler that doesn't exit.*/

#undef VERBOSE
#define VERBOS

#include <stdio.h>
#include <gtk/gtk.h>
#include <malloc.h>

#include "gzillaimgsink.h"
#include <jpeglib.h>
#include "gzillacache.h"
#include "gzillaweb.h"
#include "MIME/MIME.h"

typedef enum {
  GZILLA_JPEG_INIT,
  GZILLA_JPEG_STARTING,
  GZILLA_JPEG_READING,
  GZILLA_JPEG_DONE
} GzillaJpegState;

/* An implementation of a suspending source manager */

typedef struct {
  struct jpeg_source_mgr pub;   /* public fields */
  struct GzillaJpeg *jpeg;             /* a pointer back to the jpeg object */
} my_source_mgr;

typedef struct GzillaJpeg {
  GzillaImgSink  *imgsink;
  my_source_mgr  Src;

  GzillaJpegState state;
  size_t Start_Ofs, Skip,NewStart;
  char* Data;

  gint y;

  struct jpeg_decompress_struct cinfo;
  struct jpeg_error_mgr jerr;
} GzillaJpeg;

static GzillaJpeg* gzilla_jpeg_new (GzillaImgSink *imgsink);
static void gzilla_jpeg_callback(int, void*, __CacheFile_t* FPtr);


static void gzilla_jpeg_write      (GzillaJpeg *jpeg, __CacheFile_t* FPtr);
static void gzilla_jpeg_close      (GzillaJpeg *jpeg);


Gzw* gzImage_JPEG(const char* Type,void* P, __IOCallback_t* Call, void** Data)
{
  Gzw* child_gzw=NULL;
  GzillaImgSink *imgsink;
  GzillaWeb* web=(GzillaWeb*)P;

  if (web->imgsink)
    imgsink = web->imgsink;
  else {
    imgsink = gzilla_image_new (0, 0, NULL, 0xd6d6d6);
    imgsink->gzw = (GzwImage*) gzw_image_new (GZW_IMAGE_RGB);
  }
  child_gzw = (Gzw*) imgsink->gzw;
  *Data = gzilla_jpeg_new (imgsink);
  *Call=(__IOCallback_t) gzilla_jpeg_callback;
  return child_gzw;
}

static void gzilla_jpeg_close (GzillaJpeg* jpeg) {
  gzilla_imgsink_close(jpeg->imgsink);
  if (jpeg->state != GZILLA_JPEG_DONE)
    jpeg_destroy_decompress (&(jpeg->cinfo));
  g_free(jpeg);
}

static void
init_source (j_decompress_ptr cinfo) {
}

static boolean
fill_input_buffer (j_decompress_ptr cinfo) {
  GzillaJpeg *jpeg = ((my_source_mgr *)cinfo->src)->jpeg;
#ifdef VERBOSE
  g_print("fill_input_buffer\n");
# endif
#if 0
  if (!cinfo->src->bytes_in_buffer)
    {
#ifdef VERBOSE
  g_print ("fill_input_buffer: %d bytes in buffer\n", cinfo->src->bytes_in_buffer);
#endif
       jpeg->Start_Ofs=(unsigned long) jpeg->cinfo.src->next_input_byte -
	 (unsigned long)jpeg->Data;
#endif
   if (jpeg->Skip)
     {
        jpeg->Start_Ofs=jpeg->NewStart+jpeg->Skip-1;
        jpeg->Skip=0;
     }
    else
     {
       jpeg->Start_Ofs=(unsigned long) jpeg->cinfo.src->next_input_byte -
	 (unsigned long)jpeg->Data;
     }
   return FALSE;
#if 0
    }
  return TRUE;
#endif
}

static void
skip_input_data (j_decompress_ptr cinfo, long num_bytes) {
  GzillaJpeg *jpeg;

  if (num_bytes < 1) return;
  jpeg = ((my_source_mgr *)cinfo->src)->jpeg;

#ifdef VERBOSE
  g_print ("skip_input_data: Start_Ofs = %d, num_bytes = %d, %d bytes in buffer\n",
	   jpeg->Start_Ofs, num_bytes, cinfo->src->bytes_in_buffer);
#endif

  cinfo->src->next_input_byte += num_bytes;
  if (num_bytes < cinfo->src->bytes_in_buffer)
    {
      cinfo->src->bytes_in_buffer -= num_bytes;
    } else {
      jpeg->Skip += num_bytes - cinfo->src->bytes_in_buffer+1;
      cinfo->src->bytes_in_buffer = 0;
    }
}

static void
term_source (j_decompress_ptr cinfo) {
}

static GzillaJpeg* gzilla_jpeg_new (GzillaImgSink *imgsink)
{
  GzillaJpeg *jpeg=malloc(sizeof(*jpeg));
  my_source_mgr *src;
  
  jpeg->state = GZILLA_JPEG_INIT;
  jpeg->Start_Ofs=0;
  jpeg->Skip=0;

  jpeg->imgsink = imgsink;
  imgsink->RefCount++;
  imgsink->Parent=&jpeg->imgsink;

  /* decompression step 1 (see libjpeg.doc) */
  jpeg->cinfo.err = jpeg_std_error (&(jpeg->jerr));
  jpeg_create_decompress (&(jpeg->cinfo));

  /* decompression step 2 (see libjpeg.doc) */
  jpeg->cinfo.src = &jpeg->Src.pub;
  src = &jpeg->Src;
  src->pub.init_source = init_source;
  src->pub.fill_input_buffer = fill_input_buffer;
  src->pub.skip_input_data = skip_input_data;
  src->pub.resync_to_restart = jpeg_resync_to_restart; /* use default method */
  src->pub.term_source = term_source;
  src->pub.bytes_in_buffer = 0; /* forces fill_input_buffer on first read */
  src->pub.next_input_byte = NULL; /* until buffer loaded */

  src->jpeg = jpeg;

  /* decompression steps continue in write method */

  return jpeg;
}

void gzilla_jpeg_callback(int Op, void* B, __CacheFile_t* CPtr)
{
   if (Op) gzilla_jpeg_close(B);
   else gzilla_jpeg_write(B,CPtr);
}

static void gzilla_jpeg_write (GzillaJpeg *jpeg, __CacheFile_t* FPtr)
{
  GzillaImgType type;
  char *linebuf;
  JSAMPLE *array[1];
  gint num_read;

#ifdef VERBOSE
  g_print("gzilla_jpeg_write: (0x%lx) Bytes in buff: %ld Ofs: %d\n", jpeg,
	FPtr->Size, jpeg->Start_Ofs);
#endif
  /* See if we are supposed to skip ahead. */
  if (FPtr->Size <= jpeg->Start_Ofs) return;

  /* Concatenate with the partial input, if any. */
  jpeg->cinfo.src->next_input_byte = ((char*)FPtr->Data)+jpeg->Start_Ofs;
  jpeg->cinfo.src->bytes_in_buffer = FPtr->Size-jpeg->Start_Ofs;
  jpeg->NewStart = FPtr->Size;
  jpeg->Data=FPtr->Data;

  /* Process the bytes in the input buffer. */
  if (jpeg->state == GZILLA_JPEG_INIT)
    {

      /* decompression step 3 (see libjpeg.doc) */
      if (jpeg_read_header (&(jpeg->cinfo), TRUE) != JPEG_SUSPENDED)
	{
	  type = GZILLA_IMG_TYPE_GRAY;
	  if (jpeg->cinfo.num_components == 1)
	    type = GZILLA_IMG_TYPE_GRAY;
	  else if (jpeg->cinfo.num_components == 3)
	    type = GZILLA_IMG_TYPE_RGB;
	  else
	    g_print ("jpeg: can't handle %d component images\n",
		     jpeg->cinfo.num_components);
	  gzilla_imgsink_set_parms (jpeg->imgsink,
				    jpeg->cinfo.image_width,
				    jpeg->cinfo.image_height,
				    type);

	  /* decompression step 4 (see libjpeg.doc) */

	  jpeg->state = GZILLA_JPEG_STARTING;
	}
    }

  if (jpeg->state == GZILLA_JPEG_STARTING)
    {
      /* decompression step 5 (see libjpeg.doc) */
      if (jpeg_start_decompress (&(jpeg->cinfo)))
	{
	  jpeg->y = 0;
	  jpeg->state = GZILLA_JPEG_READING;
	}
    }

  if (jpeg->state == GZILLA_JPEG_READING)
    {
      linebuf = g_malloc (jpeg->cinfo.image_width *
			  jpeg->cinfo.num_components);
      array[0] = linebuf;
      while (jpeg->y < jpeg->cinfo.image_height)
	{
	  num_read = jpeg_read_scanlines (&(jpeg->cinfo),
				   array,
				   1);
	  if (num_read == 0)
	    break;
	  gzilla_imgsink_write (jpeg->imgsink,
				linebuf,
				0,
				jpeg->y);
	  jpeg->y++;
	}
      if (jpeg->y == jpeg->cinfo.image_height)
	{
#ifdef VERBOSE
	  g_print("height achieved\n");
#endif
	  jpeg_destroy_decompress (&(jpeg->cinfo));
	  jpeg->state = GZILLA_JPEG_DONE;
	}
      g_free (linebuf);
    }

  if (jpeg->state == GZILLA_JPEG_DONE)
    {
      gzilla_imgsink_close (jpeg->imgsink);
      jpeg->imgsink = NULL;
    }
}

