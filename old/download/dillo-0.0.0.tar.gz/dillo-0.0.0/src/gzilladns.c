/* -------------------------------------------------------------------------
 * Non blocking pthread-handled Dns scheme
 * -------------------------------------------------------------------------
 * by Jorge Arellano Cid <jcid@mailtag.com>
 * Nov, 1999
 *
 * Althought this scheme is based on gzilla's API, it IS a completely new
 * design and a 98% different implementation.
 *
 */

#include <pthread.h>
#include <glib.h>

#include <netdb.h>
#include <sys/types.h>
#include <sys/socket.h> 
#include <netinet/in.h> 
#include <errno.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <signal.h>
#include <string.h>
#include <assert.h>

#include "gzilladns.h"

/*#define VERBOSE 1*/

#ifdef VERBOSE
#  define  SAY(format, args...) fprintf(stderr, format, ##args)
#else
#  define  SAY(format, args...)
#endif


/* Note: comment the following line for debugging or gprof profiling. */
#define G_DNS_THREADED

/* Maximum dns resolving threads */
#ifdef G_DNS_THREADED
#  define G_DNS_MAX_SERVERS 3
#else
#  define G_DNS_MAX_SERVERS 1
#endif


static gboolean Dns_callback(GIOChannel *source,
          GIOCondition condition,
          gpointer data);

typedef struct
{
    gboolean in_use;   /* boolean to tell if server is doing a lookup */
    int pipefd[2];     /* pipefd's to communicate with server */
    char *hostname;    /* Adress to resolve (just a pointer)  */
} DnsServer;

static DnsServer dns_server[G_DNS_MAX_SERVERS];
static int num_servers;

typedef struct
{
   char *hostname;    /* host name for cache */
   guint32 ip_addr;   /* address of host */
} GDnsCache;

static GDnsCache *dns_cache;
static int dns_cache_size, dns_cache_size_max;

typedef struct
{
   gint tag;       /* Not used. Maybe when a_Dns_abort() behavior is defined */
   gint channel;   /* -2 if waiting, otherwise index to dns_server[] */
   char *hostname;
   void (*callback) (int Op, guint32 ip_addr, void *callback_data);
   void *callback_data;
} GDnsQueue;

static GDnsQueue *dns_queue;
static gint dns_queue_size, dns_queue_size_max;


/* ----------------------------------------------------------------------
 *  Queue functions
 */
void Dns_queue_add(gint tag, gint channel, const char *hostname,
     void (*callback) (int Op, guint32 ip_addr, void *callback_data),
     void *callback_data)
{
 if (dns_queue_size == dns_queue_size_max) {
    dns_queue_size_max <<= 1;
    dns_queue = g_realloc (dns_queue, dns_queue_size_max * sizeof(GDnsQueue));
 }
 dns_queue[dns_queue_size].tag = tag;
 dns_queue[dns_queue_size].channel = channel;
 dns_queue[dns_queue_size].hostname = g_strdup (hostname);
 dns_queue[dns_queue_size].callback = callback;
 dns_queue[dns_queue_size].callback_data = callback_data;
 ++dns_queue_size;
}

int Dns_queue_find(const char *hostname)
/* if found, returns queue index; -1 on fault */
{
int i;

 for (i = 0; i < dns_queue_size; i++)
    if ( !strcmp(hostname, dns_queue[i].hostname) )
       return i;

 return -1;
}

void Dns_queue_remove(int index)
{
int i;

 if ( index < dns_queue_size ) {
    --dns_queue_size;    /* you'll find out why ;-) */
    g_free (dns_queue[index].hostname);
    for (i = index; i < dns_queue_size; i++)
        dns_queue[i] = dns_queue[i + 1];
 }
}


/* ----------------------------------------------------------------------
 *  Dns cache functions
 */
void Dns_cache_add(char *hostname, guint32 ip_addr)
{
/* sanity check
int i;

 for (i = 0; i < dns_cache_size; i++)
    if (!strcmp (hostname, dns_cache[i].hostname))
       return;
*/
 if ( dns_cache_size == dns_cache_size_max ) {
   dns_cache_size_max <<= 1;
   dns_cache = g_realloc(dns_cache, dns_cache_size_max * sizeof(GDnsCache));
 }
 dns_cache[dns_cache_size].hostname = g_strdup (hostname);
 dns_cache[dns_cache_size].ip_addr = ip_addr;
 ++dns_cache_size;
 SAY("Cache objects: %d\n", dns_cache_size);
}


/* ----------------------------------------------------------------------
 *  Initializer function
 */

void gzilla_dns_init (void)
{
int i;

 SAY ("gzilla_dns_init: Here we go!\n");
 dns_queue_size = 0;
 dns_queue_size_max = 16;
 dns_queue = g_new (GDnsQueue, dns_queue_size_max);

 dns_cache_size = 0;
 dns_cache_size_max = 16;
 dns_cache = g_new (GDnsCache, dns_cache_size_max);

 num_servers = G_DNS_MAX_SERVERS;

 /* Set stuff to communicate with the servers (pipes and flags) */
 for ( i = 0; i < num_servers; ++i ){
    dns_server[i].in_use   = FALSE;
    dns_server[i].hostname = NULL;
 }
}

/*
 *--------------------------------------------------------------
 * Dns_abort
 * gzilla_dns_abort (until name change)
 *
 * aborts a previous call to a_Dns_lookup().
 * (To be defined)
 *
 * Results:
 *   callback function is not called. (Is this OK? JCID)
 *
 * Side effects:
 * 
 *--------------------------------------------------------------
 */

void
gzilla_dns_abort (guint32 tag)
{
  g_warning ("Dns_abort: CALLED! (this function doesn't work)\n");
  return;
}


/* ----------------------------------------------------------------------
 *  Server function (runs on it's own thread)
 */
void * Dns_server (void *data) {
int h_err;
char buff[1024];
struct hostent *host, sh;
guint32 ip_addr;
int channel, out;
/* sigset_t current_sigs; */

 pthread_sigmask(SIG_BLOCK, NULL, NULL);
/*
 pthread_sigmask(SIG_BLOCK, NULL, &current_sigs);
 pthread_sigmask(SIG_BLOCK, &current_sigs, NULL);
*/
 channel = (int) data;

 SAY("Dns_server: starting...\n channel: %d\n hostname = %s\n",
         channel, dns_server[channel].hostname);

 host  = gethostbyname(dns_server[channel].hostname); 
 /* host = gethostbyname_r(dns_server[channel].hostname, &sh,
                         buff, sizeof(buff), &h_err); */

 if ( host == NULL ) {
    ip_addr = 0;
 } else {
    memcpy(&ip_addr, host->h_addr_list[0], sizeof(ip_addr));
    ip_addr = ntohl(ip_addr);
 }
 
 /* write hostname to client */
 out = dns_server[channel].pipefd[1];
 SAY("Dns_server: IP of %s is %x, pipefd[1] = %d\n",
      dns_server[channel].hostname, ip_addr, out);
 if ( (write(out, &ip_addr, sizeof(ip_addr))) < 0)
    SAY("Dns_server: writing to pipe: %s\n", strerror(errno));
 close(out);

 return data;  /* (avoids a compiler warning) */
}


/* ----------------------------------------------------------------------
 *  Blocking server-function (Doesn't use threads)
 */
void Dns_blocking_server (void) {
struct hostent *host;
guint32 ip_addr;
int index, out;

 index = 0;
 SAY("Dns_blocking_server: starting...\n");
 SAY("Dns_blocking_server: dns_server[%d].hostname = %s\n",
                    index, dns_server[index].hostname);

 host  = gethostbyname(dns_server[index].hostname);
 if ( host == NULL ) {
    SAY("---> Dns_blocking_server: gethostbyname NULL return\n");
    ip_addr = 0;
 } else {
    SAY("---> Dns_blocking_server - good return\n");
    memcpy(&ip_addr, host->h_addr_list[0], sizeof(ip_addr));
    ip_addr = ntohl(ip_addr);
 }
 
 /* write hostname to client */
 out = dns_server[index].pipefd[1];
 SAY("Dns_blocking_server: IP of %s is %x, pipefd[1] = %d\n",
         dns_server[index].hostname, ip_addr, out);
 if ( (write(out, &ip_addr, sizeof(ip_addr))) < 0)
    SAY("Dns_blocking_server: writing to pipe: %s\n",
            strerror(errno));
 close(out);

 SAY("Dns_blocking_server: leaving...\n");
}


/* ----------------------------------------------------------------------
 *  Request function (spawns a server and lets it handle the request)
 */
void 
Dns_server_req (gint channel, const char *hostname) {
#ifdef G_DNS_THREADED
  pthread_t th1;
#endif
GIOChannel *gioch;

  if ( pipe(dns_server[channel].pipefd) != 0 ){
     SAY("Dns_server_req: Error con el pipe()\n");
     return;
  }

  dns_server[channel].in_use = TRUE;

  if ( dns_server[channel].hostname != NULL )
     g_free (dns_server[channel].hostname);
  dns_server[channel].hostname = g_strdup (hostname);

  /* Set the callback to happen within the main thread */
  gioch = g_io_channel_unix_new (dns_server[channel].pipefd[0]);
  g_io_add_watch_full (gioch, G_PRIORITY_DEFAULT,
         G_IO_IN | G_IO_PRI,
         Dns_callback,
         (gpointer) channel,
         NULL);
  g_io_channel_unref (gioch);

  /* Spawn thread */
#ifdef G_DNS_THREADED
  pthread_create(&th1, NULL, Dns_server, (void *) channel);
#else
  Dns_blocking_server();
#endif
}


/*
 *--------------------------------------------------------------
 * a_Dns_lookup
 * gzilla_dns_lookup (until name change)
 *
 * looks up an address and returns a tag for use with
 * gzilla_dns_abort(). [**** NOT DEFINED YET ****]
 *
 * Arguments:
 * char *hostname - hostname to lookup
 * callback - function to call when dns lookup is complete.
 * callback_data - data to pass to this function.
 *   
 * Results:
 * callback function is called.
 * returns -1. ( It's supposed to return a tag suitable for aborting, 
 * but that needs to be defined better before implementing JCID)
 * 
 * Side effects:
 * a thread can be spawned later.
 *
 *--------------------------------------------------------------
 */

guint32 
gzilla_dns_lookup (const char *hostname,
      void (* callback) (int Op, guint32 ip_addr, void *callback_data),
      void *callback_data)
{
int i;
gint channel;

 /* check for cache hit. */
 for (i = 0; i < dns_cache_size; i++)
    if (!strcmp (hostname, dns_cache[i].hostname))
        break;

 /* if it hits already resolved, call the callback inmediately. */
 if ( i < dns_cache_size ) {
    callback (0, dns_cache[i].ip_addr, callback_data);
    return -1; /* formerly 0 */
 }

 if ( (i = Dns_queue_find(hostname)) != -1 ) {
    /* hit in queue, but answer hasn't come back yet. */
    Dns_queue_add(0, dns_queue[i].channel, hostname, callback, callback_data);
 } else {
    /* Never requested before -- we must solve it! */

    /* Find a channel we can send the request to */
    for (channel = 0; channel < num_servers; channel++)
       if ( !dns_server[channel].in_use )
          break;
    if ( channel < num_servers ) {
       /* Found a free channel! */
       Dns_queue_add(0, channel, hostname, callback, callback_data);
       Dns_server_req (channel, hostname);
    } else {
       /* We'll have to wait for a thread to finish... */
       Dns_queue_add(0, -2, hostname, callback, callback_data);
    }
 }

 return -1;
}


/*
 *--------------------------------------------------------------
 * Dns_callback
 *
 * internal function - called when a_Dns_lookup completes. This
 * function dispatches the callback passed to a_Dns_lookup().
 *
 * Arguments:
 * gint server_num - the index into the dns_server struct.
 * gint source - unkown.
 * GdkInputCondition - unkown.
 *   
 * Results:
 *   callback function passed to g_dns_lookup is called.
 *
 * Side effects:
 * this dns_server[server_num]->in_use set to 0 for future lookups.
 * ie, the lock is removed.
 * 
 *--------------------------------------------------------------
 */

gboolean
Dns_callback(GIOChannel *source,
        GIOCondition condition,
        gpointer data)
{
guint32 ip_addr;
gint channel;
gint i, j, k;
int in;

 /* cast channel back */
 channel = (gint) data;

 /* read IP from server.  It's done as a guint32, not as a string */
 in = dns_server[channel].pipefd[0];
 if ( (read(in, &ip_addr, sizeof(guint32))) < 0)
    SAY("Dns_callback: ERROR reading from pipe: %s\n", strerror(errno));
 close(in);

 if ( ip_addr != 0 ) {
    /* DNS succeeded, let's cache it */
    Dns_cache_add(dns_server[channel].hostname, ip_addr);
 }

 /* Give answer to all queue callbacks on this channel */
 for ( i = 0; i < dns_queue_size; i++ ) {
    if ( dns_queue[i].channel == channel ) {
       dns_queue[i].callback ((ip_addr ? 0 : 3), ip_addr,
                              dns_queue[i].callback_data);
       Dns_queue_remove(i);
       --i;
    }
 }

 /* Find the next query in the queue (we're a FIFO) */
 for (j = 0; j < dns_queue_size; j++) 
    if ( dns_queue[j].channel == -2 )
       break;
 if ( j < dns_queue_size ){     /* Found a pending request... */
    /* assign this channel to every queued request with the same hostname */
    for (k = j; k < dns_queue_size; k++)
       if ( !strcmp(dns_queue[j].hostname, dns_queue[k].hostname) )
          dns_queue[k].channel = channel;
    Dns_server_req(channel, dns_queue[j].hostname);
 } else {
    /* free current channel */
    dns_server[channel].in_use = FALSE;
 }

 return FALSE;
}

