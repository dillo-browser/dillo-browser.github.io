/*
  Initialize the MIME type mapper
  Randall Maas
  1999
*/

#include "MIME.h"
void* MIME_type_Items=NULL, *MIME_mtype_Items=NULL;
int MIME_type_NItems=0, MIME_type_NAlloc=0, MIME_mtype_NItems=0,
  MIME_mtype_NAlloc=0;


void MIME_init()
{
  MIME_type_add("image/gif",  gzImage_GIF);
  MIME_type_add("image/jpeg", gzImage_JPEG);
  MIME_type_add("image/jpg", gzImage_JPEG);
  MIME_type_add("text/html",  gzHTML);
  
  /* Add a major type to handle all the text stuff */
  MIME_mtype_add("text", gzPlain);
}

