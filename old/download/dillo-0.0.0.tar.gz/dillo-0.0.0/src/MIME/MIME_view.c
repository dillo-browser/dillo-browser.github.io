/*
   Fetchs the handler for a given MIME type
   Randall Maas
   1999
*/

#include "MIME.h"

Gzw* MIME_view(const char* content_type, void* Ptr, __IOCallback_t* Call,
	      void** Data)
{
  /*
     Description
      Calls the handler for the mime type and sets Call and Data as appropriate
     
     Return Value
      0 on success, otherwise failure
  */

   __View_t VPtr;
   size_t Size=0, Size1=0;
   int SeenSlash=0;
   const char* CPtr=content_type;
   while(*CPtr && *CPtr != ' ' && *CPtr != ';')
     {
	Size++;
	if (!SeenSlash && *CPtr != '/') Size1++;
	if (*CPtr=='/') SeenSlash++;
        CPtr++;
     }

   /* Try explicit type */
   VPtr = MIME_type_fetch(content_type, Size);
   if (VPtr) return VPtr(content_type, Ptr, Call, Data);

   /* Try parent type */
   VPtr = MIME_mtype_fetch(content_type, Size1);
   if (VPtr) return VPtr(content_type, Ptr, Call, Data);

   /* Fail */
fprintf(stderr, "yecky <%s>\n",content_type);
   return NULL;
}

