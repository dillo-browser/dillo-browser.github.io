/*
    MIME type handlers
    Randall Maas
    1999
*/
#ifndef __MIME_h
#define __MIME_h
#include <gtk/gtk.h>
#include "../gzw.h"
#include "../URL/URL_protos.h"
void MIME_init(void);

Gzw* gzHTML (const char* Type, void* web, __IOCallback_t* Call, void** Data);
Gzw* gzPlain(const char* Type, void* web,__IOCallback_t* Call, void** Data);
Gzw* gzImage_JPEG(const char* Type,void* web, __IOCallback_t* Call, void**Data);
Gzw* gzImage_GIF (const char* Type,void* web, __IOCallback_t* Call, void**Data);
Gzw* MIME_view(const char* content_type, void* Ptr,__IOCallback_t* Call,
	       void** Data);

typedef Gzw* (*__View_t) (const char*,void*, __IOCallback_t* Call, void** Data);

extern void* MIME_type_Items, *MIME_mtype_Items;
extern int MIME_type_NItems, MIME_type_NAlloc, MIME_mtype_NItems,
  MIME_mtype_NAlloc;

#ifndef def_MIME_type_add
extern __inline__
#endif
int MIME_type_add(const char* Key, __View_t Method)
{
   return Hdlr_add((void*)&MIME_type_Items, &MIME_type_NItems,&MIME_type_NAlloc,
	Key,Method);
}

#ifndef def_MIME_type_fetch
extern __inline__
#endif
__View_t MIME_type_fetch(const char* Key, size_t Size)
{
   return (__View_t)Hdlr_fetch(MIME_type_Items,MIME_type_NItems, Key,Size);
}

#ifndef def_MIME_mtype_add
extern __inline__
#endif
int MIME_mtype_add(const char* Key, __View_t Method)
{
   return Hdlr_add((void**)&MIME_mtype_Items, &MIME_mtype_NItems,
	&MIME_mtype_NAlloc,Key,Method);
}

#ifndef def_MIME_type_fetch
extern __inline__
#endif
__View_t MIME_mtype_fetch(const char* Key, size_t Size)
{
   return (__View_t)Hdlr_fetch(MIME_mtype_Items,MIME_mtype_NItems, Key,Size);
}
#endif
