/*

 gzilla

 Copyright 1997 Raph Levien <raph@acm.org>

 This code is free for commercial and non-commercial use,
 modification, and redistribution, as long as the source code release,
 startup screen, or product packaging includes this copyright notice.

 */

/* The gif decoder for gzilla. It is responsible for decoding GIF data
   in a bytesink and transferring it to an imgsink.

   Adapted by Raph Levien from giftopnm.c as found in the
   netpbm-1mar1994 release. The copyright notice for giftopnm.c
   follows: */

/* +-------------------------------------------------------------------+ */
/* | Copyright 1990, 1991, 1993, David Koblas.  (koblas@netcom.com)    | */
/* |   Permission to use, copy, modify, and distribute this software   | */
/* |   and its documentation for any purpose and without fee is hereby | */
/* |   granted, provided that the above copyright notice appear in all | */
/* |   copies and that both that copyright notice and this permission  | */
/* |   notice appear in supporting documentation.  This software is    | */
/* |   provided "as is" without express or implied warranty.           | */
/* +-------------------------------------------------------------------+ */


/* Notes 13 Oct 1997

   Today, just for the hell of it, I implemented a new decoder from
   scratch. It's oriented around pushing bytes, while the old decoder
   was based around reads which may suspend. There were basically
   three motivations.

   1. To increase the speed.

   2. To fix some bugs I had seen, most likely due to suspension.

   3. To make sure that the code had no buffer overruns or the like.

   4. So that the code could be released under a freer license.

   Let's see how we did on speed. I used a large image for testing
   (fvwm95-2.gif).

   The old decoder spent a total of about 1.04 seconds decoding the
   image. Another .58 seconds went into gzilla_image_line, almost
   entirely conversion from colormap to RGB.

   The new decoder spent a total of 0.46 seconds decoding the image.
   However, the time for gzilla_image_line went up to 1.01 seconds.
   Thus, even though the decoder seems to be about twice as fast,
   the net gain is pretty minimal. Could this be because of cache
   effects?

   Lessons learned: The first, which I keep learning over and over, is
   not to try to optimize too much. It doesn't work. Just keep things
   simple. 

   Second, it seems that the colormap to RGB conversion is really a
   significant part of the overall time. It's possible that going
   directly to 16 bits would help, but that's optimization again :)


  1999-8-21 RCM: commented the heck out of this, hoping to identify where a
    buffer overrun bug is occuring, and why the UserFriendly comic strip
    doesn't render.
*/

/* Todos:

 + Make sure to handle error cases gracefully (including aborting the
   imgsink, if necessary).

 */

#undef VERBOSE

#include <stdio.h>  /* for sprintf */
#include <string.h> /* for memcpy and memmove */
#include <malloc.h>

#include <gtk/gtk.h>
#include "gzillaimgsink.h"
#include "gzillaweb.h"
#include "MIME/MIME.h"
#include "gzillacache.h"

#define INTERLACE              0x40
#define LOCALCOLORMAP  0x80

#define LM_to_uint(a,b)                        ((((unsigned char)b)<<8)|((unsigned char)a))

/* The private, internal state of the gif byte sink. */
#define        MAXCOLORMAPSIZE         256
#define        MAX_LWZ_BITS            12


typedef struct _GzillaGif {
  GzillaImgSink *imgsink;

  int            state;
  size_t         Start_Ofs;
  unsigned       Flags;

  unsigned char  input_code_size;
  char          *linebuf;
  int            pass;

  int            x, y;

  /* state for lwz_read_byte */
  int		 code_size;

  /* The original GifScreen from giftopnm */
  unsigned int   Width;
  unsigned int   Height;
  size_t	 ColorMap_ofs;
  unsigned int   ColorResolution;
  unsigned       NumColors;
  int   Background;
  unsigned spill_line_index;
#if 0
  unsigned int   AspectRatio;  /* AspectRatio (not used) */
#endif

  /* Gif89 extensions */
  int            transparent;
#if 0
  /* None are used: */
  int            delayTime;
  int            inputFlag;
  int            disposal;
#endif

  /* state for the new push-oriented decoder */
  int           packet_size; /* The amount of the data block left to process*/
  unsigned int  window;
  int           bits_in_window;
  int           last_code;  /* Last "compressed" code in the look up table */
  int           line_index;
  unsigned char  **spill_lines;
  int           num_spill_lines_max;
  int           length[(1 << MAX_LWZ_BITS) + 1];
  int           code_and_byte[(1 << MAX_LWZ_BITS) + 1];
} GzillaGif;

/* Some invariants:

   last_code <= code_mask

   code_and_byte is stored packed: (code << 8) | byte
   */

static void gzilla_gif_write      (GzillaGif *gif, __CacheFile_t*CPtr);
static void gzilla_gif_close      (GzillaGif *gif);

static size_t process_bytes (GzillaGif *gif, const unsigned char *buf,
			   size_t bufsize, __CacheFile_t* FPtr);

static GzillaGif* gzilla_gif_new (GzillaImgSink *imgsink);
static void gzilla_gif_callback(int Op, void* B, __CacheFile_t* CPtr);


Gzw* gzImage_GIF(const char* Type,void*Ptr, __IOCallback_t* Call,
		void**Data)
{
  Gzw* child_gzw=NULL;
  GzillaWeb* web=Ptr;
  GzillaImgSink *imgsink;

  if (web->imgsink)
    {
       imgsink = web->imgsink;
    }
  else {
    imgsink = gzilla_image_new (10, 10, NULL, 0xd6d6d6);
    imgsink->gzw = (GzwImage*) gzw_image_new (GZW_IMAGE_RGB);
  }
  child_gzw = (Gzw*) imgsink->gzw;
  
  *Data = gzilla_gif_new (imgsink);
  *Call=(__IOCallback_t) gzilla_gif_callback;

  return child_gzw;
}

static GzillaGif*
gzilla_gif_new (GzillaImgSink *imgsink)
{
  GzillaGif *gif=malloc(sizeof(GzillaGif));

  gif->imgsink = imgsink;
  imgsink->RefCount++;
  imgsink->Parent=&gif->imgsink;
  gif->Flags = 0;
  gif->state = 0;
  gif->Start_Ofs=0;
  gif->linebuf = NULL;
  gif->Background = -1;
  gif->transparent= -1;
  gif->num_spill_lines_max = 0;
  gif->spill_lines = 0;
  gif->window=0;
  gif->packet_size=0;

#ifdef VERBOSE
  g_print ("new gif %x\n", gif);
#endif

  return gif;
}

void gzilla_gif_callback(int Op, void* B, __CacheFile_t* FPtr)
{
   if (Op) gzilla_gif_close(B);
   else gzilla_gif_write(B,FPtr);
}
  
static void gzilla_gif_write (GzillaGif *gif, __CacheFile_t* FPtr)
{
  char *buf=((char*)FPtr->Data)+gif->Start_Ofs;
  ssize_t bufsize=FPtr->Size-gif->Start_Ofs;
if (!FPtr->Data || !gif->imgsink) return;
if (!gif->imgsink->Parent) abort();
#ifdef VERBOSE
  g_print ("gzilla_gif_write: %d bytes\n", num);
#endif

  /* Process the bytes in the input buffer. */
    if (bufsize <= 0) return;
    {
      ssize_t bytes_consumed = process_bytes (gif, buf, bufsize,FPtr);
      if (bytes_consumed < 1) return;
      gif->Start_Ofs += bytes_consumed;
   }

#ifdef VERBOSE
  g_print ("exit gzilla_gif_write, bufsize=%d\n", bufsize);
#endif
}

static void
gzilla_gif_close (GzillaGif *gif)
{
  int i;

#ifdef VERBOSE
  g_print ("destroy gif %x\n", gif);
#endif
  gzilla_imgsink_close(gif->imgsink);
  gif->imgsink=NULL;
  if (gif->linebuf != NULL)
    free (gif->linebuf);

  if (gif->spill_lines != NULL)
    {
      for (i = 0; i < gif->num_spill_lines_max; i++)
	free (gif->spill_lines[i]);
      free (gif->spill_lines);
    }

   free(gif);
}


/* --- GIF Extensions ---------------------------------------------------------*/

static inline size_t Data_Blocks(const unsigned char* Buf, size_t BSize)
{
   /*
      Description
       This reads a sequence of GIF data blocks.. and ignores them!
       Buf points to the first data block.

      Return Value
       0 = There wasn't enough bytes read yet to read the whole datablock
       otherwise the size of the data blocks
   */

  size_t Size=0;
  if (1 > BSize) return 0;
  while (Buf[0])
   {
      if (BSize <= Buf[0]+1) return 0;
      Size += Buf[0]+1;
      BSize-= Buf[0]+1;
      Buf  += Buf[0]+1;
   }
  return Size+1;
}

static size_t inline do_Generic_Ext(const unsigned char* Buf, size_t BSize)
{
  /*
     Description
       This is a GIF extension.  We ignore it with this routine.
       Buffer points to just after the extension label.

     Return Value
      0 -- block not processed
      otherwise the size of the extension label. 
  */
  size_t Size = Buf[0]+1, DSize;
  /*The Block size (the first byte) is supposed to be a specific size for each
    extension... we don't check.
   */

  if (Buf[0] > BSize) return 0;
  DSize = Data_Blocks(Buf+Size,BSize-Size);
  if (!DSize) return 0;
  Size += DSize;
  return Size <=BSize?Size:0;
}

static inline size_t do_GC_Ext(GzillaGif* gif, const unsigned char* Buf, size_t BSize)
{
   /* Graphic Control Extension */
   size_t Size=Buf[0]+2;
   unsigned Flags;
   if (Size > BSize) return 0;
   Buf++;
   Flags=Buf[0];

   /* The packed fields */
#if 0
   gif->disposal  = (Buf[0] >> 2) & 0x7;
   gif->inputFlag = (Buf[0] >> 1) & 0x1;

   /* Delay time*/
   gif->delayTime = LM_to_uint (Buf[1], Buf[2]);
#endif

   /* Transparent color index, may not be valid  (unless flag is set) */
   if ((Flags & 0x1))  {gif->transparent= Buf[3];}
   return Size;
}

# define App_Ext  (0xff)
# define Cmt_Ext  (0xfe)
# define GC_Ext   (0xf9)
# define Txt_Ext  (0x01)

/* Return TRUE when the extension is over */
static size_t do_extension (GzillaGif *gif, unsigned char Label,
			    const unsigned char *buf,
			    size_t BSize)
{
  switch(Label)
   {
      case GC_Ext: /* Graphics extension */
	return do_GC_Ext(gif, buf,BSize);

      case Cmt_Ext: /* Comment extension */
	return Data_Blocks(buf, BSize);

      case Txt_Ext: /* Plain text Extension */
	/* This extension allows (rcm thinks) the image to be rendered as text.
	 */
      case App_Ext: /* Application Extension */
      default:
	return do_Generic_Ext(buf, BSize); /*Ignore Extension */
   }
}

/* --- General Image Decoder ------------------------------------------------------*/
/* Here begins the new push-oriented decoder. It should be quite a bit
   faster than the old code, which was adapted to be asynchronous from
   David Koblas's original giftopnm code.

 */

static void
gzilla_gif_lwz_init (GzillaGif *gif)
{
  gif->num_spill_lines_max = 1;
  gif->spill_lines = malloc(sizeof(unsigned char *)* gif->num_spill_lines_max);
  gif->spill_lines[0] = malloc(gif->Width);
  gif->bits_in_window = 0;

  /* First code in table = clear_code +1
     Last code in table = first code in table
     clear_code = (1<< input code size)
  */
  gif->last_code = (1 << gif->input_code_size) + 1;
  memset(gif->code_and_byte,0,(1+gif->last_code)*sizeof(gif->code_and_byte[0]));
  gif->code_size = gif->input_code_size + 1;
  gif->line_index = 0;
}

/* Send the image line to the imgsink, also handling the interlacing. */
static void
gzilla_gif_emit_line (GzillaGif *gif, const unsigned char *linebuf)
{
   gzilla_imgsink_write (gif->imgsink, linebuf, 0, gif->y);
  if (gif->Flags & INTERLACE) {
    switch (gif->pass) {
    case 0:
    case 1:
      gif->y += 8;
      break;
    case 2:
      gif->y += 4;
      break;
    case 3:
      gif->y += 2;
      break;
    }
    if (gif->y >= gif->Height) {
      gif->pass++;
      switch (gif->pass) {
      case 1:
	gif->y = 4;
	break;
      case 2:
	gif->y = 2;
	break;
      case 3:
	gif->y = 1;
	break;
      default:
	/* arriving here is an error in the input image. */
	gif->y = 0;
	break;
      }
    }
    
  } else {
    if (gif->y < gif->Height)
      gif->y++;
  }
}

/* Decode the packetized lwz bytes into the image sink.

   I apologize for the large size of this routine and the goto error
   construct - I almost _never_ do that. I offer the excuse of
   optimizing for speed. 

   RCM -- busted these down into smaller subroutines... still very hard to
   read.
*/


static void Literal(GzillaGif* gif, unsigned code)
{
  gif->linebuf[gif->line_index++] = code;
  if (gif->line_index >= gif->Width)
    {
      gzilla_gif_emit_line (gif, gif->linebuf);
      gif->line_index = 0;
    }
  gif->length       [gif->last_code + 1] = 2;
  gif->code_and_byte[gif->last_code + 1] = (code << 8);
  gif->code_and_byte[gif->last_code]    |= code;
}

/* Profiling reveals over half the GIF time is spent here: */
static void Sequence (GzillaGif* gif, unsigned code)
{
  unsigned o_index, o_size, orig_code;
  unsigned char *obuf=NULL;
  unsigned sequence_length = gif->length[code];
  unsigned line_index=gif->line_index;
  int num_spill_lines;
  int spill_line_index=gif->spill_line_index;
  unsigned char *last_byte_ptr;

  gif->length       [gif->last_code + 1] = sequence_length + 1;
  gif->code_and_byte[gif->last_code + 1] = (code << 8);

  /* We're going to traverse the sequence backwards. Thus,
     we need to allocate spill lines if the sequence won't
     fit entirely within the present scan line. */
  if (line_index + sequence_length <= gif->Width)
    {
      num_spill_lines = 0;
      obuf = gif->linebuf;
      o_index = line_index + sequence_length;
      o_size = sequence_length - 1;
    }
  else
    {
      num_spill_lines = (line_index + sequence_length - 1) /
	gif->Width;
      o_index = (line_index + sequence_length - 1) % gif->Width + 1;
      if (num_spill_lines > gif->num_spill_lines_max)
	{
	  /* Allocate more spill lines. */
	  spill_line_index = gif->num_spill_lines_max;
	  gif->num_spill_lines_max = num_spill_lines << 1;
	  gif->spill_lines =
	    g_realloc (gif->spill_lines,
		       gif->num_spill_lines_max *
		       sizeof (unsigned char *));
	  for (; spill_line_index < gif->num_spill_lines_max;
	       spill_line_index++)
	    gif->spill_lines[spill_line_index] =
	      g_malloc(gif->Width);
	}
      spill_line_index = num_spill_lines - 1;
      obuf = gif->spill_lines[spill_line_index];
      o_size = o_index;
    }
  gif->line_index = o_index; /* for afterwards */
  
  /* for fixing up later if last_code == code */
  orig_code = code;
  last_byte_ptr = obuf + o_index - 1;
  
  /* spill lines are allocated, and we are clear to
     write. This loop does not write the first byte of
     the sequence, however (last byte traversed). */
  while (sequence_length > 1)
    {
      sequence_length -= o_size;
      /* Write o_size bytes to
	 obuf[o_index - o_size..o_index). */
      for (; o_size > 0 && o_index>0; o_size--)
	{
	  unsigned code_and_byte = gif->code_and_byte[code];
#ifdef VERBOSE
	  printf ("%d ", gif->code_and_byte[code] & 255);
#endif
	  obuf[--o_index] = code_and_byte & 255;
	  code = code_and_byte >> 8;
	}
      /* Prepare for writing to next line. */
      if (o_index == 0)
	{
	  if (spill_line_index > 0)
	    {
	      spill_line_index--;
	      obuf = gif->spill_lines[spill_line_index];
	      o_size = gif->Width;
	    }
	  else
	    {
	      obuf = gif->linebuf;
	      o_size = sequence_length - 1;
	    }
	  o_index = gif->Width;
	}
    }
  /* Ok, now we write the first byte of the sequence. */
  /* We are sure that the code is literal. */
#ifdef VERBOSE
  printf ("%d", code);
#endif
  obuf[--o_index] = code;
  gif->code_and_byte[gif->last_code] |= code;
  
  /* Fix up the output if the original code was last_code. */
  if (orig_code == gif->last_code) {
    *last_byte_ptr = code;
#ifdef VERBOSE
    printf (" fixed (%d)!", code);
#endif
  }

#ifdef VERBOSE
  printf ("\n");
#endif
  
  /* Output any full lines. */
  o_index=gif->line_index;
  if (gif->line_index >= gif->Width)
    {
      gzilla_gif_emit_line (gif, gif->linebuf);
      gif->line_index = 0;
    }
  if (num_spill_lines)
    {
      if (gif->line_index) gzilla_gif_emit_line (gif, gif->linebuf);
      for (spill_line_index = 0;
	   spill_line_index < num_spill_lines - (o_index?1:0);
	   spill_line_index++)
	gzilla_gif_emit_line
	  (gif, gif->spill_lines[spill_line_index]);
    }
  if (num_spill_lines)
    {
      /* Swap the last spill line with the gif line, using
	 linebuf as the swap temporary. */
      char* linebuf = gif->spill_lines[num_spill_lines - 1];

      gif->spill_lines[num_spill_lines - 1] = gif->linebuf;
      gif->linebuf = linebuf;
    }
  gif->spill_line_index=spill_line_index;
}

static int ProcessCode(GzillaGif* gif, unsigned code, unsigned clear_code)
{
  /*
    Return Value
    2 -- quit
    1 -- new last code needs to be done
    0 -- okay, but reset the code table
     < 0 on error
     -1 if the decompression code was not in the lookup table
  */

  /* A short table describing what to do with the code:
     code < clear_code  : This is uncompressed, raw data
     code== clear_code  : Reset the decmpression table
     code== clear_code+1: End of data stream
     code > clear_code+1: Compressed code; look up in table
  */
  if (code < clear_code)
    {
      /* a literal code. */
#ifdef VERBOSE
      printf ("literal\n");
#endif
      Literal(gif,code);
      return 1;
    }
  else if (code >= clear_code + 2)
    {
      /* a sequence code. */
      if (code > gif->last_code) return -1;
      Sequence(gif,code);
      return 1;
    }
  else if (code == clear_code)
    {
      /* clear code. Resets the whole table */
#ifdef VERBOSE
      printf ("clear\n");
#endif
      return 0;
    }
  else
    {
      /* end code. */
#ifdef VERBOSE
      printf ("end\n");
#endif
#if 0
      gzilla_imgsink_close (gif->imgsink);
      gif->imgsink = NULL;
#endif
      return 2;
    }
}

static int
gzilla_gif_decode (GzillaGif *gif, const unsigned char *buf, size_t BSize)
{
  /* 
     Data block processing.  The image stuff is a series of data blocks.  Each
     data block is 1 to 256 bytes long.  The first byte is the length of the
     data block.  0 == the last data block.
  */
  size_t bufsize, packet_size;
  int clear_code;
  unsigned int window;
  int bits_in_window;
  unsigned code;
  int code_size;
  unsigned code_mask;

  bufsize = BSize;

  /* Want to get all inner loop state into local variables. */
  packet_size = gif->packet_size;
  window = gif->window;
  bits_in_window = gif->bits_in_window;
  code_size = gif->code_size;
  code_mask = (1 << code_size) - 1;
  clear_code = 1 << gif->input_code_size;

  /* If packet size == 0, we are at the start of a data block.
     The first byte of the data block indicates how big it is (0 == last
     datablock)
     packet size is set to this size; it indicates how much of the data block
     we have left to process.
  */
  while (bufsize > 0)
    {
      /* lwz_bytes is the number of remaining lwz bytes in the packet. */
      int lwz_bytes = MIN (packet_size, bufsize);
      bufsize -= lwz_bytes;
      packet_size -= lwz_bytes;
      for (; lwz_bytes > 0; lwz_bytes--)
	{
	  /* printf ("%d ", *buf) would print the depacketized lwz stream. */

	  /* Push the byte onto the "end" of the window (MSB).  The low order
	     bits always come first in the LZW stream. */
	  window = (window >> 8) | (*buf++ << 24);
	  bits_in_window += 8;

	  while (bits_in_window >= code_size)
	    {
	      /* Extract the code.  The code is code_size (3 to 12) bits long,
		 at the start of the window */
	      code = (window >> (32 - bits_in_window)) & code_mask;

	      /* printf ("%d\n", code); would print the code stream. */
#ifdef VERBOSE
	      printf ("last_code = %d, code = %d, ", last_code, code);
#endif
	      bits_in_window -= code_size;
	      switch(ProcessCode(gif, code, clear_code))
	       {
	          case 1: /* Increment last code */
		    gif->last_code++;
		    /*gif->code_and_byte[gif->last_code+1]=0; */
		    
		    if ((gif->last_code & code_mask) == 0)
		      {
			if (gif->last_code == (1 << MAX_LWZ_BITS))
			  gif->last_code--;
			else
			  {
			    code_size++;
			    code_mask = (1 << code_size) - 1;
			  }
		      }
		    break;

	         case 0: /* Reset codes size and mask */
		   gif->last_code = clear_code + 1;
		   code_size = gif->input_code_size + 1;
		   code_mask = (1 << code_size) - 1;
		   break;

	         case 2: /* End code... consume remaining data chunks..? */
		   goto error; /*Could clean up better? */
	         default:
		   printf ("gzilla_gif_decode: error!\n");
		   goto error;
	       }
	    }
	}

      /* We reach here if
	  a) We have reached the end of the data block;
	  b) we ran out of data before reaching the end of the data block
      */
      if (bufsize <= 0) break; /* We are out of data; */

      /* Start of new data block */
      bufsize--;
      if (!(packet_size = *buf++))
	{
	   /* This is the "block terminator" -- the last data block */
	   gif->state =999; /* BUG: should Go back to getting GIF blocks. */
	   break;
	}
    }

  gif->packet_size = packet_size;
  gif->window = window;
  gif->bits_in_window = bits_in_window;
  gif->code_size = code_size;
  return BSize-bufsize;

error:
  gif->state =999;
  return BSize-bufsize;
}

static int check_sig(GzillaGif* gif, const char* ibuf, size_t Size)
{
    /* at beginning of file - read magic number */
    if (Size< 6) return 0;
    if (strncmp (ibuf, "GIF", 3) != 0) {
      gif->state = 999;
      return 6;
    }
    if (strncmp (ibuf+ 3, "87a", 3) != 0 &&
	strncmp (ibuf+ 3, "89a", 3) != 0) {
      gif->state = 999;
      return 6;
    }
    gif->state = 1;
   return 6;
}

static size_t inline do_Color_Table(GzillaGif* gif, __CacheFile_t* FPtr,
				    const unsigned char* Buf,
				    size_t BSize, size_t CT_Size)
{
  /* read the color map

     Implements, from the spec:
       Global Color Table
       Local Color Table
   */
  size_t Size = 3*(1<<(1+CT_Size));

  if (Size > BSize) return 0;

  gif->ColorMap_ofs = (unsigned long)Buf- (unsigned long)FPtr->Data;
  gif->NumColors=(1<<(1+CT_Size));
  return Size;
}

static size_t get_descriptor(GzillaGif* gif, __CacheFile_t* FPtr,
			     const unsigned char* buf,
			     size_t BSize)
{
  /*
     Description
      This implements, from the spec:
        <Logical Screen> ::= Logical Screen Descriptor [Global Color Table]
   */

   /* screen descriptor */
   size_t Size=7; /* Size of descriptor */
   unsigned char Flags;
   if (BSize< 7) return 0;
   Flags = buf[4];

   if (Flags & LOCALCOLORMAP) {
     size_t mysize= do_Color_Table(gif,FPtr,buf+7,BSize-7, Flags&0x7);
     if (!mysize) return 0;
     Size+=mysize; /* Size of the color table that follows */
     gif->Background      = buf[5];
   }

   gif->Width = LM_to_uint(buf[0],buf[1]);
   gif->Height = LM_to_uint(buf[2],buf[3]);
   gif->ColorResolution = (((buf[4]&0x70)>>3)+1);
   /*   gif->AspectRatio     = buf[6]; */

   gif->linebuf = g_malloc(gif->Width);
   gzilla_imgsink_set_parms (gif->imgsink, gif->Width, gif->Height,
			      GZILLA_IMG_TYPE_INDEXED);
   return Size;
}

/* Image Descriptor && Start of Table Based Image Data */
static size_t do_Img_Desc(GzillaGif* gif, __CacheFile_t* FPtr,
			  const unsigned char* Buf,size_t BSize)
{
   /*
      Description
       Buf points to just after the Image separator

       This implements, from the spec:
        <Table-Based Image> ::= Image Descriptor [Local Color Table] Image Data

       we should probably just check that the local stuff is consistent
       with the stuff at the header. For now, we punt... 
   */
   unsigned char Flags;
   size_t Size=9+1; /* Size of image descriptor + first byte of image data */

   if (BSize < 10) return 0;
   Flags=Buf[8];

   gif->Flags |= Flags & INTERLACE;
   gif->pass = 0;
   BSize-=9;
   Buf  +=9;
   if (Flags & LOCALCOLORMAP)
     {
        size_t LSize = do_Color_Table(gif,FPtr, Buf,BSize, Flags&0x7);
	if (!LSize) return 0;
	Size += LSize;
	Buf  += LSize;
	BSize-= LSize;
     }

   /* Finally, get the first byte of the LZW image data */
   if (BSize < 1) return 0;
   gif->input_code_size = *Buf++;
   if (gif->input_code_size > 8)
     {
        gif->state = 999;
	return Size;
     }
   gif->x = 0;
   gif->y = 0;
   gzilla_gif_lwz_init (gif);
   gif->spill_line_index=0;
   gif->state=3; /*Process the lzw data next */
   if (gif->imgsink && gif->ColorMap_ofs)
     gzilla_imgsink_set_cmap (gif->imgsink,
			      (unsigned char*)FPtr->Data+gif->ColorMap_ofs,
				gif->NumColors,
		/* RCM: wish there was a better way to handle both Background
			and tranparency */
			      gif->transparent);
   return Size;
}

/* --- Top level data block processors -------------------------------------- */
# define Img_Desc (0x2c)
# define Trailer  (0x3B)
# define Ext_Id   (0x21)
static size_t GIF_Block(GzillaGif* gif, __CacheFile_t* FPtr,
			const unsigned char* Buf, size_t BSize)
{
   /*
      Description
       This identifies which kind of GIF blocks are next, and processes them.
       It returns if there isn't enough data to process the next blocks, or if
       the next block is the lzw data (which is streamed differently)

       This implements, from the spec, <Data>* Trailer
         <Data> ::= <Graphic Block> | <Special-Purpose Block>
	 <Special-Purpose Block> ::= Application Extension | Comment Extension
	 <Graphic Block> ::= [Graphic Control Extension] <Graphic-Rendering Block>
	 <Graphic-Rendering Block> ::= <Table-Based Image> | Plain Text Extension

	<Data>* --> GIF_Block
	<Data>  --> while (...)
	<Special-Purpose Block> --> do_extension
	Graphic Control Extension --> do_extension
	Plain Text Extension --> do_extension
	<Table-Based Image> --> do_Img_Desc

      Return Value
       0 if not enough data is present, otherwise the number of bytes
       "consumed"
   */
  size_t Size=0,mysize;
  unsigned char C;

  if (BSize < 1) return 0;
  while(gif->state == 2)
    {
       if (BSize < 1) return Size;
       BSize--;
       switch(*Buf++)
	{
           case Ext_Id:
	     /* get the extension type */
	     if (BSize < 2) return Size;
	  
	     /* Have the extension block intepreted. */
	     C = *Buf++;
	     BSize--;
	     mysize = do_extension (gif, C, Buf, BSize);

	     if (!mysize)
	       /* Not all of the extension is there.. quit until more data
		  arrives*/
	       return Size;
	  
	     BSize -= mysize;
	     Buf += mysize;
	     
	     /* Increment the amount consumed by the extension introducer
		and id, and extension block size */
	     Size +=mysize+2;
	     /* Do more GIF Blocks */
	     continue;

	   case Img_Desc: /* Image descriptor */
	     mysize=do_Img_Desc(gif,FPtr, Buf,BSize);
	     if (!mysize) return Size;
	     
	     /* Increment the amount consumed by the Image Separator and the
		Resultant blocks */
	     Size += 1+mysize;
	     return Size;

	   case Trailer:
	     gif->state=999; /* BUG: should close the rest of the file */
	     return Size+1;
	     break; /* GIF terminator */

	   default: /* Unknown */
	     /* BUG: we should gripe and complain 
		fprintf(stderr,"0x%x\n", *(Buf-1)); */
		gif->state=999;
		return Size+1;
	}
   }
  return Size;
}


/* Process some bytes from the input gif stream. It's a state machine.

   From the GIF spec:
       <GIF Data Stream> ::= Header <Logical Screen> <Data>* Trailer
  
   <GIF Data Stream> --> process_bytes
   Header            --> State 0
   <Logical Screen>  --> State 1
   <Data>*           --> State 2
   Trailer           --> State > 3

   State == 3 is special... this is inside of <Data> but all of teh stuff in
      there has been gotten and set up.  So we stream it outside.
*/
static size_t process_bytes (GzillaGif *gif, const unsigned char *ibuf, size_t bufsize, __CacheFile_t* FPtr) {
  int tmp_bufsize=bufsize;
  size_t mysize;

  switch (gif->state) {
  case 0: mysize=check_sig(gif,ibuf,tmp_bufsize);
	if (!mysize) break;
	tmp_bufsize-= mysize;
	ibuf+= mysize;
	if (gif->state !=1) break;
	
  case 1: mysize=get_descriptor(gif,FPtr, ibuf,tmp_bufsize);
	if (!mysize) break;
	tmp_bufsize-= mysize;
	ibuf+= mysize;
	gif->state =2;
	
  case 2:
    /* Ok, this loop construction looks weird.  It implements the <Data>* of
       the GIF grammar.  All sorts of stuff is allocated to set up for the
       decode part (state ==2) and then there is the actual decode part (3)
    */
      mysize=GIF_Block(gif,FPtr, ibuf,tmp_bufsize);
      if (!mysize) break;
      tmp_bufsize -= mysize;
      ibuf += mysize;
      if (gif->state != 3) break;
      
  case 3:
      /* get an image byte */
      /* The users sees all of this stuff */
      mysize = gzilla_gif_decode (gif, ibuf, tmp_bufsize);
      if (mysize == 0) break;
      ibuf        += mysize;
      tmp_bufsize -= mysize;

  default:
    /* error - just consume all input */
    tmp_bufsize=0;
    break;
  }
#ifdef VERBOSE
  printf ("process_bytes: initial state %d, final state %d, %d bytes consumed\n",
	  initial_state, gif->state, bufsize - tmp_bufsize);
#endif
  return bufsize - tmp_bufsize;
}
