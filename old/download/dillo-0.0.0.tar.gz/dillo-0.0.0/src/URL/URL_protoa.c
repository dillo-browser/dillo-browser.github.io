#define def_URL_proto_add
#include "URL_protos.h"

int UM_NItems=0, UM_NAlloc=0;
void* UM_Items=NULL;
