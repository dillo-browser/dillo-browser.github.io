 /*

 gzilla

 Copyright 1997 Raph Levien <raph@acm.org>

 This code is free for commercial and non-commercial use,
 modification, and redistribution, as long as the source code release,
 startup screen, or product packaging includes this copyright notice.

 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>            /* for errno */

#include <sys/types.h>
#include <sys/wait.h>

/* This module handles the Gzilla plug-in api. */

/* todo: get abort to work. */

typedef struct _GzillaProto GzillaProto;

struct _GzillaProto {
  const char *prefix;
  const char *handler;
};

static GzillaProto plugins[] = {
  { "test:", "/home/raph/gzilla/get_test" },
  { "ftp:", "/home/raph/gzilla/get_ftp" }
};

static int 
gzilla_proto_prefix (const char *url, const char *prefix)
{
  return !strncmp (url, prefix, strlen (prefix));
}

/* Find the plug-in number to handle a given URL, or -1 if there is no
   plug-in for it. */

static int
gzilla_proto_find (const char *url)
{
  int i;

  for (i = 0; i < sizeof (plugins) / sizeof (GzillaProto); i++)
    if (gzilla_proto_prefix (url, plugins[i].prefix))
      return i;
  return -1;
}

#define MAX_ENV 32

static void
gzilla_proto_build_env (char **env, const char*url)
{
  char* PATH=getenv("PATH");
  int val1_len=strlen(PATH),val2_len=strlen(url);
  int Len = sizeof("PATH")+sizeof("REQUEST_URI")+val1_len+val2_len+4;
  char* buf = malloc (Len);

  env[0]= buf;
  memcpy (buf, "PATH", 4);
  buf[5] = '=';
  memcpy(buf+6, PATH, val1_len);
  buf[6 + 1 + val1_len] = '\0';
  buf = buf+6+2+val1_len;
  env[1]= buf;
  memcpy (buf, "REQUEST_URI", 11);
  buf[12] = '=';
  memcpy(buf+13, url, val2_len);
  buf[13 + 2 + val2_len] = '\0';
}

int 
gzilla_proto_get_url (const char *url, int FD_TypeWrite)
{
  char *env[MAX_ENV];
  int env_index = 0;
  pid_t child_pid;
  int filedes[2];
  int proto_num = gzilla_proto_find (url);
  if (proto_num <0) return -1;

  gzilla_proto_build_env(env, url);

  env[env_index] = NULL;

  if (pipe (filedes) != 0)       return -1;
  if ((child_pid = fork ()) < 0) return -1;

  if (!child_pid) {
    /* this is the child */

    /* redirect stdout to the pipe we just created */
    if (close (STDOUT_FILENO) != 0)
#ifdef VERBOSE
      g_error ("gzilla_proto_get_url: error closing stdout\n")
#endif
	;
    if (dup (filedes[1]) != STDOUT_FILENO)
#ifdef VERBOSE
      g_error ("gzilla_proto_get_url: error in dup call for stdout\n")
#endif
	;
    close (filedes[0]);
    close (filedes[1]);

#if 0
    {
      int i = 0;

      fprintf (stderr, "proto_num = %d, %s\n",
	       proto_num, plugins[proto_num].handler);
      while (env[i])
	fprintf (stderr, "%s\n", env[i++]);
    }
#endif

    execle (plugins[proto_num].handler,
	    plugins[proto_num].handler,
	    (char *)NULL,
	    env);
    
    _exit(-1);
  }

  /* this is the parent */

  /* set nonblocking */
  fcntl (filedes[0], F_SETFL, O_NONBLOCK | fcntl(filedes[0], F_GETFL));

  /* set close-on-exec */
  fcntl (filedes[0], F_SETFD, FD_CLOEXEC | fcntl(filedes[0], F_GETFD));

  close (filedes[1]);
  free(env[0]); free(env[1]);
  return filedes[0];
}
