/*
   Get a handler by name from a table
   Randall Maas
   1999
*/
#include <stdio.h>
#include <string.h>
typedef struct
{
   const char* Name;
   void (*Data)();
} _Hdlr_t;

int Hdlr_cmp(_Hdlr_t* IPtr, const char* Key, size_t Size)
{
   return strncasecmp(Key, IPtr->Name, Size) || IPtr->Name[Size];
}

void (*Hdlr_fetch(void* _IPtr,int NItems,const char* Key, size_t Size))
{
   int I;
   _Hdlr_t* IPtr=_IPtr;
   for (I = 0; I < NItems; I++,IPtr++)
    {
       if (Hdlr_cmp(IPtr,Key,Size)) continue;
       return IPtr->Data;
    }
   return NULL;
}

