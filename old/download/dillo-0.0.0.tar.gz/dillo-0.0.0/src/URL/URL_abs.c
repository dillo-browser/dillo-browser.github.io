#define def_URL_is_absolute
#include "URL_protos.h"

