/*
    Dynamic URL opener
    Randall Maas
    1999
*/
#include "URL_protos.h"
#include <malloc.h>
#include <glib.h>

static int UF_NItems=0,UF_NAlloc=0;
static __Open_t* UF_Items=NULL;
int URL_open_add(__Open_t F)
{
   /*
      Description
       Adds the method @var{F} to the list of URL openers.  it will be called
       before any others are attempted.  @var{F} needs to return -1 if it fails.
	@var{F} must ensure that it closes the FD_TypeWriter when it iis done
	with it.

      Return Value
	-1 on error, 0 otherwise
    */
   if (UF_NItems >= UF_NAlloc)
     {
        int NAlloc = UF_NAlloc? UF_NAlloc<<1:8;
        UF_Items = g_realloc(UF_Items, NAlloc*sizeof(UF_Items[0]));
        if (!UF_Items) {UF_NAlloc=0;return -1;}
        UF_NAlloc=NAlloc;
     }
   
   UF_Items[UF_NItems++]=F;
   return 0;
}

int URL_open (const char *url, void* Data)
{
   /*
      Description
       This attempts to open the URL.

      Return Value
       < 0 on error, otherwise the file descriptor with the data segment
    */
   __Open_t* IPtr = &UF_Items[UF_NItems-1]; 
   int I;
   for (I = UF_NItems; I; I--, IPtr--)
    {
       int FD= (*IPtr)(url, Data);
       if (FD < 0) continue;
	FD_bkgnd(FD);
	return FD;
    }
   return -1;
}

