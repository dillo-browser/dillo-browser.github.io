/*
    GZilla's URL methods
    Randall Maas
    1999

*/
#ifndef __URL_protos_h
#define __URL_protos_h
# include "../../config.h"
# include <stdio.h> /* for sprintf */
# include <ctype.h> /* for isalpha */
# include <string.h> /* for strcmp */
# if defined(HAVE_UNISTD_H) && HAVE_UNISTD_H
#  include <unistd.h>
# endif

# ifdef __GNUC__
#  define FUNC __attribute__((__const__))
# endif
# define URN_OTHER  "()+,-.:=@;$_!*'/%?"

extern int   Hdlr_add  (void**IPtr,int*NItems,int* NAlloc,const char*,void*);

#include "../gzillacache.h"
#include "../gzillaweb.h"
#include "../IO/GzIO.h"

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

extern int     URL_is_absolute (const char *url)                      FUNC;
extern ssize_t URL_proto_parse (const char *URL, const char **Method) FUNC;
extern char*   URL_parse_hash  (const char *URL)                      FUNC;

/* Returns a file descriptor to read data on; meta data is sent on FD_TypeWrite */
typedef int (*__Open_t) (const char *url, void*);
extern int URL_open    (const char *url, void* Callback_Data);
extern int URL_open_add(__Open_t F);
extern int URL_init(void);

extern char* HTTP_Proxy,* No_Proxy;

extern int gzilla_URL_open (const char *url, void*);
extern int gzilla_proto_get_url(const char *url, void*);
extern int gzilla_about_get    (const char *url, void*);
extern int gzilla_file_get     (const char *url, void*);
extern int gzilla_http_get     (const char *url, void*);
extern __Open_t gzilla_URL_method_fetch(const char* Method, size_t Size);
extern void* Hdlr_fetch(void* IPtr,int NItems,const char* Key, size_t Size);
extern int Gz_File_Not_Found(const char *filename, void* Web);

extern void* UM_Items;
extern int UM_NItems, UM_NAlloc;

#ifndef def_URL_proto_add
extern __inline__
#endif
int URL_proto_add(const char* Key, __Open_t Method)
{
   return Hdlr_add(&UM_Items, &UM_NItems,&UM_NAlloc,Key,Method);
}

#ifndef def_URL_proto_fetch
extern __inline__
#endif
__Open_t URL_proto_fetch(const char* Key, size_t Size)
{
   return (__Open_t)Hdlr_fetch(UM_Items,UM_NItems, Key,Size);
}

#ifndef def_URL_proto_parse
extern __inline__
#endif
ssize_t URL_proto_parse (const char *URL, const char **Method)
{
   /*
      Description
       This identifies the method specified in the URL.  
       On success, Method is set to point the start of the method string; it is
       @emph{not} a zero terminated string.

      Return Value
       < 1 on error, otherwise the length of the method string.
    */

  char* EPtr=strpbrk(URL,URN_OTHER);
  if (!EPtr || *EPtr != ':') return 0;
  *Method = URL;

  return (unsigned long)EPtr-(unsigned long)URL;
}

#ifndef def_URL_is_absolute
extern __inline__
#endif
int URL_is_absolute (const char *url)
{
  /*
     Description
      This routine checks to see if the URL passed is of the absolute form, or
      of the relative form

     Return Value
      0 is not absolute, otherwise is absolute
  */
  const char* P = strpbrk(url, URN_OTHER);
  return (P && *P == ':'); 
}

#ifndef def_URL_parse_hash
extern __inline__
#endif
char* URL_parse_hash (const char *URL) 
{
   /*
      Description
        Parse "http://a/b#c" into "http://a/b" and "#c".

      Return Value
       a pointer to the hash (if any), otherwise NULL.
   */

  /* todo: I haven't checked this for standards compliance. What's it
     supposed to do when there are two hashes? */

  return strchr(URL, '#');
}


#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif
