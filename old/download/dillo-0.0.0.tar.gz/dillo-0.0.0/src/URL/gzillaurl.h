#ifndef __Gzilla_URL_H__
#define __Gzilla_URL_H__

#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

int gzilla_url_relative (const char *base_url,
			  const char *relative_url,
			  char *new_url,
			  int size_new_url);
char *gzilla_url_parse (const char *url,
			char *hostname,
			int hostname_size,
			int *port);


#ifdef __cplusplus
}
#endif /* __cplusplus */


#endif /* __GTK_WEB_H__ */
