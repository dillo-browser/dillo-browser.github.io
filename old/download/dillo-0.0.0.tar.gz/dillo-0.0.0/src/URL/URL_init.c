/*
   Initialize the URL modules
   Randall Maas
   1999
*/
#include <stdlib.h>
#include "URL_protos.h"

char* HTTP_Proxy=NULL, *No_Proxy=NULL;

int URL_init(void)
{
   HTTP_Proxy=getenv("http_proxy");
   No_Proxy=getenv("no_proxy");
   if (URL_open_add(gzilla_proto_get_url)||
       URL_open_add(gzilla_URL_open)	  ||
       URL_proto_add("file",gzilla_file_get)||
       URL_proto_add("about",gzilla_about_get)||
       URL_proto_add("http",gzilla_http_get))
	return -1;
   return 0;
}
