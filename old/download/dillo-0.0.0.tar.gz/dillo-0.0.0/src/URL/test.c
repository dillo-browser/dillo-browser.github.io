#include "URL_protos.h"
int gzilla_socket_new() {return -1;}
void Callback(int Op, void* CData, char* Data, size_t Size)
{
  write(2, Data, Size);
}

int main(int argc, char** argv)
{
   int FD,size;
   char buf[512];
   if (URL_init()) {fprintf(stderr, "init failed!\n");}
     else {fprintf(stderr, "init succeeded!\n");}

   FD = URL_open("file:./src",Callback,NULL);
   if (FD < 0) {fprintf(stderr, "failed\n"); exit(-1);}
   while ((size=read(FD,buf,sizeof(buf)))>0) 
    write(1,buf,size);
   close(FD);

   FD = URL_open("file:URL_methods.h",Callback,NULL);
   if (FD < 0) {fprintf(stderr, "failed\n"); exit(-1);}
   while ((size=read(FD,buf,sizeof(buf)))>0) 
    write(1,buf,size);
   close(FD);


  //should fail
   FD = URL_open("file:URL_methods.c",Callback,NULL);
   if (FD < 0) {fprintf(stderr, "failed\n"); exit(-1);}
   while ((size=read(FD,buf,sizeof(buf)))>0) 
    write(1,buf,size);
   close(FD);

  //should redirect 
   FD = URL_open("about:gzilla",Callback, NULL);
   if (FD < 0) {fprintf(stderr, "failed\n"); exit(-1);}
   while ((size=read(FD,buf,sizeof(buf)))>0) 
    write(1,buf,size);
   close(FD);

   // need brains
   FD = URL_open("http://www.gzilla.org/",Callback, NULL);
   if (FD < 0) {fprintf(stderr, "failed\n"); exit(-1);}
   while ((size=read(FD,buf,sizeof(buf)))>0) 
    write(1,buf,size);
   close(FD);
   return 0;
}
