#include <stdlib.h> /* for atoi */

#include "gzillaurl.h"
#include "URL_protos.h"

/* Return TRUE if the method matches. */
static int URL_match_method (const char *url, const char *method,
                                    size_t Method_Size) FUNC;
static int URL_match_method (const char *url, const char *method,
                                    size_t Method_Size)
{
   if (strncasecmp(url, method, Method_Size)) return 0;
   return (url[Method_Size] == ':');
}

# define HTTP "http"

/* Add the trailing slash if necessary. Return FALSE if there isn't room. */
static int gzilla_url_add_slash (char *url, int size_url) {
  char *tail;

  if (!URL_match_method (url, HTTP, sizeof(HTTP)-1) &&
      !URL_match_method (url, "ftp",sizeof("ftp")-1)) return 1;

  tail = gzilla_url_parse (url, NULL, 0, NULL);
  if (tail == NULL)
    return 1;
  if (tail[0] == '\0') {
    if (strlen (url) + 1 == size_url)
      return 0;
    tail[0] = '/';
    tail[1] = '\0';
  }

  return 1;
}

/* Resolve a relative url. Return FALSE if size_new_url is inadequate */
int gzilla_url_relative (const char *base_url,
                          const char *relative_url,
                          char *new_url,
                          int size_new_url) {
  int i, j, k;
  int num_dotdot;

  if (base_url == NULL || URL_is_absolute (relative_url)) {
    if (strlen (relative_url) >= size_new_url)
      return 0;
    strcpy (new_url, relative_url);
    return gzilla_url_add_slash (new_url, size_new_url);
  }

  /* Assure that we have enough room for at least the base URL. */
  if (strlen (base_url) >= size_new_url)
    return 0;

  /* Copy http://hostname:port/ from base_url to new_url */
  i = 0;
  if (URL_match_method (base_url, HTTP, sizeof(HTTP)-1) ||
      URL_match_method (base_url, "ftp",sizeof("ftp")-1)) {
    for(;base_url[i] != '\0' && base_url[i] != ':';i++)
      new_url[i] = base_url[i];
    if (base_url[i] != '\0')
      {new_url[i] = base_url[i]; i++;}
    if (base_url[i] != '\0')
      {new_url[i] = base_url[i]; i++;}
    if (base_url[i] != '\0')
      {new_url[i] = base_url[i]; i++;}
    while (base_url[i] != '\0' && base_url[i] != '/')
      {new_url[i] = base_url[i]; i++;}
  } else {
    while (base_url[i] != '\0' && base_url[i] != ':')
      {new_url[i] = base_url[i]; i++;}
    if (base_url[i] != '\0')
      {new_url[i] = base_url[i]; i++;}
  }

  if (relative_url[0] == '/') {
    if (i + strlen (relative_url) >= size_new_url)
      return 0;
    strcpy (new_url + i, relative_url);
    return gzilla_url_add_slash (new_url, size_new_url);
  }

  /* At this point, i points to the first slash following the hostname
     (and port) in base_url. */

  /* Now, figure how many ..'s to follow. */
  num_dotdot = 0;
  j = 0;
  while (relative_url[j] != '\0') {
    if (relative_url[j] == '.' &&
        relative_url[j + 1] == '/') {
      j += 2;
    } else if (relative_url[j] == '.' &&
               relative_url[j + 1] == '.' &&
               relative_url[j + 2] == '/') {
      j += 3;
      num_dotdot++;
    } else {
      break;
    }
  }

  /* Find num_dotdot+1 slashes back from the end, point k there. */

  for (k = strlen (base_url); k > i && num_dotdot >= 0; k--)
    if (base_url[k - 1] == '/')
      num_dotdot--;

  if (k + 1 + strlen (relative_url) - j >= size_new_url)
    return 0;

  for(;i < k;i++)
    new_url[i] = base_url[i];
  if (relative_url[0] == '#')
    while (base_url[i] != '\0')
      {new_url[i] = base_url[i]; i++;}
  else if (base_url[i] == '/' || base_url[i] == '\0')
    new_url[i++] = '/';
  strcpy (new_url + i, relative_url + j);
  return gzilla_url_add_slash (new_url, size_new_url);
}

/* Parse the url, packing the hostname and port into the arguments, and
   returning the suffix. Return NULL in case of failure. */

char *gzilla_url_parse (const char *url,
                        char *hostname,
                        int hostname_size,
                        int *port) {
  const char* CPtr = index(url,':');
  char* C1Ptr;
  size_t Size;

  if (!CPtr || *CPtr != ':' || CPtr[1] != '/' || CPtr[2] != '/') 
     return NULL;

  CPtr += 3;
  if ( !(C1Ptr = strpbrk(CPtr, ":/")) )
    {
       Size = strlen(CPtr);
       if (!hostname) return (char*) CPtr+Size;
       if (Size >= hostname_size) return NULL;
       strncpy (hostname, CPtr, Size); hostname[Size] = '\0';
       return (char*) CPtr+Size;
    }

  Size = (unsigned long)C1Ptr-(unsigned long)CPtr;
  if (hostname)
    {
      if (Size >= hostname_size) return NULL;
      strncpy (hostname, CPtr, Size); hostname[Size] = '\0';
    }
  if (*C1Ptr != ':') return (char*) C1Ptr;

  if (port) *port = strtoul(++C1Ptr,&C1Ptr,0);
   
  for (; *C1Ptr && *C1Ptr != '/'; C1Ptr++);
  return C1Ptr;
}

#ifdef UNIT_TEST
/* Unit test as follows:

   gcc -g -I/usr/local/include/gtk -DUNIT_TEST gzillaurl.c -o gzillaurl
   ./gzillaurl base_url relative_url

*/

int main (int argc, char **argv) {
  char buf[80];
  char hostname[80];
  char *tail;
  int port;

  if (argc == 3) {
    if (gzilla_url_relative (argv[1], argv[2], buf, sizeof(buf))) {
      printf ("%s\n", buf);
      port = 80;
      tail = gzilla_url_parse (buf, hostname, sizeof (hostname), &port);
      if (tail != NULL) {
        printf ("hostname = %s, port = %d, tail = %s\n", hostname, port, tail);
      }
    } else {
      printf ("buffer overflow!\n");
    }
  } else {
    printf ("Usage: %s base_url relative_url\n", argv[0]);
  }
  return 0;
}
#endif
