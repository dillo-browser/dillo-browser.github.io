/*
    Add a generic handler
    Randall Maas
    1999
*/
#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include <glib.h>
typedef struct
{
   const char* Name;
   void* Data;
} _Hdlr_t;

int Hdlr_add(void**_IPtr,int*NItems, int* NAlloc, const char* Name, int*Data)
{

   /*
      Description
       This procedure inserts an item (@var{_Item}) into a table (@var{*_IPtr}).
       The table itself has a number of items (@var{*NItems}), this number will
       be incremented to reflect the additional item.  @var{*NAlloc} is the
       number of slots in the table that has been preallocated to store items.
       
       If there are no free slots in the table, the table will be resized,
	and @var{*_IPtr} will be changed.  

      Return Value
       -1 on error, 0 on success.
     */

   _Hdlr_t** IPtr=(_Hdlr_t**)_IPtr;

   /* Resize the table if it has not been allocated yet, or if there are no
      free items.  The number of free items is equal to
	 the Number Allocated (@var{*NAlloc}) - Number Used (@var{*NItems}).
    */
   if (!*IPtr || *NItems >= *NAlloc)
     {
        int N= *NAlloc? ((*NAlloc)<<1):8;
	void* NIPtr;
        NIPtr = g_realloc(*IPtr, N*sizeof(_Hdlr_t));
        if (!NIPtr) {return -1;}
	*IPtr = NIPtr;
        *NAlloc=N;
     }
   
   (*IPtr)[*NItems].Name=Name;
   (*IPtr)[*NItems].Data=Data;
   *NItems +=1;
   return 0;
#ifdef realsoonnow
   g_cache_new(New,,NULL,NULL,Hdlr_cmp);
#endif
}

