/*

 gzilla

 Copyright 1997 Raph Levien <raph@@acm.org>

 This code is free for commercial and non-commercial use,
 modification, and redistribution, as long as the source code release,
 startup screen, or product packaging includes this copyright notice.

 */

#include "URL_protos.h"
int gzilla_about_get (const char *url, void* Data)
{
  char *loc;
  const char *tail;

  tail = url + 6; /* strlen ("about:") */
  if (!strcmp (tail, "jwz"))
    loc = "http://www.jwz.org/";
  else if (!strcmp (tail, "raph"))
    loc = "http://www.levien.com/";
  else if (!strcmp (tail, "yosh"))
    loc = "http://yosh.gimp.org/";
  else if (!strcmp (tail, "snorfle"))
    loc = "http://www.snorfle.net/";
  else loc = "http://www.excite.com/";

  gzilla_web_redirect(Data, loc);
  return -1;
}
