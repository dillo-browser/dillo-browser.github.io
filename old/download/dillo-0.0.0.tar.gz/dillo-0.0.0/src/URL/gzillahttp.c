/*

 gzilla

 Copyright 1997 Raph Levien <raph@acm.org>

 This code is free for commercial and non-commercial use,
 modification, and redistribution, as long as the source code release,
 startup screen, or product packaging includes this copyright notice.

 */


/* todo: make error messages more descriptive. */

#include <unistd.h>

#include <errno.h>            /* for errno */
#include <string.h>           /* for strstr */
#include <malloc.h>
#include <stdlib.h>
#include <search.h>
#include <signal.h>
#include <fcntl.h>
#include <sys/wait.h>
#include "../IO/LDL.h"
#include "URL_protos.h"

#include "gzillaurl.h"
#include "../gzillasocket.h"

typedef struct __Info_t
{
   struct __Info_t *q_forw,*q_back;
   void* WData;
   char* Query;
} __Info_t;

static struct qelem IQue={&IQue,&IQue};

/* The callback for socket setup. This function gets called whenever
   the socket setup completes. Install the input handler for writing
   the query string to the socket. */

static void gzilla_http_callback (int Op, int FD_Sock, void* VPtr)
{
   /* Send the header stuff of to the Type channel, this is somewhat expensive
       since we are doing a lot of kernel calls to do this safely
     */
   __Info_t* IPtr=(__Info_t*) VPtr;

   char errmsg[128];

   /* This could take a while to get the query /back/... So we need to do
	something.. Alas, not much can be done right yet. */
   if (Op)
     {
       if (IPtr->Query)
	 {
	   free(IPtr->Query);
	   IPtr->Query=NULL;
	 }

	/* Let the user know it is a sad day */
	sprintf(errmsg,"Couldn't connect: %s",strerror(errno));
        gzilla_web_status(IPtr->WData,errmsg);
        /* Free this info node */
        LDL_append((struct qelem*)IPtr, &IQue);
	close(FD_Sock);
	return;
     }

   /* Send the query out... */
   FD_bkgnd(FD_Sock);
   if (IPtr->Query)
     {
	size_t Size=strlen(IPtr->Query);
	/* Make this a background IO */
	GzIO_submit(FD_Sock, 1, IPtr->Query, Size);	
	/* Bug IPtr is never freed! */
     }
   gzilla_cache_tmp(FD_Sock);
   LDL_append((struct qelem*) IPtr, &IQue);
}

/* Create a new http connection for URL url, and asynchronously
   feed the bytes that come back to bytesink. */
int gzilla_http_get (const char *url, void* Data)
{
  char hostname[256];
  int port, Ret;
  char *tail;
  char query[2048];
  __Info_t* IPtr;

  port = 80;

  /* hacked-in support for proxies, inspired by Olivier Aubert */
  if (HTTP_Proxy && !(No_Proxy && strstr (url, No_Proxy) != NULL))
    {
      gzilla_url_parse (HTTP_Proxy, hostname, sizeof(hostname), &port);
      tail = (char *)url;
    }
  else
    tail = gzilla_url_parse ((char *)url, hostname, sizeof(hostname), &port);

  if (!tail) return -1;

  sprintf (query,
	       "GET %s HTTP/1.0\r\n"
	       "User-Agent: gzilla %s\r\n"
	       "Host: %s:%d\r\n"
	       "\r\n", tail, VERSION, hostname, port);
  if (!LDL_empty(&IQue))
    {
       IPtr=(__Info_t*) IQue.q_forw;
       remque((struct qelem*) IPtr);
       if (IPtr->Query) g_free(IPtr->Query);
    }
   else
    {
       if (!(IPtr=malloc(sizeof(__Info_t)))) return -1;
    }
  IPtr->Query = strdup (query);
  IPtr->WData = Data;

   /* Setup a socket, in a Gzilla friendly fashion... because it is remote,
      we only will have information about the name.  We will get a call back
      later indicating what we should do about that.
    */
   gzilla_web_status(Data,"Connecting\n");
   Ret = gzilla_socket_new (hostname, port, gzilla_http_callback, (void*)IPtr);

   /* Bug: if socket fails, no way to recover IPtr */
   if (Ret < 0)
     {
	free(IPtr->Query);
        LDL_append((struct qelem*)IPtr,&IQue);
        gzilla_web_status(Data,"couldn't get new socket\n");
	return -1;
     }

   _FD2Ptr(Ret).Call =gzilla_web_callback;
   _FD2Ptr(Ret).Data = Data;
   return Ret;
}
