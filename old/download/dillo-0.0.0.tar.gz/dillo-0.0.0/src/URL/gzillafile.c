/*

   gzilla

   Copyright 1997 Raph Levien <raph@acm.org>

   This code is free for commercial and non-commercial use,
   modification, and redistribution, as long as the source code release,
   startup screen, or product packaging includes this copyright notice.

   Directory scanning code added by Jim McBeath <jimmc@globes.com> Jan 1998.
 */


#include <ctype.h>		/* for tolower */
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <fcntl.h>
#include <string.h>
#include <time.h>
#include <stdio.h>
#include <signal.h>

#include <errno.h>		/* for errno */
#include "URL_protos.h"
#include "../IO/GzIO.h"
#include "../gzillaweb.h"

typedef struct _GzillaFile
{
  int fd, FD_Write;
  char *dirname;
  DIR *dir;
  int state;		/* for use when converting directory into html text */
} GzillaFile;

typedef struct fileinfo
{
  char *name;			/* name of file within directory */
  char *dirname;		/* full directory name */
  int size;
  char *symlink;
  char *date;
  int isexec;
}
GzillaFileInfo;


/* Forward references */
static int gzilla_file_get_dir (const char *url, void* Data);

static char *gzilla_dir_file_html (GzillaFile *gzfile);

/* Close a file or directory. */
static void
gzilla_file_close (GzillaFile *gzfile)
{
      if (gzfile->dir)
	closedir (gzfile->dir);
}

/* Read a chunk of text from a file, or a line of generated html
 * if it is a directory.
 */
static int				/* return number of bytes of data */
gzilla_file_read (GzillaFile *gzfile,
		  char *buf,
		  int bufsize)
{
  char *s;

  /* it's a directory, we scan the directory and convert to html */

  switch (gzfile->state)
    {
    case 0:			/* output header */
      gzfile->state = 10;	/* continue header on next call */
      sprintf (buf, "<HTML><HEADER><TITLE>%s %s</TITLE></HEADER>\n",
	       "Directory listing of",
	       gzfile->dirname);
      break;
    case 10:
      gzfile->state++;
      sprintf (buf, "<BODY><H1>%s %s</H1>\n",
	       "Directory listing of",
	       gzfile->dirname);
      return strlen (buf);
    case 11:
      gzfile->state = 1;	/* ready to do files */
      strcpy (buf, "<pre>\n");
      break;
    case 1:			/* do files */
      /* we could sort the directory here */
      s = gzilla_dir_file_html (gzfile);
      if (s)
	{
	  strcpy (buf, s);
	  break;
	}
      /* end of directory, clean up */
      gzfile->state = -1;
      closedir (gzfile->dir);
      gzfile->dir = (DIR *) 0;
      strcpy (buf, "</pre>\n");
      break;
    default:
      buf[0] = 0;
      break;
    }
  return strlen (buf);
}

static void gzilla_dir_transfer(GzillaFile *GF)
{
  char buf[8192];
  int num_bytes;

   for(;;)
    {
      num_bytes = gzilla_file_read (GF, buf, sizeof (buf));
      if (num_bytes < 0)
	{
	  if (errno == EINTR)
	    break;
	  num_bytes = 0;
	}
      if (num_bytes > 0)
	write (GF->FD_Write, buf, num_bytes);
       else break;

    }
   gzilla_file_close (GF);
   close (GF->FD_Write);
}

/* Return 1 if the extension matches that of the filename. */

static int  gzilla_file_ext (const char *filename, const char *ext)
{
  int i, j;

  i = strlen (filename);
  while (i > 0 && filename[i - 1] != '.')
    i--;
  if (i == 0)
    return 0;
  for (j = 0; ext[j] != '\0'; j++)
    if (tolower (filename[i++]) != tolower (ext[j]))
      return 0;
  return (filename[i] == '\0');
}

/* Based on the extension, return the content_type for the file. */
static char *
gzilla_file_content_type (const char *filename)
{
  if (gzilla_file_ext (filename, "gif"))
    {
      return "image/gif";
    }
  else if (gzilla_file_ext (filename, "jpg") ||
	   gzilla_file_ext (filename, "jpeg"))
    {
      return "image/jpeg";
    }
  else if (gzilla_file_ext (filename, "html") ||
	   gzilla_file_ext (filename, "htm"))
    {
      return "text/html";
    }
  return "text/plain";
}

/* Create a new file connection for URL url, and asynchronously
   feed the bytes that come back to bytesink. */
int gzilla_file_get (const char *url, void* Web)
{
  char *filename;
  int fd;
  char *content_type;
  struct stat sb;
  int t;

  filename = (char *) url + 5;
  t = stat (filename, &sb);
  if (t != 0)
    {
      /* stat failed, give file-not-found error. */
      return Gz_File_Not_Found (filename, Web);
    }
  if (S_ISDIR (sb.st_mode))
    {
       /* set up for reading directory */
       return gzilla_file_get_dir (url, Web);
    }

  /*--- Basic file transfer ----------------------------------------------------- */
  fd = open (filename, O_RDONLY);
  if (fd < 0)
    {
       return Gz_File_Not_Found (filename, Web);
    }

   /* set close-on-exec */
   fcntl (fd, F_SETFD, FD_CLOEXEC | fcntl (fd, F_GETFD));
   gzilla_web_FD(Web,fd);

   /* could set nonblocking too, which might be helpful on some file
         systems (like NFS), but we won't bother. */

   content_type = gzilla_file_content_type (filename);
   gzilla_web_dispatch_by_Type(Web, content_type, &_FD2Ptr(fd).Call,
			       &_FD2Ptr(fd).Data);
   /* todo: add size fields, etc. */
   /* size is now in sb.st_size */
   return -1;
}

/* Create a new file connection for URL url
   which is a directory, and asynchronously
   feed the bytes that come back to bytesink. */
static int 
gzilla_file_get_dir (const char *url, void* Data)
{
  char *filename;
  DIR *dir;
  GzillaFile gzfile;
  int fds[2];

  filename = (char *) url + 5;
  dir = opendir (filename);
  if (!dir)
    {
        /* can't open directory */
        return Gz_File_Not_Found (filename, Data);
    }

  if (pipe(fds)) return -1;
  gzilla_web_FD(Data, fds[0]);

  /* todo: add size fields, etc. */
  gzilla_web_dispatch_by_Type(Data,"text/html",&_FD2Ptr(fds[0]).Call,
			      &_FD2Ptr(fds[0]).Data);

   {
      /* Fork this off into its own process */
      pid_t MyPID;
      MyPID=fork();
      if (MyPID > 0) {close(fds[1]); return -1;}
      close(fds[0]);
      if (MyPID < 0) {close(fds[1]); return -1;}
      signal(SIGCHLD,_exit);
      signal(SIGPIPE,_exit);
   }

   gzfile.dir = dir;
   gzfile.dirname = filename;
   gzfile.FD_Write = fds[1];
   gzfile.state = 0;
   gzilla_dir_transfer(&gzfile);
   _exit(0); /* Doesn't call closing stuff */
}

static char *
gzilla_fileinfo_html (GzillaFile *file, struct stat* SPtr, const char* name,
	const char* dirname, const char* date)
{
#define FILEINFOHTMLBUFSIZE 1200
  static char buf[FILEINFOHTMLBUFSIZE];
  int size;
  char *sizeunits;
#define MAXNAMESIZE 12
  char namebuf[MAXNAMESIZE + 1];
  char *namefill;
  const char *ref;
  char anchor[1024];
  char *cont;
  char *longcont;
  char *icon;
  char *icon_prefix;

  if (!name)
    return (char *) 0;
  if (strcmp (name, "..") == 0)
    {
      char *e = strrchr (dirname, '/');
      char *p;
      strcpy (anchor, "file:");
      p = anchor + strlen (anchor);
      strcpy (p, dirname);
      if (e)
	p[e - dirname] = 0;
      sprintf (buf, "<a href=\"%s\">%s</a>\n",
	       anchor,
	       "Up to higher level directory");
      return buf;
    }
  if (SPtr->st_size <= 9999)
    {
      size = SPtr->st_size;
      sizeunits = "bytes";
    }
  else if (SPtr->st_size / 1000 <= 9999)
    {
      size = SPtr->st_size / 1000;
      sizeunits = "Kb";
    }
  else
    {
      size = SPtr->st_size / 1000000;
      sizeunits = "Mb";
    }
      /* we could note if it's a symlink... */
  if S_ISDIR (SPtr->st_mode)
    {
      cont = "application/directory";
      longcont = "Directory";
    }
  else if (SPtr->st_mode & (S_IXUSR | S_IXGRP | S_IXOTH))
    {
      cont = "application/executable";
      longcont = "Executable";
    }
  else
    {
      cont = gzilla_file_content_type (name);
      longcont = cont;
      if (!cont)
	{
	  cont = "unknown";
	  longcont = "";
	}
    }
  icon = 0;
/* TBD - need to translate from content-type to icon */
  if (!icon)
    icon = "unknown";

/* Setup ref before shortening name so we have the full filename */  
#if 0
  if (fileinfo->symlink)
    ref = fileinfo->symlink;
  else
#endif
    ref = name;

  if (strlen (name) > MAXNAMESIZE)
    {
      strncpy (namebuf, name, MAXNAMESIZE - 3);
      strcpy (namebuf + (MAXNAMESIZE - 3), "...");
      name = namebuf;
      namefill = "";
    }
  else
    {
      static char *spaces = "                        ";
      namefill = spaces + strlen (spaces) - MAXNAMESIZE + strlen (name);
    }

/*
#if 0
  if (fileinfo->symlink)
    ref = fileinfo->symlink;
  else
#endif
    ref = name;
*/ /* removed */
  if (ref[0] == '/')
    sprintf (anchor, "file:%s", ref);
  else
    sprintf (anchor, "file:%s/%s", dirname, ref);
#define ICON_PREFIX "internal:icons/"
  icon_prefix = ICON_PREFIX;
  sprintf (buf, "\
<img src=\"%s%s\">  <a href=\"%s\">%s</a>%s %5d %-5.5s  %-12s  %s\n",
	   icon_prefix, icon, anchor, name, namefill, size, sizeunits,
	   date, longcont);
  return buf;
}

static char *
gzilla_dir_file_html (GzillaFile *gzfile)
{
  struct dirent *de;
  char *s;
  struct stat sb;
#ifndef MAXPATHLEN
#define MAXPATHLEN 1024
#endif
  char fname[MAXPATHLEN + 1];
  char *ds;
  char datebuf[40];
  int t;
  time_t currenttime;

  time (&currenttime);
  while ((de = readdir (gzfile->dir)) != 0)
    {
      if (strcmp (de->d_name, ".") == 0)
	continue;		/* skip "." */
      sprintf (fname, "%s/%s", gzfile->dirname, de->d_name);
      t = lstat (fname, &sb);	/* we want to see S_ISLNK if symlink */
      if (t)
	continue;		/* ignore files we can't stat */
#if 0
      if (S_ISLNK (sb.st_mode))
	{
	  (void) readlink (fname, abuf, sizeof (abuf));
	  if (abuf[0])
	    fileinfo.symlink = abuf;
	}
      else
	{
	  /* not a symbolic link */
	  fileinfo.symlink = (char *) 0;
	}
#endif
      ds = ctime (&(sb.st_mtime));
      if (currenttime - sb.st_mtime > 15811200)
	{
	  /* over about 6 months old */
	  sprintf (datebuf, "%6.6s  %4.4s", ds + 4, ds + 20);
	}
      else
	{
	  /* less than about 6 months old */
	  sprintf (datebuf, "%6.6s %5.5s", ds + 4, ds + 11);
	}
      s = gzilla_fileinfo_html (gzfile, &sb, de->d_name, gzfile->dirname, datebuf);
      if (s)
	return s;
    }
  return (char *) 0;
}
