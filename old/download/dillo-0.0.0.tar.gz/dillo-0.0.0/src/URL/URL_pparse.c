/*
    GZilla's URL method identifier..
    Randall Maas
    1999

    This finds out what method the URL is asking for
*/

#define def_URL_proto_parse
#include "URL_protos.h"

