#include "URL_protos.h"

/* Give a file-not-found error. */
static char Buffy[2048];
static __CacheFile_t FedCFile = {NULL,NULL, "file: not found","text/html",Buffy,sizeof(Buffy)};
int Gz_File_Not_Found(const char *filename, void* Web)
{
   /*
      Description
	This displays the HTML page for a file not found.

      Return Value
	-1
    */
   void* Data=NULL;
   __IOCallback_t Call=NULL;
   gzilla_web_dispatch_by_Type(Web, FedCFile.Type, &Call, &Data);
   if (!Call) return -1;


   sprintf(Buffy,"<html><head><title>404 Not Found</title></head>\n"
	   "<body><h1>404 Not Found</h1><p>The requested file %s"
	   " was not found in the filesystem.</p>\n</body></html>\n",filename);
   Call(0, Data, &FedCFile);
   Call(1, Data, &FedCFile);
   return -1;
}


