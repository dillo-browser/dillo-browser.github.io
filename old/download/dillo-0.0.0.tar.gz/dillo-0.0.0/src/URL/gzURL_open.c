/*

 gzilla

 Copyright 1997 Raph Levien <raph@acm.org>

 This code is free for commercial and non-commercial use,
 modification, and redistribution, as long as the source code release,
 startup screen, or product packaging includes this copyright notice.

 */


/* This module provides an API for asynchrnously retrieving URLs from
   the network and feeding them to bytesinks. */

#define gint int
#include "URL_protos.h"

int gzilla_URL_open (const char *url, void* Data)
{
    /*
        Description
	 Create a new connection for URL url, and asynchronously feed the bytes
	 that come back to bytesink.

	Return Value
	 <0 on error, otherwise the file descriptor to get the data from
     */
    {
	/* Use the method to figure out what to do */
	const char* Method=NULL;
	ssize_t Size = URL_proto_parse(url,&Method);
	__Open_t MPtr;
	if (Size < 1) return -1;
	
	/* Scan our method tree to see if there is anything. */
	if (!(MPtr = URL_proto_fetch(Method,Size))) return -1;
	return MPtr(url, Data);
    }
   return -1;
}
