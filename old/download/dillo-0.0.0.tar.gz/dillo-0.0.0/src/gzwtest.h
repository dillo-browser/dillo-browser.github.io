typedef struct _GzwTest GzwTest;

struct _GzwTest {
  Gzw gzw;

  gint counter;
};

Gzw *gzw_test_new (void);
