#ifndef __DILLODICACHE_H__
#define __DILLODICACHE_H__

#include "imgsink.h"

void a_Dicache_init (void);
void a_Dicache_request_url_img (DilloImgSink *imgsink, char *url,
                           BrowserWindow *bw); 
void a_Dicache_freeall(void);

#endif /* __DILLODICACHE_H__ */
