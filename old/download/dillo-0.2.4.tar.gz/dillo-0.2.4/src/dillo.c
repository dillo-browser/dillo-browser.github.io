/*
 * Dillo web browser
 *
 * Copyright 1997 Raph Levien <raph@acm.org>
 * Copyright 1999, 2000 Jorge Arellano Cid <jcid@inf.utfsm.cl>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <stdio.h>
#include <gtk/gtk.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <signal.h>

#include "dillo.h"
#include "web.h"
#include "misc.h"
#include "cache.h"
#include "dw_gtk_statuslabel.h"
#include "browser.h"
#include "menu.h"
#include "cache.h"
#include "browser.h"
#include "nav.h"
#include "bookmark.h"
#include "dicache.h"
#include "dns.h"
#include "IO/Url.h"
#include "prefs.h"
#include "interface.h"

/* contains the browser_window structure */
#include "browser.h"

#include "dw.h"
#include "html.h"

/*
 * Forward declarations
 */
void Dillo_check_home_dir(char *dir);
gint Dillo_check_splash_screen(gchar *file);



/*
 * ******************************** MAIN *************************************
 */
gint main(int argc, char *argv[])
{
   gchar *file;
   GString *start_url;
   BrowserWindow *bw;


   /* Ignore any broken pipes: we used to get a lot */
   signal(SIGPIPE, SIG_IGN);

   gtk_true();
   gtk_init(&argc, &argv);

   /* check that ~/.dillo exists, create it if it doesn't */
   file = a_Misc_prepend_user_home(".dillo");
   Dillo_check_home_dir(file);
   g_free(file);

   a_Prefs_init();
   a_Dns_init();
   a_Url_init();
   a_Mime_init();
   a_Dicache_init();
   a_Interface_init();
   a_Dw_image_init();

   /* a_Nav_init() has been moved into this call because it needs to be
    * initialized with the new browser_window structure */
   bw = a_Interface_new_browser_window();

   a_Bookmarks_init();

   /* Send dillo startup screen */
   file = a_Misc_prepend_user_home(".dillo/splash024.html");
   Dillo_check_splash_screen(file);
   start_url = g_string_new("file:");
   g_string_append(start_url, file);
   a_Nav_push(bw, start_url->str);
   g_free(file);
   g_string_free(start_url, TRUE);

   if (argc == 2) {
      if (a_Url_is_absolute(argv[1])) {
         a_Nav_push(bw, argv[1]);
      } else {
         /* CP: Would be wise to verify that URLs stay within those bounds */
         char url[1024];

         if (strlen(argv[1]) + 6 <= sizeof(url)) {
            /* CP: Just blithely assume it's a file URL?
             * Need more sophisticated heuristics. If there is a TLD, then 
             * proto = HTTP, for instance. */
            /* CP: Would also be wise to postpend '/' on dirs and domain 
             * names. */
            sprintf(url, "file:%s", argv[1]);
            a_Nav_push(bw, url);
         }
      }
   }
//   a_Nav_push(bw, "file:.");
   gtk_main();

   /* 
    * Memory deallocating routines
    * (This can be left to the OS, but we'll do it, with a view to test
    *  and fix our memory management)
    */
   a_Cache_freeall();
   a_Dicache_freeall();
   a_Http_freeall();
   a_Dns_freeall();
   a_Prefs_freeall();

   printf("Dillo: normal exit!\n");
   return 0;
}

/*
 * Checks if '~/.dillo' directory exists.
 * If not, attempt to create it.
 */
void Dillo_check_home_dir(char *dir)
{
   struct stat st;

   if ( stat(dir, &st) == -1 ) {
      if ( errno == ENOENT && mkdir(dir, 0700) < 0 ) {
         g_print("Dillo: error creating directory %s: %s\n",
                 dir, strerror(errno));
      } else 
         g_print("Dillo: error reading %s: %s\n", dir, strerror(errno));
   }
}

/*
 * HTML text for startup screen
 */
static char *splash=
"<!doctype html public \"-//w3c//dtd html 4.0 transitional//en\">\n\
<html>\n\
<head>\n\
 <meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-1\">\n\
</head>\n\
<hr>\n\
 <h1></a>Dillo project<br>\n\
         <h3>Version 0.2.4 Developer's release</h3></h1>\n\
<hr>\n\
<h4> License </h4>\n\
<p>\n\
    This program is free software; you can redistribute it and/or modify\n\
    it under the terms of the GNU General Public License as published by\n\
    the Free Software Foundation; either version 2 of the License, or\n\
    (at your option) any later version.\n\
<p>\n\
    This program is distributed in the hope that it will be useful,\n\
    but WITHOUT ANY WARRANTY; without even the implied warranty of\n\
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n\
    GNU General Public License for more details.\n\
\n\
<hr>\n\
<h4>NOTES:</h4>\n\
<p> \n\
<ul>\n\
<li> There's a dillorc file within the tarball; copy it to ~/.dillo/ directory.\n\
If you set force_my_colors=YES, slashdot will get readable!</li>
<li> There's developer documentation in the /doc dir within the tarball, and\n\
you can find directions on everything else at the home page. </li>\n\
<li> Dillo behaves very nice when browsing local files, images, and HTML.\n\
It's also very good for Internet searching (try www.google.com). Test it!</li>\n\
<li> Tables and frames are not supported yet.</a></li>\n\
<li> Frame-based pages will not render. You can note them cause the progress\n\
bar will show content, but no rendering will be done. Press Ctrl-V (view\n\
source) to get sure. </li>\n\
<li> This release is intended <strong>for developers only.</strong></a></li>\n\
</ul>\n\
<hr>\n\
</body>\n\
</html>\n\
";

/*
 * Check if splash screen (HTML file) is saved in .dillo/
 * (Save if not)
 */
gint Dillo_check_splash_screen(gchar *file)
{
   struct stat st;
   FILE *stream;

   if ( stat(file, &st) < 0 && errno == ENOENT ) {
      /* splash screen not saved, create it */
      if ( (stream = fopen(file, "w")) != NULL){
         fprintf(stream, splash);
         fclose(stream);
      }
   }
   return 0;
}

