#ifndef __DW_IMAGE_H__
#define __DW_IMAGE_H__
#include "dw_page.h"

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

typedef struct _DwImageInfo   DwImageInfo;
typedef union  _DwDitherInfo    DwDitherInfo;

typedef enum {
  DW_IMAGE_RGB
} DwImageType;

struct _DwImageInfo
{
  GdkVisual *visual;
  GdkColormap *cmap;

  gulong *color_pixels;
  gulong *gray_pixels;
  gulong *reserved_pixels;

  gulong *lookup_red;
  gulong *lookup_green;
  gulong *lookup_blue;

  DwDitherInfo *dither_red;
  DwDitherInfo *dither_green;
  DwDitherInfo *dither_blue;
  DwDitherInfo *dither_gray;
  guchar ***dither_matrix;

  guint nred_shades;
  guint ngreen_shades;
  guint nblue_shades;
  guint ngray_shades;
  guint nreserved;

  guint bpp;
  gint cmap_alloced;
  gdouble gamma;
};

union _DwDitherInfo
{
  gushort s[2];
  guchar c[4];
};

typedef struct _DwImage {
  Dw dw;

  DwImageType type;
  guchar* buffer;
  gint buffer_width;
  gint buffer_height;
  size_t buffer_size;
  gint width;
  gint height;
  int*  Counter;
  Dw** Parent;
} DwImage;

extern DwImageInfo *image_info;
void a_Dw_image_init (void);
Dw* a_Dw_image_new  (DwImageType type);
void a_Dw_image_size (DwImage*image, gint width, gint height);
void a_Dw_image_draw_row (DwImage**image,int NImages, guchar *data, gint x,
                         gint y, gint width);
void a_Dw_image_allocate_buffer (DwImage *image);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __DW_IMAGE_H__ */
