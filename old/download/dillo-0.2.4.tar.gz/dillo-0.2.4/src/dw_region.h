#ifndef __DW_REGION_H__
#define __DW_REGION_H__

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include "dw_rect.h"

typedef struct _DwRegion DwRegion;

/* Regions are dynamically allocated, and reference counted. Most
   functions for manipulating regions will decrement the reference
   count of the arguments, and create a new region with a reference
   count of 1. */

DwRegion *Dw_region_pin (DwRegion *region);
void a_Dw_region_drop (DwRegion *region);
DwRegion *a_Dw_region_from_rect (const DwRect *src);
gboolean a_Dw_region_empty (const DwRegion *region);

/* There should probably also be a dw_region_sanitycheck for testing
   purposes. */

/* Standard set operations on regions. */
DwRegion *a_Dw_region_union (DwRegion *src1, DwRegion *src2);
DwRegion *Dw_region_intersect (DwRegion *src1, DwRegion *src2); /* -RL :: Where is this one???*/
DwRegion *a_Dw_region_minus (DwRegion *src1, DwRegion *src2);

void a_Dw_region_tile (DwRect *dst, DwRegion *src, gint max_xs, gint max_ys,
		      gint waste);

void Dw_region_to_bitmap (DwRegion *src, guchar *buf, gint xs, gint ys);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __DW_REGION_H__ */
