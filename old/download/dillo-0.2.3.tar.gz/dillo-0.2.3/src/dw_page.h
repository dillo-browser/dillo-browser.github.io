/* This module contains the dw_page widget, which is the "back end" to
   Web text widgets including html. */

#ifndef __DW_PAGE_H__
#define __DW_PAGE_H__

#undef USE_TYPE1

#include <gtk/gtk.h>

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

typedef struct _DwPage        DwPage;
typedef struct _DwPageClass   DwPageClass;

/* Internal data structures (maybe shouldn't be in public .h file? */
typedef struct _DwPageFont    DwPageFont;
typedef struct _DwPageLink    DwPageLink;
typedef struct _DwPageAttr    DwPageAttr;
typedef struct _DwPageLine    DwPageLine;
typedef struct _DwPageWord    DwPageWord;

struct _DwPageFont {
  char *name;
  gint size;
  gboolean bold;
  gboolean italic;

#ifdef USE_TYPE1
  gint t1fontid;
#else
  GdkFont *font;
#endif
  gint space_width; /* only valid if font != NULL */
};

struct _DwPageLink {
  char *url;
};

struct _DwPageAttr {
  gint font;
  gint link;
  gint32 color;

  gint left_indent_first;
  gint left_indent_rest;
  gint right_indent;

  gint align;
};

#define DW_PAGE_ALIGN_LEFT 0
#define DW_PAGE_ALIGN_CENTER 1
#define DW_PAGE_ALIGN_RIGHT 2

struct _DwPageLine {
  gint num_words;
  gint num_words_max; /* number allocated */
  gint y_top;
  gint x_size, y_ascent, y_descent, y_space;
  gboolean hard;      /* false = soft break, true = hard break */
  gboolean first;     /* true = first line in paragraph */
  DwPageWord *words;
};

#define DW_PAGE_CONTENT_TEXT 0
#define DW_PAGE_CONTENT_WIDGET 1

struct _DwPageWord {

  gint x_size, y_ascent, y_descent;
  gint x_space; /* space after the word, only if it's not a break */

  /* This is a variant record (i.e. it could point to a widget 
   * instead of just being text). */
  gint content_type;
  union {
    char *text;
    Dw *widget;
  } content;

  gint attr;
};

struct _DwPage {
  Dw dw;

  GdkGC *gc;

  DwPageLine *lines;
  gint num_lines;
  gint num_lines_max; /* number allocated */

  gint width;         /* the width (not including pad) at which line wrap
                         was calculated. If this changes, then the whole
                         thing should get re-wrapped. */

  gint last_line_max_width; /* the maximum width of the last line (assuming
                               no word wrap) */

  DwPageFont *fonts;
  gint num_fonts;
  gint num_fonts_max;

  DwPageLink *links;
  gint num_links;
  gint num_links_max;

  GdkColor *colors;
  gint num_colors;
  gint num_colors_max;

  /* We'll store current-page colors here */
  gint32 link_color;
  gint32 bgnd_color;

  DwPageAttr *attrs;
  gint num_attrs;
  gint num_attrs_max;

  /* Stuff for doing redraws */

  GdkRectangle clear;  /* Rectangle that must be cleared. */
  GdkRectangle redraw; /* Rectangle that must be redrawn. */

  gint redraw_start_line;

  /* The link under a button press */
  gint link_pressed;

  /* The link under the button */
  gint hover_link;

  void (*link) (void *data, const char *url);
  void *link_data;

  void (*status) (void *data, const char *url);
  void *status_data;
  void (*destroy) (void* data);
  void *destroy_data;
  Dw** Parent;
};


Dw *a_Dw_page_new       (Dw**);

void
a_Dw_page_set_callbacks (DwPage *page,
                        void (*alink) (void* data, const char* url),
                        void*link_data,
                        void (*status) (void *data, const char *url),
                        void *status_data,
                        void (*destroy)(void*), void* destroy_data);

void Dw_page_set_width (DwPage *page, gint width);

void a_Dw_page_update_begin (DwPage *page);
void a_Dw_page_update_end (DwPage *page);

void a_Dw_page_init_attr (DwPage *page, DwPageAttr *attr);
gint a_Dw_page_find_font (DwPage *page, const DwPageFont *font);
gint a_Dw_page_new_link (DwPage *page, const char *url);
gint a_Dw_page_find_color (DwPage *page, gint32 color);
gint a_Dw_page_add_attr (DwPage *page, const DwPageAttr *attr);
void a_Dw_page_add_text (DwPage *page, char *text, gint attr);
void a_Dw_page_add_widget (DwPage *page, Dw *widget, gint attr);
void a_Dw_page_add_space (DwPage *page, gint attr);
void a_Dw_page_linebreak (DwPage *page);
void a_Dw_page_parbreak (DwPage *page, gint space);


#ifdef __cplusplus
}
#endif /* __cplusplus */


#endif /* __DW_PAGE_H__ */
