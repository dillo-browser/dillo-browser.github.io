#ifndef __DW_H__
#define __DW_H__

/* The main header file for the Dillo Widget set. At its heart is the
   Dw data structure, and its "helper" data structures, including
   DwRect and DwClass.

   It also includes definitions for the dispatch functions.
*/

#include "dw_rect.h"

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

typedef struct _Dw Dw;
typedef struct _DwClass DwClass;
typedef struct _DwPaint DwPaint;
typedef struct _DwContainerClass DwContainerClass;
typedef struct _DwContainer DwContainer;

/*
 * The main Dw widget structure. Most widgets will extend it (i.e.
 * allocate a structure that includes a Dw as its first element). 
 */
struct _Dw {
  const DwClass *klass;
  gint req_width_min;     /* the minimum comfortable width */
  gint req_width_max;     /* the maximum comfortable width */

   /* If the widget is not to be baseline aligned, it sets its
      req_height to the height, and req_ascent zero. Conversely, if it
      wants to be baseline aligned, it sets req_height and
      req_ascent. The descent is the height minus the ascent.
   */
   gint req_height;
   gint req_ascent;

   /* Allocation is similar to GTK.
      x, y coordinates are relative to the toplevel Dillo widget.
   */
   DwRect allocation;

   /* Flags include:

      + alignment options (baseline, vertical, horizontal?)

      + information about what's currently displayed, one of:
        + valid data (no need for repaint)
        + previously valid data (can incrementally repaint)
        + window background (don't need to clear before drawing)
        + good data underneath (don't clear before drawing; for layers)
        + unknown (better clear and repaint)

      + widget needs resize

      + widget contains embedded GTK widget (used to prune propagation
        of gtk_foreach calls)

   */
   gint flags;

   Dw *parent;

   /* Information about the enclosing gtk container. */
   DwContainer *container;
};

/* Dw flags. Should these be an enum rather than #defines? */

/* BASELINE is set if req_ascent is valid. */
#define DW_FLAG_BASELINE   1

/* REQ_RESIZE is set if the widget (or, in the case of a container, any
   descendant widgets) have requested resize). */
#define DW_FLAG_REQ_RESIZE 2

/* GTK_EMBED is set if the widget contains any embedded GTK widgets.
   This stuff probably needs some changes. */
#define DW_FLAG_GTK_EMBED  4

/* REQ_REWRAP is set if the idle rewrap function has been set.
   The flag is cleared by the idle function upon end.
   This is an experimental flag  --Jcid */
#define DW_FLAG_REQ_REWRAP 8

/* The methods defined for a Dw. */

typedef void (*DwCallback) (GtkWidget *widget,
                             gpointer   data,
                             GtkAllocation *allocation);

struct _DwClass {

  void (*size_nego_x) (Dw *dw, gint width);

  void (*size_nego_y) (Dw *dw, DwRect *allocation);

  void (*paint) (Dw *dw, DwRect *rect, DwPaint *paint);

  void (*handle_event) (Dw *dw, GdkEvent *event);

  /* todo: define the active rectangle more precisely (I think that
     widgets intersecting rect1 minus widgets intersecting rect2
     might be what we want. */
  void (*gtk_foreach) (Dw *dw, DwCallback callback, gpointer callback_data,
                       DwRect *plus, DwRect *minus);

  void (*destroy) (Dw *dw);

  /* The following method is supported only by containers: */
  void (*request_resize) (Dw *dw, Dw *child);

};

/* A few invariants for these methods:
 *
 * The paint method is only called if the widget has a toplevel container,
 * and that container is mapped and visible.
 */

struct _DwContainer {
  const DwContainerClass *klass;

  /* The GTK widget that contains the toplevel Dw widget. */
  GtkWidget *widget;

  /* The visible rectangle, in coordinates relative to the toplevel Dw. */
  DwRect visible;

  /* You get X11 window coordinates by adding these to toplevel Dw
   * coordinates. */
  gint x_offset, y_offset;
};

/*
 * These are methods on the toplevel Dw widget, for communicating to
 * the enclosing Gtk widget.
 */
struct _DwContainerClass {

  /* todo: it should probably take a flag to indicate whether
   * the previous data is considered valid. */

  /* rect is in toplevel coordinates. */
  void (*request_paint) (DwContainer *container, DwRect *rect);

  /* request a resize of the contained dw. */
  void (*request_resize) (DwContainer *container);
};

struct _DwPaint {
  gint flags;
  gint32 bg_color;
  /* may want to put the paint rect in here. */
};

/* DwPaint flags: */

/* An invariant: at least one of the UNDER flags is set. */

/* The layer under us is the background color. */
#define DW_PAINT_BG_UNDER         0x0001

/* The layer under us is on the screen. */
#define DW_PAINT_SCREEN_UNDER     0x0002

/* DW_PAINT_BUF_UNDER would indicate that the layer under us is in a
 * buffer. */

/* The screen is the background color. */
#define DW_PAINT_BG_SCREEN        0x0100

/* Good data from the last repaint is on the screen. */
#define DW_PAINT_TOP_SCREEN       0x0200
#define DW_PAINT_DEFAULT_BGND   0xd6d6c0

DwContainer *a_Dw_find_container (Dw *dw);

void a_Dw_size_nego_x (Dw *dw, gint width);
void a_Dw_size_nego_y (Dw *dw, DwRect *allocation);
void a_Dw_paint (Dw *dw, DwRect *rect, DwPaint *paint);
void a_Dw_handle_event (Dw *dw, GdkEvent *event);
void a_Dw_gtk_foreach (Dw *dw, DwCallback callback, gpointer callback_data,
                      DwRect *plus, DwRect *minus);
void a_Dw_destroy (Dw *dw);
void a_Dw_request_parent_resize (Dw *dw);
void a_Dw_request_paint (Dw *dw, DwRect *rect);

void a_Dw_paint_to_screen (GtkWidget *widget, DwContainer *container,
                          DwRect *rect, DwPaint *paint);
void a_Dw_paint_finish_screen (DwPaint *paint);
void a_Dw_set_color (Dw *dw, gint32 color);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __DW_H__ */
