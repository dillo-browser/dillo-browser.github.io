/*
 * File: dicache.c
 *
 * Copyright 1997 Raph Levien <raph@acm.org>
 * Copyright 1999 James McCollough <jamesm@gtwn.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */


#include <gtk/gtk.h>
#include <sys/time.h>       /* for libc5 compatibility */
#include <string.h>         /* for memset */
#include <stdio.h>
#include "IO/IO.h"

#include "list.h"
#include "imgsink.h"
#include "dillo.h"
#include "web.h" 
#include "dicache.h"
#include "cache.h"
#include "interface.h"


typedef struct _DilloDICacheLine DilloDICacheLine;

struct _DilloDICacheLine {
   char *url;
   gint width, height;
   guchar *Image_Buffer;
   gint in_width, in_height;
   gint NRef;
   fd_set *bitvec;              /* bit=TRUE says line is present */
   /* this field is  only valid if */
   /*  type == DILLO_IMG_TYPE_INDEXED     */
   gint last_use;
   gint Used;
   gboolean eof;                /* TRUE when we got the whole image */
   size_t Total_Size;           /* amount of memory the image takes up */
   gint NDws;
   gint dws_max;
   DwImage **dws;
   DilloImgSink *imgsink;
};

typedef struct _DilloImgSinkDIC {
   DilloImgSink imgsink;
   DilloDICacheLine *line;
   BrowserWindow *bw;
   gint FD;
} DilloImgSinkDIC;

#define DICACHE_MAX 2000000

static DilloDICacheLine **dicache;
static gint dicache_size;
static gint dicache_size_max;

static gint dicache_size_total; /* invariant: dicache_size_total is
                                 * the sum of the image sizes of all
                                 * cache lines in dicache. */
static gint dicache_counter;

void a_Dicache_init(void)
{
   dicache_size = 0;
   dicache_size_max = 16;
   dicache = g_new(DilloDICacheLine *, dicache_size_max);

   dicache_size_total = 0;
   dicache_counter = 0;
}

/*
 * Implement the write method of the cache line's image sink
 * (Write a scan line into the cached image)
 */
static void Dicache_imgsink_write(DilloImgSink *imgsink,
                                  const guchar *buf,
                                  gint x,
                                  gint Y)
{
   DilloDICacheLine *line = ((DilloImgSinkDIC *) imgsink)->line;

   if (!line->imgsink)
      return;
   if (!line->width || !line->height)
      g_warning("Write to badly sized image!\n");

   _a_Image_write(line->imgsink, buf, x, Y, line->dws, line->NDws);
   FD_SET(Y, line->bitvec);

   /* Another possibility would be to write from the cached
    * image, guaranteeing a stride of 1 for downstream
    * imagesinks. Well, we can worry about that when we start
    * doing progressive png's. -Raph */
}


/*
 * Implement the close method of the cache line's image sink
 */
static void Dicache_imgsink_close(DilloImgSink *imgsink)
{
   DilloImgSinkDIC *DIC = (DilloImgSinkDIC *) imgsink;
   DilloDICacheLine *line = DIC->line;

   line->eof = TRUE;
   if (line->imgsink)
      a_Imgsink_close(line->imgsink);
   line->imgsink = NULL;
   if (DIC->bw && DIC->FD >= 0)
      a_Interface_delete_FD(DIC->bw, DIC->FD);
   g_free(DIC);
}

/*
 * Remove an image from the cache
 * (removes the line's imgsink, allocated stuff and the line itself)
 */
static void Dicache_free(DilloDICacheLine *DIPtr)
{
   /* This one is referenced in the BrowserWindow list (let it close it)
   if (DIPtr->imgsink) 
      a_Imgsink_close(DIPtr->imgsink);
   */

   if (DIPtr->Image_Buffer) {
      g_free(DIPtr->Image_Buffer);
      dicache_size_total -= DIPtr->Total_Size;
   }
   if (DIPtr->bitvec)
      g_free(DIPtr->bitvec);

   /* DIPtr->dws is an auxiliary list (there's no need to free every Dw) */
   if (DIPtr->dws)
      g_free(DIPtr->dws);

   if (DIPtr->url)
      g_free(DIPtr->url);
   g_free(DIPtr);
}

/*
 * ?
 */
static void Dicache_remove(gint dicache_index)
{
   Dicache_free(dicache[dicache_index]);
   dicache[dicache_index] = dicache[--dicache_size];
}

/*
 * Implement the set_parms method of the cache line's image sink
 * (We'll use the image information despite the html tags --Jcid)
 */
static void Dicache_imgsink_set_parms(DilloImgSink *imgsink,
                                      gint width,
                                      gint height,
                                      DilloImgType type)
{
   DilloDICacheLine *line = ((DilloImgSinkDIC *) imgsink)->line;
   guchar *buf;
   gint I;
   size_t size;

   if (!line->imgsink)
      return;
   a_Imgsink_set_parms(line->imgsink, width, height, type);
   line->in_width = line->width = width;
   line->in_height = line->height = height;

   /* Let's set the line buffer to reference the imgsink's Dw-buffer  --Jcid */
   buf = line->Image_Buffer = line->imgsink->dw->buffer;
   /* For giggles, make the background of the undrawn parts interesting */
   size = line->imgsink->dw->buffer_size;
   memset(buf + line->Total_Size, 0xdd, size - line->Total_Size);
   line->Total_Size = size;

   /* Update the buffer area for each of the displayed images */
   for (I = 0; I < line->NDws; I++) {
      if (!line->dws[I])
         continue;
      line->dws[I]->buffer = line->Image_Buffer;
      a_Dw_image_size(line->dws[I], width, height);
   }
}

/*
 * Implement the set_cmap method of the cache line's image sink
 */
static void Dicache_imgsink_set_cmap(DilloImgSink *imgsink,
                                     const guchar *cmap,
                                     gint num_colors,
                                     gint bg_index)
{
   DilloDICacheLine *line = ((DilloImgSinkDIC *) imgsink)->line;

   a_Image_set_cmap(line->imgsink, cmap, num_colors, bg_index);
}

/*
 * ?
 */
static void Dicache_hit(DilloImgSink *imgsink, DilloDICacheLine *line)
{
   gint Wn;     /* Widget number */

   line->Used++;
   line->last_use = dicache_counter++;
   if (!line->bitvec) {
      line->bitvec = g_malloc(sizeof(*(line->bitvec)));
      FD_ZERO(line->bitvec);
   }

   /* This pointer automatically goes to NULL when the object is
    * no longer displayed */
   line->NRef++;
   imgsink->dw->Counter = &line->NRef;

   Wn = line->NDws;
   a_List_add(line->dws, Wn, sizeof(*line->dws), line->dws_max)
   line->dws[Wn] = imgsink->dw;
   ++line->NDws;

   if (!line->imgsink) {
      line->imgsink = imgsink;
      /* This makes line->imgsink go NULL at imgsink close time */
      imgsink->Parent = &line->imgsink;
   } else {
      a_Imgsink_close(imgsink);
      imgsink = NULL;
   }

   if ( line->Image_Buffer && line->height && line->width) {
      /* We know the image size! */
      line->dws[Wn]->buffer = line->Image_Buffer;
      a_Dw_image_size(line->dws[Wn], line->width, line->height);
   }
}

/*
 * Create and initialize a new cache line with safe values
 */
DilloDICacheLine *Dicache_line_new (void)
{
   DilloDICacheLine *line;

   line = g_new(DilloDICacheLine, 1);
   line->url = NULL;
   line->bitvec = NULL;
   line->last_use = dicache_counter++;
   line->eof = FALSE;

   line->in_height = 0; /* imgsink->height; */
   line->in_width = 0;  /* imgsink->width; */
   line->height = 0;    /* imgsink->height; */
   line->width = 0;     /* imgsink->width; */

   line->imgsink = NULL;
   line->Image_Buffer = NULL;
   line->Total_Size = 0;
   line->NRef = 0;
   line->NDws = 0;
   line->dws_max = 16;
   line->dws = g_malloc(line->dws_max * sizeof(DwImage *));
   line->Used = 0;
   return line;
}

/*
 * The url missed in the cache.
 * 
 * 1. Create a new imgsink[dic] that will be used to feed the decompressed
 *    image data into the cache.
 * 2. Create a new cache line
 * 3. Attach the new cache line to the new imgsink[dic] and
 *    insert it to the 'dicache' list
 * 4. Do a Dicache_hit to connect the cache line to the argument imgsink.
 * 5. Fill a DilloWeb structure for a cache URL-request.
 * 6. Request that the URL be opened and start feeding the new imgsink[dic].
 */
static void Dicache_miss(DilloImgSink *imgsink, const char *url,
                         BrowserWindow *bw)
{
   DilloDICacheLine *line;
   DilloImgSink *new_imgsink;
   DilloImgSinkDIC *new_imgsinkdic;
   DilloWeb *Web;

   /* Step 1 */
   new_imgsinkdic = g_new(DilloImgSinkDIC, 1);
   /* Imgsink initialization */
   new_imgsink = (DilloImgSink *) new_imgsinkdic;
   a_Imgsink_new(new_imgsink);
   new_imgsink->write = Dicache_imgsink_write;
   new_imgsink->close = Dicache_imgsink_close;
   new_imgsink->set_parms = Dicache_imgsink_set_parms;
   new_imgsink->set_cmap = Dicache_imgsink_set_cmap;
   new_imgsink->Parent = imgsink->Parent;
   /* ImgSinkDIC specific settings */
   new_imgsinkdic->bw = bw;
   new_imgsinkdic->FD = -1;
   new_imgsinkdic->line = NULL;

   /* Step 2 */
   /* Allocate a cache line and initialize it with safe values */
   line = Dicache_line_new();
   line->url = g_strdup(url);

   /* Step 3 */
   /* Attach the cache line to the new imgsink[dic] */
   new_imgsinkdic->line = line;
   /* Add the cache line to the 'dicache list' */
   a_List_add(dicache, dicache_size, sizeof(*dicache), dicache_size_max);
   dicache[dicache_size++] = line;

   /* Step 4 */
   Dicache_hit(imgsink, line);

   /* Step 5 */
   Web = a_Web_new(url);
   Web->bw = bw;
   Web->imgsink = new_imgsink;
   Web->flags |= WEB_Image;

   /* Step 6 */
   /* This is done later so that any status signal gets propagated */
   new_imgsinkdic->FD = a_Cache_open_url(url, NULL, Web);
}

/*
 * ?
 */
void a_Dicache_open(DilloImgSink *imgsink, const char *url,
                    BrowserWindow *bw)
{
   gint i;

   for (i = 0; i < dicache_size; i++) {
      if ( !strcmp(url, dicache[i]->url) ) {
         Dicache_hit(imgsink, dicache[i]);
         return;
      }
   }
   Dicache_miss(imgsink, url, bw);
}

/*
 * Request an image from an URL.
 * If it doesn't hit inside the decompressed image cache,
 * retrieve it from the original server.
 */
void a_Dicache_request_url_img(DilloImgSink *imgsink, char *url,
                               BrowserWindow *bw)
{
#ifdef VERBOSE
   g_print("request_url_img %s\n", url);
#endif

   a_Interface_add_imgsink(bw, imgsink);
   a_Dicache_open(imgsink, url, bw);
}

/*
 * Deallocate memory used by dicache module
 * (Call this one at exit time)
 */
void a_Dicache_freeall(void)
{
   gint i;

   /* Remove every dicache line */
   for (i = 0; i < dicache_size; ++i)
      Dicache_remove(i);
   /* Remove the dicache list */
   g_free(dicache);
}

