#ifndef __GTK_HTML_H__
#define __GTK_HTML_H__

#include <gdk/gdk.h>
#include <gtk/gtkcontainer.h>

#include "dw.h"
#include "browser.h"

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/* First, the html linkblock. For now, this mostly has forms, although
   pointers to actual links will go here soon, if for no other reason
   than to implement history-sensitive link colors. Also, it seems
   likely that imagemaps will go here. */

typedef struct _DilloHtmlLB      DilloHtmlLB;

typedef struct _DilloHtml        DilloHtml;
typedef struct _DilloHtmlClass   DilloHtmlClass;
typedef struct _DilloHtmlState   DilloHtmlState;
typedef struct _DilloHtmlForm    DilloHtmlForm;
typedef struct _DilloHtmlOption  DilloHtmlOption;
typedef struct _DilloHtmlSelect  DilloHtmlSelect;
typedef struct _DilloHtmlInput   DilloHtmlInput;


struct _DilloHtmlLB {
  BrowserWindow *bw;
  char *base_url;

  DilloHtmlForm *forms;
  gint num_forms;
  gint num_forms_max;
  gint NRef;
};


typedef enum {
  DILLO_HTML_PARSE_MODE_INIT,
  DILLO_HTML_PARSE_MODE_STASH,
  DILLO_HTML_PARSE_MODE_BODY,
  DILLO_HTML_PARSE_MODE_PRE
} DilloHtmlParseMode;

struct _DilloHtmlState {
  char *tag;
  gint attr;
  DilloHtmlParseMode parse_mode;
  gint list_level;
};

typedef enum {
  DILLO_HTML_METHOD_GET,
  DILLO_HTML_METHOD_POST
} DilloHtmlMethod;

typedef enum {
  DILLO_HTML_ENC_URLENCODING
} DilloHtmlEnc;

struct _DilloHtmlForm {
  DilloHtmlMethod method;
  char *action;
  DilloHtmlEnc enc;

  DilloHtmlInput *inputs;
  gint num_inputs;
  gint num_inputs_max;
  gboolean HasSubmitButton;  /* Submit on enterpress if it doesn't have */
};

struct _DilloHtmlOption {
  GtkWidget *menuitem;
  char *value;
  gboolean init_val;
};

struct _DilloHtmlSelect {
  GtkWidget *menu;
  gint size;

  DilloHtmlOption *options;
  gint num_options;
  gint num_options_max;
};

typedef enum {
  DILLO_HTML_INPUT_TEXT,
  DILLO_HTML_INPUT_PASSWORD,
  DILLO_HTML_INPUT_CHECKBOX,
  DILLO_HTML_INPUT_RADIO,
  DILLO_HTML_INPUT_IMAGE,
  DILLO_HTML_INPUT_HIDDEN,
  DILLO_HTML_INPUT_SUBMIT,
  DILLO_HTML_INPUT_RESET,
  DILLO_HTML_INPUT_SELECT,
  DILLO_HTML_INPUT_SEL_LIST,
  DILLO_HTML_INPUT_TEXTAREA
} DilloHtmlInputType;

struct _DilloHtmlInput {
  DilloHtmlInputType type;
  GtkWidget *widget;
  char *name;
  char *init_str;    /* note: some overloading - for buttons, init_str
                        is simply the value of the button; for text
                        entries, it is the initial value */
  DilloHtmlSelect *select;
  gboolean init_val; /* only meaningful for buttons */
};

struct _DilloHtml {
  Dw *dw;

  DilloHtmlLB *linkblock;
  size_t Start_Ofs;

  DilloHtmlState *stack;
  gint stack_top;        /* Index to the top of the stack [0 based] */
  gint stack_max;

  char *stash_buf;
  gint stash_size;
  gint stash_size_max;
  gboolean stash_space;

  gboolean PrevWasCR;    /* Flag to help parsing of "\r\n" in PRE tags */

  BrowserWindow *bw;
};

#ifdef __cplusplus
}
#endif /* __cplusplus */


#endif /* __GTK_HTML_H__ */
