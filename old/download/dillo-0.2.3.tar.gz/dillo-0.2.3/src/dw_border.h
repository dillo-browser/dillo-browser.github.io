/* This module contains a simple dw container that adds a border around
   the child widget. In addition to providing the border around the page
   widget in dillo, it is also interesting to show how to make
   container widgets in dw. */

#ifndef __DW_BORDER_H__
#define __DW_BORDER_H__

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

typedef struct _DwBorder  DwBorder;

struct _DwBorder {
  Dw dw;

  Dw *child;
  gint border;
};

Dw *a_Dw_border_new (Dw *child, gint border);

#ifdef __cplusplus
}
#endif /* __cplusplus */


#endif /* __DW_BORDER_H__ */
