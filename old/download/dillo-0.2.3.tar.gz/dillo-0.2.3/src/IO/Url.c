/*
 * File: Url.c
 *
 * Copyright (C) 1997 Raph Levien <raph@acm.org>
 * Copyright (C) 1999 Randall Maas <randym@acm.org>,
 * Copyright (C) 1999, 2000 Jorge Arellano Cid <jcid@inf.utfsm.cl>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

/* Heavily modified by Jcid, Dec 1999 & Jun 2000
 *
 * Two types of functions here:
 *     1.- URL handling for openning URLs
 *     2.- URL parsing (as strings)
 */


#include <glib.h>
#include <stdlib.h>
#include "../list.h"
#include "Url.h"
#include "../prefs.h"
#include "../misc.h"

typedef struct {
   const char *Name;   /* Method name */
   __Open_t Data;      /* Pointer to a function */
} UrlMethod_t;

/*
 * Local data
 */
char *HTTP_Proxy = NULL, *No_Proxy = NULL;

static gint UrlOpenersSize = 0, UrlOpenersMax = 8;
static __Open_t *UrlOpeners = NULL;

gint UrlMethodsSize = 0, UrlMethodsMax = 8;
static UrlMethod_t *UrlMethods = NULL;

/*
 * Forward declarations
 */
gint a_Url_open(const char *url, void *Data);
gint Url_add_opener(__Open_t F);
gint Url_open(const char *url, void *Data);

/*
 * Add a method for Url handling 
 * (currently we have File, About & Http)
 */
gint Url_add_method(const char *Name, __Open_t Method)
{
   a_List_add(UrlMethods, UrlMethodsSize, sizeof(*UrlMethods), UrlMethodsMax);
   UrlMethods[UrlMethodsSize].Name = Name;
   UrlMethods[UrlMethodsSize].Data = Method;
   UrlMethodsSize++;
   return 0;
}

/*
 * Searches the Url methods list and returns the matching one
 * (UrlMethods list is not the UrlOpeners list. Don't be confused)
 */
__Open_t Url_proto_fetch(const char *Key, gint Size)
{
   gint i, j;

   for ( i = 0; i < UrlMethodsSize; ++i ) {
      for ( j = 0; j < Size; ++j )
         if ( tolower(Key[j]) != tolower(UrlMethods[i].Name[j]) )
            break;
      if ( j == Size )
         return UrlMethods[i].Data;
   }
   return NULL;
}

/*
 * This identifies the method specified in the URL.  
 * On success, Method is set to point the start of the method string; it is
 * NOT a zero terminated string.
 * 
 * Return Value:
 *   < 1 on error, otherwise the length of the method string.
 */
gint Url_proto_parse(const char *URL, const char **Method)
{

   char *EPtr = strpbrk(URL, URN_OTHER);

   if (!EPtr || *EPtr != ':')
      return 0;
   *Method = URL;

   return (EPtr - URL);
}

/*
 * Sets the handler methods for the different protocols supported by Dillo
 */
gint a_Url_init(void)
{
   HTTP_Proxy = getenv("http_proxy");
   No_Proxy = getenv("no_proxy");
   if (Url_add_opener(a_Proto_get_url) ||
       Url_add_opener(Url_open) ||
       Url_add_method("file", a_File_get) ||
       Url_add_method("about", a_About_get) ||
       Url_add_method("http", a_Http_get))
      return -1;
   return 0;
}

/*
 * Adds method 'F' to the list of URL openers. 
 * UrlOpeners are called in LIFO order until success.
 * [
 *   - 'F' will be called before any others are attempted.
 *   - 'F' needs to return -1 if it fails;
 *   - 'F' must ensure that it closes the FD_TypeWriter when it's done with it
 * ]
 * Return Value
 *   -1 on error, 0 otherwise
 */
gint Url_add_opener(__Open_t F)
{
   a_List_add(UrlOpeners, UrlOpenersSize, sizeof(__Open_t *), UrlOpenersMax);
   UrlOpeners[UrlOpenersSize] = F;
   UrlOpenersSize++;
   return 0;
}

/*
 * Create a new connection for URL 'url', and asynchronously feed the bytes
 * that come back to bytesink. 
 *
 * Return Value:
 *   < 0 on error, otherwise the file descriptor to get the data from
 */
gint Url_open(const char *url, void *Data)
{
   const char *Method;
   gint Length;
   __Open_t MPtr;

   /* Use the method to figure out what to do */
   Method = NULL;
   Length = Url_proto_parse(url, &Method);
   if ( Length < 1 )
      return -1;

   /* Scan our method tree to see if there is anything. */
   if (!(MPtr = Url_proto_fetch(Method, Length)))
      return -1;
   return MPtr(url, Data);
}

/*
 * Attempt to open the URL.
 * Try to open it using the URL openers in LIFO order.
 * (URL openers are stored in 'UrlOpeners')
 * Return Value:
 *   < 0 on error, otherwise a file descriptor for retrieving data
 * Side effect:
 *   The file descriptor is set to background IO
 */
gint a_Url_open(const char *Url, void *Data)
{
   gint i, FD;

   /* LIFO search */
   for (i = UrlOpenersSize - 1; i >= 0; i--) {
      FD = (UrlOpeners[i]) (Url, Data);
      if (FD < 0)
         continue;
      return FD;
   }
   return -1;
}


/*
 * URL parsing routines ====================================================
 */

/*
 * This routine checks to see if the URL passed is of the absolute form, or
 * of the relative form
 * 
 * Return Value:
 *   0 is not absolute, otherwise is absolute
 */
gint a_Url_is_absolute(const char *url)
{
   const char *P = strpbrk(url, URN_OTHER);

   return (P && *P == ':');
}

/*
 * Parse "http://a/b#c" into "http://a/b" and "#c".
 * 
 * Return Value:
 *   a pointer to the last hash (if any), otherwise NULL.
 */
char* a_Url_parse_hash(const char *Url)
{
   /* todo: I haven't checked this for standards compliance. What's it
    * supposed to do when there are two hashes? */
   /* Just use the last #c --MR-- */

   return strrchr(Url, '#');
}

/*
 * Return TRUE if the method matches. 
 */
static gint Url_match_method(const char *url, const char *method,
                            size_t Method_Size)
{
   if (g_strncasecmp(url, method, Method_Size))
      return 0;
   return (url[Method_Size] == ':');
}

/*
 * Squeeze an URL (strip /./ and /../ sequences)
 * Return value: squeezed URL.
 *  The funny thing is that I don't know if this is required!
 *  Anyway, it's highly tuned for speed  --Jcid
 */
char *a_Url_squeeze(char *str)
{
   char *s, *p;
   int i, ni, nc;
  
   s = p = str;
   ni = 0;
   while ( (p = strstr(p, "/.")) != NULL ) {
      if ( p[2] == '.' && (p[3] == '/' || !p[3]) ) { /* "/../" or "/.." */
         nc = p - s;
         for ( i = 0; i < nc; ++i )
            str[ni++] = s[i];
         if ( nc && ni )
            --ni;
         while ( ni && str[--ni] != '/');
         s = p = p + 3;
      } else if ( p[2] == '/' || !p[2] ) {  /* "/./" or "/." */
         nc = p - s;
         for ( i = 0; i < nc; ++i )
            str[ni++] = s[i];
         str[ni] = '/';
         s = p = p + 2;
      } else {                              /* "/.x" */
         p += 2;
      }
   }
   /* Append the rest of 'str' */
   if ( ni == 0 && !*s ) str[ni++] = '/';
   while ( (str[ni++] = *s++) );
   return str;
}

/*
 * Resolve a "file:" URL
 */
gchar *a_Url_resolve_file(const char *BaseUrl, const char *RelativeUrl)
{
   gchar *slash;
   const char *rel;
   gchar *NewUrl = NULL;

   if ( !BaseUrl || !RelativeUrl )
      return NULL;

   rel = RelativeUrl;
   if ( g_strncasecmp(RelativeUrl, "file:", 5) == 0 ) {
      /* An absolute file-URL! */
      rel = RelativeUrl + 5;
      if ( rel[0] == '/' ) {
         /* It was already solved (todo: squeeze it?) */
         NewUrl = g_strdup(RelativeUrl);
      } else {
         /* File reference to current directory.
          * ("file:" and "file:." show current dir */
         char *cwd = a_Misc_gnu_getcwd();
         if ( (rel[0] == '.' && !rel[1]) )
            ++rel;
         NewUrl = g_strdup_printf("file:%s%s%s", cwd, cwd[1] ? "/" : "", rel);
         g_free(cwd);
      }
      return NewUrl;
   } else if ( a_Url_is_absolute(RelativeUrl) ) {
      /* An absolute URL other than "file:" */
      return g_strdup(RelativeUrl);
   }

   /* If we get here, 'BaseUrl' contains "file:" and 'rel' not */

   if ( rel[0] == '/' ) {
      /* Start from root dir */
      NewUrl = g_strdup_printf("file:%s", rel);
   } else if ( rel[0] == '#' ) {
      /* Name reference, add it to BaseUrl. (todo: strip former '#') */
      NewUrl = g_strdup_printf("%s%s", BaseUrl, RelativeUrl);
   } else {
      /* a file relative to BaseUrl */
      slash = strrchr(BaseUrl, '/');
      if ( !slash ) {
         NewUrl = g_strdup_printf("file:%s", RelativeUrl);
      } else if ( a_Misc_stristr(slash, ".htm") ) {
         char *base = g_strndup(BaseUrl, slash - BaseUrl);
         NewUrl = g_strdup_printf("%s/%s", base, RelativeUrl);
         g_free(base);
      } else {
         NewUrl = g_strdup_printf("%s/%s", BaseUrl, RelativeUrl);
      }
   }
   return NewUrl;
}

/* 
 * Resolve a relative url into a newly allocated string.
 * This function is relatively tolerant to weird parameters (not 100%) --Jcid
 */
gchar *a_Url_resolve_relative(const char *BaseUrl, const char *RelativeUrl)
{
   gchar *p;
   gint i, path_index;
   gchar *NewUrl = NULL;

   if ( !BaseUrl || !RelativeUrl )
      return NULL;

   /* "file" method here */
   if ( Url_match_method(BaseUrl, "file", 4) || 
        Url_match_method(RelativeUrl, "file", 4) ){
      NewUrl = a_Url_resolve_file(BaseUrl, RelativeUrl);
      // g_print( "FRR New : %s\n", NewUrl);
      return NewUrl;
   }

   if ( a_Url_is_absolute(RelativeUrl) ){
      /* It has the "method:..." form. */
      return g_strdup(RelativeUrl);
   }

   /* Parse method:/[/]name:port/ in BaseUrl 
    * e.g. http://hostname:port/ */
   for (i = 0; BaseUrl[i] && BaseUrl[i] != ':'; i++);
   for (i++; BaseUrl[i] && BaseUrl[i] == '/'; i++);
   for (i++; BaseUrl[i] && BaseUrl[i] != '/'; i++);
   path_index = i;

   if ( RelativeUrl[0] == '/' ){
      /* Get host from BaseUrl */
      if ( i && BaseUrl[i] == '/' ) {
         gchar *base = g_strndup(BaseUrl, i);
         NewUrl = g_strdup_printf("%s%s", base, RelativeUrl);
         g_free(base);
      } else {
         NewUrl = g_strdup_printf("%s%s", BaseUrl, RelativeUrl);
      }
   } else {
      /* Get host and path from BaseUrl */
      if ( BaseUrl[i] && (p = strrchr(BaseUrl, '/')) != NULL ) {
         gchar *base = g_strndup(BaseUrl, p - BaseUrl);
         NewUrl = g_strdup_printf("%s/%s", base, RelativeUrl);
         g_free(base);
      } else {
         NewUrl = g_strdup_printf("%s/%s", BaseUrl, RelativeUrl);
      }
   }
   a_Url_squeeze(NewUrl);
// g_print("URR\n Base: %s\n Rel: %s\n New:%s\n", BaseUrl,RelativeUrl,NewUrl);
   return NewUrl;
}

/* 
 * Parse the url, packing the hostname and port into the arguments, and
 * returning the suffix. Return NULL in case of failure.
 */
char *a_Url_parse(const char *url, char *hostname, gint hostname_size,
                  gint *port)
{
   const char *CPtr = strchr(url, ':');
   char *C1Ptr;
   size_t Size;

   if (!CPtr || CPtr[1] != '/' || CPtr[2] != '/')
      return NULL;

   CPtr += 3;
   if (!(C1Ptr = strpbrk(CPtr, ":/"))) {
      Size = strlen(CPtr);
      if (!hostname)
         return (char *) CPtr + Size;
      if (Size >= hostname_size)
         return NULL;
      strncpy(hostname, CPtr, Size);
      hostname[Size] = '\0';
      return (char *) CPtr + Size;
   }
   Size = (gulong) C1Ptr - (gulong) CPtr;
   if (hostname) {
      if (Size >= hostname_size)
         return NULL;
      strncpy(hostname, CPtr, Size);
      hostname[Size] = '\0';
   }
   if (*C1Ptr != ':')
      return (char *) C1Ptr;

   if (port)
      *port = strtoul(++C1Ptr, &C1Ptr, 0);

   for (; *C1Ptr && *C1Ptr != '/'; C1Ptr++);
   return C1Ptr;
}


