#ifndef __DILLO_BOOKMARK_H__
#define __DILLO_BOOKMARK_H__

void a_Bookmarks_init();
void a_Bookmarks_add(GtkWidget *widget, gpointer client_data);

#endif /* __DILLO_BOOKMARK_H__ */
