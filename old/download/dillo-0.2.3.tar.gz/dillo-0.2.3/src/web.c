/*
 * File: web.c
 *
 * Copyright 2000 Jorge Arellano Cid <jcid@inf.utfsm.cl>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

#include <stdio.h>
#include <stdlib.h>
#include <gtk/gtk.h>

#include "web.h"
#include "IO/IO.h"
#include "cache.h"
#include "html.h"
#include "interface.h"

#include "dw.h"
#include "dw_embedgtk.h"
#include "dw_border.h"
#include "IO/mime.h"
#include "dillo.h"
#include "nav.h"
#include "prefs.h"


/*
 * Given the MIME content type, and a fd to read it from,
 * this function connects the proper MIME viewer to it.
 */
Dw* a_Web_dispatch_by_type (const char *Type, DilloWeb *Web,
                            CA_Callback_t *Call, void **Data)
{
   Dw *dw;

   g_return_val_if_fail(Web->bw != NULL, NULL);

   dw = a_Mime_set_viewer(Type, Web, Call, Data);
   g_return_val_if_fail(dw != NULL, NULL);

   if ( Web->flags & WEB_RootUrl ) {
      a_Dw_gtk_scroller_set_dw(GTK_DW_SCROLLER(Web->bw->docwin),
                               a_Dw_border_new(dw, 5));
      /* Set the background color for pages without a <BODY> tag */
      a_Dw_set_color(dw, prefs.bg_color);
      /* Set the title bar for pages without a <TITLE> tag */
      a_Interface_set_Page_title(Web->bw, "");
   }

   /* Set the base_url in the linkblock */
   if ( Web->url && Web->linkblock ) {
      if ( Web->linkblock->base_url )
         g_free(Web->linkblock->base_url);
      Web->linkblock->base_url = g_strdup(Web->url);
   }
   
   if ( Web->bw->nav_expecting )
      a_Nav_expect_done(Web->bw, dw);

   return dw;
}

/*
 * Deallocate a DilloWeb structure
 */
void a_Web_free(DilloWeb *web)
{
   if (!web) return;
   if (web->url)
      g_free(web->url);
   g_free(web);
}

/*
 * Allocate and set safe values for a DilloWeb structure
 */
DilloWeb* a_Web_new(const char *url)
{
   DilloWeb *web= g_new(DilloWeb, 1);
 
   web->url = g_strdup(url);

   web->bw = NULL;
   web->dw = NULL;
   web->linkblock = NULL;
   web->flags = 0;

   web->imgsink = NULL;
   web->stream  = NULL;

   return web;
}

