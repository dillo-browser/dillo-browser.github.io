/*
 * File: about.c
 *
 * Copyright (C) 1997 Raph Levien <raph@acm.org>
 * Copyright (C) 1999, 2001 Jorge Arellano Cid <jcid@inf.utfsm.cl>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

#include <pthread.h>

#include "Url.h"
#include "../nav.h"
#include "../web.h"

typedef struct _SplashInfo SplashInfo_t;

struct _SplashInfo {
   gint FD_Read;
   gint FD_Write;
};


/*
 * HTML text for startup screen
 */
static char *Splash=
"Content-type: text/html

<!DOCTYPE HTML PUBLIC '-//W3C//DTD HTML 4.0 Transitional//EN'>
<html>
<head>
<title>Splash screen for dillo-0.7.0</title>
</head>
<body bgcolor='#778899' text='#000000' link='#000000' vlink='#000000'>


<!--                          -->
<!--   the head of the page   -->
<!--                          -->

<table width='100%' border='0' cellspacing='1' cellpadding='3'>
 <tr><td>
   <table border='1' cellspacing='1' cellpadding='0'>
    <tr>
    <td bgcolor='#000000'>
     <table width='100%' border='0' bgcolor='#ffffff'>
     <tr>
       <td valign='top' align='left'>
         <h1>&nbsp;Welcome to Dillo 0.7.0&nbsp;</h1>
       </td>
     </tr>
     </table>
    </tr>
   </table>
 </td></tr>
</table>

<!-- a small horizontal spacer -->
<br>


<!--                                   -->
<!-- the main layout table, definition -->
<!--                                   -->

<table width='100%' border='0' cellspacing='0' cellpadding='0'>
<tr><td valign='top' width='150' align='center'>


<!--                        -->
<!--   The navigation bar   -->
<!--                        -->

<table border='0' cellspacing='0' cellpadding='0' width='140' bgcolor='#000000'>
<tr>
  <td>
    <table width='100%' border='0' cellspacing='1' cellpadding='3'>
    <tr>
      <td colspan='1' bgcolor='#CCCCCC'>
        Dillo
      </td>
    </tr>
    <tr>
      <td bgcolor='#FFFFFF'>
        <table border='0' cellspacing='0' cellpadding='5'><tr><td>
        <table border='0' cellspacing='0' cellpadding='2'><tr>
        <td></td>
        <td>
         <a href='http://dillo.auriga.wearlab.de/dillo-help.html'>
         Help</a></td>
        </tr><tr>
        <td>&nbsp;&nbsp;</td>
        <td>
         <a href='http://dillo.auriga.wearlab.de/'>Home</a></td>
        </tr><tr>
        <td>&nbsp;&nbsp;</td>
        <td>
         <a href='http://dillo.auriga.wearlab.de/funding/objectives.html'>
         Objectives</a></td>
        </tr><tr>
        <td>&nbsp;&nbsp;</td>
        <td>
         <a href='http://dillo.auriga.wearlab.de/ChangeLog.html'>
         ChangeLog</a></td>
        </tr><tr>
        <td>&nbsp;&nbsp;</td>
        <td>
         <a href='http://dillo.auriga.wearlab.de/interview.html'>
           Interview</a></td>
        </tr><tr>
        <td>&nbsp;&nbsp;</td>
        <td>
         <a href='http://dillo.auriga.wearlab.de/D_authors.html'>
         Authors</a></td>
        </tr></table>
        </td></tr></table>
      </td>
    </tr>
    </table>
  </td>
</tr>
</table>

<!-- a small horizontal spacer -->
<br>

<table border='0' cellspacing='0' cellpadding='0' width='140' bgcolor='#000000'>
<tr>
  <td>
    <table width='100%' border='0' cellspacing='1' cellpadding='3'>
    <tr>
      <td colspan='1' bgcolor='#CCCCCC'>
        Magazines
      </td>
    </tr>
    <tr>
      <td bgcolor='#FFFFFF'>
        <table border='0' cellspacing='0' cellpadding='5'><tr><td>
        <table border='0' cellspacing='' cellpadding='2'><tr>
        <td>&nbsp;&nbsp;</td>
        <td>
         <a href='http://lwn.net'>LWN</a></td>
        </tr><tr>
        <td>&nbsp;&nbsp;</td>
        <td>
         <a href='http://linuxtoday.com/'>Linux Today</a></td>
        </tr><tr>
        <td>&nbsp;&nbsp;</td>
        <td>
         <a href='http://slashdot.org/'>Slashdot</a></td>
        </tr><tr>
        <td>&nbsp;&nbsp;</td>
        <td>
         <a href='http://www.kuro5hin.org/?op=section;section=__all__'>KuroShin</a></td>
        </tr><tr>
        <td>&nbsp;&nbsp;</td>
        <td>
         <a href='http://www.nexusmagazine.com'>Nexus&nbsp;M.</a></td>
        </tr><tr>
        <td>&nbsp;&nbsp;</td>
        <td>
         <a href='http://www.theregister.co.uk/index.html'>The Register</a></td>
        </tr><tr>
        <td>&nbsp;&nbsp;</td>
        <td>
         <a href='http://www.linuxforkids.org'>Linux4Kids</a></td>
        </tr></table>
        </td></tr></table>
      </td>
    </tr>
    </table>
  </td>
</tr>
</table>

<!-- a small horizontal spacer -->
<br>

<table border='0' cellspacing='0' cellpadding='0' width='140' bgcolor='#000000'>
<tr>
  <td>
    <table width='100%' border='0' cellspacing='1' cellpadding='3'>
    <tr>
      <td colspan='1' bgcolor='#CCCCCC'>
        Additional Stuff
      </td>
    </tr>
    <tr>
      <td bgcolor='#FFFFFF'>
        <table border='0' cellspacing='0' cellpadding='5'><tr><td>
        <table border='0' cellspacing='' cellpadding='2'><tr>
        <td>&nbsp;&nbsp;</td>
        <td><a href='http://www.google.com/'>Google</a></td>
        </tr><tr>
        <td>&nbsp;&nbsp;</td>
        <td><a href='http://freshmeat.net/'>FreshMeat</a></td>
        </tr><tr>
        <td>&nbsp;&nbsp;</td>
        <td><a href='http://www.gnu.org/gnu/thegnuproject.html'>GNU
         project</a></td>
        </tr><tr>
        <td>&nbsp;&nbsp;</td>
        <td><a href='http://www.linuxfund.org/'>LinuxFund</a></td>
        </tr></table>
        </td></tr></table>
      </td>
    </tr>
    </table>
  </td>
</tr>
</table>

<!-- a small horizontal spacer -->
<table border='0' width='100%' cellpadding='0' cellspacing='0'><tr><td height='10'></td></tr></table>



<!--                                                -->
<!-- the main layout table, a small vertical spacer -->
<!--                                                -->

</td><td width='20'></td><td valign='top'>


<!--                           -->
<!--   Main Part of the page   -->
<!--                           -->

<table border='0' cellpadding='0' cellspacing='0' align='center' bgcolor='#000000' width='100%'><tr><td>
<table border='0' cellpadding='5' cellspacing='1' width='100%'>
<tr>
  <td bgcolor='#CCCCCC'>
    <h4>Free Software</h4>
  </td>
</tr><tr>
  <td bgcolor='#FFFFFF'>
    <table border='0' cellspacing='0' cellpadding='5'><tr><td>
 <p>
 Dillo is Free Software in the terms of the GPL.
 This means you have four basic freedoms:
 <ul>
  <li>Freedom to use the program any way you see fit.
  <li>Freedom to study and modify the source code.
  <li>Freedom to make backup copies.
  <li>Freedom to redistribute it.
 </ul>
 The
<a href='http://www.gnu.org/licenses/gpl.html'>GPL</a>
 is the legal mechanism that gives you these freedoms.
It also protects them from being taken away: any derivative work
based on the program must be under the GPL.
 <br>
    </td></tr></table>
  </td>
</tr>
</table>
</td></tr></table>

<!-- a small horizontal spacer -->
<br>

<table border='0' cellpadding='0' cellspacing='0' align='center' bgcolor='#000000' width='100%'><tr><td>
<table border='0' cellpadding='5' cellspacing='1' width='100%'>
<tr>
  <td bgcolor='#CCCCCC'>
    <h4>Release overview</h4>
    17 February 2003
  </td>
</tr><tr>
  <td bgcolor='#FFFFFF'>
    <table border='0' cellspacing='0' cellpadding='5'>
    <tr>
     <td>

<P>
  This  release  is a major milestone. It features the new plugin
framework:  a gateway to extend dillo and to interface with external
programs. (It is not compatible with other browsers' plugins.)
<P>
  Dillo plugins
(<a href='http://dillo.auriga.wearlab.de/dpi1.html'>dpi</a>)
allow
extending  the  browser without increasing its core size. It even
allows using dillo as a GUI!
<P>
  We  also  made  this  dillo  embeddable!  All the rendering and
surfing  capabilities  can be used from another GTK+ application.
For instance, check this
<a href='http://melvin.hadasht.free.fr/home/dillo/sylpheed/
spamsafe-0.7.0.png'>screenshot</a> from the
<a href='http://melvin.hadasht.free.fr/home/dillo/sylpheed/'>
sylpheed-claws</a> email client.
<P>
  Now  dillo  does  IPv6, highlights found text and uses a plugin
program to manage its bookmarks.
<br><br>
     </td>
    </tr></table>
  </td>
</tr>
</table>
</td></tr></table>

<!-- a small horizontal spacer -->
<br>

<table border='0' cellpadding='0' cellspacing='0' align='center' bgcolor='#000000' width='100%'><tr><td>
<table border='0' cellpadding='5' cellspacing='1' width='100%'>
<tr>
  <td bgcolor='#CCCCCC'>
    <h4>ChangeLog highlights</h4>
    (Extracted from the full
    <a href='http://dillo.auriga.wearlab.de/ChangeLog.html'>ChangeLog</a>)
  </td>
</tr><tr>
  <td bgcolor='#FFFFFF'>
    <table border='0' cellspacing='0' cellpadding='5'>
    <tr>
     <td>
 <ul>
   <li> Added a simple command line interface, and enabled some options.
   <li> Improved alignment inside tables:
     <ul>
       <li> LEFT, RIGHT, CENTER, JUSTIFY, CHAR,
       <li> TOP, BOTTOM, MIDDLE, BASELINE. </ul>
   <li> Made dillo embeddable into other GTK+ applications.
   <li> Concomitant Control Chain (CCC):
     <ul>
       <li> Extended the theory to allow bidirectional message passing.
       <li> Reimplemented dillo's core with the new chains. </ul>
   <li> Input/Output engine (IO):
     <ul>
       <li> Extended the functionallity with a threaded operation that
            allows buffered writes of small chunks on the same FD.
       <li> Created a new IO API, and adapted dillo to it. </ul>
   <li> Used the new CCC and IO to implement dillo plugins! (dpi).
   <li> Wrote a dpi-program for bookmarks.
   <li> Added IPv6 support! [./configure --enable-ipv6]
   <li> Rewrote findtext with highlighting and a case-sensitive option.
   <li> Added a tiny warning/handler for meta refresh.
 </ul>
 <br>
     </td>
    </tr></table>
  </td>
</tr>
</table>
</td></tr></table>

<!-- a small horizontal spacer -->
<br>

<table border='0' cellpadding='0' cellspacing='0' align='center' bgcolor='#000000' width='100%'><tr><td>
<table border='0' cellpadding='5' cellspacing='1' width='100%'>
<tr>
  <td bgcolor='#CCCCCC'>
    <h4>Notes</h4>
  </td>
</tr><tr>
  <td bgcolor='#FFFFFF'>
    <table border='0' cellspacing='0' cellpadding='5'>
    <tr>
     <td>
 <ul>
   <li> There's a
     <a href='http://dillo.auriga.wearlab.de/dillorc'>dillorc</a>
     (readable  config)  file within the tarball; It is well commented
     and  has  plenty  of  options to customize dillo, so <STRONG>copy
     it</STRONG>  to  your  <STRONG>~/.dillo/</STRONG>  directory, and
     modify to your taste.
   <li> There's documentation for developers in the <CODE>/doc</CODE>
     dir  within  the  tarball;  you can find directions on everything
     else at the home page.
   <li> Dillo has context sensitive menus using the
     right mouse button (available on pages, links, and the Back and Forward buttons).
   <li> Dillo behaves very nicely when browsing local files, images, and HTML.
     It's also very good for Internet searching (try Google!).
   <li> This release is mainly intended <strong>for developers</strong>
        and <em>advanced users</em>
   <li> Frames, Java and Javascript are not supported.
 </ul>
 <br>
     </td>
    </tr></table>
  </td>
</tr>
</table>
</td></tr></table>

<!-- a small horizontal spacer -->
<table border='0' width='100%' cellpadding='0' cellspacing='0'><tr><td height='10'></td></tr></table>


<!--                                                -->
<!-- the main layout table, a small vertical spacer -->
<!--                                                -->

</td><td width='20'></td>



<!--                             -->
<!--   The right column (info)   -->
<!--                             -->
<td valign='top' align='center'>
</td>


<!--                              -->
<!-- end of the main layout table -->
<!--                              -->

</td>
</tr>
</table>

<!--               -->
<!--   footnotes   -->
<!--               -->

<br><br><center>
<hr size='2'>
<hr size='2'>
</center>
</body>
</html>
";



/*
 * Send the splash screen through the IO using a pipe.
 */
static gint About_send_splash(ChainLink *Info, DilloUrl *Url)
{
   gint SplashPipe[2];
   IOData_t *io1;
   SplashInfo_t *SpInfo;

   if (pipe(SplashPipe))
      return -1;

   SpInfo = g_new(SplashInfo_t, 1);
   SpInfo->FD_Read  = SplashPipe[0];
   SpInfo->FD_Write = SplashPipe[1];
   Info->LocalKey = SpInfo;

   /* send splash */
   io1 = a_IO_new(IOWrite, SpInfo->FD_Write);
   a_IO_set_buf(io1, Splash, strlen(Splash));
   io1->Flags |= (IOFlag_ForceClose + IOFlag_SingleWrite);
   a_Chain_link_new(Info, a_About_ccc, BCK, a_IO_ccc, 1, 1);
   a_Chain_bcb(OpStart, Info, io1, NULL);
   a_Chain_bcb(OpSend, Info, io1, NULL);

   /* Tell the cache to receive answer */
   a_Chain_fcb(OpSend, Info, (void *)SpInfo->FD_Read, NULL);
   return SpInfo->FD_Read;
}

/*
 * Push the right URL for each supported "about"
 * ( Data1 = Requested URL; Data2 = Web structure )
 */
static gint About_get(ChainLink *Info, void *Data1, void *Data2)
{
   char *loc;
   const char *tail;
   DilloUrl *Url = Data1;
   DilloWeb *web = Data2;
   DilloUrl *LocUrl;

   tail = URL_PATH(Url);

   if (!strcmp(tail, "splash")) {
      return About_send_splash(Info, Url);
   }

   if (!strcmp(tail, "jwz"))
      loc = "http://www.jwz.org/";
   else if (!strcmp(tail, "raph"))
      loc = "http://www.levien.com/";
   else if (!strcmp(tail, "yosh"))
      loc = "http://yosh.gimp.org/";
   else if (!strcmp(tail, "snorfle"))
      loc = "http://www.snorfle.net/";
   else if (!strcmp(tail, "dillo"))
      loc = "http://dillo.auriga.wearlab.de/";
   else if (!strcmp(tail, "help"))
      loc = "http://dillo.auriga.wearlab.de/dillo-help.html";
   else
      loc = "http://www.google.com/";

   LocUrl = a_Url_new(loc, NULL, 0, 0);
   a_Nav_push(web->bw, LocUrl);
   a_Url_free(LocUrl);
   return -1;
}

/*
 * CCC function for the ABOUT module
 */
void a_About_ccc(int Op, int Branch, int Dir, ChainLink *Info,
                 void *Data1, void *Data2)
{
   int FD;

   a_Chain_debug_msg("a_About_ccc", Op, Branch, Dir);

   if ( Branch == 1 ) {
      /* Start about method */
      if (Dir == BCK) {
         switch (Op) {
         case OpStart:
            /* (Data1 = URL;  Data2 = Web) */
            // Info->LocalKey gets set in About_get
            if ((FD = About_get(Info, Data1, Data2)) == -1)
               a_Chain_fcb(OpAbort, Info, NULL, NULL);
            break;
         case OpAbort:
            a_Chain_bcb(OpAbort, Info, NULL, NULL);
            g_free(Info->LocalKey);
            g_free(Info);
            break;
         }
      } else {  /* FWD */
         switch (Op) {
         case OpSend:
            /* This means the sending framework was set OK */
            FD = ((SplashInfo_t *)Info->LocalKey)->FD_Read;
            a_Chain_fcb(OpSend, Info, (void *)FD, NULL);
            break;
         case OpEnd:
            /* Everything sent! */
            a_Chain_del_link(Info, BCK);
            g_free(Info->LocalKey);
            a_Chain_fcb(OpEnd, Info, NULL, NULL);
            break;
         case OpAbort:
            g_free(Info->LocalKey);
            a_Chain_fcb(OpAbort, Info, NULL, NULL);
            break;
         }
      }
   }
}

