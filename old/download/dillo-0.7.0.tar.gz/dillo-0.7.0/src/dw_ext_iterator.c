/*
 * File: dw_ext_iterator.c
 *
 * Copyright (C) 2002 Sebastian Geerken <S.Geerken@ping.de>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

/*
 * DwExtIterator is an extension of DwIterator, which stores
 * DwIterator's in a stack, for cases where recursions are not
 * possible.
 * 
 * DwWordIterator is a simple wrapper for DwExtIterator, which splits
 * text segments into words, and is used for text search (in
 * findtext.c)
 * 
 * todo: In some cases (e.g. for "<i>foo</i>bar"), DwIterator and
 *       DwExtIterator return two words, where there is actually only
 *       one.  In this case, iterator->content.space is set to FALSE.
 *       DwWordIterator currently ignores this flag, but instead
 *       returns two words, instead of concaternating them to one.
 */

#include "dw_ext_iterator.h"
#include "list.h"
#include "misc.h"

/*
 * Create a new DwExtIterator from an existing DwIterator.
 * The content of the return value will be the content of "it".
 * NOTES:
 * (i)  If you want to continue using "it", pass a_Dw_iterator_clone (it).
 * (ii) The mask of "it" must include DW_CONTENT_WIDGET, but 
 *      a_Dw_ext_iterator_next will never return widgets.
 */
DwExtIterator* a_Dw_ext_iterator_new (DwIterator *it)
{
   DwExtIterator *eit = g_new (DwExtIterator, 1);
   DwWidget *w;
   int sp;

   eit->stack_top = 0;
   /* If this widget has parents, we must construct appropiate iterators.
    * todo: There should be a faster way instead of
    * iterating through the parent widgets. */
   /* NOTE: This has not yet been tested fully! */
   for (w = it->widget; w->parent != NULL; w = w->parent)
      eit->stack_top++;
   eit->stack_max = 4;
   while (eit->stack_top >= eit->stack_max)
      eit->stack_max <<= 1;

   /* Construct the iterators. */
   for (w = it->widget, sp = eit->stack_top - 1;
       w->parent != NULL;
       w = w->parent, sp--) {
      eit->stack[sp] = a_Dw_widget_iterator (w->parent, it->mask, FALSE);
      while (TRUE) {
         while (!a_Dw_iterator_next(eit->stack[sp])) {
            g_warning ("BUG in DwExtIterator!");
            return NULL;
         }
         if (eit->stack[sp]->content.type == DW_CONTENT_WIDGET &&
             eit->stack[sp]->content.data.widget == w)
            break;
      }
   }

   eit->stack = g_new (DwIterator*, eit->stack_max);
   eit->stack[eit->stack_top] = it;
   eit->content = it->content;
   return eit;
}

/*
 * Move iterator forward and store content in it. Returns TRUE on
 * success.
 */
gboolean a_Dw_ext_iterator_next (DwExtIterator *eit)
{
   DwIterator *it = eit->stack[eit->stack_top];

   if (a_Dw_iterator_next(it)) {
      if (it->content.type == DW_CONTENT_WIDGET) {
         /* Widget: new iterator on stack, to search in this widget. */
         eit->stack_top++;
         a_List_add (eit->stack, eit->stack_top, eit->stack_max);
         eit->stack[eit->stack_top] =
            a_Dw_widget_iterator (it->content.data.widget, it->mask, FALSE);
         return a_Dw_ext_iterator_next (eit);
      } else {
         /* Simply return the content of the iterartor. */
         eit->content = it->content;
         return TRUE;
      }
   } else {
      /* No more data in the top-most widget. */
      if (eit->stack_top > 0) {
         /* Pop iterator from stack, and move to next item in the old one. */
         a_Dw_iterator_free (it);
         eit->stack_top--;
         return a_Dw_ext_iterator_next (eit);
      } else {
         /* Stack is empty. */
         eit->content.type = DW_CONTENT_END;
         return FALSE;
      }
   }         
}

/*
 * Move iterator backward and store content in it. Returns TRUE on
 * success.
 */
gboolean a_Dw_ext_iterator_prev (DwExtIterator *eit)
{
   DwIterator *it = eit->stack[eit->stack_top];

   if (a_Dw_iterator_prev(it)) {
      if (it->content.type == DW_CONTENT_WIDGET) {
         /* Widget: new iterator on stack, to search in this widget. */
         eit->stack_top++;
         a_List_add (eit->stack, eit->stack_top, eit->stack_max);
         eit->stack[eit->stack_top] =
            a_Dw_widget_iterator (it->content.data.widget, it->mask, TRUE);
         return a_Dw_ext_iterator_prev (eit);
      } else {
         /* Simply return the content of the iterartor. */
         eit->content = it->content;
         return TRUE;
      }
   } else {
      /* No more data in the top-most widget. */
      if (eit->stack_top > 0) {
         /* Pop iterator from stack, and move to previous item in the
            old one. */
         a_Dw_iterator_free (it);
         eit->stack_top--;
         return a_Dw_ext_iterator_prev (eit);
      } else {
         /* Stack is empty. */
         eit->content.type = DW_CONTENT_START;
         return FALSE;
      }
   }         
}

/*
 * Create an exact copy of the iterator, which then can be used
 * independantly of the original one.
 */
DwExtIterator* a_Dw_ext_iterator_clone (DwExtIterator *eit)
{
   int i;
   DwExtIterator *eit2 = g_new (DwExtIterator, 1);
   eit2->stack_top = eit->stack_top;
   eit2->stack_max = eit->stack_max;
   eit2->content = eit->content;

   eit2->stack = g_new (DwIterator*, eit2->stack_max);
   for (i = 0; i <= eit2->stack_top; i++)
      eit2->stack[i] = a_Dw_iterator_clone (eit->stack[i]);

   return eit2;
}

/*
 * Free memory of iterator.
 */
void a_Dw_ext_iterator_free (DwExtIterator *eit)
{
   int i;
   for (i = 0; i < eit->stack_top; i++)
      a_Dw_iterator_clone (eit->stack[i]);
   g_free (eit->stack);
   g_free (eit);
}

/*
 * Create a new word iterator. <widget> is the top of the widget
 * tree over which is iterated.
 */
DwWordIterator* a_Dw_word_iterator_new (DwWidget *widget)
{
   DwWordIterator *it;
   DwIterator *it0;
 
   it = g_new (DwWordIterator, 1);
   it->word = NULL;
   it0 = a_Dw_widget_iterator (widget, DW_CONTENT_TEXT | DW_CONTENT_WIDGET,
                               FALSE);
   it->iterator = a_Dw_ext_iterator_new (it0);
   it->word_splitpos = NULL;
   it->content_hl_start = -1;
   it->content_hl_end = -1;
   return it;
}

/*
 * Move iterator forward and store word in it. Returns TRUE on
 * success.
 */
gboolean a_Dw_word_iterator_next (DwWordIterator *it)
{
   if (it->word) {
      g_free (it->word);
      it->word = NULL;
   }

   while (it->word_splitpos == NULL ||
          it->word_splitpos[2 * (it->word_pos + 1)] == -1) {
      if (it->word_splitpos) {
         g_free (it->word_splitpos);
         it->word_splitpos = NULL;
         it->content_hl_start = -1;
         it->content_hl_end = -1;
      }
      if (!a_Dw_ext_iterator_next (it->iterator))
         return FALSE;
      it->word_splitpos =
         a_Misc_strsplitpos (it->iterator->content.data.text, " \t\n");
      it->word_pos = -1;
   }
   
   it->word_pos++;
   it->word = a_Misc_strpdup (it->iterator->content.data.text,
                              it->word_splitpos[2 * it->word_pos],
                              it->word_splitpos[2 * it->word_pos + 1]);
   return TRUE;
}


/*
 * Move iterator backward and store word in it. Returns TRUE on
 * success.
 */
gboolean a_Dw_word_iterator_prev (DwWordIterator *it)
{
   if (it->word) {
      g_free (it->word);
      it->word = NULL;
   }

   while (it->word_splitpos == NULL || it->word_pos == 0) {
      if (it->word_splitpos) {
         g_free (it->word_splitpos);
         it->word_splitpos = NULL;
         it->content_hl_start = -1;
         it->content_hl_end = -1;
      }
      if (!a_Dw_ext_iterator_prev (it->iterator))
         return FALSE;
      it->word_splitpos =
         a_Misc_strsplitpos(it->iterator->content.data.text, " \t\n");
      it->word_pos = 0;
      while (it->word_splitpos[2 * it->word_pos] != -1)
         it->word_pos++;
   }
   
   it->word_pos--;
   it->word = a_Misc_strpdup (it->iterator->content.data.text,
                              it->word_splitpos[2 * it->word_pos],
                              it->word_splitpos[2 * it->word_pos + 1]);
   return TRUE;
}

/*
 * Highlight a part of the current word. Unhighlight the current word
 * by passing -1 as start.
 */
void a_Dw_word_iterator_highlight (DwWordIterator *it,
                                   gint start,
                                   gint end)
{
   gint new_start, new_end;

   if (start == -1) {
      /* Unhighlight the whole content word.
       * todo: This works incorrect, by unhighlighting the whole
       * current content of the DwExtIterator. Anyway, a correct
       * behavior is not needed. */
      it->content_hl_start = -1;
      it->content_hl_end = -1;
      a_Dw_ext_iterator_unhighlight (it->iterator);
   } else {
      new_start = it->word_splitpos[2 * it->word_pos] + start;
      new_end = it->word_splitpos[2 * it->word_pos] + end;

      if (it->content_hl_start == -1) {
         /* nothing selected yet */
         it->content_hl_start = new_start;
         it->content_hl_end = new_end;
      } else {
         it->content_hl_start = MIN (it->content_hl_start, new_start);
         it->content_hl_end = MAX (it->content_hl_end, new_end);
      }
      
      a_Dw_ext_iterator_highlight (it->iterator, it->content_hl_start,
                                   it->content_hl_end);
   }
}


DwWordIterator* a_Dw_word_iterator_clone (DwWordIterator *it)
{
   DwWordIterator *it2;

   it2 = g_new (DwWordIterator, 1);
   *it2 = *it;
   it2->iterator = a_Dw_ext_iterator_clone (it->iterator);
   it2->word = it->word ? g_strdup (it->word) : NULL;
   it2->word_splitpos =
      it->word_splitpos ? a_Misc_strsplitposdup (it->word_splitpos) : NULL;
   return it2;
}

void a_Dw_word_iterator_free (DwWordIterator *it)
{
   a_Dw_ext_iterator_free (it->iterator);
   if (it->word)
      g_free (it->word);
   if (it->word_splitpos)
      g_free (it->word_splitpos);
   g_free (it);
}
