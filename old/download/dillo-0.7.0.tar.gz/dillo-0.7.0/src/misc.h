#ifndef __MISC_H__
#define __MISC_H__

char *a_Misc_prepend_user_home(const char *file);
gchar *a_Misc_escape_chars(const gchar *str, gchar *esc_set);
char *a_Misc_stristr(char *src, char *str);
char *a_Misc_expand_tabs(const char *str);
gchar *a_Misc_strsep(char **orig, const char *delim);
#define d_strsep a_Misc_strsep
gint *a_Misc_strsplitpos(const gchar *str, const gchar *delim);
gint *a_Misc_strsplitposdup(gint *pos);
/* Return a NUL-terminated string containing the characters from p1 to p2. */
#define a_Misc_strpdup(s, p1, p2) g_strndup((s) + (p1), (p2) - (p1))

#endif /* __MISC_H__ */

