#ifndef __CACHE_H__
#define __CACHE_H__

#include <glib.h>


/*
 * Cache Op codes
 */
#define CA_Send    (0)  /* Normal update */
#define CA_Close   (1)  /* Successful operation close */
#define CA_Abort   (2)  /* Operation abort */

/*
 * Flag Defines
 */
#define CA_GotHeader      (1)  /* True if header is completely got */
#define CA_GotData        (2)  /* True if we have all Data in cache */
#define CA_FreeData       (4)  /* Free the cache Data on close */
#define CA_Redirect       (8)  /* Data actually points to a redirect */
#define CA_ForceRedirect (16)  /* Unconditional redirect */
#define CA_NotFound      (32)  /* True if remote server didn't found the URL */
#define CA_Stopped       (64)  /* True if the entry has been stopped */

/*
 * Callback type for cache clients
 */
typedef struct _CacheClient CacheClient_t;
typedef void (*CA_Callback_t)(int Op, CacheClient_t *Client);

/*
 * Data structure for cache clients.
 */
struct _CacheClient {
   gint Key;                /* Primary Key for this client */
   const char *Url;         /* Pointer to a cache entry Url */
   guchar *Buf;             /* Pointer to cache-data */
   guint BufSize;           /* Valid size of cache-data */
   CA_Callback_t Callback;  /* Client function */
   void *CbData;            /* Client function data */
   void *Web;               /* Pointer to the Web structure of our client */
};

/*
 * Function prototypes
 */
void a_Cache_redirect_url(const char* Orig_URL, const char* To_Url);
gint a_Cache_open_url(const char *url, CA_Callback_t Call, void *CbData);
void a_Cache_callback(int Op, void *VPtr);

char *a_Cache_url_read(const char *url, gint *size);
void a_Cache_remove_entry(char *url);
void a_Cache_freeall(void);
void a_Cache_null_client(int Op, CacheClient_t *Client);
gint a_Cache_make_client_key(void);
void a_Cache_disable_client(gint Key);
void a_Cache_stop_entry(gchar *Url);

#endif /* __CACHE_H__ */

