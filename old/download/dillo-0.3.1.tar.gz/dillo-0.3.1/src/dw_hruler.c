/*
 * File: dw_hruler.c
 *
 * Copyright (C) 2000 Jorge Arellano Cid <jcid@inf.utfsm.cl>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

#include <gtk/gtk.h>
#include "dw.h"
#include "dw_hruler.h"


/*
 * todo: implement this function so the ruler can resize dinamically.
 */
static void Dw_hruler_size_nego_y(Dw *dw, DwRect *allocation)
{
/*
   DwContainer *container;

   g_print(">Dw_hruler_size_nego_y() called\n");
   dw->allocation = *allocation;
   container = a_Dw_find_container (dw);
   if (container != NULL) {
      dw_hruler->width = container->visible.x1 - container->visible.x0 - 25;
   }
   g_print(">width set to %d\n", dw_hruler->width);
   a_Dw_request_paint(dw, allocation);
*/
   DwHruler *dw_hruler = (DwHruler *)dw;
   DwContainer *container;
   gint new_width;

   dw->allocation = *allocation;
   container = a_Dw_find_container(dw);
   if (container != NULL) {
      new_width = container->visible.x1 - container->visible.x0 - 20;
      //            - 2 * container->border_width;

   dw_hruler->dw.req_width_min = dw_hruler->dw.req_width_max = new_width;
   a_Dw_request_paint(dw, allocation);

/*
   container = a_Dw_find_container(dw);
   if (container != NULL) {
      GtkAllocation child_allocation;
      child_allocation.x = container->x_offset + dw->allocation.x0;
      child_allocation.y = container->y_offset + dw->allocation.y0;
      child_allocation.width = dw->allocation.x1 - dw->allocation.x0;
      child_allocation.height = dw->allocation.y1 - dw->allocation.y0;
      gtk_widget_size_allocate (((DwHruler *)dw)->widget, &child_allocation);
*/
   }
}

/*
 * Draw an horizontal ruler within the container boundaries
 */
static void Dw_hruler_paint(Dw *dw, DwRect *rect, DwPaint *paint)
{
   DwHruler *dw_hruler = (DwHruler *)dw;
   GtkWidget *widget;
   DwContainer *container;
   gint x, y;

   /* g_print(">Dw_hruler_paint() called\n"); */
   container = a_Dw_find_container (dw);
   if (container != NULL) {
      widget = container->widget;
      a_Dw_paint_to_screen (widget, container, rect, paint);
      x = dw->allocation.x0 + container->x_offset;
      y = dw->allocation.y0 + container->y_offset;
      gdk_draw_line (widget->window,
                     widget->style->dark_gc[widget->state],
                     x, y,
                     x + dw_hruler->dw.req_width_min, y);
      gdk_draw_line (widget->window,
                     widget->style->light_gc[widget->state],
                     x, y + 1,
                     x + dw_hruler->dw.req_width_min, y + 1);
      a_Dw_paint_finish_screen (paint);
   }
}

/*
 * ?
 */
static void Dw_hruler_destroy(Dw *dw)
{
   g_free(dw);
}

static const DwClass Dw_hruler_class = {
   NULL,                        /* Not used */
   Dw_hruler_size_nego_y,
   Dw_hruler_paint,
   NULL,                        /* handle event not used */
   NULL,                        /* gtk_foreach not used */
   Dw_hruler_destroy,
   NULL                         /* request_resize is not used */
};

/*
 * ?
 */
Dw *a_Dw_hruler_new(int width)
{
   DwHruler *dw_hruler;
   DwRect null_rect = { 0, 0, 0, 0 };

   dw_hruler = g_new(DwHruler, 1);
   dw_hruler->dw.klass = &Dw_hruler_class;
   dw_hruler->dw.allocation = null_rect;
   dw_hruler->dw.req_width_min = width;
   dw_hruler->dw.req_width_max = width;

   dw_hruler->dw.req_height = 2;
   dw_hruler->dw.req_ascent = 0;

   dw_hruler->dw.flags = 0;
   dw_hruler->dw.parent = NULL;
   dw_hruler->dw.container = NULL;

   return (Dw *) dw_hruler;
}
