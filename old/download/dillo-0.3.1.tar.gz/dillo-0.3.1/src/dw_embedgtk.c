/*
 * File: dw_embedgtk.c
 *
 * Copyright (C) 1997 Raph Levien <raph@acm.org>
 * Copyright (C) 1999 Luca Rota <drake@freemail.it>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

/*
 * A Dw widget that embeds gtk widgets inside.
 */

/* todo: deal with the child widget resizing. */

#include <gtk/gtk.h>
#include "dw.h"
#include "dw_embedgtk.h"

static void
Dw_embed_gtk_size_nego_y (Dw *dw, DwRect *allocation)
{
  DwContainer *container;
  GtkAllocation child_allocation;

  dw->allocation = *allocation;
  container = a_Dw_find_container (dw);
  if (container != NULL) {
     child_allocation.x = container->x_offset + dw->allocation.x0;
     child_allocation.y = container->y_offset + dw->allocation.y0;
     child_allocation.width = dw->allocation.x1 - dw->allocation.x0;
     child_allocation.height = dw->allocation.y1 - dw->allocation.y0;
     gtk_widget_size_allocate (((DwEmbedGtk *)dw)->widget, &child_allocation);
  }
}

static void
Dw_embed_gtk_paint (Dw *dw, DwRect *rect, DwPaint *paint)
{
  DwContainer *container;
  GtkAllocation child_allocation;
  GtkWidget *child;
  GdkEventExpose child_event;

#ifdef VERBOSE
  g_print ("Dw_embed_gtk_paint (%d, %d) - (%d, %d)\n",
           rect->x0, rect->y0, rect->x1, rect->y1);
#endif
  container = a_Dw_find_container (dw);
  g_return_if_fail (container != NULL);
  child = ((DwEmbedGtk *)dw)->widget;
  if (!GTK_WIDGET_REALIZED (child)) {
     /* Need to size allocate and realize the child widget. */
     gtk_widget_set_parent (child, container->widget);
     child_allocation.x = container->x_offset + dw->allocation.x0;
     child_allocation.y = container->y_offset + dw->allocation.y0;
     child_allocation.width = dw->allocation.x1 - dw->allocation.x0;
     child_allocation.height = dw->allocation.y1 - dw->allocation.y0;
     gtk_widget_size_allocate (child, &child_allocation);
     gtk_widget_realize (child);
  }
  if (!GTK_WIDGET_MAPPED (child))
    gtk_widget_map (child);
  if (GTK_WIDGET_NO_WINDOW (child)) {
     /* this call may not be necessary - it may be ok to call
        expose of the child widget with the screen in a "don't care"
        state. */
     a_Dw_paint_to_screen (container->widget, container, rect, paint);

     /* create a child expose event */
     child_event.type = GDK_EXPOSE;
     child_event.window = container->widget->window;
     child_event.area.x = container->x_offset + rect->x0;
     child_event.area.y = container->y_offset + rect->y0;
     child_event.area.width = rect->x1 - rect->x0;
     child_event.area.height = rect->y1 - rect->y0;
     child_event.count = 0; /* this cheats slightly */

     gtk_widget_event (child, (GdkEvent *) &child_event);

     a_Dw_paint_finish_screen (paint);
  }
}

static void
Dw_embed_gtk_foreach (Dw *dw, DwCallback callback, gpointer callback_data,
                       DwRect *plus, DwRect *minus)
{
  DwContainer *container;
  DwRect test_rect;
  GtkAllocation child_allocation;

  a_Dw_rect_intersect (&test_rect, plus, &dw->allocation);
  if (a_Dw_rect_empty (&test_rect))
    return;
  a_Dw_rect_intersect (&test_rect, minus, &dw->allocation);
  if (!a_Dw_rect_empty (&test_rect))
    return;
  container = a_Dw_find_container (dw);
  child_allocation.x = container->x_offset + dw->allocation.x0;
  child_allocation.y = container->y_offset + dw->allocation.y0;
  child_allocation.width = dw->allocation.x1 - dw->allocation.x0;
  child_allocation.height = dw->allocation.y1 - dw->allocation.y0;
  (*callback) (((DwEmbedGtk *) dw)->widget, callback_data,
               &child_allocation);
}

static void Dw_embed_gtk_destroy (Dw *dw)
{
  gtk_widget_destroy (((DwEmbedGtk *)dw)->widget);
  g_free (dw);
}

static const DwClass Dw_embed_gtk_class =
{
  NULL, /* size_nego_x not needed */
  Dw_embed_gtk_size_nego_y,
  Dw_embed_gtk_paint,
  NULL, /* handle event not used */
  Dw_embed_gtk_foreach,
  Dw_embed_gtk_destroy,
  NULL /* request resize is not used */
};

Dw *a_Dw_embed_gtk_new (GtkWidget *widget)
{
  DwEmbedGtk *dw_embed_gtk;
  DwRect null_rect = {0, 0, 0, 0};

  dw_embed_gtk = g_new (DwEmbedGtk, 1);
  dw_embed_gtk->dw.klass = &Dw_embed_gtk_class;
  dw_embed_gtk->dw.allocation = null_rect;

  /* We start the size negotiation now, so that we can fill in the
     requisition. */

  /* todo: we're not handling the case well where the widget is not
     visible. */

  gtk_widget_size_request (widget, &widget->requisition);

  dw_embed_gtk->dw.req_width_min = widget->requisition.width;
  dw_embed_gtk->dw.req_width_max = widget->requisition.width;

  dw_embed_gtk->dw.req_height = widget->requisition.height;
  dw_embed_gtk->dw.req_ascent = 0;

  dw_embed_gtk->dw.flags = 0;
  dw_embed_gtk->dw.parent = NULL;
  dw_embed_gtk->dw.container = NULL;

  dw_embed_gtk->widget = widget;

  /* todo: how to handle the widget's request_resize operation? It is
     generally handled in the toplevel Gtk container, but that leaves
     no way to resolve from the Gtk widget to "us", i.e. the specific
     Dw widget that embeds the Gtk widget.

     It may be that the only real solution is for the container to keep
     a list of Gtk widgets it contains. If this is done, it may obviate
     the need for the whole gtk_foreach mechanism.

     A totally reasonable data structure for holding the list would be
     sorted by y coordinate.
   */

  return &dw_embed_gtk->dw;
}
