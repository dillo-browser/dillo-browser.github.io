/*
 * File: dw_page.c
 *
 * Copyright (C) 1997 Raph Levien <raph@acm.org>
 * Copyright (C) 1999 Luca Rota <drake@freemail.it>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

/*
 * This module contains the Dw_page widget, which is the "back end" to
 * Web text widgets including html.
 */

#define TRACE_GTK_METHODS
#undef NO_WINDOW
#define HUGE_WINDOW
#define DW_PAGE_MAX_WINDOW_SIZE 32760

#include <ctype.h>
#include <string.h>
#include <stdio.h>

#include <gtk/gtk.h>

#include "list.h"
#include "dw.h"
#include "dw_page.h"
#include "dw_gtk_scroller.h"   /* for anchors */
#include "browser.h"           /* -RL :: I need it for BrowserWindow struct */
#include "prefs.h"
#include "commands.h"
#include "menu.h"

#define DW_GET_BW(page)   (BrowserWindow *)((page)->status_data)

/*
 * Set GtkDwScroller::anchor_pos value.
 * It is very important from where this function is called, since the last line
 * of the page (page->lines[page->num_lines - 1].y_top) is used!
 */
static void Dw_page_set_scroller_pos (DwPage *page, char *anchor)
{
   DwContainer *container;
   GtkDwScroller *scroller;

   /* Search for Dw container */
   if ( !(container = a_Dw_find_container(&page->dw)) ){
      g_print("BUG: Dw container not found\n");
      return;
   }

   scroller = GTK_DW_SCROLLER (container->widget->parent);

   if (scroller->anchor && !strcmp(anchor, scroller->anchor) ) {
      scroller->anchor_pos = page->lines[page->num_lines - 1].y_top;
      /*g_print ("Dw_page_set_scroller_pos: *%s* -> %d\n",
        scroller->anchor, page->lines[page->num_lines - 1].y_top);*/
   }
}

/* todo:
 *
 * + do request_repaint for added stuff. But what level of
 * granularity? reinstate the update_begin/update_end cycle? Do at
 * line granularity when making a new line (but risk paint
 * inconsistency)? Do at word granularity but take on region overhead
 * on every word (optimize away if outside visible rectangle)?
 *
 * + better formatting, including justification & floats
 *
 */


/*
 * Returns the x offset (the indentation plus any offset needed for
 * centering or right justification) for the line. The offset returned
 * is relative to the page (i.e. add allocation.x0 to get the dw
 * toplevel coordinate.
 */
static gint Dw_page_line_x_offset(DwPage *page, DwPageLine *line)
{
   gint x;

   if (line->first)
      x = page->attrs[line->words[0].attr].left_indent_first;
   else
      x = page->attrs[line->words[0].attr].left_indent_rest;
   return x;
}

/*
 * Dw_page_finish_line "finishes" the last line in the page. At
 * present, the only function is to size allocate the child widgets.
 * Later, it will be responsible for some justification code.
 *
 * Note: there is no need to request paint for the child widget,
 * because this is (presumably) done by update_end.
 */
static void Dw_page_finish_line(DwPage *page)
{
   DwPageLine *line;
   DwPageWord *word;
   DwRect rect;
   gint word_index;
   gint x_cursor, y_cursor;

   line = &page->lines[page->num_lines - 1];
   x_cursor = page->dw.allocation.x0 + Dw_page_line_x_offset(page, line);
   y_cursor = page->dw.allocation.y0 + line->y_top + line->y_ascent;
   for (word_index = 0; word_index < line->num_words; word_index++) {
      word = &line->words[word_index];
      if (word->content_type == DW_PAGE_CONTENT_WIDGET) {
         rect.x0 = x_cursor;
         rect.y0 = y_cursor - word->y_ascent;
         rect.x1 = x_cursor + word->x_size;
         rect.y1 = y_cursor + word->y_descent;
         a_Dw_size_nego_y(word->content.widget, &rect);
      }
      x_cursor += word->x_size + word->x_space;
   }
}

/*
 * ?
 */
static void Dw_page_add_line(DwPage *page)
{
   gint num_lines;
   DwPageLine *line;

   num_lines = page->num_lines;
   if (num_lines > 0)
      Dw_page_finish_line(page);
   a_List_add(page->lines,num_lines,sizeof(*page->lines),page->num_lines_max);
   line = &page->lines[num_lines];
   line->num_words_max = 20;
   line->num_words = 0;
   line->words = g_new(DwPageWord, line->num_words_max);
   if (num_lines == 0) {
      line->y_top = 0;
   } else {
      line->y_top =
          page->lines[num_lines - 1].y_top +
          page->lines[num_lines - 1].y_ascent +
          page->lines[num_lines - 1].y_descent +
          page->lines[num_lines - 1].y_space;
   }
   line->x_size = 0;
   line->y_ascent = 6;
   line->y_descent = 3;
   line->y_space = 0;
   line->hard = FALSE;
   line->first = (num_lines == 0 || (page->lines[num_lines - 1].hard &&
                                page->lines[num_lines - 1].y_space > 0));
   page->num_lines++;
}

/*
 * Allocate a new word in a page structure. This routine is where word
 * wrapping happens. The newly allocated word has the x_size, x_space,
 * y_ascent, and y_descent fields filled in, but no others.
 */
static DwPageWord *Dw_page_new_word(DwPage *page,
                                    gint x_size,
                                    gint y_ascent,
                                    gint y_descent,
                                    gint attr)
{
   DwPageLine *line;
   DwPageWord *word;
   gboolean new_line;
   gint width, set_width, nw, nl;
   DwPageAttr *Attr = &page->attrs[attr];

   new_line = FALSE;
   nl = page->num_lines;
   if ( nl == 0 ) {
      new_line = TRUE;
   } else {
      line = &page->lines[nl - 1];
      if ( line->hard ) {
         new_line = TRUE;
      } else {
         /* Calculate width of new line and see if it exceeds page width. */
         nw = line->num_words;
         if ( nw > 0 ) {
            set_width = page->width - Attr->right_indent;
            if ( line->first )
               set_width -= Attr->left_indent_first;
            else
               set_width -= Attr->left_indent_rest;
            if ( set_width < 100 )
               set_width = 100;
            width = line->x_size + line->words[nw - 1].x_space + x_size;
            if ( width > set_width )
               new_line = TRUE;
         }
      }
   }

   if (new_line) {
      Dw_page_add_line(page);
      line = &page->lines[nl];
   }
   nw = line->num_words;
   a_List_add(line->words, nw, sizeof(*line->words), line->num_words_max);
   word = &line->words[nw];
   word->x_size = x_size;
   word->x_space = 0;
   word->y_ascent = y_ascent;
   word->y_descent = y_descent;
   line->num_words++;

   if (nw)
      line->x_size += line->words[nw - 1].x_space;
   line->x_size += x_size;
   line->y_ascent = MAX(line->y_ascent, y_ascent);
   line->y_descent = MAX(line->y_descent, y_descent);

   /* update the width requisitions */
   if ( nw == 0 && line->first )
      page->last_line_max_width = x_size + Attr->left_indent_first;
   else if ( nw == 0 )
      page->last_line_max_width += line->words[0].x_space + x_size;
   else
      page->last_line_max_width += line->words[nw - 1].x_space + x_size;
   page->dw.req_width_max = MAX(page->dw.req_width_max,
                                page->last_line_max_width);
   page->dw.req_width_min = MAX(page->dw.req_width_min, x_size);

   return word;
}



/* Performance is not as good as it could be - it could only rewrap if
 * it needs to (should be a cheap test: the line is ok if it fits
 * within the page->width and either it's hard or the width plus the
 * width of the first word on the next line (plus the spacing of the
 * last word) exceed the page->width). This would save on memory
 * allocation too.
 *
 * But hey, it works!
 */

/*
 * Rewrap the page.
 * There are basically two times we'll want to do this:
 * either when the viewport is resized, or when the size changes on one
 * of the child widgets.
 */
static void Dw_page_rewrap(DwPage *page)
{
   DwPageLine *old_lines;
   gint old_num_lines;

   gint line_index, word_index;
   DwPageLine *old_line;
   DwPageWord *old_word, *word;

   old_lines = page->lines;
   old_num_lines = page->num_lines;

   /* g_print(">>> Dw_page_rewrap\n"); */

   /* Initialize the lines structure of the page. */
   page->num_lines = 0;
   page->num_lines_max = 16;
   page->lines = g_new(DwPageLine, page->num_lines_max);

   /* todo: reset width requisitions...
    * they will be rebuilt by Dw_page_new_word. */

   /* Iterate over the old lines, adding the words to the page structure. */
   for (line_index = 0; line_index < old_num_lines; line_index++) {
      old_line = &(old_lines[line_index]);
      /* Here, we're actually relying on the invariant that a soft line
       * is never followed by an empty hard line. */
      if (old_line->num_words == 0 && old_line->hard) {
         Dw_page_add_line(page);
      }
      for (word_index = 0; word_index < old_line->num_words; word_index++) {
         old_word = &(old_line->words[word_index]);

         /* Here we check for a word-widget resize request  --Jcid */
         if ( old_word->content_type == DW_PAGE_CONTENT_WIDGET &&
              old_word->content.widget->flags & DW_FLAG_REQ_RESIZE ){
            word = Dw_page_new_word(page,
                                    old_word->content.widget->req_width_min,
                                    old_word->content.widget->req_height,
                                    0, old_word->attr);
         } else {
            word = Dw_page_new_word(page,
                                    old_word->x_size,
                                    old_word->y_ascent,
                                    old_word->y_descent, old_word->attr);
         }
         word->x_space = old_word->x_space;
         word->content_type = old_word->content_type;
         word->content = old_word->content;
         word->attr = old_word->attr;

        if ( word->content_type == DW_PAGE_CONTENT_ANCHOR ) {
           /* y + 1 is stored in hash table to avoid problems with y == 0
            * (which would be stored as a NULL pointer) */
           g_hash_table_insert(page->anchors_table,
                               word->content.anchor,
                               (void*)
                                (page->lines[page->num_lines - 1].y_top + 1));
           Dw_page_set_scroller_pos(page, word->content.anchor);
        }
      }

      if (old_line->hard) {
         a_Dw_page_linebreak(page);
         page->lines[page->num_lines - 1].y_space = old_line->y_space;
      }
      g_free(old_line->words);
   }
   g_free(old_lines);

   a_Dw_request_parent_resize(&page->dw);
   /* Request that the entire visible area be repainted. After some
    * optimization, it may be possible to restrict the repainted area
    * to being much smaller. */
   a_Dw_request_paint(&page->dw, &page->dw.allocation);
}

/*
 * Rewrap the page at idle time
 * This approach avoids one rewrap per image resize request.
 * I'm not sure if this is the best we can do, but it works...  --Jcid
 */
static gint Dw_page_idle_rewrap(Dw *dw)
{
   Dw_page_rewrap((DwPage *) dw);
   dw->flags &= ~DW_FLAG_REQ_REWRAP;
   return FALSE;
}

/*
 * ?
 */
static void Dw_page_size_nego_x(Dw *dw, gint width)
{
   DwPage *page;

   page = (DwPage *) dw;
   if (width != page->width) {
      page->width = width;
      Dw_page_rewrap(page);
   }
   if (page->num_lines > 0)
      dw->req_height = page->lines[page->num_lines - 1].y_top +
          page->lines[page->num_lines - 1].y_ascent +
          page->lines[page->num_lines - 1].y_descent;
#ifdef VERBOSE
   g_print("dw_page_size_nego_x: requisition = %d - %d x %d\n",
           page->dw.req_width_min, page->dw.req_width_max,
           page->dw.req_height);
#endif
}

/*
 * ?
 */
static void Dw_page_size_nego_y(Dw *dw, DwRect *allocation)
{
   DwPage *page;
   DwPageLine *line;
   DwPageWord *word;
   DwRect rect;
   gint line_index, word_index;
   gint x_cursor, y_cursor;

   page = (DwPage *)dw;

   /* todo: handle a rewrap request generated by a child's resize request.
            (Partialy done  --Jcid) */

   dw->allocation = *allocation;

   for (line_index = 0; line_index < page->num_lines; line_index++) {
      line = &page->lines[line_index];
      x_cursor = page->dw.allocation.x0 + Dw_page_line_x_offset (page, line);
      y_cursor = page->dw.allocation.y0 + line->y_top + line->y_ascent;
      for (word_index = 0; word_index < line->num_words; word_index++) {
         word = &line->words[word_index];
         if (word->content_type == DW_PAGE_CONTENT_WIDGET) {
            word->x_size = (word->content.widget)->req_width_min;
            word->y_ascent = (word->content.widget)->req_height;
            rect.x0 = x_cursor;
            rect.y0 = y_cursor - word->y_ascent;
            rect.x1 = x_cursor + word->x_size;
            rect.y1 = y_cursor + word->y_descent;
            a_Dw_size_nego_y (word->content.widget, &rect);
         }
         x_cursor += word->x_size + word->x_space;
      }
   }
#ifdef VERBOSE
   g_print("dw_page_size_nego_y: allocation = (%d, %d) - (%d, %d)\n",
           dw->allocation.x0, dw->allocation.x1,
           dw->allocation.y0, dw->allocation.y1);
#endif
}

/* x and y are toplevel dw coordinates */
static void Dw_page_expose_line(DwPage *page,
                                DwRect *rect,
                                DwPaint *paint,
                                DwPageLine *line,
                                gint x,
                                gint y)
{
   GtkWidget *widget;
   DwContainer *container;
   GdkColormap *colormap;
   DwPageWord *word;
   gint word_index;
   gint x_cursor, y_cursor;
   gint last_font = -1;
   gint font;
   gint32 last_color = -1;
   gint32 color;
   GdkGC *gc;
   gint uline_width;
   DwRect child_rect;

   /* Here's an idea on how to optimize this routine to minimize the number
    * of calls to gdk_draw_string:
    *
    * Copy the text from the words into a buffer, adding a new word
    * only if: the attributes match, and the spacing is either zero or
    * equal to the width of ' '. In the latter case, copy a " " into
    * the buffer. Then draw the buffer. */

   container = a_Dw_find_container(&page->dw);
   widget = container->widget;

   /* A gtk question: should we be creating our own gc? */

   x_cursor = x + container->x_offset;
   y_cursor = y + line->y_ascent + container->y_offset;
   gc = page->gc;
   for (word_index = 0; word_index < line->num_words; word_index++) {
      word = &(line->words[word_index]);
      switch (word->content_type) {
      case DW_PAGE_CONTENT_TEXT:
         font = page->attrs[word->attr].font;
#ifndef USE_TYPE1
         if (font != last_font) {
            gdk_gc_set_font(gc, page->fonts[font].font);
            last_font = font;
         }
#endif
         color = page->attrs[word->attr].color;
         if (color != last_color) {
            if ( !page->colors[color].allocated ){
               colormap = gtk_widget_get_colormap(widget);
               page->colors[color].allocated = gdk_colormap_alloc_color(
                  colormap, &page->colors[color].color, FALSE, TRUE);
            }
            gdk_gc_set_foreground(gc, &page->colors[color].color);
            last_color = color;
         }
         gdk_draw_string(widget->window,
                         page->fonts[font].font,
                         gc,
                         x_cursor,
                         y_cursor,
                         word->content.text);
         if (page->attrs[word->attr].link >= 0) {
            uline_width = word->x_size;
            if (word_index + 1 < line->num_words &&
                page->attrs[word->attr].link ==
                page->attrs[line->words[word_index + 1].attr].link)
               uline_width += word->x_space;
            gdk_draw_line(
               widget->window,
               gc,
               x_cursor,
               y_cursor + 1,
               x_cursor + uline_width - 1,
               y_cursor + 1);
         } else if (page->attrs[word->attr].uline >= 0) {
            uline_width = word->x_size;
            if (word_index + 1 < line->num_words &&
                page->attrs[word->attr].uline ==
                page->attrs[line->words[word_index + 1].attr].uline)
               uline_width += word->x_space;
            gdk_draw_line(
               widget->window,
               gc,
               x_cursor,
               y_cursor + 1,
               x_cursor + uline_width - 1,
               y_cursor + 1);
         }

         if (page->attrs[word->attr].strike >= 0) {
            uline_width = word->x_size;
            if (word_index + 1 < line->num_words &&
                page->attrs[word->attr].strike ==
                page->attrs[line->words[word_index + 1].attr].strike)
               uline_width += word->x_space;
            gdk_draw_line(widget->window,
                          gc,
                          x_cursor,
                          y_cursor - word->y_ascent / 2,
                          x_cursor + uline_width - 1,
                          y_cursor - word->y_ascent / 2);
         }
         break;
      case DW_PAGE_CONTENT_WIDGET:
         a_Dw_rect_intersect(&child_rect, rect,
                             &word->content.widget->allocation);
         if (!a_Dw_rect_empty(&child_rect)) {
            a_Dw_paint(word->content.widget, &child_rect, paint);
            a_Dw_paint_to_screen(widget, container, &child_rect, paint);
         }
         break;
      case DW_PAGE_CONTENT_ANCHOR:
        /* nothing - an anchor isn't seen */
        /* BUG: sometimes anchors have x_space; 
         * we subtract that just in case --EG */
        x_cursor -= word->x_size + word->x_space;
        break;
      }
      x_cursor += word->x_size + word->x_space;
   }
}


/*
 * Find the first line index that includes y, relative to top of widget.
 */
static gint Dw_page_find_line_index(DwPage *page, gint y)
{
   gint line_index;

   /* This could be a faster algorithm, for example a binary search. */

   for (line_index = 0; line_index < page->num_lines; line_index++) {
      if (page->lines[line_index].y_top +
          page->lines[line_index].y_ascent +
          page->lines[line_index].y_descent > y)
         break;
   }

   return line_index;
}


/*
 * Draw the actual lines, starting at (x, y) in toplevel Dw coords.
 */
static void Dw_page_expose_lines(DwPage *page,
                                 DwRect *rect,
                                 DwPaint *paint,
                                 gint x,
                                 gint y)
{
   gint line_index;
   DwPageLine *line;
   gint x1;

   line_index = Dw_page_find_line_index(page, rect->y0 - y);
   for (; line_index < page->num_lines; line_index++) {
      line = &(page->lines[line_index]);
      if (y + line->y_top >= rect->y1)
         break;
      /* Maybe should move this into expose_line */
      x1 = x + Dw_page_line_x_offset(page, line);
      Dw_page_expose_line(page, rect, paint,
                          &(page->lines[line_index]),
                          x1,
                          y + page->lines[line_index].y_top);
   }
}

/*
 * ?
 */
static void Dw_page_paint(Dw *dw, DwRect *rect, DwPaint *paint)
{
   GtkWidget *widget;
   DwContainer *container;
   DwPage *page;
   gint x, y;

#ifdef VERBOSE
   g_print("dw_page_paint (%d, %d) - (%d, %d)",
           rect->x0, rect->y0, rect->x1, rect->y1);
#endif
   container = a_Dw_find_container(dw);
   if (container != NULL) {
#ifdef VERBOSE
      g_print(", visible = (%d, %d) - (%d, %d)\n",
              container->visible.x0, container->visible.y0,
              container->visible.x1, container->visible.y1);
#endif
      widget = container->widget;
      a_Dw_paint_to_screen(widget, container, rect, paint);
      page = (DwPage *) dw;

      /* todo: this should probably be in the realize method, not here. */
      if (page->gc == NULL) {
         page->gc = gdk_gc_new(widget->window);
      }
      /* get x and y from dw's allocation */
      x = page->dw.allocation.x0;
      y = page->dw.allocation.y0;

      Dw_page_expose_lines(page, rect, paint, x, y);
      a_Dw_paint_finish_screen(paint);
   }
}

/*
 * Find a link given a coordinate location relative to the window
 */
static gint Dw_page_find_link(DwPage *page, gint x, gint y)
{
   gint line_index;
   gint word_index;
   gint x_cursor, last_x_cursor;
   gint x1, y1;                 /* coordinates relative to page */
   gint x0, y0;                 /* coordinates relative to word */
   DwPageLine *line;

   DwPageWord *word;
   DwContainer *container;
   DwPageShape *shape;
   int dx,dy;
   int num_shape;
   guint map;

   container = a_Dw_find_container(&page->dw);
   if (container == NULL)
      return -1;

   x1 = x - (container->x_offset + page->dw.allocation.x0);
   y1 = y - (container->y_offset + page->dw.allocation.y0);

   line_index = Dw_page_find_line_index(page, y1);
   x0 = x1;
   y0 = y1 - page->lines[line_index].y_top;
   page->x_click = -1;

   if (line_index >= page->num_lines)
      return -1;
   line = &page->lines[line_index];
   x_cursor = Dw_page_line_x_offset(page, line);
   for (word_index = 0; word_index < line->num_words; word_index++) {
      word = &line->words[word_index];
      last_x_cursor = x_cursor;
      x_cursor += word->x_size + word->x_space;
      if (last_x_cursor <= x1 && x_cursor > x1) {
         // page->x_click = word->attr;
         // page->y_click = page->attrs[word->attr].flags;

         if(page->attrs[word->attr].link >= 0) {
            if(page->attrs[word->attr].flags & DW_PAGE_HAS_MAP) {
               page->x_click = x0;
               page->y_click = y0;
            }
            else
               page->x_click = -1;
            return page->attrs[word->attr].link;
         }
         else if (page->attrs[word->attr].flags & DW_PAGE_HAS_MAP) {
            //page->x_click = x0;
            //page->y_click = y0;
            map = page->attrs[word->attr].map;
            for ( num_shape=0 ; num_shape<page->num_shapes ; num_shape++) {
               shape = &(page->shapes[num_shape]);
               if(shape->map == map) {
                  if(shape->type == DW_PAGE_SHAPE_CIRCLE) {
                     dx = shape->data.circle.x - x0;
                     dy = shape->data.circle.y - y0;
                     if(shape->data.circle.r2>=(dx*dx+dy*dy))
                        return shape->link;
                  }
                  else if(shape->type == DW_PAGE_SHAPE_RECT) {
                     if(x0>shape->data.rect.left
                     && x0<shape->data.rect.right
                     && y0>shape->data.rect.top
                     && y0<shape->data.rect.bottom
                     )
                        return shape->link;
                  }
                  else if(shape->type == DW_PAGE_SHAPE_POLY) {
                     if(gdk_region_point_in (shape->data.poly, x0, y0))
                        return shape->link;
                  }
               }
            }
         }
      }
   }
   return -1;
}

/*
 * ?
 */
static void Dw_page_handle_event(Dw *dw, GdkEvent *event)
{
   DwPage *page = (DwPage *) dw;
   BrowserWindow *bw = DW_GET_BW(page);
   GdkEventButton *button;
   GdkEventMotion *motion;
   gint hover_link;

   GdkCursorType CursorType;
   char full_url[1024];

   switch (event->type) {
   case GDK_BUTTON_PRESS:
      button = (GdkEventButton *) event;
#ifdef VERBOSE
      g_print("dw_page_handle_event: button (%g, %g) +%d\n",
              button->x, button->y, button->button);
#endif
      /* todo: I think we need to do a grab. Do we do it here, or in
       * the gtk_dw_view? */

      if (button->button == 1) {
         /* Button 1: follow link */
         page->link_pressed = Dw_page_find_link(page, button->x, button->y);
      }
      if (button->button == 2) {
         /* Button 2: open link in a new window */
         gint link_pressed = Dw_page_find_link(page, button->x, button->y);
         if (link_pressed >= 0) {
            bw->menu_popup.info.title = "";
            bw->menu_popup.info.url = page->links[link_pressed].url;
            a_Commands_open_link_nw_callback(NULL, bw);
         }
         return;
      }
      if (button->button == 3) {
         /* Button 3: show link-relative pop-up menu */
         gint link_pressed = Dw_page_find_link(page, button->x, button->y);

         if (link_pressed >= 0) {
            bw->menu_popup.info.title = "";
            bw->menu_popup.info.url = page->links[link_pressed].url;
            gtk_menu_popup(GTK_MENU(bw->menu_popup.menu_over_link), NULL, NULL,
                           NULL, NULL, button->button, button->time);
         } else {
            if (bw->nav_stack_size == 0)
               return;

            bw->menu_popup.info.title = bw->nav_stack[bw->nav_stack_ptr].title;
            bw->menu_popup.info.url = bw->nav_stack[bw->nav_stack_ptr].url;
            gtk_menu_popup(GTK_MENU(bw->menu_popup.menu), NULL, NULL,
                           NULL, NULL, button->button, button->time);
         }
         return;
      }
      break;

   case GDK_BUTTON_RELEASE:
      button = (GdkEventButton *) event;

#ifdef VERBOSE
      g_print("dw_page_handle_event: button (%g, %g) -%d\n",
              button->x, button->y, button->button);
#endif

      if (button->button == 1) {
         gint link_pressed = page->link_pressed;

         page->link_pressed = -1;
         if (link_pressed >= 0 &&
             link_pressed == Dw_page_find_link(page, button->x, button->y)) {
#ifdef VERBOSE
            g_print("dw_page_handle_event: link %s\n",
                    page->links[page->link_pressed].url);
#endif
            if (page->link != NULL) {
            /*
             * todo: How do we pass these datas to the server ?
             * Url.c functions can't deal with that yet
             */
               if( page->x_click > 0 ) {
                  sprintf(full_url,"%s?%d,%d",
                          page->links[link_pressed].url,
                          page->x_click,page->y_click);
                  (*page->link) (page->link_data, full_url);
               } else
                  (*page->link) (page->link_data, page->links[link_pressed].url);
            }
            page->x_click = -1;
         }
      }
      break;

   case GDK_MOTION_NOTIFY:
      motion = (GdkEventMotion *) event;
      hover_link = Dw_page_find_link(page, motion->x, motion->y);
      if ( page->status != NULL ) {
         if( page->x_click >= 0 ) {
            CursorType = GDK_HAND2;
            sprintf(page->ismap_coords,"?%d,%d",page->x_click,page->y_click);
            (*page->status) (page->status_data, page->ismap_coords);
         } else if( page->hover_link != hover_link ) {
            if ( hover_link >= 0 ) {
               CursorType = GDK_HAND2;
               if (page->links[hover_link].alt)
                  (*page->status) (page->status_data, page->links[hover_link].alt);
               else
                  (*page->status) (page->status_data, page->links[hover_link].url);
            } else {
               CursorType = GDK_LEFT_PTR;
              (*page->status) (page->status_data, "");
            }
         } else
            break;

         if ( bw->CursorType != CursorType ) {
            GdkCursor *cursor = gdk_cursor_new(CursorType);
            gdk_window_set_cursor(bw->docwin->window, cursor);
            gdk_cursor_destroy(cursor);
            bw->CursorType = CursorType;
         }

         page->hover_link = hover_link;
      }
      break;

   default:
      g_print("dw_page_handle_event: unknown event (%d)\n", event->type);
      break;
   }
}

/*
 * outline: find the first line overlapping the plus rectangle. iterate
 * through until the bottom of the plus rectangle is reached. Simply
 * pass the minus rectangle to the children.
 */
static void Dw_page_gtk_foreach(Dw *dw, DwCallback callback, gpointer callback_data,
                                DwRect *plus, DwRect *minus)
{

   /* Only call child if DW_FLAG_GTK_EMBED is set? (this would require
    * doing a resize_request when an embedded widget got added -- is it
    * really an important optimization considering we're already
    * pruning by geometry?) */
   DwPageLine *line;
   DwPageWord *word;
   gint line_index;
   gint word_index;
   DwRect child_rect;

   line_index = Dw_page_find_line_index((DwPage *) dw,
                                        plus->y0 - dw->allocation.y0);
   for (; line_index < ((DwPage *) dw)->num_lines; line_index++) {
      line = &((DwPage *) dw)->lines[line_index];
      if (dw->allocation.y0 + line->y_top >= plus->y1)
         break;
      for (word_index = 0; word_index < line->num_words; word_index++) {
         word = &line->words[word_index];
         if (word->content_type == DW_PAGE_CONTENT_WIDGET) {
            a_Dw_rect_intersect(&child_rect, plus,
                                &word->content.widget->allocation);
            if (!a_Dw_rect_empty(&child_rect))
               a_Dw_gtk_foreach(word->content.widget,
                                callback, callback_data, plus, minus);
         }
      }
   }
}

/*
 * ?
 */
static void Dw_page_destroy(Dw *dw)
{
   DwPage *page;
   DwPageLine *line;
   DwPageWord *word;
   gint line_index;
   gint word_index;
   gint font_index;
   gint link_index;

   page = (DwPage *) dw;

   /* Destroy links to us! */
   if (page->Parent) {
      *(page->Parent) = NULL;
      page->Parent = NULL;
   }
   if (page->destroy) {
      (page->destroy) (page->destroy_data);
   }
   for (line_index = 0; line_index < page->num_lines; line_index++) {
      line = &page->lines[line_index];
      for (word_index = 0; word_index < line->num_words; word_index++) {
         word = &line->words[word_index];
         if (word->content_type == DW_PAGE_CONTENT_WIDGET)
            a_Dw_destroy(word->content.widget);
         else if (word->content_type == DW_PAGE_CONTENT_TEXT)
            g_free(word->content.text);
         else if (word->content_type == DW_PAGE_CONTENT_ANCHOR)
            g_free(word->content.anchor);
      }
      g_free(line->words);
   }
   g_free(page->lines);

#ifndef USE_TYPE1
   for (font_index = 0; font_index < page->num_fonts; font_index++) {
      g_free(page->fonts[font_index].name);
      if (page->fonts[font_index].font != NULL)
         gdk_font_unref(page->fonts[font_index].font);
   }
#endif

   g_free(page->shapes);

   g_hash_table_destroy (page->anchors_table);
   g_free(page->fonts);
   g_free(page->colors);
   g_free(page->attrs);
   for (link_index = 0; link_index < page->num_links; link_index++) {
      g_free(page->links[link_index].url);
      g_free(page->links[link_index].alt);
   }
   g_free(page->links);
   if(page->gc != NULL)
      gdk_gc_unref(page->gc);

   g_free(dw);
}

/*
 * ?
 */
static void Dw_page_request_resize(Dw *dw, Dw *child)
{
   /* ok, here's roughly how the resize request will go.
    *
    * We find the line that the child belongs to, and recalculate the
    * width requisitions for the whole widget. If the child is
    * shrinking and the child's old req_width_min is equal to the parent's,
    * then we may have to rescan the whole widget. Otherwise, it should
    * be possible to skip that step. Similarly, if the line's old width
    * is equal to the parent's, that's also reason for a rescan.
    *
    * Then, set a flag saying that there will be child widget resizes.
    * size_nego_x can find the child widgets and recalculate the
    * height of the appropriate line. How to find the child widget?
    * Keep a list of children with pending resize requests?
    *
    * For now, we could just rewrap the whole page, which is what
    * gtk_page used to do.
    */

   /* g_print("___Dw_page_request_resize :: Flag = %d\n", dw->flags); */
   a_Dw_request_parent_resize(dw);

   /* I decided to add a new flag (DW_FLAG_REQ_REWRAP), and to make
    * the rewrap based on it, because the resize flag doesn't get
    * cleared sometimes...  --Jcid */
   if ( (dw->flags & DW_FLAG_REQ_REWRAP) == 0) {
      dw->flags |= DW_FLAG_REQ_REWRAP;
      gtk_idle_add((GtkFunction)Dw_page_idle_rewrap, dw);
   }
}

static const DwClass Dw_page_class =
{
   Dw_page_size_nego_x,
   Dw_page_size_nego_y,
   Dw_page_paint,
   Dw_page_handle_event,
   Dw_page_gtk_foreach,
   Dw_page_destroy,
   Dw_page_request_resize
};

/*
 * ?
 */
Dw *a_Dw_page_new(Dw **Parent)
{
   DwPage *Dw_page;
   DwRect null_rect = {0, 0, 0, 0};

   Dw_page = g_new(DwPage, 1);
   Dw_page->dw.klass = &Dw_page_class;
   Dw_page->dw.allocation = null_rect;
   Dw_page->dw.req_width_min = 0;
   Dw_page->dw.req_width_max = 0;
   Dw_page->dw.req_height = 0;
   Dw_page->dw.req_ascent = 0;

   Dw_page->dw.flags = 0;
   Dw_page->dw.parent = NULL;
   Dw_page->dw.container = NULL;

   /* stuff from gtk_page_init. */

   Dw_page->gc = NULL;

   Dw_page->num_lines_max = 16;
   Dw_page->num_lines = 0;
   Dw_page->lines = g_new(DwPageLine, Dw_page->num_lines_max);

   Dw_page->num_fonts_max = 16;
   Dw_page->num_fonts = 0;
   Dw_page->fonts = g_new(DwPageFont, Dw_page->num_fonts_max);

   Dw_page->num_links_max = 16;
   Dw_page->num_links = 0;
   Dw_page->links = g_new(DwPageLink, Dw_page->num_links_max);

   Dw_page->num_colors_max = 16;
   Dw_page->num_colors = 0;
   Dw_page->colors = g_new(DwPageColor, Dw_page->num_colors_max);

   Dw_page->num_attrs_max = 512;
   Dw_page->num_attrs = 0;
   Dw_page->attrs = g_new(DwPageAttr, Dw_page->num_attrs_max);

   Dw_page->width = 100;

   Dw_page->last_line_max_width = 0;

   Dw_page->hover_link = -1;
   /* end stuff from gtk_page_init. */

   Dw_page->link = NULL;
   Dw_page->status = NULL;
   Dw_page->destroy = NULL;
   Dw_page->Parent = Parent;
   Dw_page->link_color = prefs.link_color;
   Dw_page->bgnd_color = prefs.bg_color;

   /* We use the hash as a key, so we'll only need a direct hash table */
   Dw_page->anchors_table = g_hash_table_new(g_str_hash, g_str_equal);
   Dw_page->x_click = -1;
   Dw_page->current_map = 0;
   Dw_page->num_shapes = 0;
   Dw_page->num_shapes_max = 8;  /* not a critical value */
   Dw_page->shapes = g_new(DwPageShape, Dw_page->num_shapes_max);

   return (Dw *) Dw_page;
}

/*
 * ?
 */
void a_Dw_page_set_callbacks(DwPage *page,
                             void (*link) (void *data, const char *url),
                             void *link_data,
                             void (*status) (void *data, const char *url),
                             void *status_data,
                             void (*_destroy) (void *data), void *destroy_data)
{
   page->link = link;
   page->link_data = link_data;
   page->status = status;
   page->status_data = status_data;
   page->destroy = _destroy;
   page->destroy_data = destroy_data;
}

/*
 * Find the color in the page structure, or add a new one if it doesn't
 * already exist. In either case, return the index.
 */
gint a_Dw_page_find_color(DwPage *page, gint32 color)
{
   gint color_index;
   gint red, green, blue;
   gint nc;

   red = (color >> 16) & 255;
   red |= red << 8;
   green = (color >> 8) & 255;
   green |= green << 8;
   blue = color & 255;
   blue |= blue << 8;
   nc = page->num_colors;
   for (color_index = 0; color_index < nc; color_index++) {
      if (page->colors[color_index].color.red == red &&
          page->colors[color_index].color.green == green &&
          page->colors[color_index].color.blue == blue) {
         return color_index;
      }
   }
   a_List_add(page->colors, nc, sizeof(page->colors), page->num_colors_max);
   page->colors[color_index].color.red = red;
   page->colors[color_index].color.green = green;
   page->colors[color_index].color.blue = blue;
   page->colors[color_index].allocated = FALSE;
   page->num_colors++;
   return color_index;
}

/*
 * Set all attribute fields except font to reasonable defaults.
 */
void a_Dw_page_init_attr(DwPage *page, DwPageAttr *attr)
{
   attr->link = -1;
   attr->map = 0;
   attr->uline = -1;
   attr->strike = -1;
   attr->color = a_Dw_page_find_color(page, 0);
   attr->left_indent_first = 0;
   attr->left_indent_rest = 0;
   attr->right_indent = 0;
   attr->flags = DW_PAGE_ALIGN_LEFT;
}

/*
 * Find the font in the page structure, or add a new one if it doesn't
 * already exist. In either case, return the index.
 */
gint a_Dw_page_find_font(DwPage *page, const DwPageFont *font)
{
   gint font_index, nf;

   nf = page->num_fonts;
   for (font_index = 0; font_index < nf; font_index++) {
      if (page->fonts[font_index].size == font->size &&
          page->fonts[font_index].bold == font->bold &&
          page->fonts[font_index].italic == font->italic &&
          !strcmp(page->fonts[font_index].name, font->name)) {
         return font_index;
      }
   }
   a_List_add(page->fonts, nf, sizeof(*page->fonts), page->num_fonts_max);
   page->fonts[font_index].name = g_strdup(font->name);
   page->fonts[font_index].size = font->size;
   page->fonts[font_index].bold = font->bold;
   page->fonts[font_index].italic = font->italic;
   page->fonts[font_index].font = NULL;
   page->fonts[font_index].space_width = 0;
   page->num_fonts++;
   return font_index;
}

/*
 * Create a new link, return the index.
 */
gint a_Dw_page_new_link(DwPage *page, const char *url, const char *alt)
{
   gint nl;

   nl = page->num_links;
   a_List_add(page->links, nl, sizeof(*page->links), page->num_links_max);
   page->links[nl].url = url ? g_strdup(url) : NULL;
   page->links[nl].alt = alt ? g_strdup(alt) : NULL;
   return page->num_links++;
}

/*
 * Add a new attr to the page structure and return its index.
 * (Certainly it can be implemented to make repeated attributes share
 *  the same index, but this way improves performance dramatically! --Jcid)
 */
gint a_Dw_page_add_attr(DwPage *page, const DwPageAttr *attr)
{
   gint na;

   na = page->num_attrs;
   a_List_add(page->attrs, na, sizeof(*page->attrs), page->num_attrs_max);
   page->attrs[na] = *attr;
   page->num_attrs++;
   return na;
}

/*
 * Load the gdk font for the font data structure if necessary. In either
 * case, return the gdk font. (NULL if using t1lib fonts)
 */
static GdkFont *Dw_page_realize_font(DwPageFont *font)
{
   char fontname[256];

   if (font->font != NULL)
      return font->font;

   sprintf(fontname, "-*-%s-%s-%s-*-*-%d-*-75-75-*-*-*-*",
           font->name,
           font->bold ? "bold" : "medium",
           font->italic ? "i" : "r",
           font->size);
   font->font = gdk_font_load(fontname);

   if (font->font == NULL && font->italic) {
      /* Some italic fonts (e.g. Courier) use "o" instead of "i". */
      sprintf(fontname, "-*-%s-%s-o-*-*-%d-*-75-75-*-*-*-*",
              font->name,
              font->bold ? "bold" : "medium",
              font->size);
      font->font = gdk_font_load(fontname);
   }
   if (font->font == NULL) {
      /* Can't load the font - substitute the default instead. */
      font->font = gdk_font_load("-adobe-helvetica-medium-r-normal--*-100-*-*-*-*-*-*");
   }
   if (font->font == NULL) {
      /* Try another platform-font that should be available. (iPaq) */
      font->font =
      gdk_font_load("-misc-fixed-medium-r-normal--13-120-75-75-c-80-iso8859-1");
   }
   if (font->font == NULL) {
      g_print("Can't load any fonts!\n");
      /* Should probably abort here. */
   }
   font->space_width = gdk_char_width(font->font, ' ');
   return font->font;
}

/*
 * Add a word to the page structure. Stashes the argument pointer in
 * the page data structure so that it will be deallocated on destroy.
 */
void a_Dw_page_add_text(DwPage *page, char *text, gint attr)
{
   DwPageWord *word;
   gint x_size, y_ascent, y_descent;
   GdkFont *gdkfont;
   DwPageFont *font;

   if (attr >= page->num_attrs || page->attrs[attr].font >= page->num_fonts)
      return;                   /*BUG: Should use default text! */
   font = &(page->fonts[page->attrs[attr].font]);
   gdkfont = Dw_page_realize_font(font);

   x_size = gdk_string_width(gdkfont, text);
   y_ascent = gdkfont->ascent;
   y_descent = gdkfont->descent;

   word = Dw_page_new_word(page, x_size, y_ascent, y_descent, attr);
   word->content_type = DW_PAGE_CONTENT_TEXT;
   word->content.text = text;
   word->attr = attr;
}

/*
 * Add a widget (word type) to the page
 */
void a_Dw_page_add_widget(DwPage *page, Dw *dw, gint attr)
{
   DwPageWord *word;
   gint x_size, y_ascent, y_descent;

   /* First, find the child widget's width. For now, we always
    * give the minimum requisition, but that will change with table
    * support (tables should probably get 100% of the set width - the
    * margins, or the maximum requisition, whichever is smaller). */

   x_size = dw->req_width_min;
   a_Dw_size_nego_x(dw, x_size);
   if (dw->flags & DW_FLAG_BASELINE) {
      y_ascent = dw->req_ascent;
      y_descent = dw->req_height - y_ascent;
   } else {
      /* align bottom of widget to baseline for now */
      y_ascent = dw->req_height;
      y_descent = 0;
   }
   word = Dw_page_new_word(page, x_size, y_ascent, y_descent, attr);

   word->content_type = DW_PAGE_CONTENT_WIDGET;
   word->content.widget = dw;
   word->attr = attr;

   dw->parent = &page->dw;

   /* The rest of the size negotiation continues in finish_line. */
}


/*
 * Add an anchor to the page. name is copied, so no strdup is neccessary for
 * the caller.
 */
void a_Dw_page_add_anchor(DwPage *page, char *name)
{
   DwPageWord *word;

   word = Dw_page_new_word(page, 0, 0, 0, 0);
   word->content_type = DW_PAGE_CONTENT_ANCHOR;
   word->content.anchor = g_strdup(name);
   word->attr = 0;

   /* Store the anchor in the DwPage's hash table */
   /* y + 1 is stored in hash table to avoid problems with y == 0
    * (which would be stored as a NULL pointer) */
   g_hash_table_insert(page->anchors_table,
                       word->content.anchor,
                       (void*) (page->lines[page->num_lines - 1].y_top + 1));
   /* and set the position */
   Dw_page_set_scroller_pos(page, name);
}


/*
 * ?
 */
void a_Dw_page_add_space(DwPage *page, gint attr)
{
   gint nl, nw;
   gint space;
   DwPageFont *font;
   GdkFont *gdkfont;

   font = &(page->fonts[page->attrs[attr].font]);
   gdkfont = Dw_page_realize_font(font);

   nl = page->num_lines - 1;
   if (nl >= 0) {
      nw = page->lines[nl].num_words - 1;
      if (nw >= 0) {
         space = font->space_width;
         page->lines[nl].words[nw].x_space = space;
      }
   }
}

/*
 * Cause a line break
 */
void a_Dw_page_linebreak(DwPage *page)
{
   gint i;

   i = page->num_lines;
   if (i == 0)
      return;
   page->lines[i - 1].hard = TRUE;
}

/*
 * Cause a paragraph break
 */
void a_Dw_page_parbreak(DwPage *page, gint space)
{
   gint i;

   i = page->num_lines;
   if (i == 0)
      return;
   page->lines[i - 1].hard = TRUE;
   if (space > page->lines[i - 1].y_space)
      page->lines[i - 1].y_space = space;
}

/*
 * Call this routine before updating the state. By wrapping all state
 * changes between these two routines, the internal state of the widget
 * always matches the display, without requiring each state change
 * operation to calculate updates on a fine-grained basis.
 */
void a_Dw_page_update_begin(DwPage *page)
{
   page->redraw_start_line = page->num_lines;
   if (page->num_lines > 0 && !page->lines[page->num_lines - 1].hard)
      page->redraw_start_line--;
}

/*
 * Call this routine after updating the state.
 */
void a_Dw_page_update_end(DwPage *page)
{
   DwRect repaint;
   gint last_line;

   if (page->num_lines > 0)
      Dw_page_finish_line(page);

   /* Request repaint of all lines from redraw_start_line to the last
    * line in the page (inclusive). */
   last_line = page->num_lines - 1;
   if (page->redraw_start_line <= last_line) {
      repaint.x0 = page->dw.allocation.x0;
      repaint.y0 = page->dw.allocation.y0 +
          page->lines[page->redraw_start_line].y_top;
      repaint.x1 = page->dw.allocation.x1;
      repaint.y1 = page->dw.allocation.y0 + page->lines[last_line].y_top +
          page->lines[last_line].y_ascent + page->lines[last_line].y_descent;
      a_Dw_request_paint(&page->dw, &repaint);
   }
   a_Dw_request_parent_resize(&page->dw);
}

/*
 * Set the width. Cause a rewrap and check_resize if necessary.
 */
void Dw_page_set_width(DwPage *page, gint width)
{
   gint new_width;

   new_width = width - 2 * GTK_CONTAINER(page)->border_width;
   if (new_width != page->width) {
      page->width = new_width;
      Dw_page_rewrap(page);
   }
}


typedef struct {
   gint LineNum;
   gint Index;
} LineData;

typedef enum {
  F_NewKey,
  F_Read,
  F_Seek,
  F_Found,
  F_End
} FindState;

typedef struct {
   gchar *Key;
   guint KeyLen;
   DwPage *Page;
   gint LineNum;
   gint Matches;
   GSList *IList;
   GString *TextBuf;
   gchar StopSet[3];
   gint Eof;
   FindState State;
} FindData;

/*
 * Read lines into local buffer
 */
void Dw_page_read_lines(FindData *F, gint N)
{
   gint i, j, nw;
   LineData *LNode;

   for (j = 0; F->LineNum < F->Page->num_lines && j < N; F->LineNum++, j++) {
      LNode = g_new(LineData, 1);
      LNode->LineNum = F->LineNum;
      LNode->Index = F->TextBuf->len;
      F->IList = g_slist_append(F->IList, LNode);
      /* This can find strings that span over two or more lines */
      for(nw = i = 0; i < F->Page->lines[F->LineNum].num_words; i++) {
         if (F->Page->lines[F->LineNum].words[i].content_type != DW_PAGE_CONTENT_TEXT)
             continue;
         F->TextBuf = g_string_append(F->TextBuf, F->Page->lines[F->LineNum].words[i].content.text);
         F->TextBuf = g_string_append(F->TextBuf, " ");
         ++nw;
      }
      if ( nw == 0 ) /* Empty line ? */
         F->IList = g_slist_remove(F->IList, LNode);
   }
   F->Eof = ( F->LineNum == F->Page->num_lines );
}

/*
 * Erase the first N character from local buffer
 */
void Dw_page_erase_chars(FindData *F, gint N)
{
   gint i;
   LineData *LNode, *LNext;

   for ( i = 0; (LNode = g_slist_nth_data(F->IList, i)); i++ )
      LNode->Index -= N;

   while ( (LNode = g_slist_nth_data(F->IList, 0)) && LNode->Index <= 0 ) {
      LNode->Index = 0;
      if ( (LNext = g_slist_nth_data(F->IList, 1)) && LNext->Index <= 0 )
         F->IList = g_slist_remove(F->IList, LNode);
      else
         break;
   }
   F->TextBuf = g_string_erase(F->TextBuf, 0, N);
}

/*
 * Erase the local buffer
 */
void Dw_page_erase_buf(FindData *F)
{
   LineData *LNode;

   if ( F->IList )
      while ( (LNode = g_slist_nth_data(F->IList, 0)) )
         F->IList = g_slist_remove(F->IList, LNode);

   if ( F->TextBuf )
      F->TextBuf = g_string_truncate(F->TextBuf, 0);
}

/*
 * Find the text in the page.
 */
void a_Dw_page_find_text(DwPage *page, char *NewKey)
{
   gint i;
   gchar *Ptr = NULL;
   LineData *LNode;
   GtkDwScroller *scroller;
   DwContainer *container;
   static FindData *F = NULL;

   if ( (container = a_Dw_find_container(&page->dw)) )
      scroller = GTK_DW_SCROLLER (container->widget->parent);
   else {
      g_print("BUG: Dw container not found\n");
      return;
   }

   if ( !F )
      F = g_new0(FindData, 1);
   if ( !F->Key || strcmp(F->Key, NewKey) || F->Page != page )
      F->State = F_NewKey;

   /* Let the FSM find the search string */
   while ( 1 ) {
      switch (F->State) {
      case F_NewKey:
         if ( !F->TextBuf ) F->TextBuf = g_string_sized_new(256);
         if ( F->Key ) g_free(F->Key);
         F->Key = g_strdup(NewKey);
         if ( !(F->KeyLen = strlen(F->Key)) ) return;
         sprintf(F->StopSet, "%c%c", tolower(F->Key[0]),toupper(F->Key[0]));
         Dw_page_erase_buf(F);
         F->Page = page;
         F->Matches= F->LineNum = F->Eof = 0;
         F->State = F_Read;
         break;
      case F_Read:
         if ( F->Eof )
            F->State = F_End;
         else {
            Dw_page_read_lines(F, 10);
            F->State = F_Seek;
         }
         // g_print("TextBuf: %s\n", F->TextBuf->str);
         break;
      case F_Seek:
         if ( !(Ptr = strpbrk(F->TextBuf->str, F->StopSet)) ) {
            Dw_page_erase_buf(F);
            F->State = F_Read;
         } else if ( strlen(Ptr) < F->KeyLen ) {
            F->State = F_Read;
         } else if ( g_strncasecmp(Ptr, F->Key, F->KeyLen) == 0 ) {
            Dw_page_erase_chars(F, Ptr - F->TextBuf->str);
            F->State = F_Found;
         } else
            Dw_page_erase_chars(F, Ptr - F->TextBuf->str + 1);
         break;
      case F_Found:
         F->Matches++;
         LNode = g_slist_nth_data(F->IList, 0);
         i = LNode->LineNum;
         a_Dw_gtk_scroller_jump_pos(scroller, page->lines[i].y_top);
         Dw_page_erase_chars(F, 1);
         F->State = F_Seek;
         return;
      case F_End:
         if ( F->Matches )
            F->State = F_NewKey;
         else
            return;
      }
   }
}

