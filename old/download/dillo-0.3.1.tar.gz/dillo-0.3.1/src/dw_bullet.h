#ifndef __DW_BULLET_H__
#define __DW_BULLET_H__

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

typedef struct _DwBullet DwBullet;

typedef enum {
  DW_BULLET_DISC=1,
  DW_BULLET_CIRCLE=2,
  DW_BULLET_SQUARE=3,
  DW_BULLET_1=4,
  DW_BULLET_a=5,
  DW_BULLET_A=6,
  DW_BULLET_i=7,
  DW_BULLET_I=8
} DwBulletType;

struct _DwBullet {
  Dw dw;

  DwBulletType type;
};

Dw *a_Dw_bullet_new (DwBulletType type);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __DW_BULLET_H__ */
