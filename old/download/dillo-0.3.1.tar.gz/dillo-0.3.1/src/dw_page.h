/* This module contains the dw_page widget, which is the "back end" to
   Web text widgets including html. */

#ifndef __DW_PAGE_H__
#define __DW_PAGE_H__

#undef USE_TYPE1

#include <gtk/gtk.h>

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

typedef struct _DwPage        DwPage;
typedef struct _DwPageClass   DwPageClass;

/* Internal data structures (maybe shouldn't be in public .h file? */
typedef struct _DwPageFont    DwPageFont;
typedef struct _DwPageLink    DwPageLink;
typedef struct _DwPageAttr    DwPageAttr;
typedef struct _DwPageLine    DwPageLine;
typedef struct _DwPageWord    DwPageWord;
typedef struct _DwPageColor   DwPageColor;
typedef struct _DwPageShape   DwPageShape;

struct _DwPageFont {
  char *name;
  gint size;
  gboolean bold;
  gboolean italic;

#ifdef USE_TYPE1
  gint t1fontid;
#else
  GdkFont *font;
#endif
  gint space_width; /* only valid if font != NULL */
};

struct _DwPageLink {
  char *url;
  char *alt;
};

#define DW_PAGE_SHAPE_ERROR   0
#define DW_PAGE_SHAPE_DEFAULT 1
#define DW_PAGE_SHAPE_CIRCLE  2
#define DW_PAGE_SHAPE_RECT    3
#define DW_PAGE_SHAPE_POLY    4

struct _DwPageShape {
   guint map;
   gint type;
   gint link;

   union {
      GdkRegion *poly;
      struct  {
         int x;
         int y;
         int r2;
      } circle;
      struct  {
         int top;
         int bottom;
         int left;
         int right;
      } rect;
   } data;
};

/*
 * Link finding rules:
 * -------------------
 *   if (DwPageAttr->link)
 *     if (DwPageAttr HAS_MAP)
 *          // add server-side map informations to url
 *       else
 *          // regular link
 *   else if (DwPageAttr HAS_MAP)
 *        // client-side image map with (shapes)
 */
struct _DwPageAttr {
  gint font;
  gint link;
  gint uline;
  gint strike;
  guint map;
  gint32 color;

  gint left_indent_first;
  gint left_indent_rest;
  gint right_indent;

  gint flags;  /* -EG :: was align */
};

/* these defines are DwPageAttr->flags
 * ALIGN_LEFT == ALIGN_RIGTH ==0  -> CENTER
 * ALIGN_LEFT == ALIGN_RIGTH ==1  -> JUSTIFIED */
#define DW_PAGE_ALIGN_LEFT   1
#define DW_PAGE_ALIGN_RIGHT  2
#define DW_PAGE_HAS_MAP      4

struct _DwPageLine {
  gint num_words;
  gint num_words_max; /* number allocated */
  gint y_top;
  gint x_size, y_ascent, y_descent, y_space;
  gboolean hard;      /* false = soft break, true = hard break */
  gboolean first;     /* true = first line in paragraph */
  DwPageWord *words;
};

#define DW_PAGE_CONTENT_TEXT 0
#define DW_PAGE_CONTENT_WIDGET 1
#define DW_PAGE_CONTENT_ANCHOR 2

struct _DwPageWord {
  gint x_size, y_ascent, y_descent;
  gint x_space; /* space after the word, only if it's not a break */

  /* This is a variant record (i.e. it could point to a widget
   * instead of just being text). */
  gint content_type;
  union {
    char *text;
    Dw *widget;
    char *anchor;
  } content;

  gint attr;
};

struct _DwPageColor {
   GdkColor color;
   gboolean allocated;
};

struct _DwPage {
  Dw dw;

  GdkGC *gc;

  DwPageLine *lines;
  gint num_lines;
  gint num_lines_max; /* number allocated */

  /* Page's anchors
   * Key: char*, but no removal neccessary (is stored in DwPageWord)
   * Value: int (pixel offset [1 based]) */
  GHashTable *anchors_table;

  /* Page's maps
   * Key: guint = g_str_hash(char *map)
   * Value: num_shapes + 1 */
  DwPageShape *shapes;
  gint num_shapes;
  gint num_shapes_max; /* number allocated */
  guint current_map;
  gint x_click, y_click;
  char ismap_coords[10];

  gint width;         /* the width (not including pad) at which line wrap
                       * was calculated. If this changes, then the whole
                       * thing should get re-wrapped. */

  gint last_line_max_width; /* the maximum width of the last line (assuming
                             * no word wrap) */

  DwPageFont *fonts;
  gint num_fonts;
  gint num_fonts_max;

  DwPageLink *links;
  gint num_links;
  gint num_links_max;

  DwPageColor *colors;
  gint num_colors;
  gint num_colors_max;

  /* We'll store current-page colors here */
  gint32 link_color;
  gint32 bgnd_color;

  DwPageAttr *attrs;
  gint num_attrs;
  gint num_attrs_max;

  /* Stuff for doing redraws */

  GdkRectangle clear;  /* Rectangle that must be cleared. */
  GdkRectangle redraw; /* Rectangle that must be redrawn. */

  gint redraw_start_line;

  /* The link under a button press */
  gint link_pressed;

  /* The link under the button */
  gint hover_link;

  void (*link) (void *data, const char *url);
  void *link_data;

  void (*status) (void *data, const char *url);
  void *status_data;
  void (*destroy) (void* data);
  void *destroy_data;
  Dw** Parent;
};


Dw *a_Dw_page_new       (Dw**);

void
a_Dw_page_set_callbacks (DwPage *page,
                        void (*alink) (void* data, const char* url),
                        void*link_data,
                        void (*status) (void *data, const char *url),
                        void *status_data,
                        void (*destroy)(void*), void* destroy_data);

void Dw_page_set_width (DwPage *page, gint width);

void a_Dw_page_update_begin (DwPage *page);
void a_Dw_page_update_end (DwPage *page);

void a_Dw_page_init_attr (DwPage *page, DwPageAttr *attr);
gint a_Dw_page_find_font (DwPage *page, const DwPageFont *font);
gint a_Dw_page_new_link(DwPage *page, const char *url, const char *alt);
gint a_Dw_page_find_color (DwPage *page, gint32 color);
gint a_Dw_page_add_attr (DwPage *page, const DwPageAttr *attr);
void a_Dw_page_add_text (DwPage *page, char *text, gint attr);
void a_Dw_page_add_widget (DwPage *page, Dw *widget, gint attr);
void a_Dw_page_add_anchor (DwPage *page, char *name);
void a_Dw_page_add_space (DwPage *page, gint attr);
void a_Dw_page_linebreak (DwPage *page);
void a_Dw_page_parbreak (DwPage *page, gint space);
void a_Dw_page_find_text (DwPage *page, char *search_string);


#ifdef __cplusplus
}
#endif /* __cplusplus */


#endif /* __DW_PAGE_H__ */
