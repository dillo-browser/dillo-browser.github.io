/*
 * File: image.c
 *
 * Copyright (C) 1997 Raph Levien <raph@acm.org>
 * Copyright (C) 1999 James McCollough <jamesm@gtwn.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

/*
 * This file implements image data transfer methods. It handles the transfer
 * of data from an Image to a Dw_image widget.
 */

#include <gtk/gtk.h>
#include <stdio.h>
#include <string.h>

#include "image.h"


/* todo: performance seems rather poor :(
 *
 * Need to add support for RGBA images */

static size_t linebuf_size = 0;
static guchar *linebuf = NULL;

/*
 * ?
 */
static void
 a_Image_line(DilloImage *Image, const guchar *buf, const guchar *cmap, gint y)
{
   guint x, width, in_width;
   gint byte;

   /* todo: handle image types other than indexed. */

   width = Image->width;
   in_width = Image->in_width;

   switch (Image->in_type) {
      case DILLO_IMG_TYPE_INDEXED:
         if (width == in_width) {
            for (x = 0; x < width; x++) {
               byte = buf[x];
               linebuf[x * 3] = cmap[byte * 3];
               linebuf[x * 3 + 1] = cmap[byte * 3 + 1];
               linebuf[x * 3 + 2] = cmap[byte * 3 + 2];
            }
         } else {
            /* could use DDA here if speed were an issue */
            for (x = 0; x < width; x++) {
               byte = buf[x * in_width / width];
               linebuf[x * 3] = cmap[byte * 3];
               linebuf[x * 3 + 1] = cmap[byte * 3 + 1];
               linebuf[x * 3 + 2] = cmap[byte * 3 + 2];
            }
         }
         break;
      case DILLO_IMG_TYPE_GRAY:
         if (width == in_width) {
            for (x = 0; x < width; x++) {
               byte = buf[x];
               linebuf[x * 3] = byte;
               linebuf[x * 3 + 1] = byte;
               linebuf[x * 3 + 2] = byte;
            }
         } else {
            /* could use DDA here if speed were an issue */
            for (x = 0; x < width; x++) {
               byte = buf[x * in_width / width];
               linebuf[x * 3] = byte;
               linebuf[x * 3 + 1] = byte;
               linebuf[x * 3 + 2] = byte;
            }
         }
         break;
      case DILLO_IMG_TYPE_RGB:
         if (width == in_width) {
            /* could avoid memcpy here, if clever. For example, return a
             * boolean to indicate whether to use linebuf or the inputbuf. */
            memcpy(linebuf, buf, in_width * 3);
         } else {
            /* could use DDA here if speed were an issue */
            for (x = 0; x < width; x++) {
               gint lb0, x0;

               lb0 = x * 3;
               x0 = (x * in_width / width) * 3;
               linebuf[lb0] = buf[x0];
               linebuf[lb0 + 1] = buf[x0 + 1];
               linebuf[lb0 + 2] = buf[x0 + 2];
            }
         }
         break;
      case DILLO_IMG_TYPE_NOTSET:
         g_warning("ERROR: Image type not set...\n");
         break;
   }
}

/*
 * Implement the write method
 */
void a_Image_write(DilloImage *Image, const guchar *buf, gint x0, guint y)
{
   g_return_if_fail ( y < Image->height );

   /* Decode buf into linebuf */
   a_Image_line(Image, buf, Image->cmap, y);

   /* Merge linebuf into the image buffer */
   a_Dw_image_draw_row(Image->dw, linebuf, Image->width, Image->height, 0, y);
}

/*
 * Implement the close method
 */
void a_Image_close(DilloImage *Image)
{
   g_free(Image);
}

/*
 * Set some parameters of the image
 */
void a_Image_set_parms(DilloImage *Image, guint width, guint height,
                       DilloImgType type)
{
   Image->in_type = type;
   Image->in_width = Image->width = width;
   Image->in_height = Image->height = height;
   if (3 * width > linebuf_size) {
      linebuf_size = 3 * width;
      linebuf = g_realloc(linebuf, linebuf_size);
   }
   a_Dw_image_size(Image->dw, width, height);
}

/*
 * Implement the set_cmap method
 */
void a_Image_set_cmap(DilloImage *Image,
                      const guchar *cmap,    /*size = 3*num_colors */
                      gint num_colors,
                      gint bg_index)
{
   g_return_if_fail ( Image != NULL );

   Image->cmap = g_realloc(Image->cmap, 3 * 256);   /*num_colors); */
   memcpy(Image->cmap, cmap, 3 * num_colors);
   if (bg_index >= 0 && bg_index < 256) {       /*num_colors) { */
      Image->cmap[bg_index * 3]     = (Image->bg_color >> 16) & 0xff;
      Image->cmap[bg_index * 3 + 1] = (Image->bg_color >> 8) & 0xff;
      Image->cmap[bg_index * 3 + 2] = (Image->bg_color) & 0xff;
   }
}

/*
 * Create and initialize a ne image structure.
 */
DilloImage *
 a_Image_new(gint width, gint height, const char *alt, gint32 bg_color)
{
   DilloImage *Image;

   Image = g_new(DilloImage, 1);
   Image->dw = (DwImage *) a_Dw_image_new(DW_IMAGE_RGB);
   Image->width = Image->in_width = 0;
   Image->height = Image->in_height = 0;
   Image->cmap = NULL;
   Image->in_type = DILLO_IMG_TYPE_NOTSET;
   Image->alt = (alt) ? g_strdup(alt) : NULL;
   Image->bg_color = bg_color;
   Image->ProcessedBytes = 0;

   return Image;
}
