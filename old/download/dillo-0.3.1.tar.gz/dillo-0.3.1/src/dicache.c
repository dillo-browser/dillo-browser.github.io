/*
 * File: dicache.c
 *
 * Copyright 2000 Jorge Arellano Cid <jcid@inf.utfsm.cl>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */


#include <gtk/gtk.h>
#include <sys/time.h>       /* for libc5 compatibility */
#include <string.h>         /* for memset */
#include <stdio.h>
#include "IO/IO.h"

#include "list.h"
#include "image.h"
#include "dillo.h"
#include "web.h"
#include "dicache.h"
#include "cache.h"
#include "interface.h"


static DICacheEntry **dicache;
static gint dicache_size;
static gint dicache_size_max;

static gint dicache_size_total; /* invariant: dicache_size_total is
                                 * the sum of the image sizes of all
                                 * cache lines in dicache. */
static gint dicache_counter;

/*
 * Initialize dicache data
 */
void a_Dicache_init(void)
{
   dicache_size = 0;
   dicache_size_max = 16;
   dicache = g_new(DICacheEntry *, dicache_size_max);

   dicache_size_total = 0;
   dicache_counter = 0;
}

/*
 * Create and initialize a new cache entry with safe values
 */
DICacheEntry *a_Dicache_entry_new(const gchar *Url)
{
   static gint DicKey = 0;
   DICacheEntry *entry;

   if ( ++DicKey < 0 ) DicKey = 1;

   entry = g_new(DICacheEntry, 1);
   entry->Key = DicKey;
   entry->url = g_strdup(Url);
   entry->width = 0;
   entry->height = 0;
   entry->type = DILLO_IMG_TYPE_NOTSET;
   entry->cmap = NULL;
   entry->ImageBuffer = NULL;

   entry->TotalSize = 0;
   entry->Y = 0;
   entry->State = DIC_Empty;
   entry->LastUse = 0;

   entry->CacheClientKey = -1;

   return entry;
}

/*
 * Add an entry to the dicache
 */
void a_Dicache_add_entry(DICacheEntry *entry)
{
   /* Allocate memory */
   a_List_add(dicache, dicache_size, sizeof(*dicache), dicache_size_max);
   dicache[dicache_size] = entry;
   dicache_size++;
}

/*
 * Search an entry in the dicache (given the Url)
 * Return value: a pointer to the entry if found; NULL otherwise.
 */
DICacheEntry *a_Dicache_get_entry(const gchar* Url)
{
   gint i;

   for (i = dicache_size - 1; i >= 0; i--) {
      if ( !strcmp(Url, dicache[i]->url) )
         return dicache[i];
   }
   return NULL;
}

/*
 * Search an entry in the dicache (given the DicEntryKey)
 * Return value: a pointer to the entry if found; NULL otherwise.
 */
DICacheEntry *a_Dicache_get_entry_by_key(gint Key)
{
   gint i;

   for (i = dicache_size - 1; i >= 0; i--) {
      if ( dicache[i]->Key == Key )
         return dicache[i];
   }
   return NULL;
}

/*
 * Remove a dicache entry (Using Url or DicKey as primary Key)
 */
void a_Dicache_remove(const gchar *Url, gint DicKey)
{
   gint i;
   DICacheEntry *entry;

   for (i = 0; i < dicache_size; ++i) {
      entry = dicache[i];
      if ( (Url && !strcmp(Url, entry->url)) || DicKey == entry->Key )
         break;
   }

   if ( i < dicache_size ) {
      /* Eliminate this dicache entry */
      if ( entry->url )
         g_free(entry->url);
      if ( entry->cmap )
         g_free(entry->cmap);
      if ( entry->ImageBuffer ) {
         g_free(entry->ImageBuffer);
         dicache_size_total -= entry->TotalSize;
      }
      g_free(entry);
      dicache[i] = dicache[--dicache_size];
   }
}

// -------------------------------------------------------------------------

/*
 * This function is a cache client; (but feeds its clients from dicache)
 */
void a_Dicache_callback(int Op, CacheClient_t *Client)
{
   /* todo: Handle Op = CA_Abort (to show what was got)  --Jcid */

   DilloWeb *Web = Client->Web;
   DilloImage *Image = Web->Image;
   DICacheEntry *DicEntry = a_Dicache_get_entry(Web->url);

   g_return_if_fail ( DicEntry != NULL );

   if ( Op == CA_Close || Op == CA_Abort ) {
      a_Interface_close_client(Web->bw, Client->Key);
      return;
   }

   if ( DicEntry->State == DIC_Close || DicEntry->State == DIC_Write ) {
      if ( Image->height == 0 ) {
         /* Set parms */
         Image->dw->buffer = DicEntry->ImageBuffer;
         a_Image_set_parms(Image, DicEntry->width, DicEntry->height,
                           DicEntry->type);
         /* Set cmap */
         Image->cmap = DicEntry->cmap;
      }
      /* Update client */
      a_Dw_image_update(Image->dw, 0, DicEntry->Y + (Image->height == 1),
                        Image->width);
   }
}

// -------------------------------------------------------------------------

/*
 * Set image's width, height & type
 * (By now, we'll use the image information despite the html tags --Jcid)
 */
void a_Dicache_set_parms(gint DicEntryKey, DilloImage *Image,
                         gint width, gint height, DilloImgType type)
{
   DICacheEntry *DicEntry;

   g_return_if_fail ( Image != NULL );

   /* Allocate and initialize this image */
   a_Image_set_parms(Image, width, height, type);

   /* Find the DicEntry for this Image */
   DicEntry = a_Dicache_get_entry_by_key(DicEntryKey);
   g_return_if_fail ( DicEntry != NULL );

   /* Initialize the DicEntry */
   DicEntry->ImageBuffer = Image->dw->buffer;
   DicEntry->TotalSize = Image->dw->buffer_size;
   DicEntry->width = width;
   DicEntry->height = height;
   DicEntry->type = type;
   DicEntry->State = DIC_SetParms;

   /* For giggles, make the background of the undrawn parts interesting */
   memset(DicEntry->ImageBuffer, 0xdd, DicEntry->TotalSize);

   /* Update the buffer area for this image */
   a_Dw_image_size(Image->dw, width, height);
}

/*
 * Implement the set_cmap method for the Image
 */
void a_Dicache_set_cmap(gint DicKey, DilloImage *Image,
                        const guchar *cmap, gint num_colors, gint bg_index)
{
   DICacheEntry *DicEntry = a_Dicache_get_entry_by_key(DicKey);

   a_Image_set_cmap(Image, cmap, num_colors, bg_index);
   DicEntry->cmap = Image->cmap;
   DicEntry->State = DIC_SetCmap;
}

/*
 * Implement the write method
 * (Write a scan line into the Dicache entry)
 * buf: row buffer
 * Y  : row number
 * x  : horizontal offset? (always zero)
 */
void a_Dicache_write(DilloImage *Image, gint DicKey,
                     const guchar *buf, gint x, gint Y)
{
   DICacheEntry *DicEntry;

   g_return_if_fail ( Image != NULL );
   DicEntry = a_Dicache_get_entry_by_key(DicKey);
   g_return_if_fail ( DicEntry != NULL );
   g_return_if_fail ( DicEntry->width > 0 && DicEntry->height > 0 );

   a_Image_write(Image, buf, x, Y);
   DicEntry->Y = Y;
   DicEntry->State = DIC_Write;
}

/*
 * Implement the close method of the decoding process
 */
void a_Dicache_close(gint DicKey, CacheClient_t *Client)
{
   DICacheEntry *DicEntry;
   DilloWeb *Web = Client->Web;

   DicEntry = a_Dicache_get_entry_by_key(DicKey);
   g_return_if_fail ( DicEntry != NULL );
   DicEntry->State = DIC_Close;

   a_Image_close(Web->Image);
   a_Interface_close_client(Web->bw, Client->Key);
}

// -------------------------------------------------------------------------

/*
 * Deallocate memory used by dicache module
 * (Call this one at exit time)
 */
void a_Dicache_freeall(void)
{
   /* Remove every dicache entry */
   while ( dicache_size )
      a_Dicache_remove(NULL, dicache[0]->Key);
   /* Remove the dicache list */
   g_free(dicache);
}
