#ifndef __CAPI_H__
#define __CAPI_H__

#include <glib.h>
#include "cache.h"
#include "web.h"

/*
 * Function prototypes
 */
gint a_Capi_open_url(DilloWeb *web, CA_Callback_t Call, void *CbData);
char *a_Capi_url_read(const DilloUrl *Url, gint *Size);
gint a_Capi_dpi_send_cmd(void *bw, char *cmd, char *server, gint flags);



#endif /* __CAPI_H__ */

