#ifndef __DW_EXT_ITERATOR_H__
#define __DW_EXT_ITERATOR_H__

#include "dw_widget.h"

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

typedef struct _DwExtIterator
{
   DwIterator **stack;
   gint stack_top;
   gint stack_max;

   DwContent content;
} DwExtIterator;

typedef struct _DwWordIterator
{
   /* The current word. NULL, when at the end or at the beginning */
   gchar *word;

   /* private stuff */
   DwExtIterator *iterator;
   gint *word_splitpos;     /* the positions of the words within
                             * iterator->content.data.text, as returned
                             * by a_Misc_strsplitpos */
   gint word_pos;           /* the  current position within word_splitpos */
   gint content_hl_start, content_hl_end;
} DwWordIterator;

DwExtIterator* a_Dw_ext_iterator_new   (DwIterator *it);
gboolean       a_Dw_ext_iterator_next  (DwExtIterator *eit);
gboolean       a_Dw_ext_iterator_prev  (DwExtIterator *eit);
DwExtIterator* a_Dw_ext_iterator_clone (DwExtIterator *eit);
void           a_Dw_ext_iterator_free  (DwExtIterator *eit);

#define        a_Dw_ext_iterator_highlight(eit, s, e) \
                  a_Dw_iterator_highlight((eit)->stack[(eit)->stack_top], s, e)
#define        a_Dw_ext_iterator_unhighlight(eit) \
                  a_Dw_iterator_unhighlight((eit)->stack[(eit)->stack_top])
#define        a_Dw_ext_iterator_scroll_to(eit, p) \
                  a_Dw_iterator_scroll_to((eit)->stack[(eit)->stack_top], p)

DwWordIterator* a_Dw_word_iterator_new       (DwWidget *widget);
gboolean        a_Dw_word_iterator_next      (DwWordIterator *it);
gboolean        a_Dw_word_iterator_prev      (DwWordIterator *it);
void            a_Dw_word_iterator_highlight (DwWordIterator *it,
                                              gint start,
                                              gint end);
DwWordIterator* a_Dw_word_iterator_clone     (DwWordIterator *it);
void            a_Dw_word_iterator_free      (DwWordIterator *it);

#define         a_Dw_word_iterator_unhighlight(it) \
                   a_Dw_word_iterator_highlight(it, -1, -1)
#define         a_Dw_word_iterator_scroll_to(it, p) \
                   a_Dw_ext_iterator_scroll_to((it)->iterator, p)


#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __DW_EXT_ITERATOR_H__ */
