#ifndef __DW_EMBED_GTK_H__
#define __DW_EMBED_GTK_H

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

typedef struct _DwEmbedGtk DwEmbedGtk;

struct _DwEmbedGtk {
  Dw dw;

  GtkWidget *widget;
};

Dw *a_Dw_embed_gtk_new (GtkWidget *widget);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __DW_EMBED_GTK_H__ */
