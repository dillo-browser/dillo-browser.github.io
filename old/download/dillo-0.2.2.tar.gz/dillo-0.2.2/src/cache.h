#ifndef __CACHE_H__
#define __CACHE_H__

#include <glib.h>


/*
 * Cache Op codes
 */
#define CA_Send    (0)  /* Normal update */
#define CA_Close   (1)  /* Successful operation close */
#define CA_Abort   (2)  /* Operation abort */

/*
 * Flag Defines
 */
#define CA_GotHeader      (1)  /* True if header is completely got */
#define CA_GotData        (2)  /* True if we have all Data in cache */
#define CA_FreeData       (4)  /* Free the cache Data on close */
#define CA_Redirect       (8)  /* Data actually points to a redirect */
#define CA_ForceRedirect (16)  /* Unconditional redirect */

/* Callback type for cache clients */
typedef void (*CA_Callback_t)(int Op, void *CbData, void *Buf, gint BufSize);

/* 
 * Function prototypes
 */
void a_Cache_redirect_url(const char* Orig_URL, const char* To_Url);
gint  a_Cache_open_url(const char *url, CA_Callback_t Call, void *CbData);
void a_Cache_callback(int Op, void *VPtr);

char *a_Cache_url_read(const char *url, gint *size);
void a_Cache_remove_entry(char *url);
void a_Cache_freeall(void);
void a_Cache_null_client(int Op, void *CbData, void *Buf, gint BufSize);


#endif /* __CACHE_H__ */

