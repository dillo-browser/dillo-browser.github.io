#ifndef __DILLO_H__
#define __DILLO_H__

#include "browser.h"
#include "web.h"
#include "IO/mime.h"

#define DILLO_HOME "http://dillo.sourceforge.net/"

#endif /* __DILLO_H__ */
