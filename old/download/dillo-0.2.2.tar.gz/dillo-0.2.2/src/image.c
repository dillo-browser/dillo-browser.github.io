/*
 * File: image.c
 *
 * Copyright (C) 1997 Raph Levien <raph@acm.org>
 * Copyright (C) 1999 James McCollough <jamesm@gtwn.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

/*
 * This file implements image data transfer methods. It handles the transfer
 * of data from an ImgSink to a Dw_image widget.
 */

#include <gtk/gtk.h>
#include <stdio.h>
#include <string.h>

#include "imgsink.h"


/* todo: performance seems rather poor :(
 * 
 * Need to add support for RGBA images */

static size_t linebuf_size = 0;
static guchar *linebuf = NULL;

/*
 * ?
 */
static void a_Image_line(DilloImgSink *image,
                         const guchar *buf,
                         const guchar *cmap,
                         gint y)
{
   gint width;
   gint in_width;
   gint x;
   gint byte;

   /* todo: handle image types other than indexed. */

   width = image->width;
   in_width = image->in_width;

   switch (image->in_type) {
      case DILLO_IMG_TYPE_INDEXED:
         if (width == in_width) {
            for (x = 0; x < width; x++) {
               byte = buf[x];
               linebuf[x * 3] = cmap[byte * 3];
               linebuf[x * 3 + 1] = cmap[byte * 3 + 1];
               linebuf[x * 3 + 2] = cmap[byte * 3 + 2];
            }
         } else {
            /* could use DDA here if speed were an issue */
            for (x = 0; x < width; x++) {
               byte = buf[x * in_width / width];
               linebuf[x * 3] = cmap[byte * 3];
               linebuf[x * 3 + 1] = cmap[byte * 3 + 1];
               linebuf[x * 3 + 2] = cmap[byte * 3 + 2];
            }
         }
         break;
      case DILLO_IMG_TYPE_GRAY:
         if (width == in_width) {
            for (x = 0; x < width; x++) {
               byte = buf[x];
               linebuf[x * 3] = byte;
               linebuf[x * 3 + 1] = byte;
               linebuf[x * 3 + 2] = byte;
            }
         } else {
            /* could use DDA here if speed were an issue */
            for (x = 0; x < width; x++) {
               byte = buf[x * in_width / width];
               linebuf[x * 3] = byte;
               linebuf[x * 3 + 1] = byte;
               linebuf[x * 3 + 2] = byte;
            }
         }
         break;
      case DILLO_IMG_TYPE_RGB:
         if (width == in_width) {
            /* could avoid memcpy here, if clever. For example, return a 
             * boolean to indicate whether to use linebuf or the inputbuf. */
            memcpy(linebuf, buf, in_width * 3);
         } else {
            /* could use DDA here if speed were an issue */
            for (x = 0; x < width; x++) {
               gint lb0, x0;

               lb0 = x * 3;
               x0 = (x * in_width / width) * 3;
               linebuf[lb0] = buf[x0];
               linebuf[lb0 + 1] = buf[x0 + 1];
               linebuf[lb0 + 2] = buf[x0 + 2];
            }
         }
         break;
      case DILLO_IMG_TYPE_NOTSET:
         g_warning("ERROR: Imgsink hasn't set image type...\n");
         break;
   }
}

/*
 * ?
 */
void _a_Image_write(DilloImgSink *imgsink,
                    const guchar *buf,
                    gint x0,
                    gint y,
                    DwImage **dws, gint NDws)
{
   /* Convert buf to linebuf */
   /* Convert linebuf to Display Buffer */
   gint y_begin, y_end, y_new;

   y_begin = (y * imgsink->height + imgsink->in_height - 1) / 
             imgsink->in_height;
   y_end = ((y + 1) * imgsink->height + imgsink->in_height - 1) / 
            imgsink->in_height;
   if (y_end <= y_begin)
      return;

   a_Image_line(imgsink, buf, imgsink->cmap, y);

   for (y_new = y_begin; y_new < y_end && y_new < imgsink->in_height; y_new++)
      a_Dw_image_draw_row(dws, NDws, linebuf, 0, y_new, imgsink->width);
}

/*
 * Implement the write method of the image sink
 */
static void a_Image_write(DilloImgSink * imgsink,
                          const guchar *buf,
                          gint x0, gint y)
{
   _a_Image_write(imgsink, buf, x0, y, &imgsink->dw, 1);
}

/*
 * Implement the close method of the image sink
 */
void a_Image_close(DilloImgSink * imgsink)
{
   if (imgsink->RefCount > 1) {
      imgsink->RefCount--;
      return;
   }
   if (imgsink->cmap)
      g_free(imgsink->cmap);
   if (imgsink->Parent)
      *(imgsink->Parent) = NULL;
   g_free(imgsink);
}

/*
 * Implement the set_parms method of the image sink 
 */
void a_Image_set_parms(DilloImgSink * imgsink,
                       gint width,
                       gint height,
                       DilloImgType type)
{
   imgsink->in_type = type;
   imgsink->in_width = imgsink->width = width;
   imgsink->in_height = imgsink->height = height;
   if (3 * width > linebuf_size) {
      linebuf_size = 3 * width;
      linebuf = g_realloc(linebuf, linebuf_size);
   }
   a_Dw_image_size(imgsink->dw, width, height);
}

/*
 * Implement the set_cmap method of the image sink 
 */
void a_Image_set_cmap(DilloImgSink * imgsink,
                      const guchar *cmap,    /*size = 3*num_colors */
                      gint num_colors,
                      gint bg_index)
{
   if (!imgsink)
      return;
   imgsink->cmap = g_realloc(imgsink->cmap, 3 * 256);   /*num_colors); */
   if (!imgsink->cmap)
      return;
   memcpy(imgsink->cmap, cmap, 3 * num_colors);
   if (bg_index >= 0 && bg_index < 256) {       /*num_colors) { */
      imgsink->cmap[bg_index * 3] = (imgsink->bg_color >> 16) & 0xff;
      imgsink->cmap[bg_index * 3 + 1] = (imgsink->bg_color >> 8) & 0xff;
      imgsink->cmap[bg_index * 3 + 2] = (imgsink->bg_color) & 0xff;
   }
}

/*
 * Create, initialize and set methods (for a newly allocated imgsink)
 */
DilloImgSink *a_Image_new(gint width, gint height,
                          const char *alt, gint32 bg_color)
{
   DilloImgSink *image;

   image = a_Imgsink_new(NULL);
   image->width = width;
   image->height = height;
   image->bg_color = bg_color;

   /* Set imgsink's methods */
   image->write = a_Image_write;
   image->close = a_Image_close;
   image->set_cmap = a_Image_set_cmap;
   image->set_parms = a_Image_set_parms;
   image->RefCount++;

   return image;
}
