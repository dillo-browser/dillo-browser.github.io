/*
 * Dillo
 *
 * Some code copied from:
 * The GIMP -- an image manipulation program
 * Copyright (C) 1995 Spencer Kimball and Peter Mattis
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>
#include "commands.h"
#include "browser.h"

DilloMenuPopup menu_popup;

/*
 * Make a new menu, insert it into the menu bar, and return it.
 */
GtkWidget *
Menu_new (GtkWidget * menubar, const char *name,
          gboolean right_justify, BrowserWindow * bw) {
   GtkWidget *menu;
   GtkWidget *menuitem;
   guint tmp_key;

   menu = gtk_menu_new();
   menuitem = gtk_menu_item_new_with_label((char *) name);
   tmp_key = gtk_label_parse_uline(GTK_LABEL(GTK_BIN
                                             (menuitem)->child), name);
   gtk_widget_add_accelerator(menuitem, "activate_item", bw->accel_group,
                              tmp_key, GDK_MOD1_MASK, 0);

   if (right_justify)
      gtk_menu_item_right_justify(GTK_MENU_ITEM(menuitem));
   gtk_menu_item_set_submenu(GTK_MENU_ITEM(menuitem), menu);
   gtk_menu_bar_append(GTK_MENU_BAR(menubar), menuitem);
   gtk_widget_show(menuitem);
   gtk_menu_set_accel_group(GTK_MENU(menu), bw->accel_group);
   return menu;
}

/*
 * Add an item to a menu, including the name, an accelerator (not yet
 * implemented), and a callback function for activation.
 */
static GtkWidget *
Menu_add (GtkWidget * menu, const char *name, const char *accel,
          void *data, BrowserWindow * bw, 
          void (*callback) (GtkWidget * widget, void *data)) {
   GtkWidget *menuitem;
   GtkAccelGroup *menu_accels;
   GdkModifierType accel_mods;
   guint accel_key;
   guint tmp_key;

   menuitem = gtk_menu_item_new_with_label((char *) name);
   gtk_menu_append(GTK_MENU(menu), menuitem);
   menu_accels = gtk_menu_ensure_uline_accel_group(GTK_MENU(menu));
   tmp_key = gtk_label_parse_uline(GTK_LABEL(GTK_BIN(menuitem)->child),
                                   name);
   gtk_widget_add_accelerator(menuitem, "activate_item",
                              menu_accels, tmp_key, 0, 0);
   gtk_widget_show(menuitem);

   if (accel != NULL) {
      gtk_accelerator_parse(accel, &accel_key, &accel_mods);
      gtk_widget_add_accelerator(menuitem, "activate", bw->accel_group,
                              accel_key, (guint)accel_mods, GTK_ACCEL_VISIBLE);
   }
   if (callback != NULL)
      gtk_signal_connect(GTK_OBJECT(menuitem), "activate",
                         (GtkSignalFunc) callback, data);
   return menuitem;
}

/*
 * Add a separator into the menu.
 */
static void Menu_sep(GtkWidget * menu)
{
   GtkWidget *widget;

   widget = gtk_menu_item_new();
   gtk_menu_append(GTK_MENU(menu), widget);
   gtk_widget_show(widget);
}

/*
 * Make up a new menubar for a main browser window. The accelerator table
 * is stored in bw->accel_group.
 * Currently does not deal with dynamic menu items (bookmarks and history).
 * CP: It *seems* to handle dynamic menu items...
 */
GtkWidget *a_Menu_mainbar_new(BrowserWindow * bw)
{
   GtkWidget *menubar;
   GtkWidget *file_menu;
   GtkWidget *document_menu;
   GtkWidget *browse_menu;
   GtkWidget *bookmarks_menu;
   GtkWidget *help_menu;

   menubar = gtk_menu_bar_new();
   bw->accel_group = gtk_accel_group_new();
  
   /* FILE MENU */
   file_menu = Menu_new(menubar, "_File", FALSE, bw);
   Menu_add(file_menu, "_New Browser", "<ctrl>N", bw, bw,
            a_Commands_new_callback);
   Menu_add(file_menu, "_Open File...", "<ctrl>O", bw, bw,
            a_Commands_openfile_callback);
   Menu_add(file_menu, "Open _URL...", "<ctrl>L", bw, bw,
            a_Commands_openurl_callback);
   Menu_add(file_menu, "_Preferences", "<ctrl>E", bw, bw,
            a_Commands_prefs_callback);
   Menu_add(file_menu, "Close _Window", "<ctrl>W", bw, bw,
            a_Commands_close_callback);
   Menu_sep(file_menu);
   Menu_add(file_menu, "E_xit Dillo", "<ctrl>X", bw, bw,
            a_Commands_exit_callback);

   /* DOCUMENT MENU */
   document_menu = Menu_new(menubar, "_Document", FALSE, bw);
   Menu_add(document_menu, "_View Source", "<ctrl>V", bw, bw,
            a_Commands_viewsource_callback);
   Menu_add(document_menu, "Select _All", NULL, bw, bw,
            a_Commands_selectall_callback);
   Menu_add(document_menu, "_Find Text...", "<ctrl>F", bw, bw,
            a_Commands_findtext_callback);
   Menu_add(document_menu, "_Print...", "<ctrl>P", bw, bw,
            a_Commands_print_callback);

   /* BROWSE MENU */
   browse_menu = Menu_new(menubar, "_Browse", FALSE, bw);
   bw->back_menuitem = Menu_add(browse_menu, "_Back", NULL, bw, bw,
                                a_Commands_back_callback);
   bw->forw_menuitem = Menu_add(browse_menu, "_Forward", NULL, bw, bw,
                                a_Commands_forw_callback);
   Menu_add(browse_menu, "_Reload", "<ctrl>R", bw, bw,
            a_Commands_reload_callback);
   bw->stop_menuitem = Menu_add(browse_menu, "_Stop Loading", NULL,
                                bw, bw, a_Commands_stop_callback);
   Menu_add(browse_menu, "_Home", NULL, bw, bw, a_Commands_home_callback);

   /* BOOKMARKS MENU */
   bookmarks_menu = Menu_new(menubar, "B_ookmarks", FALSE, bw);
   bw->bookmarks_menu = bookmarks_menu;
   Menu_add(bookmarks_menu, "_Add Bookmark", "<ctrl>D", bw, bw,
            a_Commands_addbm_callback);
   Menu_add(bookmarks_menu, "_View Bookmarks", NULL, bw, bw,
            a_Commands_viewbm_callback);
   Menu_sep(bookmarks_menu);

   /* HELP MENU */
   help_menu = Menu_new(menubar, "_Help", TRUE, bw);
   Menu_add(help_menu, "Dillo _Home", NULL, bw, bw,
            a_Commands_helphome_callback);
   Menu_add(help_menu, "Dillo _Manual", NULL, bw, bw,
            a_Commands_manual_callback);
   return menubar;
}

/*
 * Make a new popup menu and return it. 
 */
GtkWidget *a_Menu_popup_new (BrowserWindow *bw)
{
   GtkWidget *menu;

   menu = gtk_menu_new ();

   Menu_add (menu, "_Add Bookmark", "<ctrl>A", bw, bw,
             a_Commands_addbm_callback);
   Menu_sep (menu);
   Menu_add (menu, "_Save As...", "<ctrl>S", bw, bw,
             a_Commands_save_callback);

   return menu;
}

/*
 * Make a new popup menu called when the mouse is over a link and return it.
 */
GtkWidget *a_Menu_popup_ol_new (BrowserWindow *bw)
{
   GtkWidget *menu;

   menu = gtk_menu_new ();
   Menu_add (menu, "_Open Link in New Window", "<ctrl>O", bw, bw,
             a_Commands_open_link_nw_callback);
   /* Menu_sep (menu); */
   Menu_add (menu, "_Add Bookmark for Link", "<ctrl>A", bw, bw,
             a_Commands_addbm_callback);

/*  Arg!! a_Commands_save_callback doesn't work if the page isn't 
 *  already into cache -RL */
/*  But it used to work...  --Jcid */
/*
   Menu_sep (menu);
   Menu_add (menu, "_Save Link As...", "<ctrl>S", bw, bw,
             a_Commands_save_callback);
*/
   return menu;
}
