
#ifndef __DILLO_BROWSER_H__
#define __DILLO_BROWSER_H__

#include <sys/types.h>
typedef struct _BrowserWindow BrowserWindow; 
typedef struct _DilloBookmark DilloBookmark;
typedef struct _DilloMenuPopup DilloMenuPopup;

#include "imgsink.h"

typedef struct {
    char *url;
    char *title;
    /* maybe put some more stuff here:
     * + cached widgets 
     * + form data
     * + scroll position
     */
} DilloNav;

/* browser_window contains all widgets to create a single window */
struct _BrowserWindow
{
    /* widgets for the main window */
    GtkWidget *main_window;
    GtkWidget *back_button;
    GtkWidget *forw_button;
    GtkWidget *stop_button;
    GtkWidget *location;
    GtkWidget *location_button;
    GtkWidget *status;
    GtkWidget *imgprogress;
    GtkWidget *progress;
     
  /* the keyboard accelerator table */
  GtkAccelGroup *accel_group;

  /* individual menuitems so their sensitivity can be set. */
  GtkWidget *back_menuitem;
  GtkWidget *forw_menuitem;
  GtkWidget *stop_menuitem;

  /* the bookmarks menu so that we can add things to it. */
  GtkWidget *bookmarks_menu;

  /* This is the main document widget. (HTML rendering or whatever) */
  GtkWidget *docwin;

  /* pointers to bytesinks for all active connections in the window */
  fd_set FD_Set;
  gint Num_FDs_Used;

  /* pointers to imgsinks for all active connections in the window */
  DilloImgSink **imgsinks;
  gint num_imgsinks;
  gint num_imgsinks_max;
  /* Number of different images in the page */
  gint num_images;
  /* Number of different images already loaded */
  gint num_images_got;

  /* widgets for dialog boxes off main window */
  GtkWidget *open_dialog_window;
  GtkWidget *open_dialog_entry;
  GtkWidget *openfile_dialog_window;
  GtkWidget *quit_dialog_window;
  GtkWidget *save_dialog_window;
  GtkWidget *save_dialog_entry;

  /* Dillo navigation stack (implemented with list.h) */
  DilloNav *nav_stack;
  gint nav_stack_size;
  gint nav_stack_size_max;
  /* 'nav_stack_ptr' refers to what's being displayed */
  gint nav_stack_ptr;
  /* When the user clicks a link, that one doesn't change, but this one
   * gets set to expect the answer. When the document finally loads, 
   * 'nav_stack[++nav_stack_ptr]' is set to reflect this one. */
  DilloNav nav_expect;
  /* 'nav_expecting' is true if the last URL is being loaded for
   * the first time and has not gotten the dw. */
  gboolean nav_expecting;

  /* The tag for the idle function that sets button sensitivity. */
  gint sens_idle_tag;

  /* ? */
  BrowserWindow *bw;
};

//#include "web.h"

struct _DilloBookmark {
  char *title;
  char *url;
  GtkWidget *menuitem;
};

    
/* The popup menus so that we can call them. */
struct _DilloMenuPopup
{
   GtkWidget *menu;
   GtkWidget *menu_over_link;
   DilloNav info;
};

extern BrowserWindow **browser_window;
extern gint num_bw;
extern DilloMenuPopup menu_popup;

#endif /* __DILLO_BROWSER_H__ */

