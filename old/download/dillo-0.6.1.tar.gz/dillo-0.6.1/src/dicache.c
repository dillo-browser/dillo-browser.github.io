/*
 * File: dicache.c
 *
 * Copyright 2000 Jorge Arellano Cid <jcid@inf.utfsm.cl>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */


#include <gtk/gtk.h>
#include <sys/time.h>       /* for libc5 compatibility */
#include <string.h>         /* for memset */
#include <stdio.h>
#include "IO/IO.h"

#include "list.h"
#include "image.h"
#include "dillo.h"
#include "web.h"
#include "dicache.h"
#include "cache.h"
#include "interface.h"


static DICacheEntry **dicache;
static gint dicache_size;
static gint dicache_size_max;

static gint dicache_size_total; /* invariant: dicache_size_total is
                                 * the sum of the image sizes of all
                                 * cache lines in dicache. */
static gint dicache_counter;

/*
 * Initialize dicache data
 */
void a_Dicache_init(void)
{
   dicache_size = 0;
   dicache_size_max = 16;
   dicache = g_new(DICacheEntry *, dicache_size_max);

   dicache_size_total = 0;
   dicache_counter = 0;
}

/*
 * Create and initialize a new cache entry with safe values
 */
DICacheEntry *Dicache_entry_new(const DilloUrl *Url)
{
   static gint DicKey = 0;
   DICacheEntry *entry;

   if ( ++DicKey < 0 ) DicKey = 1;

   entry = g_new(DICacheEntry, 1);
   entry->Key = DicKey;
   entry->url = a_Url_dup(Url);
   entry->width = 0;
   entry->height = 0;
   entry->type = DILLO_IMG_TYPE_NOTSET;
   entry->cmap = NULL;
   entry->ImageBuffer = NULL;

   entry->TotalSize = 0;
   entry->Y = 0;
   entry->BitVec = NULL;
   entry->State = DIC_Empty;

   return entry;
}

/*
 * Add an entry to the dicache
 */
DICacheEntry *a_Dicache_add_entry(const DilloUrl *Url)
{
   /* Allocate memory */
   a_List_add(dicache, dicache_size, sizeof(*dicache), dicache_size_max);
   dicache[dicache_size] = Dicache_entry_new(Url);
   dicache_size++;
   return dicache[dicache_size - 1];
}

/*
 * Search an entry in the dicache (given the Url)
 * Return value: a pointer to the entry if found; NULL otherwise.
 */
DICacheEntry *a_Dicache_get_entry(const DilloUrl *Url)
{
   gint i;

   for (i = dicache_size - 1; i >= 0; i--) {
      if ( !a_Url_cmp(Url, dicache[i]->url) )
         return dicache[i];
   }
   return NULL;
}

/*
 * Search an entry in the dicache (given the DicEntryKey)
 * Return value: a pointer to the entry if found; NULL otherwise.
 */
DICacheEntry *a_Dicache_get_entry_by_key(gint Key)
{
   gint i;

   for (i = dicache_size - 1; i >= 0; i--) {
      if ( dicache[i]->Key == Key )
         return dicache[i];
   }
   return NULL;
}

/*
 * Remove a dicache entry (Using Url or DicKey as primary Key)
 */
void a_Dicache_remove(const DilloUrl *Url, gint DicKey)
{
   gint i;
   DICacheEntry *entry;

   for (i = 0; i < dicache_size; ++i) {
      entry = dicache[i];
      if ( (Url && !a_Url_cmp(Url, entry->url)) || DicKey == entry->Key )
         break;
   }

   if ( i < dicache_size ) {
      /* Eliminate this dicache entry */
      a_Url_free(entry->url);
      g_free(entry->cmap);
      if (entry->ImageBuffer) {
         g_free(entry->ImageBuffer);
         dicache_size_total -= entry->TotalSize;
      }
      a_Bitvec_free(entry->BitVec);
      g_free(entry);
      dicache[i] = dicache[--dicache_size];
   }
}

// -------------------------------------------------------------------------

/*
 * This function is a cache client; (but feeds its clients from dicache)
 */
void a_Dicache_callback(int Op, CacheClient_t *Client)
{
   /* todo: Handle Op = CA_Abort (to show what was got)  --Jcid */
   gint i;
   DilloWeb *Web = Client->Web;
   DilloImage *Image = Web->Image;
   DICacheEntry *DicEntry = a_Dicache_get_entry(Web->url);

   g_return_if_fail ( DicEntry != NULL );

   if ( Op == CA_Send ) {
      if ( Image->height == 0 && DicEntry->State >= DIC_SetParms ) {
         /* Set parms */
         a_Image_set_parms(Image, DicEntry->ImageBuffer,
                           DicEntry->width, DicEntry->height, DicEntry->type);
      }
      if ( DicEntry->State == DIC_Write ) {

         for ( i = 0; i < DicEntry->height; ++i )
            if ( a_Bitvec_get_bit(DicEntry->BitVec, i) &&
                 !a_Bitvec_get_bit(Image->BitVec, i) )
               a_Image_write(
                  Image, DicEntry->ImageBuffer + i*DicEntry->width*3, i,FALSE);

      }
   } else if ( Op == CA_Close || Op == CA_Abort ) {
      a_Image_close(Web->Image);
      a_Interface_close_client(Web->bw, Client->Key);
   }
}

// -------------------------------------------------------------------------

/*
 * Set image's width, height & type
 * (By now, we'll use the image information despite the html tags --Jcid)
 */
void a_Dicache_set_parms(gint DicEntryKey, DilloImage *Image,
                         gint width, gint height, DilloImgType type)
{
   DICacheEntry *DicEntry;
   size_t Size = width * height * 3;

   g_return_if_fail ( Image != NULL && width && height );
   /* Find the DicEntry for this Image */
   DicEntry = a_Dicache_get_entry_by_key(DicEntryKey);
   g_return_if_fail ( DicEntry != NULL );

   /* Initialize the DicEntry */
   DicEntry->ImageBuffer = g_new(guchar, Size);
   DicEntry->TotalSize = Size;
   DicEntry->width = width;
   DicEntry->height = height;
   DicEntry->type = type;
   DicEntry->BitVec = a_Bitvec_new(height);
   DicEntry->State = DIC_SetParms;

   /* For giggles, make the background of the undrawn parts interesting */
   memset(DicEntry->ImageBuffer, 0xdd, DicEntry->TotalSize);

   /* Allocate and initialize this image */
   a_Image_set_parms(Image, DicEntry->ImageBuffer, width, height, type);
}

/*
 * Implement the set_cmap method for the Image
 */
void a_Dicache_set_cmap(gint DicKey, DilloImage *Image,
                        const guchar *cmap, gint num_colors, gint bg_index)
{
   DICacheEntry *DicEntry = a_Dicache_get_entry_by_key(DicKey);

   g_return_if_fail ( DicEntry != NULL );

   DicEntry->cmap = g_realloc(DicEntry->cmap, 3 * num_colors);
   memcpy(DicEntry->cmap, cmap, 3 * num_colors);
   if (bg_index >= 0 && bg_index < num_colors) {
      DicEntry->cmap[bg_index * 3]     = (Image->bg_color >> 16) & 0xff;
      DicEntry->cmap[bg_index * 3 + 1] = (Image->bg_color >> 8) & 0xff;
      DicEntry->cmap[bg_index * 3 + 2] = (Image->bg_color) & 0xff;
   }

   a_Image_set_cmap(Image, DicEntry->cmap);
   DicEntry->State = DIC_SetCmap;
}

/*
 * Implement the write method
 * (Write a scan line into the Dicache entry)
 * buf: row buffer
 * Y  : row number
 * x  : horizontal offset? (always zero)
 */
void a_Dicache_write(DilloImage *Image, gint DicKey,
                     const guchar *buf, gint x, gint Y)
{
   DICacheEntry *DicEntry;

   g_return_if_fail ( Image != NULL );
   DicEntry = a_Dicache_get_entry_by_key(DicKey);
   g_return_if_fail ( DicEntry != NULL );
   g_return_if_fail ( DicEntry->width > 0 && DicEntry->height > 0 );

   a_Image_write(Image, buf, Y, TRUE);
   DicEntry->Y = Y;
   a_Bitvec_set_bit(DicEntry->BitVec, Y);
   DicEntry->State = DIC_Write;
}

/*
 * Implement the close method of the decoding process
 */
void a_Dicache_close(gint DicKey, CacheClient_t *Client)
{
   DilloWeb *Web = Client->Web;
   DICacheEntry *DicEntry = a_Dicache_get_entry_by_key(DicKey);

   g_return_if_fail ( DicEntry != NULL );

   DicEntry->State = DIC_Close;
   if (DicEntry->cmap) {
      g_free(DicEntry->cmap);
      DicEntry->cmap = NULL;
   }
   a_Image_close(Web->Image);
   a_Interface_close_client(Web->bw, Client->Key);
}

// -------------------------------------------------------------------------

/*
 * Deallocate memory used by dicache module
 * (Call this one at exit time)
 */
void a_Dicache_freeall(void)
{
   /* Remove every dicache entry */
   while ( dicache_size )
      a_Dicache_remove(NULL, dicache[0]->Key);
   /* Remove the dicache list */
   g_free(dicache);
}
