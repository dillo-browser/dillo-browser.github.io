/*
 * File: Url.c
 *
 * Copyright (C) 1997 Raph Levien <raph@acm.org>
 * Copyright (C) 1999 Randall Maas <randym@acm.org>,
 * Copyright (C) 1999, 2000 Jorge Arellano Cid <jcid@inf.utfsm.cl>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

/* Heavily modified by Jcid, Dec 1999 & Jun 2000
 *
 * This module selects the apropriate CCC-function for a given URL.
 */


#include <glib.h>
#include <stdlib.h>
#include "../list.h"
#include "Url.h"
#include "../prefs.h"
#include "../misc.h"

typedef struct {
   const char *Name;   /* Method name */
   UrlOpener_t Data;   /* Pointer to a function */
} UrlMethod_t;

typedef struct {
   const char *Name;             /* Method name */
   ChainFunction_t cccFunction;  /* Pointer to a CCC function */
} UrlMethod2_t;

/*
 * Local data
 */
DilloUrl *HTTP_Proxy = NULL;
gchar *No_Proxy = NULL;

static gint UrlOpenersSize = 0, UrlOpenersMax = 8;
static UrlOpener_t *UrlOpeners = NULL;

gint UrlMethodsSize = 0, UrlMethodsMax = 8;
static UrlMethod_t *UrlMethods = NULL;

/*
 * Forward declarations
 */
gint Url_add_opener(UrlOpener_t F);


/*
 * Add a method for Url handling
 * (currently we have File, About & Http)
 * -- Currently not used
 */
gint Url_add_method(const char *Name, UrlOpener_t Method)
{
   a_List_add(UrlMethods, UrlMethodsSize, sizeof(*UrlMethods), UrlMethodsMax);
   UrlMethods[UrlMethodsSize].Name = Name;
   UrlMethods[UrlMethodsSize].Data = Method;
   UrlMethodsSize++;
   return 0;
}

/*
 * Adds method 'F' to the list of URL openers.
 * UrlOpeners are called in LIFO order until success.
 * -- Currently not used
 */
gint Url_add_opener(UrlOpener_t F)
{
   a_List_add(UrlOpeners, UrlOpenersSize, sizeof(UrlOpener_t *), UrlOpenersMax);
   UrlOpeners[UrlOpenersSize] = F;
   UrlOpenersSize++;
   return 0;
}

/*
 * Search the cccList for a matching ccc function.
 */
ChainFunction_t a_Url_get_ccc_funct(const DilloUrl *Url)
{
   static UrlMethod2_t cccList[3] = { {"http",  a_Http_ccc},
                                      {"file",  a_File_ccc},
                                      {"about", a_About_ccc} };
   const gchar *Key = NULL;
   gint KeyLen, i, j;

   /* Use the method inside the URL as a Key to decide what cccFunct matches */
   if ( !URL_SCHEME(Url) )
      return NULL;
   else {
      Key = URL_SCHEME(Url);
      KeyLen = strlen(Key);
   }

   for ( i = 0; i < 3; ++i ) {
      for ( j = 0; j < KeyLen; ++j )
         if ( tolower(Key[j]) != cccList[i].Name[j] )
            break;
      if ( j == KeyLen )
         return cccList[i].cccFunction;
   }
   return NULL;
}

/*
 * Set data required by this module
 */
gint a_Url_init2(void)
{
   gchar *env_proxy = getenv("http_proxy");

   if (env_proxy && strlen(env_proxy))
      HTTP_Proxy = a_Url_new(env_proxy, NULL, 0, 0);
   No_Proxy = getenv("no_proxy");
   if (!HTTP_Proxy && prefs.http_proxy)
      HTTP_Proxy = prefs.http_proxy;
   if (!No_Proxy && prefs.no_proxy)
      No_Proxy = prefs.no_proxy;

   return 0;
}
