#ifndef __URL_H__
#define __URL_H__

#include "../../config.h"
#include "../chain.h"
#include "../url.h"
#include <glib.h>
#include <stdio.h> /* for sprintf */
#include <ctype.h>
#include <string.h>
#include <unistd.h>
#include "IO.h"


/*
 * URL opener codes
 */
#define URL_Http
#define URL_File
#define URL_Plugin
#define URL_None


#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/* Returns a file descriptor to read data on; meta data is sent on FD_TypeWrite */
typedef gint (*UrlOpener_t) (const DilloUrl *url, void *data);

/*
 * Module functions
 */
gint  a_Url_init2 (void);
ChainFunction_t a_Url_get_ccc_funct(const DilloUrl *Url);

extern DilloUrl *HTTP_Proxy;
extern gchar    *No_Proxy;

/*
 * External functions
 */
extern void a_Http_freeall(void);

void a_Http_ccc (int Op, int Br, ChainLink *Info, void *Data, void *ExtraData);
void a_File_ccc (int Op, int Br, ChainLink *Info, void *Data, void *ExtraData);
void a_About_ccc(int Op, int Br, ChainLink *Info, void *Data, void *ExtraData);
void a_IO_ccc   (int Op, int Br, ChainLink *Info, void *Data, void *ExtraData);


#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __URL_H__ */

