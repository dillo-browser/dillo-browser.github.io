#ifndef __COLORS_H__
#define __COLORS_H__

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

gint32 a_Color_parse (const char *subtag, gint32 default_color);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __COLORS_H__ */
