#ifndef __GTK_WEB_H__
#define __GTK_WEB_H__

#include <gtk/gtk.h>
#include "URL/Url.h"
#include "imgsink.h"
#include "interface.h"
typedef struct _DilloWeb DilloWeb;
typedef struct _DilloLinkBlock DilloLinkBlock;

#include "dw.h"
#include "dw_gtk_scroller.h"
#include "browser.h"
#include "IO/IOQ.h"

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

struct _DilloLinkBlock {
  struct _BrowserWindow* bw;
  char *base_url;
};

struct _DilloWeb {
  DilloImgSink *imgsink;
  Dw *dw;

  char *header;         /* The HTTP header response (without '\r' chars) */
  int Start_Ofs;
  int size_header;      /* strlen(header) */
  int size_header_max;

  int state;

  int Child_FD;
  int Cache_FD;

  char *url;

  BrowserWindow *bw;
  DilloLinkBlock *child_linkblock;
};


#define a_Web_fd(Web,fd) do{if (Web) ((DilloWeb*)Web)->Child_FD = fd;\
   IO_set_fd_to_bkgnd(fd);}while(0)
#define a_Web_status(Web,text) a_Interface_status(text,Web?((DilloWeb*)Web)->bw:NULL)

DilloWeb* a_Web_new (const char* URL);
void a_Web_free (DilloWeb*);
void a_Web_callback (int Op, void*web, __CacheFile_t*);
Dw* a_Web_dispatch_by_type(DilloWeb* web, const char* Type,
                           __IOCallback_t* Call, void** Data);

#ifdef __cplusplus
}
#endif /* __cplusplus */


#endif /* __GTK_WEB_H__ */
