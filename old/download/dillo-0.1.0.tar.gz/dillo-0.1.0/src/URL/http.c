/*
 * File: http.c
 *
 * Copyright (C) 1997 Raph Levien <raph@acm.org>
 * Copyright (C) 1999 Jorge Arellano Cid <jcid@inf.utfsm.cl>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */


/* todo: make error messages more descriptive. */

#include <unistd.h>

#include <errno.h>              /* for errno */
#include <string.h>             /* for strstr */
#include <stdlib.h>
#include <search.h>
#include <signal.h>
#include <fcntl.h>
#include <sys/wait.h>
#include "Url.h"

#include "url.h"
#include "../socket.h"

typedef struct __Info_t {
   void *WData;
   char *Query;
} __Info_t;

/*
 * Local data
 */
static GList *Free_nodes = NULL;  /* __Info_t list of free nodes */


/*
 * The callback for socket setup. This function gets called whenever
 * the socket setup completes. It installs the input handler for writing
 * the query string to the socket. 
 *  If OP has a nonzero value, socket connection failed.
 */
static void Http_callback(int Op, int FD_Sock, void *VPtr)
{
   /* Send the header stuff of to the Type channel, this is somewhat expensive
    * since we are doing a lot of kernel calls to do this safely */

   __Info_t *IPtr = (__Info_t *) VPtr;
   char errmsg[128];

   /* This could take a while to get the query /back/... So we need to do
    * something.. Alas, not much can be done right yet. */
   if (Op) {
      /* Let the user know it is a sad day */
      sprintf(errmsg,  (Op == 3) ? "Error: DNS can't resolve the address" :
                                   "Error: unable to connect...");
      a_Web_status(IPtr->WData, errmsg);

      if ( IPtr && IPtr->Query ) {
         g_free(IPtr->Query);
         IPtr->Query = NULL;
         /* Free this info node */
         Free_nodes = g_list_append(Free_nodes, (gpointer) IPtr);
      }
      close(FD_Sock);

   } else {
      /* Send the query out... */
      IO_set_fd_to_bkgnd(FD_Sock);
      if (IPtr->Query) {
         size_t Size = strlen(IPtr->Query);
   
         /* Make this a background IO */
         a_IO_submit(FD_Sock, 1, IPtr->Query, Size);
         /* BUG: IPtr is never freed! */
      }
      a_Cache_tmp(FD_Sock);
      Free_nodes = g_list_append(Free_nodes, (gpointer) IPtr);
      /* Remove the "Connecting" msg. */
      a_Web_status(IPtr->WData, "");
   }
}

/*
 * Make the query string
 */
char *Http_query(char *url, const char *hostname, int port)
{
   char *str;
   GString *s_port = g_string_new(""),
           *query  = g_string_new("");

   /* Sending the default port in the query causes 302 answers  --Jcid */
   g_string_sprintfa(s_port, (port == 80) ? "" : ":%d", port);

   str = strstr(url,"?!POST:");
   if ( str ){
      *str = '\0';
      /* strlen("?!POST:") is 7 */
      str += 7;
      g_string_sprintfa(query,
                       "POST %s HTTP/1.0\r\n"
                       "User-Agent: Dillo/%s\r\n"
                       "Host: %s%s\r\n"
                       "Content-type: application/x-www-form-urlencoded\r\n"
                       "Content-length: %d\r\n"
                       "\r\n"
                       "%s\r\n",
                       url, VERSION, hostname, s_port->str, strlen(str), str);
   }else{
      g_string_sprintfa(query, "GET %s HTTP/1.0\r\n"
                       "User-Agent: Dillo/%s\r\n"
                       "Host: %s%s\r\n"
                       "\r\n", url, VERSION, hostname, s_port->str);
   }
   str = query->str;
   g_string_free(query, FALSE);
   g_string_free(s_port, TRUE);
   return str;
}

/*
 * Create a new http connection for URL 'url', and asynchronously
 * feed the bytes that come back to bytesink.
 */
int a_Http_get(const char *url, void *Data)
{
   char hostname[256], msg[512];
   int port, Ret;
   char *tail;
   char *query;
   __Info_t *IPtr;

   port = 80;

   /* hacked-in support for proxies, inspired by Olivier Aubert */
   if (HTTP_Proxy && !(No_Proxy && strstr(url, No_Proxy) != NULL)) {
      a_Url_parse(HTTP_Proxy, hostname, sizeof(hostname), &port);
      tail = (char *) url;
   } else
      tail = a_Url_parse((char *) url, hostname, sizeof(hostname), &port);

   if (!tail)
      return -1;

   query = Http_query (tail, hostname, port);

   if ( Free_nodes ) {
      /* Get a node from the list */
      IPtr = (__Info_t *) Free_nodes->data;
      Free_nodes = g_list_remove(Free_nodes, (gpointer) IPtr);
      if (IPtr->Query)
         g_free(IPtr->Query);
   } else {
      if (!(IPtr = g_malloc(sizeof(__Info_t)))) {
         g_free (query);
         return -1;
      }
   }
   IPtr->Query = g_strdup(query);
   IPtr->WData = Data;
   g_free(query);

   /* Setup a socket, in a Dillo friendly fashion... because it is remote,
    * we only will have information about the name.  We will get a call back
    * later indicating what we should do about that.
    */
   sprintf(msg, "Connecting to %s...\n", hostname);
   a_Web_status(Data, msg);
   Ret = a_Socket_new(hostname, port, Http_callback, (void *) IPtr);

   /* BUG: if socket fails, no way to recover IPtr */
   if (Ret < 0) {
      g_free(IPtr->Query);
      IPtr->Query = NULL;
      Free_nodes = g_list_append(Free_nodes, (gpointer) IPtr);
      a_Web_status(Data, "Couldn't get new socket\n");
      return -1;
   } else {
      _FD2Ptr(Ret).Call = a_Web_callback;
      _FD2Ptr(Ret).Data = Data;
   }
   return Ret;
}

/*
 * Deallocate memory used by 'Free_nodes' list
 * (Call this one at exit time)
 */
void a_Http_freeall(void)
{
__Info_t *IPtr;

   while ( Free_nodes ) {
      IPtr = (__Info_t *) Free_nodes->data;
      Free_nodes = g_list_remove(Free_nodes, (gpointer) IPtr);
   }
}

