/*  
 * URL methods  Randall Maas  1999
 */

/* Heavily rearranged by jcid, Dec 1999 */

#ifndef __Url_h
#define __Url_h
# include "../../config.h"
# include <stdio.h> /* for sprintf */
# include <ctype.h> /* for isalpha */
# include <string.h> /* for strcmp */
# if defined(HAVE_UNISTD_H) && HAVE_UNISTD_H
#  include <unistd.h>
# endif

# ifdef __GNUC__
#  define FUNC __attribute__((__const__))
# endif
# define URN_OTHER  "()+,-.:=@;$_!*'/%?"


#include "../cache.h"
#include "../web.h"
#include "../IO/IO.h"

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/* Returns a file descriptor to read data on; meta data is sent on FD_TypeWrite */
typedef int (*__Open_t) (const char *url, void*);

/*
 * Module functions
 */
int   a_Url_is_absolute (const char *url);
char* a_Url_parse_hash  (const char *URL);
int   a_Url_open (const char *url, void* Callback_Data);
int   a_Url_init (void);

extern char *HTTP_Proxy, *No_Proxy;

/*
 * External functions
 */
extern void* a_Hdlr_fetch (void* IPtr,int NItems,const char* Key, size_t Size);
extern int a_Hdlr_add (void**IPtr,int*NItems,int* NAlloc,const char*,void*);
extern int a_Proto_get_url (const char *url, void*);
extern int a_About_get (const char *url, void*);
extern int a_File_get  (const char *url, void*);
extern int a_Http_get  (const char *url, void*);
extern void a_Http_freeall(void);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif

