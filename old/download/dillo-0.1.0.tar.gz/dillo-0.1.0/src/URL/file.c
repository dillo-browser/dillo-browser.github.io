/*
 * File: file.c :)
 *
 * Copyright (C) 2000 Jorge Arellano Cid <jcid@inf.utfsm.cl>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

/*
 * Directory scanning is no longer streamed, but it gets sorted instead!
 * Directory entries on top, files next.
 * Not forked anymore; pthread handled.
 * With new HTML layout.
 */

#include <pthread.h>
#include <ctype.h>              /* for tolower */
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <fcntl.h>
#include <string.h>
#include <time.h>
#include <stdio.h>
#include <signal.h>

#include <errno.h>      /* for errno */
#include "Url.h"
#include "../IO/IO.h"
#include "../web.h"
#include "../list.h"

typedef struct _DilloDir {
   int FD_Write, FD_Read;
   char *dirname;
   DIR *dir;
   gboolean scanned;  /* Flag: Have we scanned it? */
   char **dlist;       /* List of subdirectories (for sorting) */
   int dlist_size;
   int dlist_max;
   int dlist_idx;
   char **flist;       /* List of files (for sorting) */
   int flist_size;
   int flist_max;
   int flist_idx;
} DilloDir;



/*
 * Local data (used only by File_Not_Found_msg)
 */
static char Buffy[2048];
static __CacheFile_t FedCFile =
   {"file: not found", "text/html", Buffy, sizeof(Buffy)};


/*
 * Forward references 
 */
static int File_get_dir(const char *url, void *Data);
static char *File_dir2html(DilloDir *Dfile);
static int File_Not_Found_msg(const char *filename, void *Web);


/*
 * Allocate and set safe a DilloDir structure for directory processing
 */
DilloDir *File_dillofile_new(char *dirname)
{
   DIR *dir;
   int fds[2];
   DilloDir *Dfile;

   if ( !(dir = opendir(dirname)) || pipe(fds) )
      return NULL;

   Dfile = g_new(DilloDir, 1);
   Dfile->dir = dir;
   Dfile->scanned = FALSE;
   Dfile->dirname = g_strdup(dirname);
   Dfile->FD_Read  = fds[0];
   Dfile->FD_Write = fds[1];
   Dfile->dlist = NULL;
   Dfile->dlist_size = 0;
   Dfile->dlist_max = 256;
   Dfile->dlist_idx = 0;
   Dfile->flist = NULL;
   Dfile->flist_size = 0;
   Dfile->flist_max = 256;
   Dfile->flist_idx = 0;

   return Dfile;
}


/*
 * Read a local directory, translate it to html, and send it through a pipe.
 * (This function runs on its own thread)
 */
static void *File_dir_transfer(void *data)
{
   char buf[8192], 
        *s;
   DilloDir *GF = (DilloDir *) data;


   /* Send page title and header */
   sprintf(buf, "<HTML><HEADER><TITLE>%s %s</TITLE></HEADER>\n",
                "Directory listing of", GF->dirname);
   write(GF->FD_Write, buf, strlen(buf));
   sprintf(buf, "<BODY><H1>%s %s</H1>\n<pre>\n", "Directory listing of",
                GF->dirname);
   write(GF->FD_Write, buf, strlen(buf));
   
   /* Append formatted directory contents */
   while ( (s = File_dir2html(GF)) ){
      write(GF->FD_Write, s, strlen(s));
   }

   /* Close open HTML tags */
   sprintf(buf, "\n</pre></BODY></HTML>\n");
   write(GF->FD_Write, buf, strlen(buf));

   close(GF->FD_Write);
   closedir(GF->dir);
   GF->dir = NULL;
   g_free(GF->dirname);
   return NULL;
}

/* 
 * Return 1 if the extension matches that of the filename. 
 */
static int File_ext(const char *filename, const char *ext)
{
   char *e;

   if ( !(e = strrchr(filename, '.')) )
      return 0;
   return (strcasecmp(ext, ++e) == 0);
}

/*
 * Based on the extension, return the content_type for the file. 
 */
static char *File_content_type(const char *filename)
{
   if (File_ext(filename, "gif")) {
      return "image/gif";
   } else if (File_ext(filename, "jpg") || File_ext(filename, "jpeg")) {
      return "image/jpeg";
   } else if (File_ext(filename, "png")) {
      return "image/png";
   } else if (File_ext(filename, "html") || File_ext(filename, "htm")) {
      return "text/html";
   }
   return "text/plain";
}

/*
 * Create a new file connection for URL url, and asynchronously
 * feed the bytes that come back to bytesink. 
 */
int a_File_get(const char *url, void *Web)
{
   char *filename;
   int fd;
   char *content_type;
   struct stat sb;
   int t;

   filename = (char *) url + 5;
   t = stat(filename, &sb);
   if (t != 0) {
      /* stat failed, give file-not-found error. */
      return File_Not_Found_msg(filename, Web);
   }

   if (S_ISDIR(sb.st_mode)) {
      /* set up for reading directory */
      fd = File_get_dir(url, Web);
      /* Force html type! */
      content_type = File_content_type("dir.html");
   } else {
      fd = open(filename, O_RDONLY);
      content_type = File_content_type(filename);
   }

   if (fd < 0)
      return File_Not_Found_msg(filename, Web);

   /* set close-on-exec */
   fcntl(fd, F_SETFD, FD_CLOEXEC | fcntl(fd, F_GETFD));
   a_Web_fd(Web, fd);
   a_Web_dispatch_by_type(Web, content_type, &_FD2Ptr(fd).Call,
                          &_FD2Ptr(fd).Data);

   return -1;
}

/*
 * Create a pipe connection for URL 'url', which is a directory, 
 * and feed an ordered html listing through it.
 * (The feeder function runs on its own thread)
 */
static int File_get_dir(const char *url, void *Data)
{
   pthread_t th1;
   GString *g_dirname;
   DilloDir *Dfile;

   /* Lets get sure this directory url has a trailing slash */
   g_dirname = g_string_new(url + 5); /*  "file:" */
   if ( g_dirname->str[g_dirname->len - 1] != '/' )
      g_string_append(g_dirname, "/");

   /* Lets get a structure ready for transfer */
   Dfile = File_dillofile_new(g_dirname->str);
   g_string_free(g_dirname, TRUE);

   if ( Dfile ) {
      pthread_create(&th1, NULL, File_dir_transfer, Dfile);
      return Dfile->FD_Read;
   } else
      return -1;
}

/*
 * Return a HTML-line from file info.
 */
static char *File_info2html(struct stat *SPtr, const char *name,
                            const char *dirname, const char *date)
{
   static char *dots = ".. .. .. .. .. .. .. .. .. .. .. .. .. .. .. .. ..";
   static char buf[1200];
   int size, ndots;
   char *sizeunits;

#define MAXNAMESIZE 30
   char namebuf[MAXNAMESIZE + 1];
   const char *ref;
   char anchor[1024];
   char *cont;
   char *longcont;

   if (!name)
      return NULL;

   if (strcmp(name, "..") == 0) {
      if ( strcmp(dirname, "/") != 0 ){        /* Not the root dir */
         char *parent = g_strdup(dirname);
         char *p;
         /* cut trailing '/' */
         parent[strlen(parent) - 1] = 0;
         /* make 'parent' have the parent dir path */
         p = strrchr(parent, '/');
         *(p + 1) = 0; 
         sprintf(buf, "<a href=\"%s\">%s</a>\n<p>\n",
                 parent, "Parent directory");
      } else
         strcpy(buf, "<br>\n");
      return buf;
   }

   if (SPtr->st_size <= 9999) {
      size = SPtr->st_size;
      sizeunits = "bytes";
   } else if (SPtr->st_size / 1000 <= 9999) {
      size = SPtr->st_size / 1000;
      sizeunits = "Kb";
   } else {
      size = SPtr->st_size / 1000000;
      sizeunits = "Mb";
   }
   /* we could note if it's a symlink... */
   if S_ISDIR (SPtr->st_mode) {
      cont = "application/directory";
      longcont = "Directory";
   } else if (SPtr->st_mode & (S_IXUSR | S_IXGRP | S_IXOTH)) {
      cont = "application/executable";
      longcont = "Executable";
   } else {
      cont = File_content_type(name);
      longcont = cont;
      if (!cont) {
         cont = "unknown";
         longcont = "";
      }
   }

#if 0
   /* Setup ref before shortening name so we have the full filename */
   if (fileinfo->symlink)
      ref = fileinfo->symlink;
   else
#endif
      ref = name;

   if ( strlen(name) > MAXNAMESIZE) {
      strncpy(namebuf, name, MAXNAMESIZE - 3);
      strcpy(namebuf + (MAXNAMESIZE - 3), "...");
      name = namebuf;
   }
   ndots = MAXNAMESIZE - strlen(name);
   ndots = MAX(ndots, 0);

   if (ref[0] == '/')
      sprintf(anchor, "file:%s", ref);
   else
      sprintf(anchor, "file:%s%s", dirname, ref);
   sprintf(buf,
           /* "<img src=\"internal:icon/%s\">"   Not yet...  --Jcid */
           "%s<a href=\"%s\">%s</a> %s%10s %5d %-5s %s\n",
           S_ISDIR (SPtr->st_mode) ? ">" : " ", anchor, name,
/*
           "<a href=\"%s\">%s</a>%s %s%10s %5d %-5s %s\n",
           anchor, name, S_ISDIR (SPtr->st_mode) ? "/" : " ",
*/
           dots+50-ndots, longcont, size, sizeunits, date);

   return buf;
}

/*
 * Given a timestamp, create a date string and place it in 'datestr'
 */
void File_get_datestr(time_t *mtime, char *datestr)
{
   time_t currenttime;
   char *ds;

   time(&currenttime);
   ds = ctime(mtime);
   if (currenttime - *mtime > 15811200) {
      /* over about 6 months old */
      sprintf(datestr, "%6.6s  %4.4s", ds + 4, ds + 20);
   } else {
      /* less than about 6 months old */
      sprintf(datestr, "%6.6s %5.5s", ds + 4, ds + 11);
   }
}

/*
 * Compare two strings 
 * This function is used for directory sorting 
 */
int File_comp(const void *a, const void *b)
{
   return strcmp(*(char **)a, *(char **)b);
}

/*
 * Read directory entries to a list, sort them alphabetically, and return
 * formatted HTML, line by line, one per entry.
 * When there're no more entries, return NULL
 */
static char *File_dir2html(DilloDir *Dfile)
{
   struct dirent *de;
   struct stat sb;
   char *name, *s;
   int *index;

#ifndef MAXPATHLEN
#define MAXPATHLEN 1024
#endif
   char fname[MAXPATHLEN + 1];
   char datebuf[64];

   if ( !Dfile->scanned ) {
      /* Lets scan every name and sort them */
      while ((de = readdir(Dfile->dir)) != 0) {
         if (strcmp(de->d_name, ".") == 0)
            continue;              /* skip "." */
         sprintf(fname, "%s/%s", Dfile->dirname, de->d_name);
         
         if ( stat(fname, &sb) == -1)
            continue;              /* ignore files we can't stat */

         if ( S_ISDIR(sb.st_mode) ) {
            a_List_add(Dfile->dlist, Dfile->dlist_size, sizeof(char *),
                       Dfile->dlist_max);
            Dfile->dlist[Dfile->dlist_size] = strdup(de->d_name);
            ++Dfile->dlist_size;
         } else {
            a_List_add(Dfile->flist, Dfile->flist_size, sizeof(char *),
                       Dfile->flist_max);
            Dfile->flist[Dfile->flist_size] = strdup(de->d_name);
            ++Dfile->flist_size;
         }
      }
      /* sort the enries */
      qsort(Dfile->dlist, Dfile->dlist_size, sizeof(char *), File_comp);
      qsort(Dfile->flist, Dfile->flist_size, sizeof(char *), File_comp);

      /* Directory scanning done */
      Dfile->scanned = TRUE;
   }

   if ( Dfile->dlist_idx < Dfile->dlist_size ) {
      /* We still have directory entries */
      name = Dfile->dlist[Dfile->dlist_idx];
      index = &Dfile->dlist_idx;
   } else if ( Dfile->flist_idx < Dfile->flist_size ) {
      /* We still have file entries */
      name = Dfile->flist[Dfile->flist_idx];
      index = &Dfile->flist_idx;
   } else {
      g_free(Dfile->flist);
      g_free(Dfile->dlist);
      return NULL;
   }

   sprintf(fname, "%s/%s", Dfile->dirname, name);
   stat(fname, &sb);
   File_get_datestr(&sb.st_mtime, datebuf);
   s = File_info2html(&sb, name, Dfile->dirname, datebuf);
   g_free(name);
   ++(*index);
   return s;
}

/*
 * Give a file-not-found error (an HTML page).
 * Return Value: -1
 */
int File_Not_Found_msg(const char *filename, void *Web)
{
   void *Data = NULL;
   __IOCallback_t Call = NULL;

   a_Web_dispatch_by_type(Web, FedCFile.Type, &Call, &Data);
   if (!Call)
      return -1;

   sprintf(Buffy, "<html><head><title>404 Not Found</title></head>\n"
           "<body><h1>404 Not Found</h1><p>The requested file %s"
    " was not found in the filesystem.</p>\n</body></html>\n", filename);
   Call(0, Data, &FedCFile);
   Call(1, Data, &FedCFile);
   return -1;
}


