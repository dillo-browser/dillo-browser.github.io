/*
 * File: nav.c
 *
 * Copyright (C) 1997 Raph Levien <raph@acm.org>
 * Copyright (C) 1999 James McCollough <jamesm@gtwn.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

#include <stdio.h>
#include <gtk/gtk.h>
#include "cache.h"
#include "browser.h"
#include "menu.h"
#include "dillo.h"
#include "interface.h"

#include "list.h"
#include "dw.h"
#include "web.h"
#include "dicache.h"
#include "dillo.h"
#include "URL/url.h"
#include "dw_gtk_progressbar.h"
#include "prefs.h"

/* Support for a navigation stack */

/*
 * The other main thing to do is make the dillo_nav structure a per-window
 * thing rather than a global. This would be needed if we ever get multiple
 * browser windows going.
 *
 * Done -Ian
 */

/* 
 * ToDo: be smarter about aborting "loading" connections.
 * 
 * This probably means making a distinction between documents that
 * have successfully been loaded (and are on the nav stack) and
 * documents that aren't. Right now, the predicate (ptr = size - 1
 * and loading_ptr = size) is used as a stand-in, but it isn't quite
 * right, because it's possible to load the document, go back, then
 * go forward.
 * 
 * Documents that have been succesfully loaded should also have
 * slightly different navigation behavior: the url (and maybe title)
 * should be displayed immediately. 
 */


/* 
 * Not sure this should really be separate from the routine that creates
 * bytesinks. 
 */
void a_Nav_init(BrowserWindow *bw)
{
   bw->size_dillo_nav = 1;
   bw->size_dillo_nav_max = 16;
   bw->dillo_nav = g_new(DilloNav, bw->size_dillo_nav_max);
   bw->dillo_nav->title = NULL;

   bw->dillo_nav_ptr = 0;
   bw->dillo_nav_loading_ptr = 0;

   bw->last_waiting = FALSE;
}

/*
 * ?
 */
static void Nav_open_url(BrowserWindow *bw, const char *url)
{

   DilloWeb *Web = a_Web_new(url);
   char *url_head, *url_tail;
   int FD;
   GdkCursor *regCursor;

/**/g_print("Nav_open_url: url=%s\n", url);

  a_Interface_set_button_sens (bw);
  a_Interface_abort_all (bw);
/* BUG: cancel last waiting!?! */

   Web->bw = bw;

   if (!bw->last_waiting) {
      gtk_entry_set_text(GTK_ENTRY(bw->location),
                         bw->dillo_nav[bw->dillo_nav_ptr - 1].url);
   }

   /* todo: scroll to the name in the url_tail */
   url_head = g_strdup(url);
   if ((url_tail = a_Url_parse_hash(url))) 
      url_head[url_tail - url] = '\0';
/*
 * g_print("Nav_open_url: url_head=%s\n", url_head);
 * g_print("Nav_open_url: url_tail=%s\n", url_tail);
 * g_print("Nav_open_url: url=%s\n\n", url);
 */
   FD = a_Cache_open_url(url_head, Web);
   g_free(url_head);

   if (FD >= 0) {
      /* Reset progress bars */
      a_Dw_gtk_progressbar_update(bw->progress, "", 1);
      a_Dw_gtk_progressbar_update(bw->imgprogress, "", 1);

      regCursor = gdk_cursor_new(GDK_LEFT_PTR);
      a_Interface_add_bytesink(bw, FD);
      gdk_window_set_cursor(bw->docwin->window, regCursor);
   } else {
      a_Web_free(Web);
   }
}

/* 
 * Cancel the last waiting nav structure if present. The responsibility
 * for actually aborting the bytesink remains with the caller. 
 */
void a_Nav_cancel_last_waiting(BrowserWindow *bw)
{
   gint i;

   if (bw->last_waiting) {
      i = bw->dillo_nav_loading_ptr - 1;
      g_free(bw->dillo_nav[i].url);
      if (bw->dillo_nav[i].title != NULL)
         g_free(bw->dillo_nav[i].title);
      bw->size_dillo_nav--;
      bw->dillo_nav_loading_ptr--;
      bw->last_waiting = FALSE;
   }
   if (bw->dillo_nav_loading_ptr != bw->dillo_nav_ptr)
      g_warning("a_Nav_cancel_last_waiting: invariants broken");
}

/* 
 * Make 'url' the current browsed page
 * It looks in the cache before requesting the URL from the original server.
 */
void a_Nav_push(BrowserWindow *bw, const char *url)
{
   gint i;
   char *str, *url_copy;

   if (!bw)
      return;
   for (i = bw->dillo_nav_ptr; i < bw->size_dillo_nav; i++) {
      if (bw->dillo_nav[i].url)
         g_free(bw->dillo_nav[i].url);
      if (bw->dillo_nav[i].title)
         g_free(bw->dillo_nav[i].title);
   }
   a_List_add(bw->dillo_nav, bw->dillo_nav_ptr, sizeof(*bw->dillo_nav),
              bw->size_dillo_nav_max);

   url_copy = g_strdup(url);
   if ((str = strstr (url,"?!POST")) != NULL)
      *str = '\0';

   bw->dillo_nav[bw->dillo_nav_ptr].url = g_strdup(url);
   bw->dillo_nav[bw->dillo_nav_ptr].title = NULL;
   bw->size_dillo_nav = bw->dillo_nav_ptr + 1;
   bw->dillo_nav_loading_ptr = bw->dillo_nav_ptr + 1;
   bw->last_waiting = TRUE;

   Nav_open_url(bw, url_copy);
   g_free(url_copy);
}

/* 
 * Wraps a_Nav_push to match 'DwPage->link' function type
 */
void a_Nav_vpush(void *vbw, const char *url)
{
   if (!vbw)
      return;
   a_Nav_push((BrowserWindow *) vbw, url);
}

/* 
 * Send the browser back to previous page
 */
void a_Nav_back(BrowserWindow *bw)
{
   a_Nav_cancel_last_waiting(bw);
   if (bw->dillo_nav_ptr <= 1)
      return;
   bw->dillo_nav_ptr--;
   bw->dillo_nav_loading_ptr = bw->dillo_nav_ptr;
   Nav_open_url(bw, bw->dillo_nav[bw->dillo_nav_ptr - 1].url);
}

/* 
 * Send the browser to next page in the history list
 */
void a_Nav_forw(BrowserWindow *bw)
{
   a_Nav_cancel_last_waiting(bw);
   if (bw->dillo_nav_ptr >= bw->size_dillo_nav)
      return;
   bw->dillo_nav_ptr++;
   bw->dillo_nav_loading_ptr = bw->dillo_nav_ptr;
   Nav_open_url(bw, bw->dillo_nav[bw->dillo_nav_ptr - 1].url);
}

/* 
 * Redirect the browser to DILLO_HOME!
 */
void a_Nav_home(BrowserWindow *bw)
{
   a_Nav_push(bw, prefs.home);
} 

/* 
 * Implement the RELOAD button functionality.
 * (We haven't defined it yet ;)
 */
void a_Nav_reload(BrowserWindow *bw)
{
   a_Nav_cancel_last_waiting(bw);
   if (bw->dillo_nav->url == NULL || bw->size_dillo_nav <= 0)
      return;
   a_Cache_remove_url(bw->dillo_nav[bw->dillo_nav_ptr - 1].url);
   /* todo: should remove url from dicache too, so images can be reloaded.
    * Anyway, it would be interesting to make it an option.  --Jcid */
   Nav_open_url(bw, bw->dillo_nav[bw->dillo_nav_ptr - 1].url);
}

/* End navigation stack. */

