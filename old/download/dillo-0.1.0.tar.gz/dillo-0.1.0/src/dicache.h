#ifndef __DILLODICACHE_H__
#define __DILLODICACHE_H__

#include "imgsink.h"

void a_Dicache_init (void);
void a_Dicache_request_url_img (DilloImgSink *imgsink, char *url,
                           BrowserWindow *bw); 
DilloWeb* a_Dicache_new_img_decoder(DilloImgSink *imgsink, const char *URL);
void a_Dicache_freeall(void);

#endif /* __DILLODICACHE_H__ */
