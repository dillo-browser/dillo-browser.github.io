/*
 * File: dw_rect.c
 *
 * Copyright (C) 1997 Raph Levien <raph@acm.org>
 * Copyright (C) 1999 Luca Rota <drake@freemail.it>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

/*
 * Simple primitives for manipulating rectangles.
 * This code is adapted from xink.
 */

#include <gtk/gtk.h>

#include "dw_rect.h"

/* Make a copy of the rectangle. */
void Dw_rect_copy(DwRect * dest, const DwRect * src)
{
   dest->x0 = src->x0;
   dest->y0 = src->y0;
   dest->x1 = src->x1;
   dest->y1 = src->y1;
}

/*
 * Find the smallest rectangle that includes both source rectangles.
 */
void Dw_rect_union(DwRect * dest, const DwRect * src1, const DwRect * src2)
{
   if (a_Dw_rect_empty(src1)) {
      Dw_rect_copy(dest, src2);
   } else if (a_Dw_rect_empty(src2)) {
      Dw_rect_copy(dest, src1);
   } else {
      dest->x0 = MIN(src1->x0, src2->x0);
      dest->y0 = MIN(src1->y0, src2->y0);
      dest->x1 = MAX(src1->x1, src2->x1);
      dest->y1 = MAX(src1->y1, src2->y1);
   }
}

/*
 * Return the intersection of the two rectangles
 */
void a_Dw_rect_intersect(DwRect * dest, const DwRect * src1, const DwRect * src2)
{
   dest->x0 = MAX(src1->x0, src2->x0);
   dest->y0 = MAX(src1->y0, src2->y0);
   dest->x1 = MIN(src1->x1, src2->x1);
   dest->y1 = MIN(src1->y1, src2->y1);
}

/*
 * Return true if the rectangle is empty.
 */
gboolean a_Dw_rect_empty(const DwRect * src)
{
   return (src->x1 <= src->x0 || src->y1 <= src->y0);
}

/* -RL :: NOT used !?! */
gboolean Dw_rect_point_inside(DwRect * rect, DwPoint * point)
{
   return (point->x >= rect->x0 && point->y >= rect->y0 &&
           point->x < rect->x1 && point->y < rect->y1);
}
