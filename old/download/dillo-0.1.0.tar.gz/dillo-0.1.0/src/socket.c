/*
 * File: socket.c
 *
 * Copyright (C) 1997 Raph Levien <raph@acm.org>
 * Copyright (C) 1999 Sammy Mannaert <nstalkie@tvd.be>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

/*
 * This module provides an API for asynchronously opening a client
 * socket using the GTK framework.
 */


#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <stdio.h>

#include <netdb.h>              /* for gethostbyname, etc. */
#include <sys/socket.h>         /* for lots of socket stuff */
#include <netinet/in.h>         /* for ntohl and stuff */

#include "dns.h"

static void Socket_input_handler(gpointer data,
                                 gint source,
                                 GdkInputCondition condition);

typedef struct _DilloSocket {
   int dns_tag;
   int input_tag;
   int port;
   struct sockaddr_in sin;
   int fd;
   void (*callback) (int Op, int fd, void *callback_data);
   void *callback_data;
} DilloSocket;

/*
 * Static data
 */


static GList *Active_sockets,    /* Active sockets list */
             *Inactive_sockets;  /* Inactive&available sockets */


/*
 * Initialize the socket data structures. 
 */
void a_Socket_init(void)
{
  Active_sockets   = NULL,  /* Active sockets list */
  Inactive_sockets = NULL;  /* Inactive&available sockets */
}

/*
 * Try connecting the socket. On success or error, delete the socket
 * structure, remove the input tag (if any), and call the callback. 
 */
static void Socket_try_connect(DilloSocket * SPtr)
{
   int status;
   int fd = SPtr->fd;
   void (*callback) (int Op, int _fd, void *callback_data) = SPtr->callback;
   void *callback_data = SPtr->callback_data;

   /* Note: handling of the EISCONN error condition was added by
    * Tristan Tarrant on 28 Nov 1997. This apparently fixes some
    * problems on Solaris 2.5. */

   /* What's still totally unclear to me is why there would be an
    * EISCONN error return. Is it possible that this routine is
    * getting called to many times? */

   status = connect(fd, (struct sockaddr *) &(SPtr->sin), sizeof(struct sockaddr_in));

   
   if (status < 0 && errno == EISCONN)
      /* socket already connected! :) */
      status = 0;
   
   if (status < 0 && !(errno == EINPROGRESS ||
                              errno == EAGAIN ||
                              errno == EINTR)) {
      /* An unhandled error */
      SPtr->callback_data = NULL;
      callback(1, fd, callback_data);
      close(fd);
      Active_sockets = g_list_remove(Active_sockets, (gpointer) SPtr);
      Inactive_sockets = g_list_append(Inactive_sockets, (gpointer) SPtr);
      fd = -1;

   } else if (status == 0) {
      /* connection succeeded */
      if (SPtr->input_tag)
         gdk_input_remove(SPtr->input_tag);
      
      Active_sockets = g_list_remove(Active_sockets, (gpointer) SPtr);
      SPtr->callback_data = NULL;
      Inactive_sockets = g_list_append(Inactive_sockets, (gpointer) SPtr);

      /* Note: do the callback after changes to socket structure are
       * complete, just in case callback wants to allocate any new
       * sockets or abort any old ones. */
      callback(0, fd, callback_data);
   } else {
      if (SPtr->input_tag == 0)
         SPtr->input_tag =
             gdk_input_add(fd,
                           GDK_INPUT_WRITE,
                           (GdkInputFunction) Socket_input_handler,
                           (void *) SPtr);
   }

/* Testing stuff */
   { GList *Lp;
       printf("ASckts>");
       for ( Lp = Active_sockets; Lp ; Lp = Lp->next)
          g_print("*");
       g_print("<\n");
   }
}


/*
 * The input handler. Try to connect the socket. 
 */
static void Socket_input_handler(gpointer data,
                                 gint source,
                                 GdkInputCondition condition)
{
   Socket_try_connect((DilloSocket *) data);
}

/* 
 * Create the socket. Try connecting it if in
 * DNS_WAIT state. If it's not in DNS_WAIT state, then it's in INIT
 * state and the try_connect call will happen in a_Socket_new. 
 */
static void Socket_dns_callback(int Op, guint32 ip_addr, void *callback_data)
{
   DilloSocket *SPtr = (DilloSocket *) callback_data;

   // g_print("Socket_dns_callback: IP = %x\n", ip_addr);
            
   if (Op) {
      /* DNS failed.. */
      void (*callback) (int _Op, int fd, void *callbackdata) = SPtr->callback;

      callback(Op, SPtr->fd, SPtr->callback_data);
      SPtr->callback_data = NULL;
      close(SPtr->fd);
      
      Active_sockets = g_list_remove(Active_sockets, (gpointer) SPtr);
      SPtr->callback_data = NULL;
      
      Inactive_sockets = g_list_append(Inactive_sockets, (gpointer) SPtr);

      return;
   }

   /* Found the socket structure. */
   SPtr->sin.sin_addr.s_addr = htonl(ip_addr);

   Socket_try_connect(SPtr);
}


/*
 * Create a new connection to (hostname, port). 
 * After socket creation,
 * call the callback with the file descriptor of the socket.
 * The callback may be called inside the call to this function, or later
 * from a GTK input handler.
 * If the socket creation fails, the callback is called with 'fd' set to -1,
 * and 'op' set to 1.
 */
int a_Socket_new(const char *hostname,
                 gint port,
                 void (*callback) (int op, int fd, void *callback_data),
                 void *callback_data)
{
   DilloSocket *SPtr = NULL;

   if ( !Inactive_sockets ) {
      SPtr = g_new(DilloSocket, 1);
   } else {
      /* We have inactive sockets */
      SPtr = (DilloSocket *) Inactive_sockets->data;
      Inactive_sockets = g_list_remove(Inactive_sockets, (gpointer) SPtr);
   }

   SPtr->input_tag = 0;
   SPtr->port = port;
   SPtr->callback = callback;
   SPtr->callback_data = callback_data;
   SPtr->fd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
   if (SPtr->fd < 0) {
      /* Failed.. clean up */
      SPtr->callback_data = NULL;
      Inactive_sockets = g_list_append(Inactive_sockets, (gpointer) SPtr);
      callback(1, -1, callback_data);
      return -1;
   }
   /* set up sin structure, in preparation for the connect call */
   SPtr->sin.sin_family = AF_INET;
   SPtr->sin.sin_port = htons(SPtr->port);

   /* set nonblocking */
   fcntl(SPtr->fd, F_SETFL, O_NONBLOCK | fcntl(SPtr->fd, F_GETFL));

   /* set close-on-exec */
   fcntl(SPtr->fd, F_SETFD, FD_CLOEXEC | fcntl(SPtr->fd, F_GETFD));

   
   Active_sockets = g_list_append(Active_sockets, (gpointer) SPtr);

   /* Note: dns lookup is done after socket structure is already set up,
    * in case callback is called immediately.
    * 
    * Also note: the integer tag is casted to a void * so that it can
    * pass through the dns callback mechanism. Allocating a new memory
    * structure to hold the tag would have been cleaner from a type
    * point of view, but less efficient.
    * 
    * Final note: the socket_try_connect call is deferred until after
    * the call to a_Dns_lookup, because (if successful), it might
    * deallocate the socket structure, and it wouldn't be good to have
    * that happen before the following assignment to it. 
    */

   SPtr->dns_tag = (int) a_Dns_lookup (hostname, Socket_dns_callback, 
                                       (void*) SPtr);
   return SPtr->fd;
}

#if 0
/*
 * Abort the connection. After an abort call, the callback associated
 * with the tag will not be called. Also frees resources used in
 * setting up the connection (aborting a pending dns request, closing
 * the socket, and removing an input handler, depending on the state
 * of the connection).
 */
void a_Socket_abort(int fd) 
{
   DilloSocket *SPtr = Socket_lookup(fd);
   if (!SPtr) {
      g_warning("trying to abort nonexistent socket tag!\n");
      return;
   }
   /* Found the socket structure. */ if (SPtr->state == DILLO_SOCKET_DNS_WAIT)
       dillo_dns_abort(SPtr->dns_tag);

   else
      close(SPtr->fd);

   SPtr->callback(1, -1, SPtr->callback_data);
   SPtr->callback_data = NULL;
   if (SPtr->input_tag)
      gdk_input_remove(SPtr->input_tag);
   
   Active_sockets = g_list_remove(Active_sockets, (gpointer) SPtr);
   
   Inactive_sockets = g_list_append(Inactive_sockets, (gpointer) SPtr);
}
#endif


/*
 * Deallocate memory used by 'Inactive_sockets' and 'Active_sockets' lists
 * (Call this one at exit time)
 */
void a_Socket_freeall(void)
{
DilloSocket *SPtr;

   while ( Inactive_sockets ) {
      SPtr = Inactive_sockets->data;
      Inactive_sockets = g_list_remove(Inactive_sockets, (gpointer) SPtr);
   }
   while ( Active_sockets ) {
      SPtr = Active_sockets->data;
      Active_sockets = g_list_remove(Active_sockets, (gpointer) SPtr);
   }
}
