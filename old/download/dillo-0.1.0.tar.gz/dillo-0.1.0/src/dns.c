/*
 * File: dns.c
 *
 * Copyright (C) 1999, 2000 Jorge Arellano Cid <jcid@inf.utfsm.cl>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

/*
 * Non blocking pthread-handled Dns scheme
 */

#include <pthread.h>
#include <glib.h>

#include <netdb.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <errno.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <signal.h>
#include <string.h>
#include <assert.h>

#include "dns.h"
#include "list.h"

#define VERBOSE 1 

#ifdef VERBOSE
#define  SAY(format, args...) g_print(format, ##args)
#else
#define  SAY(format, args...)
#endif


/*
 * Note: comment the following line for debugging or gprof profiling. 
 */
#define G_DNS_THREADED

/* 
 * Uncomment the following line for libc5 optimization 
 */
/* #define LC5 */


/* Maximum dns resolving threads */
#ifdef G_DNS_THREADED
#define G_DNS_MAX_SERVERS 3
#else
#define G_DNS_MAX_SERVERS 1
#endif


typedef struct {
   gboolean in_use;      /* boolean to tell if server is doing a lookup */
   gboolean ip_ready;    /* boolean: is IP lookup done? */
   guint32 ip_addr;      /* IP address _EXPERIMENTAL_ */
   char *hostname;       /* Adress to resolve (just a pointer)  */
} DnsServer;

typedef struct {
   char *hostname;          /* host name for cache */
   guint32 ip_addr;         /* address of host */
} GDnsCache;

typedef struct {
   gint tag;       /* Not used. Maybe when a_Dns_abort() behavior is defined */
   gint channel;   /* -2 if waiting, otherwise index to dns_server[] */
   char *hostname;
   void (*callback) (int Op, guint32 ip_addr, void *callback_data);
   void *callback_data;
} GDnsQueue;


/*
 * Forward declarations
 */
static gint Dns_idle_client(int channel);

/*
 * Local Data
 */
static DnsServer dns_server[G_DNS_MAX_SERVERS];
static int num_servers;
static GDnsCache *dns_cache;
static int dns_cache_size, dns_cache_size_max;
static GDnsQueue *dns_queue;
static gint dns_queue_size, dns_queue_size_max;


/* ----------------------------------------------------------------------
 *  Dns queue functions
 */
void Dns_queue_add(gint tag, gint channel, const char *hostname,
         void (*callback) (int Op, guint32 ip_addr, void *callback_data),
                   void *callback_data)
{
   a_List_add(dns_queue,dns_queue_size,sizeof(*dns_queue),dns_queue_size_max);
   dns_queue[dns_queue_size].tag = tag;
   dns_queue[dns_queue_size].channel = channel;
   dns_queue[dns_queue_size].hostname = g_strdup(hostname);
   dns_queue[dns_queue_size].callback = callback;
   dns_queue[dns_queue_size].callback_data = callback_data;
   dns_queue_size++;
}

/*
 * Find hostname index in dns_queue
 * (if found, returns queue index; -1 if not
 */
int Dns_queue_find(const char *hostname)
{
   int i;

   for (i = 0; i < dns_queue_size; i++)
      if (!strcmp(hostname, dns_queue[i].hostname))
         return i;

   return -1;
}

/*
 * Given an index, remove an entry from the dns_queue
 */
void Dns_queue_remove(int index)
{
   int i;

   if (index < dns_queue_size) {
      --dns_queue_size;         /* you'll find out why ;-) */
      g_free(dns_queue[index].hostname);
      for (i = index; i < dns_queue_size; i++)
         dns_queue[i] = dns_queue[i + 1];
   }
}


/*
 *  Add an IP/hostname pair to Dns-cache
 */
void Dns_cache_add(char *hostname, guint32 ip_addr)
{
/* sanity check
 * int i;
 * 
 * for (i = 0; i < dns_cache_size; i++)
 * if (!strcmp (hostname, dns_cache[i].hostname))
 * return;
 */

   a_List_add(dns_cache,dns_cache_size,sizeof(*dns_cache),dns_cache_size_max);
   dns_cache[dns_cache_size].hostname = g_strdup(hostname);
   dns_cache[dns_cache_size].ip_addr = ip_addr;
   ++dns_cache_size;
   SAY("Cache objects: %d\n", dns_cache_size);
}


/* 
 *  Initializer function
 */
void a_Dns_init(void)
{
   int i;

   SAY("dillo_dns_init: Here we go!\n");
   dns_queue_size = 0;
   dns_queue_size_max = 16;
   dns_queue = g_new(GDnsQueue, dns_queue_size_max);

   dns_cache_size = 0;
   dns_cache_size_max = 16;
   dns_cache = g_new(GDnsCache, dns_cache_size_max);

   num_servers = G_DNS_MAX_SERVERS;

   /* Set stuff to communicate with the servers (pipes and flags) */
   for (i = 0; i < num_servers; ++i) {
      dns_server[i].in_use = FALSE;
      dns_server[i].hostname = NULL;
   }
}

/*
 * Abort a previous call to a_Dns_lookup().
 * (Not defined yet)
 * Results:
 *   callback function is not called. (Is this OK?  --Jcid)
 */
void a_Dns_abort(guint32 tag)
{
   g_warning("a_Dns_abort: CALLED! (this function doesn't work)\n");
   return;
}


/*
 *  Server function (runs on it's own thread)
 */
void *Dns_server(void *data)
{
   struct hostent *host;
   guint32 ip_addr;
   int channel;
#ifdef LC5
   int h_err;
   char buff[1024];
   struct hostent sh;
#endif

/* sigset_t current_sigs; */

   pthread_sigmask(SIG_BLOCK, NULL, NULL);
/*
 * pthread_sigmask(SIG_BLOCK, NULL, &current_sigs);
 * pthread_sigmask(SIG_BLOCK, &current_sigs, NULL);
 */
   channel = (int) data;

   SAY("Dns_server: starting...\n channel: %d\n hostname = %s\n",
       channel, dns_server[channel].hostname);

#ifdef LC5
   host = gethostbyname_r(dns_server[channel].hostname, &sh, buff,
                          sizeof(buff), &h_err); 
#else
   host = gethostbyname(dns_server[channel].hostname);
#endif

   if (host == NULL) {
      ip_addr = 0;
   } else {
      memcpy(&ip_addr, host->h_addr_list[0], sizeof(ip_addr));
      ip_addr = ntohl(ip_addr);
   }

   /* write hostname to client */
   SAY("Dns_server: %s is %x\n",
       dns_server[channel].hostname, ip_addr);
   dns_server[channel].ip_addr = ip_addr;
   dns_server[channel].ip_ready = TRUE;

   return data;                 /* (avoids a compiler warning) */
}


/*
 *  Blocking server-function (Doesn't use threads)
 */
void Dns_blocking_server(void)
{
   struct hostent *host;
   guint32 ip_addr;
   int index;

   index = 0;
   SAY("Dns_blocking_server: starting...\n");
   SAY("Dns_blocking_server: dns_server[%d].hostname = %s\n",
       index, dns_server[index].hostname);

   host = gethostbyname(dns_server[index].hostname);
   if (host == NULL) {
      SAY("---> Dns_blocking_server: gethostbyname NULL return\n");
      ip_addr = 0;
   } else {
      SAY("---> Dns_blocking_server - good return\n");
      memcpy(&ip_addr, host->h_addr_list[0], sizeof(ip_addr));
      ip_addr = ntohl(ip_addr);
   }

   /* write IP to server data channel */
   SAY("Dns_blocking_server: IP of %s is %x\n",
       dns_server[index].hostname, ip_addr);
   dns_server[index].ip_addr = ip_addr;
   dns_server[index].ip_ready = TRUE;

   SAY("Dns_blocking_server: leaving...\n");
}


/*
 *  Request function (spawn a server and let it handle the request)
 */
void Dns_server_req(gint channel, const char *hostname)
{
#ifdef G_DNS_THREADED
   pthread_t th1;
#endif

   dns_server[channel].in_use = TRUE;
   dns_server[channel].ip_ready = FALSE;

   /* Lets set an idle client to read the solved IP */
   gtk_idle_add((GtkFunction)Dns_idle_client, (void *)channel);

   if (dns_server[channel].hostname != NULL)
      g_free(dns_server[channel].hostname);
   dns_server[channel].hostname = g_strdup(hostname);

   /* Spawn thread */
#ifdef G_DNS_THREADED
   pthread_create(&th1, NULL, Dns_server, (void *) channel);
#else
   Dns_blocking_server();
#endif
}


/*
 * looks up an address and returns a tag for use with
 * a_dns_abort(). [**** Tag is not defined yet ****]
 *
 * Arguments:
 *  char *hostname - hostname to lookup
 *  callback - function to call when dns lookup is complete.
 *  callback_data - data to pass to this function.
 *   
 * Results:
 *  callback function is called.
 *  returns -1. ( It's supposed to return a tag suitable for aborting,
 *  but that needs to be defined better before implementing it  --Jcid)
 * 
 * Side effects:
 *  a thread can be spawned later.
 */
guint32
a_Dns_lookup(const char *hostname,
         void (*callback) (int Op, guint32 ip_addr, void *callback_data),
             void *callback_data)
{
   int i;
   gint channel;

   /* check for cache hit. */
   for (i = 0; i < dns_cache_size; i++)
      if (!strcmp(hostname, dns_cache[i].hostname))
         break;

   /* if it hits already resolved, call the callback inmediately. */
   if (i < dns_cache_size) {
      callback(0, dns_cache[i].ip_addr, callback_data);
      return -1;                /* formerly 0 */
   }
   if ((i = Dns_queue_find(hostname)) != -1) {
      /* hit in queue, but answer hasn't come back yet. */
      Dns_queue_add(0, dns_queue[i].channel, hostname, callback, callback_data);
   } else {
      /* Never requested before -- we must solve it! */

      /* Find a channel we can send the request to */
      for (channel = 0; channel < num_servers; channel++)
         if (!dns_server[channel].in_use)
            break;
      if (channel < num_servers) {
         /* Found a free channel! */
         Dns_queue_add(0, channel, hostname, callback, callback_data);
         Dns_server_req(channel, hostname);
      } else {
         /* We'll have to wait for a thread to finish... */
         Dns_queue_add(0, -2, hostname, callback, callback_data);
      }
   }

   return -1;
}

/*
 * This is a Gtk+ idle function that
 * reads the DNS results and completes the stopped jobs.
 */
static gint Dns_idle_client(int channel)
{
   int i, j, k;
   DnsServer *srv = &dns_server[channel];
   
   if ( srv->ip_ready ){
      if (srv->ip_addr != 0) {
         /* DNS succeeded, let's cache it */
         Dns_cache_add(srv->hostname, srv->ip_addr);
      }
      /* Give answer to all queued callbacks on this channel */
      for (i = 0; i < dns_queue_size; i++) {
         if (dns_queue[i].channel == channel) {
            dns_queue[i].callback((srv->ip_addr ? 0 : 3), srv->ip_addr,
                                  dns_queue[i].callback_data);
            Dns_queue_remove(i);
            --i;
         }
      }
   
      /* Find the next query in the queue (we're a FIFO) */
      for (j = 0; j < dns_queue_size; j++)
         if (dns_queue[j].channel == -2)
            break;
      if (j < dns_queue_size) {    /* Found a pending request... */
         /* assign this channel to every queued request with the same hostname */
         for (k = j; k < dns_queue_size; k++)
            if (!strcmp(dns_queue[j].hostname, dns_queue[k].hostname))
               dns_queue[k].channel = channel;
         Dns_server_req(channel, dns_queue[j].hostname);
      } else {
         /* free current channel */
         dns_server[channel].in_use = FALSE;
      }
      /* Done! */
      return FALSE;
   }

   /* IP not already solved, keep on trying... */
   return TRUE;
}

/*
 *  Dns memory-deallocation
 *  (Call this one at exit time)
 *  The Dns_queue is deallocated at execution time (no need to do that here)
 *  'dns_cache' is the only one that grows dinamically
 */
void a_Dns_freeall(void)
{
int i;

   for ( i = 0; i < dns_cache_size; ++i ){
      g_free(dns_cache[i].hostname);
   }
   g_free(dns_cache);
}



