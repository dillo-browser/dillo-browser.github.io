/*
 * File: web.c
 *
 * Copyright (C) 1997 Raph Levien <raph@acm.org>
 * Copyright (C) 1999 Sammy Mannaert <nstalkie@tvd.be>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

#include <ctype.h> /* for tolower */
#include <stdio.h>
#include <stdlib.h>
#include <gtk/gtk.h>

#include "web.h"
#include "IO/IO.h"
#include "cache.h"
#include "html.h"
#include "interface.h"

#include "dw.h"
#include "dw_embedgtk.h"
#include "MIME/mime.h"
#include "dillo.h"
#include "nav.h"
#include "prefs.h"

/*
 * Extract a single field from the header, storing the value in field.
 * Return TRUE if field found. 
 * (This function expects a '\r' stripped header)
 */
static int
Web_parse_field (const char *header, char *field, size_t size_field,
                 const char *fieldname) {
   int i, j;
 
   for (i = 0; header[i] != '\0'; i++) {
      for (j = 0; fieldname[j] != '\0'; j++) {
        if (tolower (fieldname[j]) != tolower (header[i + j]))
           break;
      }
      if (fieldname[j] == '\0' && header[i + j] == ':') {
        i += j + 1;
        while (header[i] == ' ') i++;
        for (j = 0; j + 1 < size_field && header[i] != '\n'; j++)
           field[j] = header[i++];
        field[j] = '\0';
        return 1;
      } 
  
      /* skip to next field */
      while (header[i] != '\0' && header[i] != '\n') i++;
      if (header[i] == '\0') i--;
   }
   return 0;
}

/*
 * Given the MIME content type, and a fd to read it from,
 * this function connects the proper MIME viewer to it.
 */
Dw* a_Web_dispatch_by_type (DilloWeb *web, const char *Type,
                            __IOCallback_t *Call, void **Data)
{
   Dw* dw;

   if (!web) return NULL;

   dw = a_Mime_set_view(Type, web, Call, Data);
   
   if (web->url  && web->child_linkblock) {
      if (web->child_linkblock->base_url)
         g_free(web->child_linkblock->base_url);
      web->child_linkblock->base_url = g_strdup(web->url);
   }
   if ( !web->imgsink) {
      /* todo: move creation of dillo_image from dispatcher to here. */
      if (dw) {
         a_Interface_have_dw(web->bw, dw);
         /* -RL :: Set the background color for pages without a <BODY> tag */
         a_Dw_set_color(dw, prefs.bg_color);
         /* -RL :: Set the title bar for pages without a <TITLE> tag */
         a_Interface_set_Page_title(web->bw, "");
      }
   }
   if (web->Child_FD >= 0) {
       IO_set_fd_to_bkgnd(web->Child_FD);
       /* Link the data to a new memory segment in the cache */
       a_Cache_insert(web->Child_FD, web->Cache_FD, web->url, Type);
   }
   return dw;
}

/*
 * Parse the header for content-type, and create a new child based on
 * that info. This is the main MIME dispatcher.
 */
static void Web_dispatch (DilloWeb *web, __CacheFile_t *CPtr)
{
   char content_buf[256];

   /* g_print("Header: %s", web->header); */

   _FD2Ptr(CPtr->FD).Call = NULL;
   if (web->header[9] == '3' && web->header[10] == '0') {
     /* redirect */
     char url[1024];

     if (Web_parse_field (web->header, url, sizeof(url), "Location")) {
        /* First, add the redirect into our cache */
        a_Cache_redirect_url(web->url, url);
        /* Now redirect the browser. */
        a_Nav_push(web->bw, url);
     }
     a_Web_free(web);
     /* Close current connection */
     _FD2Ptr(CPtr->FD).Data = NULL;
     _FD2Ptr(CPtr->FD).Call = NULL;
     close(CPtr->FD);

     return;
   }
 
   /* Overwrite the header portion of the cache */
   memmove((char*)CPtr->Data, ((char*)CPtr->Data)+web->Start_Ofs,
           CPtr->Size-web->Start_Ofs);
 
   /* Update the cache's data segment size */
   CPtr->Size -= web->Start_Ofs;
 
   /* Stick it in the cache look up table*/
   CPtr->URL= g_strdup(web->url);
   a_Cache_add(CPtr);
 
   web->child_linkblock = NULL;
   if (Web_parse_field (web->header, content_buf, sizeof(content_buf),
                        "Content-Length")) {
      /* If there's a full size buffer, we'll just allocate the stuff once */
      long Size = atol(content_buf);
      void *Data;
      if (Size > 0 && (Data=g_realloc((void*)CPtr->Data,Size))) {
         CPtr->Data = Data;
         /* Fill out required data */
         CPtr->Total_Size = Size;
         CPtr->Block_Size = Size;
      }
   }
 
   _FD2Ptr(CPtr->FD).Data=NULL;
   _FD2Ptr(CPtr->FD).Call=NULL;
   if (Web_parse_field (web->header, content_buf, sizeof(content_buf),
       "Content-Type")) {
      a_Web_dispatch_by_type(web, content_buf,&_FD2Ptr(CPtr->FD).Call,
                             &_FD2Ptr(CPtr->FD).Data);
      /* Since we have data, do the first "update" notice. */
      if (_FD2Ptr(CPtr->FD).Call && _FD2Ptr(CPtr->FD).Call != a_Web_callback)
         _FD2Ptr(CPtr->FD).Call(0,_FD2Ptr(CPtr->FD).Data,CPtr);
      if (web->Child_FD < 0) {
         /* The cache thing is no longer autofree: we have the header! */
         CPtr->Flags &= ~GZ_AUTOFREE;
         CPtr->Type = g_strdup(content_buf);
      }
   }
   a_Web_free(web);
}

/*
 * Deallocate a DilloWeb structure
 */
void a_Web_free(DilloWeb *web)
{
   if (!web) return;
   if (web->url)
      g_free(web->url);
   if (web->header) 
      g_free(web->header);
   g_free(web);
}

/*
 * Consume bytes until the HTTP header is completely retrieved.
 * This function also strips '\r' chars from the header string.
 * (HTTP header ends in a blank line; usually a "\r\n\r\n" sequence)
 */
void a_Web_callback (int Op, void *P, __CacheFile_t *CPtr)
{
   int i;
   DilloWeb *web = (DilloWeb*)P;
   int N = web->state;
   char *C = CPtr ? ((char*)CPtr->Data + web->Start_Ofs) : NULL;
   int num = CPtr ? (CPtr->Size - web->Start_Ofs) : 0;
 
   if (Op) {
      a_Web_free(web);
      return;
   }
  
   for (i = 0; i < num && N < 2; i++,C++) {
      if (web->size_header + 2 > web->size_header_max) {
         web->size_header_max <<= 1;
         web->header = g_realloc (web->header, web->size_header_max);
      }
      /* invariant: there is room for at least two more characters */
      if (*C) web->Start_Ofs++;
      if (*C=='\r' || !*C) continue;
      if (*C=='\n') N++; else N=0;
      web->header[web->size_header++] = *C;
      if (N == 2) web->header[web->size_header] = '\0';
   }
   web->state = N;
   if (N >= 2) {
      /* Got header! Parse content-type and create a new child. */
      Web_dispatch (web, CPtr);
   }
}

/*
 * Allocate and set safe values for a DilloWeb structure
 */
DilloWeb* a_Web_new (const char* url)
{
   DilloWeb *web= g_new(DilloWeb, 1);
 
   web->imgsink=NULL;
   web->dw = NULL;
 
   web->bw=NULL;
   web->child_linkblock=NULL;
   web->Child_FD=-1;
   web->Cache_FD=-1;
 
   web->Start_Ofs=0;
   web->size_header_max = 1024;
   web->size_header = 0;
   web->header = g_malloc(web->size_header_max);
 
   web->state = 0;
 
   web->url = g_strdup(url);
 
   return web;
}
