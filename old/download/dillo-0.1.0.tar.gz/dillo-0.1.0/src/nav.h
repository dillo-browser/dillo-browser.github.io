#ifndef __DILLO_NAV_H__
#define __DILLO_NAV_H__


#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/* always include dillonav.c before this file. */

void a_Nav_push(BrowserWindow *bw, const char*);
void a_Nav_vpush(void *vbw, const char *url);
void a_Nav_back(BrowserWindow *bw);
void a_Nav_forw(BrowserWindow *bw);
void a_Nav_home(BrowserWindow *bw);
void a_Nav_reload(BrowserWindow *bw);
void a_Nav_init(BrowserWindow *bw);
void a_Nav_cancel_last_waiting (BrowserWindow *bw);


#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __DILLO_NAV_H__ */

                                        
