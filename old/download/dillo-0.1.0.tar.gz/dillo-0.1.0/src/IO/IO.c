/*
 * Dillo's IO Queue Processor
 * Randall Maas 1999
 *
 * Rearranged, changed & integrated by Jcid.
 */

#include <stdio.h>
#include <sys/wait.h>
#include <signal.h>
#include <search.h>
#include <errno.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/time.h>
#include <fcntl.h>
#include "IOQ.h"
#include "IO.h"
#include "../dillo.h"
#include "../cache.h"


/*
 * IO module data
 */
__Dillo_FD_t _FD2Data[NUM_FDS] = { {NULL} };
fd_set Gz_FDs;


/*
 * Forward declarations
 */
static void IO_complete(int FD, __Dillo_IO_t *IPtr);
static int IO_Clean(int FD, __Dillo_IO_t *IPtr);


/*
 * ?
 */
static void BS_Input(gpointer Data, gint FD, GdkInputCondition Why)
{
   __Dillo_IO_t *IPtr = (__Dillo_IO_t *) Data;

   if (Why == GDK_INPUT_WRITE) {
      IPtr->IO.Status = IO_do(FD, &IPtr->IO);
      if (IPtr->IO.Status >= 1 && IPtr->IOVec.iov_len > IPtr->IO.Status) {
         IPtr->IOVec.iov_len -= IPtr->IO.Status;
         IPtr->IOVec.iov_base += IPtr->IO.Status;
      } else if (IPtr->IO.Status < 0 ||
                 IPtr->IOVec.iov_len >= IPtr->IO.Status) {
         /* Writes are single shot... */
         gdk_input_remove(_FD2Ptr(FD).Param[1]);
         _FD2Ptr(FD).Flags &= ~GZ_INPUTWRITE;
      }
      return;
   }
   if (_FD2Ptr(FD).Flags & GZ_INPUTWRITE)
      return;
   IPtr->IO.Status = IO_do(FD, &IPtr->IO);
   IO_Clean(FD, IPtr);
}

/*
 * Remove gdk_input-watch-functions for a given FD, and close the FD
 */
void a_IO_abort(int FD)
{
   if (FD < 0)
      return;
   if ((_FD2Ptr(FD).Flags & GZ_INPUTWRITE))
      gdk_input_remove(_FD2Ptr(FD).Param[1]);
   if ((_FD2Ptr(FD).Flags & GZ_INPUTREAD))
      gdk_input_remove(_FD2Ptr(FD).Param[0]);
   _FD2Ptr(FD).Flags &= ~GZ_INPUTADDED;
   close(FD);
}

/*
 * ?
 */
void a_IO_init(void)
{
   FD_ZERO(&Gz_FDs);
}

/*
 * ?
 */
void a_IO_submit(int FD, int Op, void *Data, size_t Size)
{
   __Dillo_IO_t *IPtr = &_FD2Ptr(FD).IO[Op];
   int Mask = Op ? GZ_INPUTWRITE : GZ_INPUTREAD;

   IPtr->IO.Count = 1;
   IPtr->IO.IOReq = &IPtr->IOVec;
   IPtr->IO.Op = Op;            /* stupid */
   IPtr->Cache_FD = -1;         /* There is no file to write the data to */
   IPtr->IOVec.iov_base = Data;
   IPtr->IOVec.iov_len = Size;
   FD_SET(FD, &Gz_FDs);

   if (!(_FD2Ptr(FD).Flags & Mask)) {
      _FD2Ptr(FD).Param[IPtr->IO.Op] = gdk_input_add(FD,
         IPtr->IO.Op ? GDK_INPUT_WRITE : GDK_INPUT_READ, BS_Input, IPtr);
      _FD2Ptr(FD).Flags |= Mask;
   }
}

/*
 * This creates the next read on the IO channel into our cache memory
 * buffers.
 * 
 * Return Value
 * 0 == Ok, otherwise badness
 */
static int IO_NextRead(int FD, __Dillo_IO_t *IPtr, __CacheFile_t *DPtr)
{
   size_t Transfer_Size;        /* BUG: use fd block size */

   Transfer_Size = DPtr->Block_Size;
   if (!DPtr->Total_Size) {
      void *NewData;

      /* Allocate more memory chunks */
      if (!(NewData = g_realloc((void *) DPtr->Data, DPtr->Size + Transfer_Size))) {
         /* Bad things have happened... we didn't get any more space */
         return -1;
      }
      /* Update our pointer to the memory... */
      DPtr->Data = NewData;
   } else {
      /* Check to see if we are done... */
      if (DPtr->Size >= DPtr->Total_Size)
         return -1;

      /* Figure out how to top the cache memory buffer off */
      if (DPtr->Block_Size + DPtr->Size > DPtr->Total_Size)
         Transfer_Size = DPtr->Total_Size - DPtr->Size;
   }

   /* Indicate where our next read is going to in memory... */
   IPtr->IOVec.iov_base = ((char *) DPtr->Data) + DPtr->Size;
   IPtr->IOVec.iov_len = Transfer_Size;

   return 0;
}

/*
 * This routine handles a successfully completed read.
 */
static void IO_complete(int FD, __Dillo_IO_t *IPtr)
{
   __CacheFile_t *DPtr = FD2Cache(FD);
   void *Data = _FD2Ptr(FD).Data;
   int FreeMe = 0;

   /* First update our cache memory stuff */
   /* Update the size of valid memory that we have */
   DPtr->Size += IPtr->IO.Status;

   /* Next update our client */
   if (_FD2Ptr(FD).Call)
      _FD2Ptr(FD).Call(0, Data, DPtr);

   /* Third, create a new read */
   if (!IPtr->IO.Op)
      if (IO_NextRead(FD, IPtr, DPtr)) {
         /* Okay, something bad has happened, or we should otherwise close
          * this puppy */
         shutdown(FD, 2);
         if (_FD2Ptr(FD).Call)
            _FD2Ptr(FD).Call(1, _FD2Ptr(FD).Data, DPtr);
         a_IO_abort(FD);
         _FD2Ptr(FD).Param[0] = 0;
         _FD2Ptr(FD).Param[1] = 0;
         _FD2Ptr(FD).Flags = 0;
         _FD2Ptr(FD).Call = NULL;
         FreeMe = 1;
      }
   /* Is this also supposed to go to the cache? */
   if (IPtr->Cache_FD < 0) {
      /* Queue up some more stuff read .... */
      if (FreeMe && (DPtr->Flags & GZ_AUTOFREE)) {
         CacheFree = g_list_append(CacheFree, (gpointer) DPtr);
         g_free((void *) DPtr->Data);
         DPtr->Data = NULL;
      }
      return;
   }
   /* It /is/ also supposed to go to the cache... */
   /* Now queue this IO up for more fun... */
   a_IO_submit(IPtr->Cache_FD, 1, IPtr->IOVec.iov_base, IPtr->IOVec.iov_len);
}

/*
 * ?
 */
static int IO_Clean(int FD, __Dillo_IO_t *IPtr)
{
   __IOCallback_t Call = _FD2Ptr(FD).Call;
   void *Data = _FD2Ptr(FD).Data;

   /* See if the thing is a dead one, and needs to be closed */
   if (IPtr->IO.Status < 1) {
      /* Pass the notification on if this isn't an IO for writing to
       * the cache and there isn't another FD to chain to... */
      __CacheFile_t *FPtr = FD2Cache(FD);

      if (!IPtr->IO.Op) {
         if (Call)
            Call(1, Data, FPtr);
         _FD2Ptr(FD).Call = NULL;
         /* Close the cache channel too */
         if (IPtr->Cache_FD) {
            a_IO_abort(IPtr->Cache_FD);
            FD_CLR(FD, &Gz_FDs);
         }
         if (FPtr->Flags & GZ_AUTOFREE) {
            CacheFree = g_list_append(CacheFree, (gpointer) FPtr);
            g_free((void *) FPtr->Data);
         }
      }
      FD_CLR(FD, &Gz_FDs);
      shutdown(FD, 2);
      a_IO_abort(FD);
      _FD2Ptr(FD).Data = NULL;
      _FD2Ptr(FD).Call = NULL;
      return 0;
   }
   /* Complete the IO. 
    * Check to see if it is a completion of a write to cache
    * (we do it here -- instead of in IO_complete) to speed processing..
    */
   if (IPtr->IO.Op)
      return 0;
   if (IPtr->IO.Status == 0)
      return 0;

   IO_complete(FD, IPtr);
   return 1;
}



/*
 *  Reads code 
 */

/* See if GNU goodness is defined, if not, we won't bother.  Our routine
 * below will do the same thing, just not as quickly */
#ifndef TEMP_FAILURE_RETRY
#define TEMP_FAILURE_RETRY(x) x
#endif

/*
 * Set file descriptor to be nonblocking and generate interrupts 
 */
void IO_set_fd_to_bkgnd(int FD)
{
   fcntl(FD, F_SETFL, O_NONBLOCK | fcntl(FD, F_GETFL));
}

/*
 * @node Submitting IO, IO
 * @subheading Submitting background IO
 * When you have a some IO to do, and would like it to occur in the background,
 * you will need to fill out a IO request structure '__IO_req_t'):
 * 
 * @example
 * __IO_req_t Req;
 * struct iovec IOs[2];
 * char BufA[256],BufB[512];
 * 
 * Req.Op = 0;  -- A read operation.  1 would be a write operation
 * Req.FD = fd; -- The file descriptor to read from 
 * Req.Count=2; -- We will read into two buffers: A and B 
 * Req.IOReq=IOs;
 * IOs[0].iov_base=(__ptr_t)BufA  -- Read 256 bytes into buffer A
 * IOs[0].iov_len = sizeof(BufA);
 * IOs[1].iov_base=(__ptr_t)BufB; -- Then read 512 bytes into buffer B 
 * IOs[1].iov_len = sizeof(BufB);
 * 
 * @end example
 * 
 * @emph{Note 1:} The IO request structure is retained in the queue until it is
 * completed.
 * 
 * @subheading Handling completed IO
 * Any IO request that is placed into the completion queue or the failed queue
 * is done.  It is up to your program to manage those resources as
 * appropriate.
 * 
 * The @var{Status} field of each element is used to indicate:
 * @table @asis
 * @item > 0
 * The number of bytes read
 * 
 * @item == 0
 * No data was read, the file descriptor has no more data (EOF).  It should
 * be closed.
 * 
 * @item < 0
 * Significant error.  The value of @var{Status} the negative of the
 * @var{errno}.
 * @end table
 * 
 * @node SIGIO, IO
 * @subheading Setting up to recieve notification.
 * 
 * If you would like to pause your program while waiting for any IO, use the
 * @code{pause} system call.  Your program will continue after a signal has
 * been received.
 */

/*
 * The @var{Status} field of each element is used to indicate:
 * @table @asis
 * @item > 0
 * The number of bytes read
 * 
 * @item == 0
 * No data was read, the file descriptor has no more data (EOF).  It should
 * be closed.
 * 
 * @item < 0
 * Significant error.  The value of @var{Status} the negative of the
 * @var{errno}.
 * @end table
 * 
 * @subheading Non-blocking IO
 * 
 * Files that are opened should be use the @code{O_NONBLOCK} or
 * @code{O_NDELAY} flags to allow execution to continue even if there is no
 * data avaible (or can be sent).
 * 
 * For file descriptors and IO streams that are already open, these can be
 * set via a call like @code{fcntl(fd, F_SETFL, O_NONBLOCK);}
 * 
 */

ssize_t IO_do(int FD, __IO_req_t *IPtr)
{
   ssize_t Status;

   if (!IPtr->Op) {             /* Read */
      /* We use a macro to handle interrupted stuff, and retry the IO */
      Status = TEMP_FAILURE_RETRY(readv(FD, IPtr->IOReq, IPtr->Count));
   } else {
      /* Operation is Write */
      /* We use a macro to handle interrupted stuff, and retry the IO */
      Status = TEMP_FAILURE_RETRY(writev(FD, IPtr->IOReq, IPtr->Count));
   }

   if (Status >= 0)
      return Status;
   /* Handle errors! */
   switch (errno) {
   case EINTR:          /* Interrupt came in, and not handled above...?! */
#if defined(EWOULDBLOCK) && EWOULDBLOCK != EAGAIN
   case EWOULDBLOCK:
#endif
#ifdef EAGAIN
   case EAGAIN:
#endif
      return 0;

   case EIO:            /* Hardware error */
   case EBADF:          /* Bogus file descriptor */
   case EFBIG:          /* Write takes up way too much space on disk */
   case ENOSPC:         /* Disk is full */
   case EPIPE:          /* Pipe is not open on other end! */
   case EFAULT:         /* Something points to bogus memory */
   case EINVAL:         /* An invalid argument */
   case EISDIR:         /* FD refers to a directory */
   case EOPNOTSUPP:     /* FD doesn't support operation */

   default:             /* Not supposed to happen! */
      return -errno;
   }
}
