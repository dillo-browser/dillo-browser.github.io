/*
    IO Request Structures
    Randall Maas
    1999
*/

#ifndef __IOReq_h
# define __IOReq_h
# include "../../config.h"
# include <search.h>
# if defined (HAVE_FCNTL_H) && HAVE_FCNTL_H
#  include <fcntl.h>
# endif
# if defined(HAVE_UNISTD_H) && HAVE_UNISTD_H
#  include <unistd.h>
# endif
# if defined(HAVE_SYS_UIO_H) && HAVE_SYS_UIO_H
#   include <sys/uio.h>
# else
struct iovec {void* iov_base; size_t iov_len;};
static inline ssize_t readv(int fd, const struct iovec* V, int count)
{
   ssize_t Size=0;
   for (; count;count--,V++)
    {
       ssize_t S= read(fd,V->iov_base,V->iov_len);
       if (S <= 0) break;
       Size+=S;
    }
   return Size;
}
static inline ssize_t writev(int fd, const struct iovec* V, int count)
{
   ssize_t Size=0;
   for (; count;count--,V++)
    {
       ssize_t S= write(fd,V->iov_base,V->iov_len);
       if (S <= 0) break;
       Size+=S;
    }
   return Size;
}
# endif

typedef struct __IO_req_t
{
   int Op; /*Read(0)/Write(1) */
   ssize_t Status;
   size_t Count;
   struct iovec* IOReq;
} __IO_req_t;

extern ssize_t IO_do(int FD, __IO_req_t* IPtr);
extern void IO_set_fd_to_bkgnd(int FD);

#endif
