#ifndef __GzIO_h
#define __GzIO_h

#include <unistd.h>
#include <sys/time.h>
#include "IOQ.h"
#include "../cache.h"

#define NUM_FDS (8*sizeof(fd_set))

# define GZ_INPUTREAD  (1)
# define GZ_INPUTWRITE (2)
# define GZ_INPUTADDED (GZ_INPUTREAD | GZ_INPUTWRITE)

typedef struct
{
   __IO_req_t IO;
   struct iovec IOVec;
   int Cache_FD;
} __Dillo_IO_t;

/* You may want to change this to separate tables in the future if lots of
   descriptors get used.... You will only need to change the macros...*/
typedef struct
{
   __IOCallback_t Call;
   void* Data;
   __CacheFile_t*  Cache;
   unsigned Flags;
   int Param[2]; /* Generic parameters... */
   __Dillo_IO_t IO[2];
} __Dillo_FD_t;

extern __Dillo_FD_t _FD2Data[NUM_FDS];
#define _FD2Ptr(x)     _FD2Data[x]
#define FD2Cache(x)    _FD2Data[x].Cache

void a_IO_init(void);
void a_IO_submit(int FD, int Op, void* Data, size_t Size);
void a_IO_abort(int FD);
#endif
