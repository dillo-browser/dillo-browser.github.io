/*
 * Fast list methods
 * Feb 2000  --Jcid
 *
 * For now we just have a_List_add, but maybe in the future we can add
 * a_List_remove.
 */


/*
 * a_List_add()
 *
 * Make sure there's space for another item within the list
 * (First, allocate an 'alloc_step' sized chunk, after that, double the
 *  request size --to make it faster)
 */
#define a_List_add(list,num_items,item_size,alloc_step) \
   if ( !list ) { \
      list = g_malloc(alloc_step * item_size); \
      num_items = 0; \
   } \
   if ( num_items == alloc_step ){ \
      alloc_step <<= 1; \
      list = g_realloc(list, alloc_step * item_size); \
   }

