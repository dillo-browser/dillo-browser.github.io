/*
 * File: cache.c
 *
 * Copyright 1997 Raph Levien <raph@acm.org>
 * Copyright 1999 Jorge Arellano Cid <jcid@inf.utfsm.cl>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

/*
 * Rearranged, changed, integrated, extended and commented by Jcid 
 */

#include <ctype.h>              /* for tolower */
#include <sys/types.h>
#include <sys/stat.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <netinet/in.h>         /* needed before including socket.h */

#include <search.h>
#include "IO/IO.h"
#include "config.h"
#include "URL/url.h"
#include "cache.h" 
#include "socket.h"
#include "web.h"

#define CACHE_MAX 2000000


/*
 *  Local data
 */

/* invariant: cache_size_total is the sum of the buf_size fields of
              all cache lines in cache. */
static size_t cache_size_total = 0;
static int cache_counter;

GList *CacheFree   = NULL,
      *CacheActive = NULL;



/*
 * Attach an already open file to a write-behind file descriptor.
 * All of the pending IOs for the 'FD' IO channel will be marked to
 * write-behind to the 'Cache_FD' IO channel.
 */
void Cache_attach_fd(int FD, int Cache_FD)
{
   _FD2Ptr(FD).IO[0].Cache_FD = Cache_FD;
}

/*
 *  Create a new entry in the URL cache
 */
__CacheFile_t *Cache_new_entry(const char *URL)
{
   __CacheFile_t *CPtr;

   if ( CacheFree ) {
      CPtr = CacheFree->data;
      CacheFree = g_list_remove(CacheFree, (gpointer) CPtr);
   } else {
      CPtr = g_malloc(sizeof(*CPtr));
   }

   /* Insert it into the cache if it is defined */
   CPtr->URL = URL ? g_strdup(URL) : NULL;
   CPtr->Data = 0;
   
   CacheActive = g_list_append(CacheActive, (gpointer) CPtr);
   CPtr->Size = 0;
   CPtr->Total_Size = 0;
   CPtr->Block_Size = 512;
   CPtr->last_use = 0;
   CPtr->Flags = 0;
   CPtr->FD = -1;
   if (URL) {
      /* add cache structure into cache table */
      a_Cache_add(CPtr);
   }
   return CPtr;
}

/*
 * Insert the URL redirection into our cache
 */
void a_Cache_redirect_url(const char *Orig_URL, const char *To_URL)
{
   __CacheFile_t *CPtr = Cache_new_entry(Orig_URL);

   if (!CPtr)
      return;
   CPtr->Type = NULL;
   CPtr->Data = g_strdup(To_URL);
   CPtr->Flags |= GZ_REDIRECT;
}

/*
 *  Submit a temporary IO
 */
__CacheFile_t *a_Cache_tmp(int FD)
{
   __CacheFile_t *CPtr = Cache_new_entry(NULL);
   struct stat MyStat;

   /* Autotune: find out the prefferred transfer size */
   if (!fstat(FD, &MyStat))
      CPtr->Block_Size = MyStat.st_blksize;

   CPtr->Data = g_malloc(CPtr->Block_Size);
   CPtr->Flags |= GZ_AUTOFREE;
   CPtr->Type = NULL;
   CPtr->FD = FD;
   
   CacheActive = g_list_append(CacheActive, (gpointer) CPtr);
   FD2Cache(FD) = CPtr;

   a_IO_submit(FD, 0, (void *) CPtr->Data, CPtr->Block_Size);
   return CPtr;
}


/*
 * Add the cache'd file structure into the cache table
 */
int a_Cache_add(__CacheFile_t* File)
{
   return a_Hdlr_add(&GzCache_Items, &GzCache_NItems,&GzCache_NAlloc, 
                     File->URL, File);
}

/*
 * Get the data structure for a cached URL (using URL as the search key)
 * If URL isn't cached, return NULL
 */
static inline __CacheFile_t *Cache_fetch(const char *URL)
{
   return (__CacheFile_t *) a_Hdlr_fetch(GzCache_Items, GzCache_NItems, URL,
                                         strlen(URL));
}

/* 
 * Remove a line from the cache
 */
static void Cache_remove(__CacheFile_t *CPtr)
{
   CacheActive = g_list_remove(CacheActive, (gpointer) CPtr);
   if (CPtr->Type) {
      g_free((char *) CPtr->Type);
      CPtr->Type = NULL;
   }
   if (CPtr->Data) {
      g_free((void *) CPtr->Data);
      CPtr->Data = NULL;
   }
   CacheFree = g_list_append(CacheFree, (gpointer) CPtr);

   if (CPtr->Total_Size)
      cache_size_total -= CPtr->Total_Size;
   else
      cache_size_total -= CPtr->Size;
}

/* 
 * Pipe the cache line contents to the bytesink. The implementation is
 * to create a new cache connection, and start the cache idle process
 * if needed. 
 */
static void Cache_hit(__CacheFile_t *CPtr, void *Data)
{
   __IOCallback_t Call = NULL;
   void *DItsData = NULL;

   if (                         /*  (CPtr->Flags & GZ_AUTOFREE) ||  */
         !CPtr->Type) {
      /* BUG: the actual thing isn't in the cache; we should add this to a 
       * notification list to call when it is 
       * CI_t *P= g_malloc(sizeof(*P)); P->CPtr=CPtr;P->Data=Data;
       * gtk_idle_add((GtkFunction) Cache_idle, P);
       * abort();
       */
      return;
   }
   a_Web_dispatch_by_type(Data, CPtr->Type, &Call, &DItsData);

   /* Send out the type information of the cache item */
   if (Call) {
      Call(0, DItsData, CPtr);
      Call(1, DItsData, CPtr);
   }
   CPtr->last_use = cache_counter++;
}

/* 
 * Try finding the url in the cache. If it hits, pipe the cache contents
 * to the bytesink. If it misses, set up a new connection.
 */
int a_Cache_open_url(const char *url, void *Data)
{
   /* todo: maybe do some canonicalization of the url here? */
   __CacheFile_t *CPtr = Cache_fetch(url);

   if ( !CPtr ) {
      /* BUG: if the item hasn't been cached yet, we've got problems!
       * (Bad comment. What does 'problems' mean here?  --Jcid) */
      return a_Url_open(url, Data);
   } 

   if ( CPtr->Flags & GZ_REDIRECT ) {
      /* We have cached a redirect command.. open that instead */
      /**/ g_print("*");
      return a_Cache_open_url((char *) CPtr->Data, Data);
   }

   if ( !(CPtr->Flags & GZ_AUTOFREE)) 
      Cache_hit(CPtr, Data);
   return -1;
}

/*
 * Save the specified URL to the specifed IO channel (Cache_FD).
 * If the URL is already downloaded, all of the data is written to the IO
 * channel.
 * If the URL is partly downloaded, all of the available data is written to
 * the IO channel, and any future data is written as it arrives.
 * If the URL is not even started downloading yet, a connection is opened,
 * and all of the data will be written to the IO channel (as well as the
 * memory cache)
 * 
 * Return Value:
 * -1 on error, otherwise success.
 */
int a_Cache_url_copy(const char *url, int Cache_FD)
{
   __CacheFile_t *CPtr = Cache_fetch(url);

   /* Is it an already open file? */
   if (!CPtr) {
      /* No, We have to open the remote URL */
      DilloWeb *Web = a_Web_new(NULL);

      Web->Cache_FD = Cache_FD;
      return a_Url_open(url, Web);
   }
   if (!(CPtr->Flags & GZ_REDIRECT)) {
      /* We have already started caching this file... we need to catch up */
      a_IO_submit(Cache_FD, 1, (char *) CPtr->Data, CPtr->Size);

      /* Have the current open IO channel send any further stuff to the cache
       */
      if (CPtr->FD >= 0)
         Cache_attach_fd(CPtr->FD, Cache_FD);
      return 0;
   }
   /* Its a redirect... */
   return a_Cache_url_copy((char *) CPtr->Data, Cache_FD);
}

/*
 * BUG: Cache delete is bogus! 
 */
__CacheFile_t *Cache_delete(const char *A, size_t Size)
{
   return NULL;
}

/* todo: the case where the URL is open in a different window is not
 * handled well (I think we should abort the bytesink if the
 * cache line is not at eof). */
void a_Cache_remove_url(char *url)
{
   __CacheFile_t *File = Cache_delete(url, strlen(url));

   if (File)
      Cache_remove(File);
}

/*
 * Description
 * This inserts the URL into the cache, and initializes the IO transfer
 */
void a_Cache_insert(int FD, int Cache_FD, const char *url, const char *type)
{
   __CacheFile_t *CPtr = Cache_new_entry(url);
   struct stat MyStat;

   /* Autotune: find out the prefferred transfer size */
   if (!fstat(FD, &MyStat))
      CPtr->Block_Size = MyStat.st_blksize;

   CPtr->Data = g_malloc(CPtr->Block_Size);
   CPtr->Type = g_strdup(type);
   if (FD >= 0) {
      FD2Cache(FD) = CPtr;
      Cache_attach_fd(FD, Cache_FD);
   }
   a_IO_submit(FD, 0, (char *) CPtr->Data, CPtr->Block_Size);
}

/*
 * ?
 */
char *a_Cache_url_read(const char* url, int *size)
{
   __CacheFile_t *CPtr = Cache_fetch(url);

   if ( !(CPtr->Flags & GZ_REDIRECT) ){
        *size = CPtr->Size;
        return (char *)CPtr->Data;
   }
   return NULL;
}


/*
 * Deallocate memory used by 'CacheFree' and 'CacheActive' lists
 * (Call this one at exit time)
 */
void a_Cache_freeall(void)
{
   __CacheFile_t *CPtr;

   while ( CacheFree ) {
      CPtr = CacheFree->data;
      CacheFree = g_list_remove(CacheFree, (gpointer) CPtr);
/* This may cause some trouble  --Jcid
      if ( CPtr->URL ) 
         g_free((char *)CPtr->URL);
      if ( CPtr->Type )
         g_free((char *)CPtr->Type);
      if ( CPtr->Data )
         g_free((char *)CPtr->Data);
*/
   }
   while ( CacheActive ) {
      CPtr = CacheActive->data;
      CacheActive = g_list_remove(CacheActive, (gpointer) CPtr);
/* Enabling this, makes the browser hang at exit time  --Jcid
      if ( CPtr->URL ) 
         g_free((char *)CPtr->URL);
      if ( CPtr->Type )
         g_free((char *)CPtr->Type);
      if ( CPtr->Data )
         g_free(CPtr->Data);
*/
   }
}

