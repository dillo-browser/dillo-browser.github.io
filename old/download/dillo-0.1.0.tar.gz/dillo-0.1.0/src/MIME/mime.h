/*
    MIME type handlers
    Randall Maas
    1999
*/
#ifndef __MIME_h
#define __MIME_h
#include <gtk/gtk.h>
#include "../dw.h"
#include "../URL/Url.h"

typedef Dw* (*__View_t) (const char*,void*, __IOCallback_t* Call, void** Data);

/* 
   Function prototypes defined elsewhere 
*/
Dw* a_Html_text (const char* Type, void* web, __IOCallback_t* Call, void** Data);
Dw* a_Dw_plain(const char* Type, void* web,__IOCallback_t* Call, void** Data);
Dw* a_Jpeg_image(const char* Type,void* web, __IOCallback_t* Call, void**Data);
Dw* a_Gif_image (const char* Type,void* web, __IOCallback_t* Call, void**Data);
Dw* a_Png_image (const char* Type,void* web, __IOCallback_t* Call, void**Data);

/* 
   Functions defined inside Mime module
*/
void a_MIME_init(void);
Dw* a_Mime_set_view(const char* content_type, void* Ptr,__IOCallback_t* Call,
               void** Data);
int a_Mime_add_type(const char* Key, __View_t Method);
int a_Mime_add_mayor_type(const char* Key, __View_t Method);


#endif
