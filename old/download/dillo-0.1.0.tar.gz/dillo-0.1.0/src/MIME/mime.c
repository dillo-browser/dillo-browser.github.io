/*
 * MIME type mapper  Randall Maas 1999
 */

/*
 *  Heavily rearranged to a new structure by jcid, Dec 1999
 *  (added some comments also... :)
 */

#include "mime.h"

/*
 *  Local data
 */
void *MIME_type_Items, *MIME_mtype_Items;
int MIME_type_NItems, MIME_type_NAlloc, MIME_mtype_NItems, MIME_mtype_NAlloc;


/*
 * ?
 */
int a_Mime_add_type(const char *Key, __View_t Method)
{
   return a_Hdlr_add((void *) &MIME_type_Items, &MIME_type_NItems, &MIME_type_NAlloc,
                   Key, Method);
}

/*
 * ?
 */
__View_t MIME_type_fetch(const char *Key, size_t Size)
{
   return (__View_t) a_Hdlr_fetch(MIME_type_Items, MIME_type_NItems, Key, Size);
}

/*
 * ?
 */
int a_Mime_add_mayor_type(const char *Key, __View_t Method)
{
   return a_Hdlr_add((void **) &MIME_mtype_Items, &MIME_mtype_NItems,
                   &MIME_mtype_NAlloc, Key, Method);
}

/*
 * ?
 */
__View_t MIME_mtype_fetch(const char *Key, size_t Size)
{
   return (__View_t) a_Hdlr_fetch(MIME_mtype_Items, MIME_mtype_NItems, Key, Size);
}


/*
 * Initializes Mime module and, sets the supported Mime types.
 */
void a_MIME_init()
{
   MIME_type_Items = NULL;
   MIME_mtype_Items = NULL;
   MIME_type_NItems = 0;
   MIME_type_NAlloc = 0;
   MIME_mtype_NItems = 0;
   MIME_mtype_NAlloc = 0;

   a_Mime_add_type("image/gif", a_Gif_image);
   a_Mime_add_type("image/jpeg", a_Jpeg_image);
   a_Mime_add_type("image/jpg", a_Jpeg_image);
   a_Mime_add_type("image/png", a_Png_image);
   a_Mime_add_type("text/html", a_Html_text);

   /* Add a major type to handle all the text stuff */
   a_Mime_add_mayor_type("text", a_Dw_plain);
}


/*
 * Calls the handler for the mime type and sets Call and Data as appropriate
 * 
 * Return Value:
 * A VPtr on success, otherwise NULL
 */
Dw *a_Mime_set_view(const char *content_type, void *Ptr, __IOCallback_t * Call,
                     void **Data)
{

   __View_t VPtr;
   size_t Size = 0, Size1 = 0;
   int SeenSlash = 0;
   const char *CPtr = content_type;

   while (*CPtr && *CPtr != ' ' && *CPtr != ';') {
      Size++;
      if (!SeenSlash && *CPtr != '/')
         Size1++;
      if (*CPtr == '/')
         SeenSlash++;
      CPtr++;
   }

   /* Try explicit type */
   VPtr = MIME_type_fetch(content_type, Size);
   if (VPtr)
      return VPtr(content_type, Ptr, Call, Data);

   /* Try parent type */
   VPtr = MIME_mtype_fetch(content_type, Size1);
   if (VPtr)
      return VPtr(content_type, Ptr, Call, Data);

   /* Fail */
   g_print("yecky <%s>\n", content_type);
   return NULL;
}
