#ifndef __CACHE_H__
#define __CACHE_H__
#include <unistd.h>
#include <glib.h>


# define GZ_AUTOFREE (1) /* Free the cache file on close */
# define GZ_REDIRECT (2) /* Data actually points to a redirect */

typedef struct {
   const char *URL;
   const char *Type;
   void *Data;
   size_t Size,  /* Actually size of valid range */
     Total_Size, /* Goal size of the memory block */
     Block_Size; /* The preferred transfer size */
   unsigned Flags;
   int last_use;
   int FD;
} __CacheFile_t;

typedef void (*__IOCallback_t)(int,void*, __CacheFile_t*);

/* 
 * Exported Data
 */
extern GList *CacheFree, *CacheActive;
extern void* GzCache_Items;
extern int GzCache_NItems, GzCache_NAlloc;

/* 
 * Function prototypes
 */
void a_Cache_redirect_url(const char* Orig_URL, const char* To_Url);
int  a_Cache_open_url (const char *url, void*);
int  a_Cache_url_copy (const char *url, int Cache_FD);
char *a_Cache_url_read (const char *url, int *size);
void a_Cache_remove_url (char *url);
void a_Cache_insert (int FD, int Cache_FD,const char* url, const char* type);
int  a_Cache_add (__CacheFile_t* File);
__CacheFile_t* a_Cache_tmp (int FD);
void a_Cache_freeall(void);


#endif /* __CACHE_H__ */


