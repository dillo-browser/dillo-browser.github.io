#ifndef __DILLO_MISC_H__
#define __DILLO_MISC_H__

char *a_Misc_prepend_user_home(char *file);
char *a_Misc_stristr(char *src, char *str);

#endif /* __DILLO_MISC_H__ */

