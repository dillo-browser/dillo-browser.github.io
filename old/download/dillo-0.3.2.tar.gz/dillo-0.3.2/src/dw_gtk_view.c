/*
 * File: dw_gtk_view.c
 *
 * Copyright (C) 1997 Raph Levien <raph@acm.org>
 * Copyright (C) 1999 Luca Rota <drake@freemail.it>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

/*
 * This module is a GTK+ widget that also serves as a container for a
 * Dw widget. It also adds scrollbars with an automatic scrolling
 * policy. It's heavily adapted from gtkscrolledwindow.c in GTK+.
 */

#include <gtk/gtk.h>
#include <gdk/gdkkeysyms.h>     /* -RL :: I need it for key_press event */

#include "dw.h"
#include "dw_gtk_view.h"
#include "dw_gtk_scroller.h"

#define KEY_SCROLL_PIXELS       14

static void Dw_gtk_view_class_init(GtkDwViewClass *klass);
static void Dw_gtk_view_init(GtkDwView *dw_view);
static void Dw_gtk_view_map(GtkWidget *widget);
static void Dw_gtk_view_unmap(GtkWidget *widget);
static void Dw_gtk_view_realize(GtkWidget *widget);
static void Dw_gtk_view_unrealize(GtkWidget *widget);
static void Dw_gtk_view_destroy(GtkObject *object);
static void Dw_gtk_view_size_request(GtkWidget *widget,
                                     GtkRequisition *requisition);
static void Dw_gtk_view_size_allocate(GtkWidget *widget,
                                      GtkAllocation *allocation);
static void Dw_gtk_view_paint(GtkWidget *widget,
                              GdkRectangle *area);
static void Dw_gtk_view_draw(GtkWidget *widget,
                             GdkRectangle *area);
static gint Dw_gtk_view_expose(GtkWidget *widget,
                               GdkEventExpose *event);

static gint Dw_gtk_view_button(GtkWidget *widget,
                               GdkEventButton *event);
static gint Dw_gtk_view_motion_notify(GtkWidget *widget,
                                      GdkEventMotion *event);

static gint Dw_gtk_view_key_press(GtkWidget *widget,
                                  GdkEventKey *event);
static void Dw_gtk_view_h_scroll(GtkDwView *dw_view,
                                 gint scroll);
static void Dw_gtk_view_v_scroll(GtkDwView *dw_view,
                               gint scroll);

static void Dw_gtk_view_remove(GtkContainer *container,
                                   GtkWidget *widget);

static GtkContainerClass *parent_class = NULL;

#define DW_VIEW_MAX_WINDOW_SIZE 32760
#define DW_VIEW_BUMP 30000

/*
 * Get&set a unique GTK+ type-number for GtkDwView widget
 */
guint Dw_gtk_view_get_type()
{
   static guint dw_view_type = 0;

   if (!dw_view_type) {
      GtkTypeInfo dw_view_info =
      {
         "GtkDwView",
         sizeof(GtkDwView),
         sizeof(GtkDwViewClass),
         (GtkClassInitFunc) Dw_gtk_view_class_init,
         (GtkObjectInitFunc) Dw_gtk_view_init,
         (GtkArgSetFunc) NULL,
         (GtkArgGetFunc) NULL,
         (GtkClassInitFunc) NULL
      };

      dw_view_type = gtk_type_unique(gtk_container_get_type(), &dw_view_info);
   }
   return dw_view_type;
}

/*
 * Initialize a new intance of this class
 */
static void Dw_gtk_view_class_init(GtkDwViewClass *class)
{
   GtkObjectClass *object_class;
   GtkWidgetClass *widget_class;
   GtkContainerClass *container_class;

   object_class = (GtkObjectClass *) class;
   widget_class = (GtkWidgetClass *) class;
   container_class = (GtkContainerClass *) class;

   parent_class = gtk_type_class(gtk_container_get_type());

   object_class->destroy = Dw_gtk_view_destroy;

   widget_class->map = Dw_gtk_view_map;
   widget_class->unmap = Dw_gtk_view_unmap;
   widget_class->realize = Dw_gtk_view_realize;
   widget_class->unrealize = Dw_gtk_view_unrealize;
   widget_class->draw = Dw_gtk_view_draw;
   widget_class->expose_event = Dw_gtk_view_expose;
   widget_class->size_request = Dw_gtk_view_size_request;
   widget_class->size_allocate = Dw_gtk_view_size_allocate;

   widget_class->button_press_event = Dw_gtk_view_button;
   widget_class->button_release_event = Dw_gtk_view_button;
   widget_class->motion_notify_event = Dw_gtk_view_motion_notify;
   widget_class->key_press_event = Dw_gtk_view_key_press;

   container_class->remove = Dw_gtk_view_remove;
}

/* What to put in the _init function and what to put in the _new function?
 * The real rule is that the stuff in the init function is called
 * when instantiations of subclasses are created, while stuff in
 * the  new function is not. Just don't subclass this widget and
 * everything will be fine. */

/*
 * Initialize the "object" part of 'dw_view'
 */
static void Dw_gtk_view_init(GtkDwView *dw_view)
{
/*  GTK_WIDGET_UNSET_FLAGS (dw_view, GTK_NO_WINDOW); */
   GTK_WIDGET_SET_FLAGS(dw_view, GTK_CAN_FOCUS);
#if 0
   GTK_WIDGET_SET_FLAGS(dw_view, GTK_BASIC);
#endif

   dw_view->shadow_type = GTK_SHADOW_IN;
   dw_view->main_window = NULL;
   dw_view->view_window = NULL;
   dw_view->hadjustment = NULL;
   dw_view->vadjustment = NULL;

   dw_view->dw = NULL;

   dw_view->repaint_idle_tag = 0;
}

/*
 * Do nothing!
 * (It seems that "changed" work is handled by dw_gtk_scroller  --Jcid)
 */
static void Dw_gtk_view_adjustment_changed(GtkAdjustment *adjustment,
                                           gpointer data)
{
   g_return_if_fail(adjustment != NULL);
   g_return_if_fail(data != NULL);
   g_return_if_fail(GTK_IS_DW_VIEW(data));

   /* g_print("Dw_gtk_view_adjustment_changed IN\n"); */
}

/*
 * ?
 */
static void Dw_gtk_view_unmap_callback(GtkWidget *widget,
                                       gpointer data,
                                       GtkAllocation *allocation)
{
   gtk_widget_unmap(widget);
}

/*
 * ?
 */
static void Dw_gtk_view_size_allocate_callback(GtkWidget *widget,
                                               gpointer data,
                                               GtkAllocation *allocation)
{
   gtk_widget_size_allocate(widget, allocation);
}

/*
 * Handler for adjustments value-changes
 */
static void Dw_gtk_view_adjustment_value_changed(GtkAdjustment *adjustment,
                                                 gpointer data)
{
   GtkDwView *viewport;
   gint x_scroll, y_scroll;     /* delta scroll amount */
   gint x_top, y_top;           /* toplevel coordinates */
   gint x_win, y_win;           /* window coordinates */

   DwRect *visible;
   gboolean bumped;
   DwRect old_win, new_win;
   DwRect intersect;
   DwRect empty = {0, 0, 0, 0};

   /* todo: no doubt this routine will need some fiddling when the offsets
    * get implemented. */

   g_return_if_fail(adjustment != NULL);
   g_return_if_fail(data != NULL);
   g_return_if_fail(GTK_IS_DW_VIEW(data));

   viewport = GTK_DW_VIEW(data);

   x_top = 0;
   y_top = 0;

   if (viewport->hadjustment->lower != (viewport->hadjustment->upper -
                                    viewport->hadjustment->page_size))
      x_top = viewport->hadjustment->lower - viewport->hadjustment->value;

   if (viewport->vadjustment->lower != (viewport->vadjustment->upper -
                                    viewport->vadjustment->page_size))
      y_top = viewport->vadjustment->lower - viewport->vadjustment->value;

   if (GTK_WIDGET_REALIZED(viewport)) {
      visible = &viewport->dw_container->visible;
      bumped = FALSE;
      /* old_win is the current location of the X window in Dw
       * toplevel coordinates. */
      old_win.x0 = -viewport->dw_container->x_offset;
      old_win.x1 = old_win.x0 + DW_VIEW_MAX_WINDOW_SIZE;
      old_win.y0 = -viewport->dw_container->y_offset;
      old_win.y1 = old_win.y0 + DW_VIEW_MAX_WINDOW_SIZE;

      if (-x_top + viewport->dw_container->x_offset +
          visible->x1 - visible->x0 >
          DW_VIEW_MAX_WINDOW_SIZE) {
         viewport->dw_container->x_offset -= DW_VIEW_BUMP;
         bumped = TRUE;
      } else if (-x_top + viewport->dw_container->x_offset < 0) {
         viewport->dw_container->x_offset += DW_VIEW_BUMP;
         if (viewport->dw_container->x_offset > 0)
            viewport->dw_container->x_offset = 0;
         bumped = TRUE;
      }
      if (-y_top + viewport->dw_container->y_offset +
          visible->y1 - visible->y0 >
          DW_VIEW_MAX_WINDOW_SIZE) {
         viewport->dw_container->y_offset -= DW_VIEW_BUMP;
         bumped = TRUE;
      } else if (-y_top + viewport->dw_container->y_offset < 0) {
         viewport->dw_container->y_offset += DW_VIEW_BUMP;
         if (viewport->dw_container->y_offset > 0)
            viewport->dw_container->y_offset = 0;
         bumped = TRUE;
      }
      /* note: repaint is not necessary, because the window
       * move will generate an expose. */

      x_win = x_top - viewport->dw_container->x_offset;
      y_win = y_top - viewport->dw_container->y_offset;
      gdk_window_move(GTK_WIDGET(viewport)->window, x_win, y_win);

      /* Note: (todo: write up eager unmap) */

      if (bumped) {
         /* new_win is the new location of the X window in Dw
          * toplevel coordinates. */
         new_win.x0 = -viewport->dw_container->x_offset;
         new_win.x1 = new_win.x0 + DW_VIEW_MAX_WINDOW_SIZE;
         new_win.y0 = -viewport->dw_container->y_offset;
         new_win.y1 = new_win.y0 + DW_VIEW_MAX_WINDOW_SIZE;

         /* If bumped, two things need to be done:
          *
          * First, all embedded gtk's visible in the old but not
          * the new are unmapped.
          *
          * Second, all embedded gtk's visible in the intersection
          * of old and new are size_allocated.
          */

         if (viewport->dw != NULL)
            a_Dw_gtk_foreach(viewport->dw,
                             Dw_gtk_view_unmap_callback,
                             NULL,
                             &old_win,
                             &new_win);

         a_Dw_rect_intersect(&intersect, &old_win, &new_win);
         if (viewport->dw != NULL)
            a_Dw_gtk_foreach(viewport->dw,
                             Dw_gtk_view_size_allocate_callback,
                             NULL,
                             &intersect,
                             &empty);
      }
   }

   /* Update visible rectangle. */
   x_scroll = viewport->dw_container->visible.x0 + x_top;
   y_scroll = viewport->dw_container->visible.y0 + y_top;
   viewport->dw_container->visible.x0 -= x_scroll;
   viewport->dw_container->visible.y0 -= y_scroll;
   viewport->dw_container->visible.x1 -= x_scroll;
   viewport->dw_container->visible.y1 -= y_scroll;
}

/*
 * Return the widget's horizontal adjustment
 */
GtkAdjustment *a_Dw_gtk_view_get_hadjustment(GtkDwView *viewport)
{
   g_return_val_if_fail(viewport != NULL, NULL);
   g_return_val_if_fail(GTK_IS_DW_VIEW(viewport), NULL);

   return viewport->hadjustment;
}

/*
 * Return the widget's vertical adjustment
 */
GtkAdjustment *a_Dw_gtk_view_get_vadjustment(GtkDwView *viewport)
{
   g_return_val_if_fail(viewport != NULL, NULL);
   g_return_val_if_fail(GTK_IS_DW_VIEW(viewport), NULL);

   return viewport->vadjustment;
}

/*
 * Set viewport's horizontal adjustment to 'adjustment'.
 * This funsction sets the whole adjustment, not only its value.
 * ('viewport' will use 'adjustment' as its horizontal adjustment)
 */
void Dw_gtk_view_set_hadjustment(GtkDwView *viewport,
                                 GtkAdjustment *adjustment)
{
   g_return_if_fail(viewport != NULL);
   g_return_if_fail(GTK_IS_DW_VIEW(viewport));
   g_return_if_fail(adjustment != NULL);

   if (viewport->hadjustment) {
      gtk_signal_disconnect_by_data(GTK_OBJECT(viewport->hadjustment), (gpointer) viewport);
      gtk_object_unref(GTK_OBJECT(viewport->hadjustment));
   }
   viewport->hadjustment = adjustment;
   gtk_object_ref(GTK_OBJECT(viewport->hadjustment));

   gtk_signal_connect(GTK_OBJECT(adjustment), "changed",
                      (GtkSignalFunc) Dw_gtk_view_adjustment_changed,
                      (gpointer) viewport);
   gtk_signal_connect(GTK_OBJECT(adjustment), "value_changed",
                      (GtkSignalFunc) Dw_gtk_view_adjustment_value_changed,
                      (gpointer) viewport);

   Dw_gtk_view_adjustment_changed(adjustment, (gpointer) viewport);
}

/*
 * Set viewport's vertical adjustment to 'adjustment'.
 * (i.e. 'viewport' will use 'adjustment' as its vertical adjustment)
 */
void Dw_gtk_view_set_vadjustment(GtkDwView *viewport,
                                 GtkAdjustment *adjustment)
{
   g_return_if_fail(viewport != NULL);
   g_return_if_fail(GTK_IS_DW_VIEW(viewport));
   g_return_if_fail(adjustment != NULL);

   if (viewport->vadjustment) {
      gtk_signal_disconnect_by_data(GTK_OBJECT(viewport->vadjustment), (gpointer) viewport);
      gtk_object_unref(GTK_OBJECT(viewport->vadjustment));
   }
   viewport->vadjustment = adjustment;
   gtk_object_ref(GTK_OBJECT(viewport->vadjustment));

   gtk_signal_connect(GTK_OBJECT(adjustment), "changed",
                      (GtkSignalFunc) Dw_gtk_view_adjustment_changed,
                      (gpointer) viewport);
   gtk_signal_connect(GTK_OBJECT(adjustment), "value_changed",
                      (GtkSignalFunc) Dw_gtk_view_adjustment_value_changed,
                      (gpointer) viewport);

   Dw_gtk_view_adjustment_changed(adjustment, (gpointer) viewport);
}

/*
 * Destroy the widget, remove idle functions and free memory.
 */
static void Dw_gtk_view_destroy(GtkObject *object)
{
   GtkDwView *dw_view;

   g_return_if_fail(object != NULL);
   g_return_if_fail(GTK_IS_DW_VIEW(object));

   dw_view = GTK_DW_VIEW(object);

   if (dw_view->repaint_idle_tag)
      gtk_idle_remove(dw_view->repaint_idle_tag);

   if (dw_view->dw)
      a_Dw_destroy(dw_view->dw);

   a_Dw_region_drop(dw_view->repaint_region);

   g_free(dw_view->dw_container);

   if (GTK_OBJECT_CLASS(parent_class)->destroy)
      (*GTK_OBJECT_CLASS(parent_class)->destroy) (object);
}

/*
 * ?
 */
static void Dw_gtk_view_map(GtkWidget *widget)
{
   GtkDwView *dw_view;

#ifdef VERBOSE
   g_print("gtk_dw_view_map\n");
#endif

   g_return_if_fail(widget != NULL);
   g_return_if_fail(GTK_IS_DW_VIEW(widget));

   if (!GTK_WIDGET_MAPPED(widget)) {
      GTK_WIDGET_SET_FLAGS(widget, GTK_MAPPED);
      dw_view = GTK_DW_VIEW(widget);

      gdk_window_show(dw_view->main_window);

      /* should probably map children - perhaps using a gtk_foreach
       * method on the embedded dw. */
   }
}

/*
 * ?
 */
static void Dw_gtk_view_unmap(GtkWidget *widget)
{
   GtkDwView *dw_view;
   DwRect empty = {0, 0, 0, 0};

   g_return_if_fail(widget != NULL);
   g_return_if_fail(GTK_IS_DW_VIEW(widget));

   dw_view = GTK_DW_VIEW(widget);

   if (GTK_WIDGET_MAPPED(widget)) {
      GTK_WIDGET_UNSET_FLAGS(widget, GTK_MAPPED);

      gdk_window_hide(dw_view->main_window);

      /* should probably unmap children - perhaps using a gtk_foreach
       * method on the embedded dw. */
   }
   /* clear out repaint region, if the widget is not mapped then repaints
    * are pointless. It's explicitly cleared to help satisfy the invariant
    * that the paint method on the child dw will only be called when
    * the toplevel widget is mapped and visible. */

   a_Dw_region_drop(dw_view->repaint_region);
   dw_view->repaint_region = a_Dw_region_from_rect(&empty);
}

/*
 * Create an X window for the widget
 */
static void Dw_gtk_view_realize(GtkWidget *widget)
{
   GtkDwView *dw_view;
   GdkWindowAttr attributes;
   gint attributes_mask;

#ifdef VERBOSE
   g_print("gtk_dw_view_realize\n");
#endif

   g_return_if_fail(widget != NULL);
   g_return_if_fail(GTK_IS_DW_VIEW(widget));

   GTK_WIDGET_SET_FLAGS(widget, GTK_REALIZED);
   dw_view = GTK_DW_VIEW(widget);

   attributes.x = widget->allocation.x + GTK_CONTAINER(widget)->border_width;
   attributes.y = widget->allocation.y + GTK_CONTAINER(widget)->border_width;
   attributes.width = widget->allocation.width - GTK_CONTAINER(widget)->border_width * 2;
   attributes.height = widget->allocation.height - GTK_CONTAINER(widget)->border_width * 2;
   attributes.window_type = GDK_WINDOW_CHILD;
   attributes.wclass = GDK_INPUT_OUTPUT;
   attributes.visual = gtk_widget_get_visual(widget);
   attributes.colormap = gtk_widget_get_colormap(widget);
   attributes.event_mask = gtk_widget_get_events(widget) |
       GDK_EXPOSURE_MASK |
       GDK_BUTTON_PRESS_MASK |
       GDK_BUTTON_RELEASE_MASK |
       GDK_POINTER_MOTION_MASK |
       GDK_ENTER_NOTIFY_MASK |
       GDK_LEAVE_NOTIFY_MASK |
       GDK_KEY_PRESS_MASK;
   attributes_mask = GDK_WA_X | GDK_WA_Y | GDK_WA_VISUAL | GDK_WA_COLORMAP;

   dw_view->main_window = gdk_window_new(widget->parent->window, &attributes, attributes_mask);
   gdk_window_set_user_data(dw_view->main_window, dw_view);

   attributes.x += widget->style->klass->xthickness;
   attributes.y += widget->style->klass->ythickness;
   attributes.width -= widget->style->klass->xthickness * 2;
   attributes.height -= widget->style->klass->ythickness * 2;

   dw_view->view_window = gdk_window_new(dw_view->main_window, &attributes, attributes_mask);
   gdk_window_set_user_data(dw_view->view_window, dw_view);

   attributes.x = 0;
   attributes.y = 0;

   attributes.width = DW_VIEW_MAX_WINDOW_SIZE;
   attributes.height = DW_VIEW_MAX_WINDOW_SIZE;

   widget->window = gdk_window_new(dw_view->view_window, &attributes, attributes_mask);
   gdk_window_set_user_data(widget->window, dw_view);

   widget->style = gtk_style_attach(widget->style, dw_view->main_window);
   gtk_style_set_background(widget->style, dw_view->main_window, GTK_STATE_NORMAL);
   gtk_style_set_background(widget->style, widget->window, GTK_STATE_NORMAL);

   gdk_window_show(widget->window);
   gdk_window_show(dw_view->view_window);
}

/*
 * ?
 */
static void Dw_gtk_view_unrealize(GtkWidget *widget)
{
   GtkDwView *dw_view;

   g_return_if_fail(widget != NULL);
   g_return_if_fail(GTK_IS_DW_VIEW(widget));

   GTK_WIDGET_SET_FLAGS(widget, GTK_REALIZED);
   dw_view = GTK_DW_VIEW(widget);

   gtk_style_detach(widget->style);

   gdk_window_destroy(widget->window);
   widget->window = NULL;
   gdk_window_destroy(dw_view->view_window);
   dw_view->view_window = NULL;
   gdk_window_destroy(dw_view->main_window);
   dw_view->main_window = NULL;
}

/*
 * Allocate the child window & update the adjustments.
 */
static void Dw_gtk_view_allocate_child(GtkWidget *widget)
{
   GtkDwView *dw_view;
   GtkAllocation view_allocation;
   gint natural_width, natural_height;
   gint actual_width, actual_height;
   DwRect dw_allocation;

   dw_view = GTK_DW_VIEW(widget);

   view_allocation = widget->allocation;

   view_allocation.x += widget->style->klass->xthickness;
   view_allocation.width -= widget->style->klass->xthickness * 2;

   view_allocation.y += widget->style->klass->ythickness;
   view_allocation.height -= widget->style->klass->ythickness * 2;

   /* Size negotiation stuff. The sequence is as follows:
    *
    * 1. Determine the "natural width." This is the width of the parent
    * gtkdwscroller, minus some space set aside from the scrollbar.
    *
    * 2. Call size_nego_x on the child with the natural width.
    *
    * 3. The actual width is the max of the natural width and the
    * requisition minimum width. Similarly for actual height.
    *
    * 4. Call size_nego_y on the child with the actual width and
    * height.
    *
    * 5. The hadjustment upper is the actual width.
    *
    * 6. The vadjustment upper is the actual height.
    *
    */

   /* 1. Determine natural width. Note. This depends on the allocation
    * of the parent (gtkdwscroller) being set before the size_allocate
    * method of the child (gtkdwview) is called. */

   if (GTK_IS_DW_SCROLLER(widget->parent)) {
      natural_width = (widget->parent->allocation.width -
                       (25 + widget->style->klass->xthickness * 2));
   } else {
      natural_width = view_allocation.width;
   }
   natural_height = view_allocation.height;

#ifdef VERBOSE
   g_print("natural = %d x %d\n", natural_width, natural_height);
#endif

   /* 2. Call size_nego_x on child. */
   if (dw_view->dw != NULL)
      a_Dw_size_nego_x(dw_view->dw, natural_width);

   /* 3. Determine actual width. */
   actual_width = natural_width;
   actual_height = natural_height;

   if (dw_view->dw != NULL) {
      actual_width = MAX(actual_width, dw_view->dw->req_width_min);
      actual_height = MAX(actual_height, dw_view->dw->req_height);
   }
#ifdef VERBOSE
   g_print("actual = %d x %d\n", actual_width, actual_height);
#endif

   /* 4. Call size_nego_y on child. */
   dw_allocation.x0 = 0;
   dw_allocation.y0 = 0;
   dw_allocation.x1 = actual_width;
   dw_allocation.y1 = actual_height;
   if (dw_view->dw != NULL)
      a_Dw_size_nego_y(dw_view->dw, &dw_allocation);

#ifdef VERBOSE
   g_print("before, h = (%g -> %g, %g, +%g, ++%g, =%g)\n",
           dw_view->hadjustment->lower,
           dw_view->hadjustment->upper,
           dw_view->hadjustment->page_size,
           dw_view->hadjustment->page_increment,
           dw_view->hadjustment->step_increment,
           dw_view->hadjustment->value);
   g_print("before, v = (%g -> %g, %g, +%g, ++%g, =%g)\n",
           dw_view->vadjustment->lower,
           dw_view->vadjustment->upper,
           dw_view->vadjustment->page_size,
           dw_view->vadjustment->page_increment,
           dw_view->vadjustment->step_increment,
           dw_view->vadjustment->value);
#endif

   dw_view->hadjustment->page_size = view_allocation.width;
   dw_view->hadjustment->page_increment = dw_view->hadjustment->page_size / 2;
   dw_view->hadjustment->step_increment = 10;
   dw_view->hadjustment->lower = 0;
   dw_view->hadjustment->upper = actual_width;

   dw_view->vadjustment->page_size = view_allocation.height;
   dw_view->vadjustment->page_increment = dw_view->vadjustment->page_size / 2;
   dw_view->vadjustment->step_increment = 10;
   dw_view->vadjustment->lower = 0;
   dw_view->vadjustment->upper = actual_height;

   dw_view->hadjustment->value = MIN(dw_view->hadjustment->value,
                                      dw_view->hadjustment->upper -
                                      dw_view->hadjustment->page_size);
   dw_view->hadjustment->value = MAX(dw_view->hadjustment->value, 0);

   dw_view->vadjustment->value = MIN(dw_view->vadjustment->value,
                                      dw_view->vadjustment->upper -
                                      dw_view->vadjustment->page_size);
   dw_view->vadjustment->value = MAX(dw_view->vadjustment->value, 0);

#ifdef VERBOSE
   g_print("after, h = (%g -> %g, %g, +%g, ++%g, =%g)\n",
           dw_view->hadjustment->lower,
           dw_view->hadjustment->upper,
           dw_view->hadjustment->page_size,
           dw_view->hadjustment->page_increment,
           dw_view->hadjustment->step_increment,
           dw_view->hadjustment->value);
   g_print("after, v = (%g -> %g, %g, +%g, ++%g, =%g)\n",
           dw_view->vadjustment->lower,
           dw_view->vadjustment->upper,
           dw_view->vadjustment->page_size,
           dw_view->vadjustment->page_increment,
           dw_view->vadjustment->step_increment,
           dw_view->vadjustment->value);
#endif

   gtk_signal_emit_by_name(GTK_OBJECT(dw_view->hadjustment), "changed");
   gtk_signal_emit_by_name(GTK_OBJECT(dw_view->vadjustment), "changed");
}

/*
 * This routine does resizing and repainting of the widget, as
 * initiated by dw_request_resize and dw_request_repaint calls.
 */
static gint Dw_gtk_view_idle_func(GtkDwView *dw_view)
{
   DwRect rect;
   DwRect clip_rect;
   DwPaint paint;

   /* g_print("OOO Dw_gtk_view_idle_func\n"); */

   if (dw_view->dw != NULL && (dw_view->dw->flags & DW_FLAG_REQ_RESIZE))
      Dw_gtk_view_allocate_child(GTK_WIDGET(dw_view));

   a_Dw_region_tile(&rect, dw_view->repaint_region, 1024, 256, 1000);

   /* Intersect with the visible rect again because it might have changed
    * since the rect was added to the region.   */
   a_Dw_rect_intersect(&clip_rect, &rect, &dw_view->dw_container->visible);

   if ( !a_Dw_rect_empty(&clip_rect) ) {
      /* No assumptions are made about the existing screen state.
       *
       * todo: perhaps extend this so that we know about "old valid
       * data" (i.e. DW_PAINT_TOP_SCREEN). For the time being, the
       * added complexity is probably not worth it. */
      paint.flags = DW_PAINT_BG_UNDER;
      paint.bg_color = DW_PAINT_DEFAULT_BGND;

      /* todo: perhaps move some of this logic into its own routine,
       * to avoid code duplication. */

      /* todo: set clip rectangle to clip_rect. */

      if (dw_view->dw != NULL)
         a_Dw_paint(dw_view->dw, &clip_rect, &paint);

      a_Dw_paint_to_screen(GTK_WIDGET(dw_view), dw_view->dw_container,
                           &clip_rect, &paint);

      /* todo: set clip rectangle back to whole window (?) */
   }
   dw_view->repaint_region = a_Dw_region_minus(dw_view->repaint_region,
                                               a_Dw_region_from_rect(&rect));

   if (a_Dw_region_empty(dw_view->repaint_region)) {
      dw_view->repaint_idle_tag = 0;
      return FALSE;
   } else
      return TRUE;
}

/*
 * This routine gets called when any child widget needs a repaint.
 * What we do is add the repaint rectangle to the request repaint
 * region, and start an idle process to repaint it if necessary.
 *
 * An interesting question: where do we intersect the rectangle
 * with the visible rect? Here? For the time being, yes.
 */
static void Dw_gtk_view_request_paint(DwContainer *container, DwRect *rect)
{
   GtkWidget *widget;
   GtkDwView *dw_view;
   DwRect clip_rect;

   a_Dw_rect_intersect(&clip_rect, &container->visible, rect);

   if (a_Dw_rect_empty(&clip_rect))
      return;

   widget = container->widget;
   dw_view = GTK_DW_VIEW(widget);
   dw_view->repaint_region =
       a_Dw_region_union(a_Dw_region_from_rect(&clip_rect),
                         dw_view->repaint_region);

   if (dw_view->repaint_idle_tag == 0)
      dw_view->repaint_idle_tag =
          gtk_idle_add((GtkFunction) Dw_gtk_view_idle_func, dw_view);
}

/*
 * This routine gets called when any child widget requests a resize.
 */
static void Dw_gtk_view_request_resize(DwContainer *container)
{
   GtkDwView *dw_view;
   GtkWidget *widget;

   widget = container->widget;
   dw_view = GTK_DW_VIEW(widget);

   /* g_print("--- Dw_gtk_view_request_resize\n"); */

   if (dw_view->repaint_idle_tag == 0)
      dw_view->repaint_idle_tag =
          gtk_idle_add((GtkFunction) Dw_gtk_view_idle_func, dw_view);
}

static const DwContainerClass Dw_gtk_view_container_class =
{
   Dw_gtk_view_request_paint,
   Dw_gtk_view_request_resize
};

/*
 * Create a new GtkDwView widget
 */
GtkWidget *a_Dw_gtk_view_new(GtkAdjustment *hadjustment,
                             GtkAdjustment *vadjustment)
{
   GtkDwView *dw_view;
   DwContainer *dw_container;
   DwRect empty = {0, 0, 0, 0};

   dw_view = gtk_type_new(Dw_gtk_view_get_type());

   if (!hadjustment)
      hadjustment = (GtkAdjustment *) gtk_adjustment_new(0.0, 0.0, 0.0, 0.0, 0.0, 0.0);

   if (!vadjustment)
      vadjustment = (GtkAdjustment *) gtk_adjustment_new(0.0, 0.0, 0.0, 0.0, 0.0, 0.0);

   Dw_gtk_view_set_hadjustment(dw_view, hadjustment);
   Dw_gtk_view_set_vadjustment(dw_view, vadjustment);

   dw_view->repaint_region = a_Dw_region_from_rect(&empty);

   /* I'm going to make the container here so that it can respond
    * to stuff like size allocation. */
   dw_container = g_new(DwContainer, 1);

   dw_container->klass = &Dw_gtk_view_container_class;

   dw_container->widget = GTK_WIDGET(dw_view);

   /* todo: make visible rectangle reflect actual widget size */
   dw_container->visible.x0 = 0;
   dw_container->visible.y0 = 0;
   dw_container->visible.x1 = 0; /* 100,  640; */
   dw_container->visible.y1 = 0; /* 100,  400; */

   /* todo: support real offsets */
   dw_container->x_offset = 0;
   dw_container->y_offset = 0;

   dw_view->dw_container = dw_container;

   return GTK_WIDGET(dw_view);
}

/*
 * Add a Dw to the dw_view.
 * If there was already a dw present, delete it.
 */
void a_Dw_gtk_view_set_dw(GtkDwView *dw_view, Dw *dw)
{
   g_return_if_fail(dw_view != NULL);
   g_return_if_fail(GTK_IS_DW_VIEW(dw_view));

   if (dw_view->dw != NULL && dw_view->dw != dw)
      a_Dw_destroy(dw_view->dw);
   dw_view->dw = dw;
   dw->container = dw_view->dw_container;

   /* Set the vertical scroller to page top */
   Dw_gtk_view_v_scroll(dw_view, -dw_view->vadjustment->value);

   /* Call size allocation & paint functions on child if we're mapped. */
   if (GTK_WIDGET_VISIBLE(dw_view) && GTK_WIDGET_MAPPED(dw_view)) {
      Dw_gtk_view_allocate_child(GTK_WIDGET(dw_view));
      Dw_gtk_view_request_paint(dw_view->dw_container,
                                &dw_view->dw_container->visible);
   }
}

/*
 * ?
 */
static void Dw_gtk_view_paint(GtkWidget *widget, GdkRectangle *area)
{
   GtkDwView *dw_view;
   GtkStateType state;
   gint x, y;

#ifdef VERBOSE
   g_print("gtk_dw_view_paint\n");
#endif

   g_return_if_fail(widget != NULL);
   g_return_if_fail(GTK_IS_DW_VIEW(widget));
   g_return_if_fail(area != NULL);

   if (GTK_WIDGET_DRAWABLE(widget)) {
      dw_view = GTK_DW_VIEW(widget);

      state = widget->state;
      if (!GTK_WIDGET_IS_SENSITIVE(widget))
         state = GTK_STATE_INSENSITIVE;

      x = GTK_CONTAINER(dw_view)->border_width;
      y = GTK_CONTAINER(dw_view)->border_width;

      gtk_draw_shadow(widget->style, dw_view->main_window,
                      GTK_STATE_NORMAL, dw_view->shadow_type,
                      0, 0, -1, -1);
   }
}

/*
 * ?
 */
static void Dw_gtk_view_draw(GtkWidget *widget, GdkRectangle *area)
{
   GtkDwView *dw_view;

#ifdef VERBOSE
   g_print("gtk_dw_view_draw\n");
#endif

   g_return_if_fail(widget != NULL);
   g_return_if_fail(GTK_IS_DW_VIEW(widget));
   g_return_if_fail(area != NULL);

   if (GTK_WIDGET_DRAWABLE(widget)) {
      dw_view = GTK_DW_VIEW(widget);

      /* todo: draw children. */

      Dw_gtk_view_paint(widget, area);

   }
}

#define REQUEST_EXPOSE

/*
 * ?
 */
static gint Dw_gtk_view_expose(GtkWidget *widget, GdkEventExpose *event)
{
   GtkDwView *dw_view;

#ifndef REQUEST_EXPOSE
   DwPaint paint;
#endif
   DwRect expose_rect;

   g_return_val_if_fail(widget != NULL, FALSE);
   g_return_val_if_fail(GTK_IS_DW_VIEW(widget), FALSE);
   g_return_val_if_fail(event != NULL, FALSE);

   dw_view = GTK_DW_VIEW(widget);
   if (GTK_WIDGET_VISIBLE(widget) && GTK_WIDGET_MAPPED(widget)) {

      if (dw_view->dw != NULL && (dw_view->dw->flags & DW_FLAG_REQ_RESIZE))
         Dw_gtk_view_allocate_child(widget);

      if (event->window == dw_view->main_window) {
         Dw_gtk_view_paint(widget, &event->area);
      } else if (event->window == widget->window) {
#ifdef REQUEST_EXPOSE
         expose_rect.x0 = event->area.x - dw_view->dw_container->x_offset;
         expose_rect.y0 = event->area.y - dw_view->dw_container->y_offset;
         expose_rect.x1 = expose_rect.x0 + event->area.width;
         expose_rect.y1 = expose_rect.y0 + event->area.height;
         Dw_gtk_view_request_paint(dw_view->dw_container, &expose_rect);
#else
         /* we assume that X cleared the expose rectangle before calling us.
          *
          * Note: this is, in general, a _bad_ assumption. It is entirely
          * possible that whatever it is that caused the expose event
          * (usually scrolling, sometimes unobscuring the window) is
          * interleaved with drawing commands to the window. In that
          * case, the window will _not_ be cleared to the background
          * color.
          *
          * I'm not sure what's the best way to fix this, really. The
          * easiest thing to do would be to not set SCREEN_UNDER and
          * BG_SCREEN. That would, however, cause unnecessary rectangle
          * clears.
          *
          * That's what the code does now, so no action is necessary for
          * correctness, only efficiency.
          */
         paint.flags = DW_PAINT_BG_UNDER;

         paint.bg_color = DW_PAINT_DEFAULT_BGND;

         expose_rect.x0 = event->area.x - dw_view->dw_container->x_offset;
         expose_rect.y0 = event->area.y - dw_view->dw_container->y_offset;
         expose_rect.x1 = expose_rect.x0 + event->area.width;
         expose_rect.y1 = expose_rect.y0 + event->area.height;

         /* todo: set clip rectangle to expose_rect. */

         if (dw_view->dw != NULL)
            a_Dw_paint(dw_view->dw, &expose_rect, &paint);

         a_Dw_paint_to_screen(widget, dw_view->dw_container,
                              &expose_rect, &paint);

         /* todo: set clip rectangle back to whole window (?) */

         /* todo: remove rectangle from repaint region (?) */
#endif
      }
   }
   return TRUE;
}

/*
 * ?
 */
static void Dw_gtk_view_size_request(GtkWidget *widget,
                                     GtkRequisition *requisition)
{
   GtkDwView *dw_view;

   /* g_print("Dw_gtk_view_size_request\n"); */

   g_return_if_fail(widget != NULL);
   g_return_if_fail(GTK_IS_DW_VIEW(widget));
   g_return_if_fail(requisition != NULL);

   dw_view = GTK_DW_VIEW(widget);

   requisition->width = 20;
   requisition->height = 10;
}

/*
 * ?
 */
static void Dw_gtk_view_size_allocate(GtkWidget *widget,
                                      GtkAllocation *allocation)
{
   GtkDwView *dw_view;
   GtkAllocation view_allocation;

#ifdef VERBOSE
   g_print("gtk_dw_view_size_allocate\n");
#endif

   g_return_if_fail(widget != NULL);
   g_return_if_fail(GTK_IS_DW_VIEW(widget));
   g_return_if_fail(allocation != NULL);

   dw_view = GTK_DW_VIEW(widget);

   widget->allocation = *allocation;
   view_allocation = *allocation;

   if (GTK_WIDGET_REALIZED(widget)) {
      gdk_window_move_resize(dw_view->main_window,
                             view_allocation.x,
                             view_allocation.y,
                             view_allocation.width,
                             view_allocation.height);
   }
   /* XXX: I don think the widget has to be realized for this to work... */

   view_allocation.x = widget->style->klass->xthickness;
   view_allocation.width -= widget->style->klass->xthickness * 2;

   view_allocation.y = widget->style->klass->ythickness;
   view_allocation.height -= widget->style->klass->ythickness * 2;

   if (GTK_WIDGET_REALIZED(widget)) {
      gdk_window_move_resize(dw_view->view_window,
                             view_allocation.x,
                             view_allocation.y,
                             view_allocation.width,
                             view_allocation.height);
   }

   /* We have to set the visible rectangle here or the first page won't
    * draw correctly, since the first paint requests are called before
    * the widget is realized. */
   dw_view->dw_container->visible.x1 =
       dw_view->dw_container->visible.x0 + view_allocation.width;
   dw_view->dw_container->visible.y1 =
       dw_view->dw_container->visible.y0 + view_allocation.height;

   Dw_gtk_view_allocate_child(widget);
}

/*
 * ?
 */
static gint Dw_gtk_view_handle_event(GtkWidget *widget, GdkEvent *event)
{
   GtkDwView *dw_view;

   g_return_val_if_fail(widget != NULL, FALSE);
   g_return_val_if_fail(GTK_IS_DW_VIEW(widget), FALSE);
   g_return_val_if_fail(event != NULL, FALSE);

   dw_view = GTK_DW_VIEW(widget);

   if (event->any.window != widget->window)
      return FALSE;

   if (dw_view->dw != NULL)
      a_Dw_handle_event(dw_view->dw, event);
   return TRUE;
}

/*
 * ?
 */
static gint Dw_gtk_view_button(GtkWidget *widget, GdkEventButton *event)
{
   gint ret_val;
   g_return_val_if_fail(widget != NULL, FALSE);
   g_return_val_if_fail(GTK_IS_DW_VIEW(widget), FALSE);
   g_return_val_if_fail(event != NULL, FALSE);

   ret_val = Dw_gtk_view_handle_event(widget, (GdkEvent *) event);

   if(!GTK_WIDGET_HAS_FOCUS(widget) && ret_val)
      gtk_widget_grab_focus(widget);

   return ret_val;
}

/*
 * ?
 */
static gint Dw_gtk_view_motion_notify(GtkWidget *widget,
                                     GdkEventMotion *event)
{
   return Dw_gtk_view_handle_event(widget, (GdkEvent *) event);
}

/*
 * ?
 */
static gint Dw_gtk_view_key_press(GtkWidget *widget, GdkEventKey *event)
{
   GtkDwView *dw_view;
   gint return_val;

   g_return_val_if_fail(widget != NULL, FALSE);
   g_return_val_if_fail(GTK_IS_DW_VIEW(widget), FALSE);
   g_return_val_if_fail(event != NULL, FALSE);

   dw_view = GTK_DW_VIEW(widget);
   return_val = TRUE;

   switch (event->keyval) {
   case GDK_Home:
      Dw_gtk_view_v_scroll (dw_view, -dw_view->vadjustment->value);
      break;
   case GDK_End:
      Dw_gtk_view_v_scroll (dw_view, +dw_view->vadjustment->upper);
      break;
   case GDK_Page_Up:
      Dw_gtk_view_v_scroll (dw_view, -dw_view->vadjustment->page_increment);
      break;
   case GDK_Page_Down:
      Dw_gtk_view_v_scroll (dw_view, +dw_view->vadjustment->page_increment);
      break;
   case GDK_Up:
      Dw_gtk_view_v_scroll (dw_view, -KEY_SCROLL_PIXELS);
      break;
   case GDK_Down:
      Dw_gtk_view_v_scroll (dw_view, +KEY_SCROLL_PIXELS);
      break;
   case GDK_Left:
      Dw_gtk_view_h_scroll (dw_view, -KEY_SCROLL_PIXELS);
      break;
   case GDK_Right:
      Dw_gtk_view_h_scroll (dw_view, +KEY_SCROLL_PIXELS);
      break;
   default:
      return_val = FALSE;
      break;
   }

/* gtk_signal_emit_stop_by_name (GTK_OBJECT (widget), "key_press_event"); */

   return return_val;
}

/*
 * ?
 */
static void Dw_gtk_view_v_scroll(GtkDwView *dw_view, gint scroll)
{
   gfloat upper;

   dw_view->vadjustment->value += scroll;
   upper = dw_view->vadjustment->upper - dw_view->vadjustment->page_size;

   dw_view->vadjustment->value = MIN (dw_view->vadjustment->value, upper);
   dw_view->vadjustment->value = MAX (dw_view->vadjustment->value, 0.0);

   gtk_signal_emit_by_name(GTK_OBJECT(dw_view->vadjustment), "value_changed");
}

/*
 * ?
 */
static void Dw_gtk_view_h_scroll(GtkDwView* dw_view, gint scroll)
{
   gfloat upper;

   dw_view->hadjustment->value += scroll;
   upper = dw_view->hadjustment->upper - dw_view->hadjustment->page_size;

   dw_view->hadjustment->value = MIN (dw_view->hadjustment->value, upper);
   dw_view->hadjustment->value = MAX (dw_view->hadjustment->value, 0.0);

   gtk_signal_emit_by_name (GTK_OBJECT(dw_view->hadjustment), "value_changed");
}

/*
 * ?
 */
static void Dw_gtk_view_remove(GtkContainer *container, GtkWidget *widget)
{
   GtkDwView *dw_view;
   gboolean widget_was_visible;

   g_return_if_fail (container != NULL);
   g_return_if_fail (GTK_IS_DW_VIEW(container));
   g_return_if_fail (widget != NULL);
   g_return_if_fail (GTK_IS_WIDGET(widget));

   dw_view = GTK_DW_VIEW(container);
   widget_was_visible = GTK_WIDGET_VISIBLE(widget);

   gtk_widget_unparent (widget);

   if (widget_was_visible)
      gtk_widget_queue_resize (GTK_WIDGET(container));
}
