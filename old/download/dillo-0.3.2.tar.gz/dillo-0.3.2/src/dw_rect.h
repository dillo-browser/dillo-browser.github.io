/* Some simple data structures and utilities for working with rectangles. */

#ifndef __DW_RECT_H__
#define __DW_RECT_H__

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

typedef struct _DwPoint {
  gint x, y;
} DwPoint;

typedef struct _DwRect {
  gint x0, y0, x1, y1;
} DwRect;

/* Since rectangles are of fixed size, it is expected that they are
   statically allocated (i.e. on the stack). Functions on rectangles,
   however, will be defined in terms of pointers to rectangles.

   Functions with a rectangle return will have a "destination"
   rectangle pointer as the first argument. */

void Dw_rect_copy (DwRect *dest, const DwRect *src);
void Dw_rect_union (DwRect *dest, const DwRect *src1, const DwRect *src2);
void a_Dw_rect_intersect (DwRect *dest,
			 const DwRect *src1, const DwRect *src2);
gboolean a_Dw_rect_empty (const DwRect *src);
gboolean Dw_rect_point_inside (DwRect *rect, DwPoint *point);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __DW_RECT_H__ */
