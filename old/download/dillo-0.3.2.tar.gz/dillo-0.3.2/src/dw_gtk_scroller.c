
/* Part of Dillo, but adapted from gtk_scroller.c, so I'm including
 * the standard GTK+ license: */

/* GTK - The GIMP Toolkit
 * Copyright (C) 1995-1997 Peter Mattis, Spencer Kimball and Josh MacDonald
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <gtk/gtk.h>
#include "dw_gtk_scroller.h"
#include "dw_gtk_view.h"

#include "dw_page.h"
#include "dw_border.h"

#define SCROLLBAR_SPACING 0

static void Dw_gtk_scroller_class_init(GtkDwScrollerClass *klass);
static void Dw_gtk_scroller_init(GtkDwScroller *dw_scroller);
static void Dw_gtk_scroller_destroy(GtkObject *object);
static void Dw_gtk_scroller_map(GtkWidget *widget);
static void Dw_gtk_scroller_unmap(GtkWidget *widget);
static void Dw_gtk_scroller_draw(GtkWidget *widget,
                                 GdkRectangle *area);
static void Dw_gtk_scroller_size_request(GtkWidget *widget,
                                         GtkRequisition *requisition);
static void Dw_gtk_scroller_size_allocate(GtkWidget *widget,
                                          GtkAllocation *allocation);
static void Dw_gtk_scroller_remove(GtkContainer *container,
                                   GtkWidget *widget);
static void Dw_gtk_scroller_viewport_allocate(GtkWidget *widget,
                                              GtkAllocation *allocation);
static void Dw_gtk_scroller_adjustment_changed(GtkAdjustment *adjustment,
                                               gpointer data);
static void Dw_gtk_scroller_adjustment_value_changed(GtkAdjustment *adjustment,
                                                    gpointer data);
static void Dw_gtk_scroller_queue_anchor_pos (GtkDwScroller *dw_scroller,
                                             int y);
static int  Dw_gtk_scroller_anchor_timeout (gpointer data);
static void Dw_gtk_scroller_anchor_stop_timeout        (GtkDwScroller *dw_scroller);
static int  Dw_gtk_scroller_set_vadjustment_value (GtkDwScroller *dw_scroller,
                                                  int y);

static GtkContainerClass *parent_class = NULL;


/*
 * ?
 */
guint Dw_gtk_scroller_get_type()
{
   static guint dw_scroller_type = 0;

   if (!dw_scroller_type) {
      GtkTypeInfo dw_scroller_info =
      {
         "GtkDwScroller",
         sizeof(GtkDwScroller),
         sizeof(GtkDwScrollerClass),
         (GtkClassInitFunc) Dw_gtk_scroller_class_init,
         (GtkObjectInitFunc) Dw_gtk_scroller_init,
         (GtkArgSetFunc) NULL,
         (GtkArgGetFunc) NULL,
         (GtkClassInitFunc) NULL
      };

      dw_scroller_type = gtk_type_unique(gtk_container_get_type(), &dw_scroller_info);
   }
   return dw_scroller_type;
}

/*
 * ?
 */
static void Dw_gtk_scroller_class_init(GtkDwScrollerClass *class)
{
   GtkObjectClass *object_class;
   GtkWidgetClass *widget_class;
   GtkContainerClass *container_class;

   object_class = (GtkObjectClass *) class;
   widget_class = (GtkWidgetClass *) class;
   container_class = (GtkContainerClass *) class;

   parent_class = gtk_type_class(gtk_container_get_type());

   object_class->destroy = Dw_gtk_scroller_destroy;

   widget_class->map = Dw_gtk_scroller_map;
   widget_class->unmap = Dw_gtk_scroller_unmap;
   widget_class->draw = Dw_gtk_scroller_draw;
   widget_class->size_request = Dw_gtk_scroller_size_request;
   widget_class->size_allocate = Dw_gtk_scroller_size_allocate;

#if 0
   container_class->add = Dw_gtk_scroller_add;
#endif
   container_class->remove = Dw_gtk_scroller_remove;

#if 0
   container_class->foreach = Dw_gtk_scroller_foreach;
#endif
}

/*
 * ?
 */
static void Dw_gtk_scroller_init(GtkDwScroller *dw_scroller)
{
   GTK_WIDGET_SET_FLAGS(dw_scroller, GTK_NO_WINDOW);

   dw_scroller->hscrollbar = NULL;
   dw_scroller->vscrollbar = NULL;
   dw_scroller->hscrollbar_policy = GTK_POLICY_AUTOMATIC;
   dw_scroller->vscrollbar_policy = GTK_POLICY_AUTOMATIC;

   dw_scroller->old_vadjustment_value = 0;
   dw_scroller->anchor = NULL;
   dw_scroller->timeout_id = -1;
}

/*
 * Allocate a new scroller Dw
 */
GtkWidget *a_Dw_gtk_scroller_new(GtkAdjustment *hadjustment,
                                 GtkAdjustment *vadjustment)
{
   GtkDwScroller *dw_scroller;

   dw_scroller = gtk_type_new(Dw_gtk_scroller_get_type());

   dw_scroller->viewport = a_Dw_gtk_view_new(hadjustment, vadjustment);
   hadjustment = a_Dw_gtk_view_get_hadjustment(GTK_DW_VIEW(dw_scroller->viewport));
   vadjustment = a_Dw_gtk_view_get_vadjustment(GTK_DW_VIEW(dw_scroller->viewport));

   gtk_signal_connect(GTK_OBJECT(hadjustment), "changed",
                      (GtkSignalFunc) Dw_gtk_scroller_adjustment_changed,
                      (gpointer) dw_scroller);
   gtk_signal_connect(GTK_OBJECT(vadjustment), "changed",
                      (GtkSignalFunc) Dw_gtk_scroller_adjustment_changed,
                      (gpointer) dw_scroller);

   gtk_signal_connect(GTK_OBJECT(vadjustment), "value_changed",
                      (GtkSignalFunc) Dw_gtk_scroller_adjustment_value_changed,
                      (gpointer) dw_scroller);

   dw_scroller->hscrollbar = gtk_hscrollbar_new(hadjustment);
   dw_scroller->vscrollbar = gtk_vscrollbar_new(vadjustment);

   gtk_widget_set_parent(dw_scroller->viewport, GTK_WIDGET(dw_scroller));
   gtk_widget_set_parent(dw_scroller->hscrollbar, GTK_WIDGET(dw_scroller));
   gtk_widget_set_parent(dw_scroller->vscrollbar, GTK_WIDGET(dw_scroller));

   gtk_widget_show(dw_scroller->viewport);
   gtk_widget_show(dw_scroller->hscrollbar);
   gtk_widget_show(dw_scroller->vscrollbar);

   return GTK_WIDGET(dw_scroller);
}

#if 0
GtkAdjustment *Dw_gtk_scroller_get_hadjustment(GtkDwScroller *dw_scroller)
{
   g_return_val_if_fail(dw_scroller != NULL, NULL);
   g_return_val_if_fail(GTK_IS_DW_SCROLLER(dw_scroller), NULL);

   return gtk_range_get_adjustment(GTK_RANGE(dw_scroller->hscrollbar));
}

GtkAdjustment *Dw_gtk_scroller_get_vadjustment(GtkDwScroller *dw_scroller)
{
   g_return_val_if_fail(dw_scroller != NULL, NULL);
   g_return_val_if_fail(GTK_IS_DW_SCROLLER(dw_scroller), NULL);

   return gtk_range_get_adjustment(GTK_RANGE(dw_scroller->vscrollbar));
}
#endif

/*
 * ?
 */
void a_Dw_gtk_scroller_set_policy(GtkDwScroller *dw_scroller,
                                  GtkPolicyType hscrollbar_policy,
                                  GtkPolicyType vscrollbar_policy)
{
   g_return_if_fail(dw_scroller != NULL);
   g_return_if_fail(GTK_IS_DW_SCROLLER(dw_scroller));

   if ((dw_scroller->hscrollbar_policy != hscrollbar_policy) ||
       (dw_scroller->vscrollbar_policy != vscrollbar_policy)) {
      dw_scroller->hscrollbar_policy = hscrollbar_policy;
      dw_scroller->vscrollbar_policy = vscrollbar_policy;

      if (GTK_WIDGET(dw_scroller)->parent)
         gtk_widget_queue_resize(GTK_WIDGET(dw_scroller));
   }
}

/*
 * ?
 */
static void Dw_gtk_scroller_destroy(GtkObject *object)
{
   GtkDwScroller *dw_scroller;

   g_return_if_fail(object != NULL);
   g_return_if_fail(GTK_IS_DW_SCROLLER(object));

   dw_scroller = GTK_DW_SCROLLER(object);

   if (dw_scroller->anchor)
      g_free (dw_scroller->anchor);
   Dw_gtk_scroller_anchor_stop_timeout (dw_scroller);

   gtk_widget_destroy(dw_scroller->viewport);
   gtk_widget_destroy(dw_scroller->hscrollbar);
   gtk_widget_destroy(dw_scroller->vscrollbar);

   if (GTK_OBJECT_CLASS(parent_class)->destroy)
      (*GTK_OBJECT_CLASS(parent_class)->destroy) (object);
}

/*
 * ?
 */
static void Dw_gtk_scroller_map(GtkWidget *widget)
{
   GtkDwScroller *dw_scroller;

   g_return_if_fail(widget != NULL);
   g_return_if_fail(GTK_IS_DW_SCROLLER(widget));

   if (!GTK_WIDGET_MAPPED(widget)) {
      GTK_WIDGET_SET_FLAGS(widget, GTK_MAPPED);
      dw_scroller = GTK_DW_SCROLLER(widget);

      if (GTK_WIDGET_VISIBLE(dw_scroller->viewport) &&
          !GTK_WIDGET_MAPPED(dw_scroller->viewport))
         gtk_widget_map(dw_scroller->viewport);

      if (GTK_WIDGET_VISIBLE(dw_scroller->hscrollbar) &&
          !GTK_WIDGET_MAPPED(dw_scroller->hscrollbar))
         gtk_widget_map(dw_scroller->hscrollbar);

      if (GTK_WIDGET_VISIBLE(dw_scroller->vscrollbar) &&
          !GTK_WIDGET_MAPPED(dw_scroller->vscrollbar))
         gtk_widget_map(dw_scroller->vscrollbar);
   }
}

/*
 * ?
 */
static void Dw_gtk_scroller_unmap(GtkWidget *widget)
{
   GtkDwScroller *dw_scroller;

   g_return_if_fail(widget != NULL);
   g_return_if_fail(GTK_IS_DW_SCROLLER(widget));

   if (GTK_WIDGET_MAPPED(widget)) {
      GTK_WIDGET_UNSET_FLAGS(widget, GTK_MAPPED);
      dw_scroller = GTK_DW_SCROLLER(widget);

      if (GTK_WIDGET_MAPPED(dw_scroller->viewport))
         gtk_widget_unmap(dw_scroller->viewport);

      if (GTK_WIDGET_MAPPED(dw_scroller->hscrollbar))
         gtk_widget_unmap(dw_scroller->hscrollbar);

      if (GTK_WIDGET_MAPPED(dw_scroller->vscrollbar))
         gtk_widget_unmap(dw_scroller->vscrollbar);
   }
}

/*
 * ?
 */
static void Dw_gtk_scroller_draw(GtkWidget *widget,
                                 GdkRectangle *area)
{
   GtkDwScroller *dw_scroller;
   GdkRectangle child_area;

   g_return_if_fail(widget != NULL);
   g_return_if_fail(GTK_IS_DW_SCROLLER(widget));
   g_return_if_fail(area != NULL);

   if (GTK_WIDGET_DRAWABLE(widget)) {
      dw_scroller = GTK_DW_SCROLLER(widget);

      if (gtk_widget_intersect(dw_scroller->viewport, area, &child_area))
         gtk_widget_draw(dw_scroller->viewport, &child_area);

      if (gtk_widget_intersect(dw_scroller->hscrollbar, area, &child_area))
         gtk_widget_draw(dw_scroller->hscrollbar, &child_area);

      if (gtk_widget_intersect(dw_scroller->vscrollbar, area, &child_area))
         gtk_widget_draw(dw_scroller->vscrollbar, &child_area);
   }
}

/*
 * ?
 */
static void Dw_gtk_scroller_size_request(GtkWidget *widget,
                                         GtkRequisition *requisition)
{
   GtkDwScroller *dw_scroller;
   gint extra_height;
   gint extra_width;

   g_return_if_fail(widget != NULL);
   g_return_if_fail(GTK_IS_DW_SCROLLER(widget));
   g_return_if_fail(requisition != NULL);

   dw_scroller = GTK_DW_SCROLLER(widget);

   requisition->width = 0;
   requisition->height = 0;

   if (GTK_WIDGET_VISIBLE(dw_scroller->viewport)) {
      gtk_widget_size_request(dw_scroller->viewport, &dw_scroller->viewport->requisition);

      requisition->width += dw_scroller->viewport->requisition.width;
      requisition->height += dw_scroller->viewport->requisition.height;
   }
   extra_width = 0;
   extra_height = 0;

   if ((dw_scroller->hscrollbar_policy == GTK_POLICY_AUTOMATIC) ||
       GTK_WIDGET_VISIBLE(dw_scroller->hscrollbar)) {
      gtk_widget_size_request(dw_scroller->hscrollbar,
                              &dw_scroller->hscrollbar->requisition);

      requisition->width = MAX(requisition->width,
                               dw_scroller->hscrollbar->requisition.width);
      extra_height = SCROLLBAR_SPACING + dw_scroller->hscrollbar->requisition.height;
   }
   if ((dw_scroller->vscrollbar_policy == GTK_POLICY_AUTOMATIC) ||
       GTK_WIDGET_VISIBLE(dw_scroller->vscrollbar)) {
      gtk_widget_size_request(dw_scroller->vscrollbar,
                              &dw_scroller->vscrollbar->requisition);

      requisition->height = MAX(requisition->height,
                                dw_scroller->vscrollbar->requisition.height);
      extra_width = SCROLLBAR_SPACING + dw_scroller->vscrollbar->requisition.width;
   }
   requisition->width += GTK_CONTAINER(widget)->border_width * 2 + extra_width;
   requisition->height += GTK_CONTAINER(widget)->border_width * 2 + extra_height;
}

/*
 * ?
 */
static void Dw_gtk_scroller_size_allocate(GtkWidget *widget,
                                          GtkAllocation *allocation)
{
   GtkDwScroller *dw_scroller;
   GtkAllocation viewport_allocation;
   GtkAllocation child_allocation;
   guint previous_hvis;
   guint previous_vvis;

   g_return_if_fail(widget != NULL);
   g_return_if_fail(GTK_IS_DW_SCROLLER(widget));
   g_return_if_fail(allocation != NULL);

   dw_scroller = GTK_DW_SCROLLER(widget);
   widget->allocation = *allocation;

   Dw_gtk_scroller_viewport_allocate(widget, &viewport_allocation);

#if 0
   gtk_container_disable_resize(GTK_CONTAINER(dw_scroller));
#endif

   if (GTK_WIDGET_VISIBLE(dw_scroller->viewport)) {
      do {
         Dw_gtk_scroller_viewport_allocate(widget, &viewport_allocation);

         child_allocation.x = viewport_allocation.x + allocation->x;
         child_allocation.y = viewport_allocation.y + allocation->y;
         child_allocation.width = viewport_allocation.width;
         child_allocation.height = viewport_allocation.height;

         previous_hvis = GTK_WIDGET_VISIBLE(dw_scroller->hscrollbar);
         previous_vvis = GTK_WIDGET_VISIBLE(dw_scroller->vscrollbar);

         gtk_widget_size_allocate(dw_scroller->viewport, &child_allocation);
      } while ((previous_hvis != GTK_WIDGET_VISIBLE(dw_scroller->hscrollbar)) ||
        (previous_vvis != GTK_WIDGET_VISIBLE(dw_scroller->vscrollbar)));
   }
   if (GTK_WIDGET_VISIBLE(dw_scroller->hscrollbar)) {
      child_allocation.x = viewport_allocation.x;
      child_allocation.y = viewport_allocation.y + viewport_allocation.height + SCROLLBAR_SPACING;
      child_allocation.width = viewport_allocation.width;
      child_allocation.height = dw_scroller->hscrollbar->requisition.height;
      child_allocation.x += allocation->x;
      child_allocation.y += allocation->y;

      gtk_widget_size_allocate(dw_scroller->hscrollbar, &child_allocation);
   }
   if (GTK_WIDGET_VISIBLE(dw_scroller->vscrollbar)) {
      child_allocation.x = viewport_allocation.x + viewport_allocation.width + SCROLLBAR_SPACING;
      child_allocation.y = viewport_allocation.y;
      child_allocation.width = dw_scroller->vscrollbar->requisition.width;
      child_allocation.height = viewport_allocation.height;
      child_allocation.x += allocation->x;
      child_allocation.y += allocation->y;

      gtk_widget_size_allocate(dw_scroller->vscrollbar, &child_allocation);
   }
#if 0
   gtk_container_enable_resize(GTK_CONTAINER(dw_scroller));
#endif
}

#if 0
/*
 * ?
 */
static void Dw_gtk_scroller_add(GtkContainer *container,
                                GtkWidget *widget)
{
   GtkDwScroller *dw_scroller;

   g_return_if_fail(container != NULL);
   g_return_if_fail(GTK_IS_DW_SCROLLER(container));
   g_return_if_fail(widget != NULL);

   dw_scroller = GTK_DW_SCROLLER(container);
   gtk_container_add(GTK_CONTAINER(dw_scroller->viewport), widget);
}

#endif

/*
 * ?
 */
static void Dw_gtk_scroller_remove(GtkContainer *container, GtkWidget *widget)
{
   GtkDwScroller *dw_scroller;
   gboolean widget_was_visible;

   g_return_if_fail (container != NULL);
   g_return_if_fail (GTK_IS_DW_SCROLLER (container));
   g_return_if_fail (widget != NULL);
   g_return_if_fail (GTK_IS_WIDGET (widget));

   dw_scroller = GTK_DW_SCROLLER (container);
   /* -RL :: I don't know what this widget is. */
   widget_was_visible = GTK_WIDGET_VISIBLE (widget);

   gtk_widget_unparent (widget);

   if (widget_was_visible)
      gtk_widget_queue_resize (GTK_WIDGET (container));
}

/*
 * Set 'dw' as the new contained widget in the GtkDwView.
 * (The GtkDwScroller widget has a GtkDwView inside)
 */
void a_Dw_gtk_scroller_set_dw(GtkDwScroller *dw_scroller, Dw *dw)
{
   /* New dw will be first at 0, but Dw_gtk_scroller_adjustment_value_changed
    * should not react on this "value_change" */
   dw_scroller->old_vadjustment_value = 0;

   a_Dw_gtk_view_set_dw(GTK_DW_VIEW(dw_scroller->viewport), dw);
}

#if 0
static void Dw_gtk_scroller_foreach(GtkContainer *container,
                                    GtkCallback callback,
                                    gpointer callback_data)
{
   GtkDwScroller *dw_scroller;

   g_return_if_fail(container != NULL);
   g_return_if_fail(GTK_IS_DW_SCROLLER(container));
   g_return_if_fail(callback != NULL);

   dw_scroller = GTK_DW_SCROLLER(container);

   (*callback) (dw_scroller->viewport, callback_data);
}
#endif

/*
 * ?
 */
static void Dw_gtk_scroller_viewport_allocate(GtkWidget *widget,
                                              GtkAllocation *allocation)
{
   GtkDwScroller *dw_scroller;

   g_return_if_fail(widget != NULL);
   g_return_if_fail(allocation != NULL);

   dw_scroller = GTK_DW_SCROLLER(widget);

   allocation->x = GTK_CONTAINER(widget)->border_width;
   allocation->y = GTK_CONTAINER(widget)->border_width;
   allocation->width = widget->allocation.width - allocation->x * 2;
   allocation->height = widget->allocation.height - allocation->y * 2;

   if (GTK_WIDGET_VISIBLE(dw_scroller->vscrollbar))
      allocation->width -= dw_scroller->vscrollbar->requisition.width + SCROLLBAR_SPACING;
   if (GTK_WIDGET_VISIBLE(dw_scroller->hscrollbar))
      allocation->height -= dw_scroller->hscrollbar->requisition.height + SCROLLBAR_SPACING;
}

/*
 * ?
 */
static void Dw_gtk_scroller_adjustment_changed(GtkAdjustment *adjustment,
                                               gpointer data)
{
   GtkDwScroller *scrolled_win;
   GtkWidget *scrollbar;
   gint hide_scrollbar;
   gint policy;

   g_return_if_fail(adjustment != NULL);
   g_return_if_fail(data != NULL);

   scrolled_win = GTK_DW_SCROLLER(data);

   if (adjustment == gtk_range_get_adjustment(GTK_RANGE(scrolled_win->hscrollbar))) {
      scrollbar = scrolled_win->hscrollbar;
      policy = scrolled_win->hscrollbar_policy;
   } else if (adjustment == gtk_range_get_adjustment(GTK_RANGE(scrolled_win->vscrollbar))) {
      scrollbar = scrolled_win->vscrollbar;
      policy = scrolled_win->vscrollbar_policy;
   } else {
      g_warning("could not determine which adjustment scrollbar received change signal for");
      return;
   }

   if (policy == GTK_POLICY_AUTOMATIC) {
      hide_scrollbar = FALSE;
      if ((adjustment->upper - adjustment->lower) <= adjustment->page_size)
         hide_scrollbar = TRUE;

      if (hide_scrollbar) {
         if (GTK_WIDGET_VISIBLE(scrollbar))
            gtk_widget_hide(scrollbar);
      } else {
         if (!GTK_WIDGET_VISIBLE(scrollbar))
            gtk_widget_show(scrollbar);
      }
   }
}


/* Currently used to catch scrolling by the user and then stop
 * Dw_gtk_scroller_anchor_timeout. dw_scroller->old_vadjustment_value is used
 * because:
 * 1. You get a "value_changed" signal also as a side effect of "changed"
 *    signals.
 * 2. Dw_gtk_scroller_anchor_timeout should not be stopped when the adjustment
 *    value is changed by Dw_gtk_scroller_set_vadjustment_value.
 */
static void Dw_gtk_scroller_adjustment_value_changed(GtkAdjustment *adjustment,
                                                    gpointer data)
{
   GtkDwScroller *dw_scroller = (GtkDwScroller*)data;

   if (!dw_scroller->timeout_flag)
      return;

   if (dw_scroller->old_vadjustment_value != (int)adjustment->value) {
      dw_scroller->old_vadjustment_value = adjustment->value;
      dw_scroller->timeout_flag = FALSE;

      /*g_print ("Dw_gtk_scroller_adjustment_value_changed: "
       "stopping timeout\n"); */
   }  /*else
       g_print ("Dw_gtk_scroller_adjustment_value_changed: nothing\n");*/
}


/*
 * This timeout function is set by Dw_gtk_scroller_queue_anchor_pos and sets,
 * if necessary, the pixel position of the anchor.
 * The limit per GtkDwScroller is one timeout function.
 * Note: a timeout function returns TRUE, if it will continue to run.
 */
static int Dw_gtk_scroller_anchor_timeout (gpointer data)
{
   GtkDwScroller *dw_scroller = (GtkDwScroller*)data;

#if 0
   static int i = 0;

   if (i == 0)
      g_print ("Dw_gtk_scroller_anchor_timeout\n");

   i = (i + 1) % 10;
#endif

   if (dw_scroller->timeout_flag && dw_scroller->anchor_pos != -1)
      {
        if (Dw_gtk_scroller_set_vadjustment_value (dw_scroller,
                                                   dw_scroller->anchor_pos))
           /* pixel position set successfully -> currently not used
              anymore (mut may be reassigned by DwPage) */
           dw_scroller->anchor_pos = -1;
        else
           /* If we have problems, keep running */
           dw_scroller->timeout_flag = TRUE;
      }

   if (!dw_scroller->timeout_flag) {
      /* some things to do before ending */
      a_Dw_gtk_scroller_set_anchor (dw_scroller, NULL);
      dw_scroller->timeout_id = -1;
   }

   return dw_scroller->timeout_flag;
}

/*
 * Stop the timeout function directly.
 * (Setting timeout_flag to FALSE also stops the timeout)
 */
static void Dw_gtk_scroller_anchor_stop_timeout (GtkDwScroller *dw_scroller)
{
   if (dw_scroller->timeout_id != -1) {
      gtk_timeout_remove (dw_scroller->timeout_id);
      dw_scroller->timeout_id = -1;
   }
}


/*
 * Starts the timeout function, with initial scroller position at y.
 */
static void Dw_gtk_scroller_queue_anchor_pos (GtkDwScroller *dw_scroller,
                                             int y)
{
   Dw_gtk_scroller_anchor_stop_timeout (dw_scroller);

   if (dw_scroller->anchor) {
      dw_scroller->anchor_pos = y;
      dw_scroller->timeout_flag = TRUE;
      dw_scroller->timeout_id =
        gtk_timeout_add (200, Dw_gtk_scroller_anchor_timeout, dw_scroller);
   }
}

/*
 * Sets the #anchor for the Scroller. NULL for no anchor.
 * Should be called before a_Dw_gtk_scroller_queue_anchor resp.
 * a_Dw_gtk_scroller_jump_anchor
 */
void a_Dw_gtk_scroller_set_anchor (GtkDwScroller *dw_scroller, gchar *anchor)
{
   if (dw_scroller->anchor) g_free(dw_scroller->anchor);

   dw_scroller->anchor = (anchor) ? g_strdup(anchor) : NULL;
}

/*
 * Starts the timeout function for jumping to the #anchor.
 * Similar to a_Dw_gtk_scroller_jump_anchor, but intended for searching
 * the positions while the page is loaded.
 * Call a_Dw_gtk_scroller_set_anchor before.
 */
void a_Dw_gtk_scroller_queue_anchor (GtkDwScroller *dw_scroller)
{
   Dw_gtk_scroller_queue_anchor_pos (dw_scroller, -1);
}

/*
 * Jumps directly to the #anchor. If this failes, queue anchor.
 * The page must be loaded before.
 * Call a_Dw_gtk_scroller_set_anchor before.
 * Currently this function is not used (see comment in Nav_open_url).
 */
void a_Dw_gtk_scroller_jump_anchor (GtkDwScroller *dw_scroller)
{
   GtkDwView *view = NULL;
   DwBorder *border = NULL;
   DwPage *page = NULL;
   void *p = NULL;
   int y;

   Dw_gtk_scroller_anchor_stop_timeout(dw_scroller);

   if (dw_scroller->anchor) {
      /* debugger friendly version */
      view = GTK_DW_VIEW (dw_scroller->viewport);
      if (view) border = (DwBorder*) (view->dw);
      if (border) page = (DwPage*) (border->child);
      if (page)
        p = g_hash_table_lookup(page->anchors_table, dw_scroller->anchor);

      if (p) {
        /* Anchor found */
        /* y + 1 is stored in hash table to avoid problems with y == 0
         * (which would be stored as a NULL pointer) */
        y = (int) p - 1;
        if (!Dw_gtk_scroller_set_vadjustment_value (dw_scroller, y))
           /* Can't set it now -> queue */
           Dw_gtk_scroller_queue_anchor_pos (dw_scroller, y);
      } else {
        /* Anchor not found */
        /* It may be that the <a name="xxx"> has not been read yet. */
        Dw_gtk_scroller_queue_anchor_pos (dw_scroller, -1);
      }
   } else {
     /* no anchor: jump to top */
     Dw_gtk_scroller_set_vadjustment_value (dw_scroller, 0);
   }
}


/*
 * Sets the scroller position. Returns whether successful.
 * FALSE is also returned if the position had to be adjusted (when the space
 * between anchor and bottom of the page is less than the viewport height).
 * Sometimes this is because too less of the page has been read yet.
 */
static int Dw_gtk_scroller_set_vadjustment_value (GtkDwScroller *dw_scroller,
                                                 int y)
{
   GtkAdjustment *adj;
   int retval;

   adj = GTK_DW_VIEW(dw_scroller->viewport)->vadjustment;
   retval = FALSE;

   /* Sometimes an anchor position is set in dw_scroller->anchor_pos which
      is bigger adj->upper */
   if (adj->upper > y) {
      retval = TRUE;

      if (y > adj->upper - adj->page_size) {
        retval = FALSE;
        y = adj->upper - adj->page_size;

        if (y < 0)
           y = 0;
      }

      dw_scroller->old_vadjustment_value = y;
      gtk_adjustment_set_value (adj, y);
   }

   return retval;
}


void a_Dw_gtk_scroller_jump_pos (GtkDwScroller *dw_scroller,
     int y)
{
   if (!Dw_gtk_scroller_set_vadjustment_value (dw_scroller, y))
      /* Can't set it now -> queue */
      Dw_gtk_scroller_queue_anchor_pos (dw_scroller, y);
}
