#ifndef __IO_h
#define __IO_h

#include<unistd.h>
#include<sys/uio.h>

#define IORead   0
#define IOWrite  1
#define IOWrites 2
#define IOClose  3
#define IOAbort  4


typedef void (*IOCallback_t)(int Op, void *CbData);

typedef struct {
   gint Op;               /* IORead | IOWrite | IOWrites */
   gint GdkTag;           /* gdk_input tag (used to remove) */
   glong Status;          /* Number of bytes read, or -errno code */
   struct iovec IOVec;    /* Buffer place and length */
   IOCallback_t Callback; /* External function to be called when Op is done */
   void *CbData;          /* Callback function data */
   gint FD;               /* Current File Descriptor */
} IOData_t;


/*
 * Exported functions
 */
void a_IO_submit(IOData_t *req);
void a_IO_abort(IOData_t *io);


#endif

