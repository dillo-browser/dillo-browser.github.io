#ifndef __DILLO_DNS_H__
#define __DILLO_DNS_H__

#include <gtk/gtk.h>

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

void a_Dns_init (void);

/* Returns tag */
guint32 a_Dns_lookup (const char *hostname,
                           void (* callback) (int Op, guint32 ip_addr, void *callback_data),
                           void *callback_data);

void a_Dns_abort (guint32 tag);
void a_Dns_freeall(void);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __DILLO_DNS_H__ */
