/*
 * File: dw.c
 *
 * Copyright (C) 1997 Raph Levien <raph@acm.org>
 * Copyright (C) 1999 Luca Rota <drake@freemail.it>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

/*
 * Generic dispatch functions for the Dw widget set.
 */

#include <gtk/gtk.h>
#include <stdio.h>

#include "dw_rect.h"
#include "dw.h"


/*
 * Request the class-method horizontal-size negotiation method to be called
 */
void a_Dw_size_nego_x(Dw *dw, gint width)
{
   if (dw->klass->size_nego_x)
      dw->klass->size_nego_x(dw, width);
}

/*
 * Note: in addition to invoking the method, this routine also resets
 * DW_FLAG_REQ_RESIZE flag, because calling this method generally
 * means that the resize request has been granted.
 */
void a_Dw_size_nego_y(Dw *dw, DwRect *allocation)
{
   dw->flags &= ~DW_FLAG_REQ_RESIZE;
   dw->klass->size_nego_y(dw, allocation);
}

/*
 * ?
 */
void a_Dw_paint(Dw *dw, DwRect *rect, DwPaint *paint)
{

   /* propagates container info down. */
   if (dw->container == NULL && dw->parent != NULL)
      // dw->container = dw->parent->container;
      dw->container = a_Dw_find_container(dw);

   dw->klass->paint(dw, rect, paint);
}

/*
 * ?
 */
void a_Dw_handle_event(Dw *dw, GdkEvent *event)
{
   if (dw->klass->handle_event)
      dw->klass->handle_event(dw, event);
}

/*
 * ?
 */
void a_Dw_gtk_foreach(Dw *dw, DwCallback callback, gpointer callback_data,
                      DwRect *plus, DwRect *minus)
{
   if (dw->klass->gtk_foreach)
      dw->klass->gtk_foreach(dw, callback, callback_data, plus, minus);
}

/*
 * Deallocate memory used by the widget.
 */
void a_Dw_destroy(Dw *dw)
{
   dw->klass->destroy(dw);
}

/*
 * This routine is not a straightforward invocation of the widget
 * method. Rather, it sets the REQ_RESIZE flag on the widget and calls
 * the request_resize method on the widget's parent, if the flag is
 * not already set.
 */
void a_Dw_request_parent_resize(Dw *dw)
{
   if (!(dw->flags & DW_FLAG_REQ_RESIZE)) {
       dw->flags |= DW_FLAG_REQ_RESIZE;
       if (dw->parent != NULL) {
          if (dw->parent->klass->request_resize)
             dw->parent->klass->request_resize(dw->parent, dw);
       } else if (dw->container != NULL) {
          if (dw->container->klass->request_resize)
             dw->container->klass->request_resize(dw->container);
       }
   }
}

/*
 * ?
 */
void a_Dw_request_paint(Dw *dw, DwRect *rect)
{
   DwContainer *container;

   container = a_Dw_find_container(dw);
   if (container == NULL)
      return;
   container->klass->request_paint(container, rect);
}


/* Some utility functions. */

/*
 * Find the container or return NULL if there isn't one.
 */
DwContainer *a_Dw_find_container(Dw *dw)
{
   while (dw != NULL) {
      if (dw->container != NULL)
         return dw->container;
      dw = dw->parent;
   }
   return NULL;
}

/*
 * Transfer the top layer to the screen if it's not already there.
 */
void a_Dw_paint_to_screen(GtkWidget *widget, DwContainer *container,
                          DwRect *rect, DwPaint *paint)
{
   if (!(paint->flags & DW_PAINT_SCREEN_UNDER)) {
      if (paint->flags & DW_PAINT_BG_UNDER) {
         gdk_window_clear_area(widget->window,
                               container->x_offset + rect->x0,
                               container->y_offset + rect->y0,
                               rect->x1 - rect->x0, rect->y1 - rect->y0);
         paint->flags |= DW_PAINT_SCREEN_UNDER;
      } else {
         /* here's where we'd paint the buf to the screen */
         /* inconsistent state */
      }
   }
}

/*
 * Update paint flags to indicate we just painted to the screen.
 * (Similarly, there will be a a_Dw_paint_finish_buf to indicate we just
 *  painted to the buf.)
 */
void a_Dw_paint_finish_screen(DwPaint *paint)
{
   paint->flags &= ~DW_PAINT_BG_UNDER;
   paint->flags |= DW_PAINT_SCREEN_UNDER;
}

/*
 * Set the background color of a Dw
 */
void a_Dw_set_color(Dw *dw, gint32 color)
{
   const gint COLOR_MASK = 0xff;
   const gint COLOR_ELEMENT_WIDTH = 8;

   GdkColormap *colormap;
   GtkWidget *widget;
   DwContainer *container;
   GdkColor gdk_color;

   gdk_color.pixel = color;

   /* Split gint into rgb components */
   gdk_color.red = (gdk_color.pixel >> 2 * COLOR_ELEMENT_WIDTH) & COLOR_MASK;
   gdk_color.green = (gdk_color.pixel >> COLOR_ELEMENT_WIDTH) & COLOR_MASK;
   gdk_color.blue = gdk_color.pixel & COLOR_MASK;

   /* Now approximately scale the components from 8 bit values to 16 bit values */
   gdk_color.red |= gdk_color.red << 8;
   gdk_color.green |= gdk_color.green << 8;
   gdk_color.blue |= gdk_color.blue << 8;
#ifdef VERBOSE
   g_print("color:\tred %d\tgreen %d\tblue %d\n", gdk_color.red,
           gdk_color.green, gdk_color.blue);
#endif

   container = a_Dw_find_container(dw);
   if (container != NULL) {
      widget = container->widget;
      /* Get drawingarea colormap */
      colormap = gdk_window_get_colormap(GTK_WIDGET(widget)->window);
      /* Allocate color */
      gdk_color_alloc(colormap, &gdk_color);

      gdk_window_set_background(GTK_WIDGET(widget)->window, &gdk_color);
      gdk_window_clear(GTK_WIDGET(widget)->window);
   }
}
