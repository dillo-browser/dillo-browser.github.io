/* This module contains the dw_page widget, which is the "back end" to
   Web text widgets including html. */

#ifndef __DW_PAGE_H__
#define __DW_PAGE_H__

#undef USE_TYPE1

#include <gdk/gdk.h>
#include "dw_container.h"
#include "url.h"

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#define DW_TYPE_PAGE            (a_Dw_page_get_type ())
#define DW_PAGE(obj)            GTK_CHECK_CAST ((obj), DW_TYPE_PAGE, DwPage)
#define DW_PAGE_CLASS(klass)    GTK_CHECK_CLASS_CAST ((klass), DW_TYPE_PAGE, \
                                   DwPageClass)
#define DW_IS_PAGE(obj)         GTK_CHECK_TYPE ((obj), DW_TYPE_PAGE)
#define DW_IS_PAGE_CLASS(klass) GTK_CHECK_CLASS_TYPE ((klass), DW_TYPE_PAGE)


typedef struct _DwPage        DwPage;
typedef struct _DwPageClass   DwPageClass;

/* Internal data structures (maybe shouldn't be in public .h file? */
typedef struct _DwPageLine   DwPageLine;
typedef struct _DwPageWord   DwPageWord;

/* these defines are DwPageAttr->flags
 * ALIGN_LEFT == ALIGN_RIGTH ==0  -> CENTER
 * ALIGN_LEFT == ALIGN_RIGTH ==1  -> JUSTIFIED */

struct _DwPageLine
{
   gint first_word;    /* first-word's position in DwPageWord [0 based] */
   gint last_word;     /* last-word's position in DwPageWord [1 based] */

   gint y_top, y_space;
   DwRequisition size;
   gboolean hard;      /* false = soft break, true = hard break */
   gboolean first;     /* true = first line in paragraph */
};

#define DW_PAGE_CONTENT_TEXT 0
#define DW_PAGE_CONTENT_WIDGET 1
#define DW_PAGE_CONTENT_ANCHOR 2

struct _DwPageWord {
   /* todo: perhaps add a x_left? */
   DwRequisition size;
   gint x_space; /* space after the word, only if it's not a break */
   
   /* This is a variant record (i.e. it could point to a widget 
    * instead of just being text). */
   gint content_type;
   union {
      char *text;
      DwWidget *widget;
      char *anchor;
   } content;
   
   DwStyle *style;
};


struct _DwPage
{
   DwContainer container;
   
   /* These values are set by set_... */
   gint32 avail_width, avail_ascent, avail_descent;

   /* The page width calculated by rewrapping / adding of words */
   gint32 real_width;

   /* the maximum width of the last line (assuming no word wrap) */
   gint32 last_line_max_width;
  
   DwPageLine *lines;
   gint num_lines;
   gint num_lines_max; /* number allocated */

   DwPageWord *words;
   gint current_word;  /* The word that is being added to the lines */
   gint num_words;
   gint num_words_max; /* number allocated */

   /* The link under a button press */
   gint link_pressed;
   
   /* The link under the button */
   gint hover_link;
   
   /* Dw** Parent; todo: Not needed in new Dw? */

};


struct _DwPageClass
{
   DwContainerClass parent_class;

   void (*link_entered)  (DwPage *page,
                          gint link, gint x, gint y);
   void (*link_pressed)  (DwPage *page,
                          gint link, gint x, gint y,
                          GdkEventButton *event);
   void (*link_released) (DwPage *page,
                          gint link, gint x, gint y,
                          GdkEventButton *event);
   void (*link_clicked)  (DwPage *page,
                          gint link, gint x, gint y,
                          GdkEventButton *event);
};


DwWidget*  a_Dw_page_new      (void);
GtkType    a_Dw_page_get_type (void);

void a_Dw_page_update_begin (DwPage *page);
void a_Dw_page_update_end (DwPage *page);
void a_Dw_page_add_text(DwPage *page, char *text, DwStyle *style);
void a_Dw_page_add_widget (DwPage *page,
                           DwWidget *widget,
                           DwStyle *style);
void a_Dw_page_add_anchor (DwPage *page, char *name, DwStyle *style);
void a_Dw_page_add_space(DwPage *page, DwStyle *style);
void a_Dw_page_linebreak (DwPage *page);
void a_Dw_page_parbreak (DwPage *page, gint space);

#ifdef __cplusplus
}
#endif /* __cplusplus */


#endif /* __DW_PAGE_H__ */
