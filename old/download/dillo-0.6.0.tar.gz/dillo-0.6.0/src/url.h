/*
 * File : url.h - Dillo
 *
 * Copyleft (C) 2001 Livio Baldini Soares <livio@linux.ime.usp.br>
 *              2001 Jorge Arellano Cid   <jcid@users.sourceforge.net>
 *
 * Parse and normalize all URL's inside Dillo.
 */

#ifndef __DILLO_URL_H__
#define __DILLO_URL_H__

#include <glib.h>


#define DILLO_URL_HTTP_PROTOCOL    "http"
#define DILLO_URL_HTTPS_PROTOCOL   "https"
#define DILLO_URL_ABOUT_PROTOCOL   "about"
#define DILLO_URL_FILE_PROTOCOL    "file"
#define DILLO_URL_FTP_PROTOCOL     "ftp"
#define DILLO_URL_MAILTO_PROTOCOL  "mailto"
#define DILLO_URL_NEWS_PROTOCOL    "news"
#define DILLO_URL_TELNET_PROTOCOL  "telnet"
#define DILLO_URL_GOPHER_PROTOCOL  "gopher"

#define DILLO_URL_HTTP_PORT        80
#define DILLO_URL_HTTPS_PORT       443
#define DILLO_URL_FTP_PORT         21
#define DILLO_URL_MAILTO_PORT      25
#define DILLO_URL_NEWS_PORT        119
#define DILLO_URL_TELNET_PORT      23
#define DILLO_URL_GOPHER_PORT      70

#define URN_OTHER  "()+,-.:=@;$_!*'/%?"

/* 
 * Values for DilloUrl->flags.
 * Specifies which which action to perform with this URL.
 */
#define URL_Get                 0x00000001
#define URL_Post                0x00000002
#define URL_ISindex             0x00000004
#define URL_Ismap               0x00000008
#define URL_RealmAccess         0x00000010

#define URL_E2EReload           0x00000020
#define URL_ReloadImages        0x00000040
#define URL_ReloadPage          0x00000080
#define URL_ReloadFromCache     0x00000100

#define URL_ReloadIncomplete    0x00000200

/* Access methods to access fields inside DilloURL */
#define URL_PROTO(u)    u->protocol
#define URL_HOST(u)     u->hostname
#define URL_PATH(u)     (u->path ? u->path->str : NULL)
#define URL_ANCHOR(u)   u->anchor
#define URL_PORT(u)     u->port
#define URL_FLAGS(u)    u->flags
#define URL_DATA(u)     u->data
#define URL_ALT(u)      u->alt
#define URL_POS(u)      u->scrolling_position
#define URL_STR(u)      (u->url_string ? u->url_string->str : NULL)

/* URL-camp compare methods */
#define URL_STRCAMP_EQ(s1,s2) \
   ((!(s1) && !(s2)) || ((s1) && (s2) && !strcmp(s1,s2)))
#define URL_STRCAMP_I_EQ(s1,s2) \
   ((!(s1) && !(s2)) || ((s1) && (s2) && !g_strcasecmp(s1,s2)))
#define URL_GSTRCAMP_EQ(s1,s2) \
   ((!(s1) && !(s2)) || ((s1) && (s2) && !strcmp((s1)->str,(s2)->str)))
#define URL_GSTRCAMP_I_EQ(s1,s2) \
   ((!(s1) && !(s2)) || ((s1) && (s2) && !g_strcasecmp((s1)->str,(s2)->str)))


typedef struct _DilloUrl DilloUrl;

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

struct _DilloUrl {
   GString *url_string;
   const gchar *protocol;
   const gchar *hostname;
   GString *path;
   const gchar *anchor; 
   gint port;
   gint flags;
   const gchar *data;              /* POST */
   const gchar *alt;               /* "alt" text (used by image maps) */
   gint ismap_url_len;             /* Used by server side image maps */
   gint ismap_path_len;            /* Used by server side image maps */
   gint scrolling_position;        /* remember position for history stack */
};

DilloUrl* a_Url_new(const gchar *url_str, const gchar *base_url, 
                    gint flags, gint pos);

void a_Url_free(DilloUrl *u);
DilloUrl* a_Url_dup(const DilloUrl *u);
gint a_Url_cmp(const DilloUrl* A, const DilloUrl* B);
gchar* a_Url_string_no_anchor(const DilloUrl *url);
void a_Url_set_flags(DilloUrl *u, gint flags);
void a_Url_set_data(DilloUrl *u, gchar *data);
void a_Url_set_alt(DilloUrl *u, gchar *alt);
void a_Url_set_pos(DilloUrl *u, gint pos);
void a_Url_set_ismap_coords(DilloUrl *u, gchar *coord_str);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __DILLO_URL_H__ */
