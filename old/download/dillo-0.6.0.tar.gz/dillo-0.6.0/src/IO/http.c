/*
 * File: http.c
 *
 * Copyright (C) 2000, 2001 Jorge Arellano Cid <jcid@inf.utfsm.cl>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

/*
 * HTTP connect functions
 */


#include <unistd.h>
#include <errno.h>              /* for errno */
#include <string.h>             /* for strstr */
#include <stdlib.h>
#include <signal.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <sys/socket.h>         /* for lots of socket stuff */
#include <netinet/in.h>         /* for ntohl and stuff */

#include "Url.h"
#include "IO.h"
#include "../dns.h"
#include "../cache.h"
#include "../web.h"
#include "../interface.h"

//#define DEBUG_LEVEL 5
#include "../debug.h"


/* 'Url' and 'Web' are just references (no need to deallocate them here). */
typedef struct {
   gint SockFD;
   const DilloUrl *Url;    /* reference to original URL */
   guint port;             /* need a separate port in order to support PROXY */
   gboolean use_proxy;     /* indicates whether to use proxy or not */
   DilloWeb *Web;          /* reference to client's Web structure */
   guint32 ip_addr;        /* Holds the DNS answer */
   GIOChannel *GioCh;      /* GIOChannel to monitor the connecting process */
   gint Err;               /* Holds the errno of the connect() call */
} SocketData_t;


/*
 * Local data
 */
GSList *ValidSocks = NULL;  /* Active sockets list. It holds pointers to
                             * SocketData_t structures. */


/*
 * Forward declarations
 */
static void Http_send_query(ChainLink *Info, SocketData_t *S);
static void Http_expect_answer(SocketData_t *S);


/*
 * Create and init a new SocketData_t struct
 */
SocketData_t *Http_sock_new(void)
{
   SocketData_t *S = g_new0(SocketData_t, 1);
   DEBUG_MSG(4, "ValidSocks = %p\n", ValidSocks);
   ValidSocks = g_slist_append(ValidSocks, (gpointer)S);
   return S;
}

/*
 * Validate a socket pointer
 */
gint Http_socket_valid(SocketData_t *S)
{
   return (g_slist_find(ValidSocks, S) != NULL);
}

/*
 * Free SocketData_t struct
 */
void Http_socket_free(SocketData_t *S)
{
   if (S->GioCh)
     g_io_channel_unref(S->GioCh);
   ValidSocks = g_slist_remove(ValidSocks, (gpointer)S);
   g_free(S);
}

/*
 * Make the http query string
 */
char *Http_query(const DilloUrl *url, gboolean use_proxy)
{
   gchar *str;
   GString *s_port    = g_string_new(""),
           *query     = g_string_new(""),
           *full_path = g_string_new("");

   /* Sending the default port in the query may cause a 302-answer.  --Jcid */
   if (URL_PORT(url) && URL_PORT(url) != DILLO_URL_HTTP_PORT)
      g_string_sprintfa(s_port, ":%d", URL_PORT(url));

   if (use_proxy) 
      g_string_sprintfa(full_path, "%s%s",
                        URL_STR(url), 
                        URL_PATH(url) ? "" : "/");
   else
      g_string_sprintfa(full_path, "%s%s",
                        URL_PATH(url) ? URL_PATH(url) : "/",
                        URL_ANCHOR(url) ? URL_ANCHOR(url) : "");

   if ( URL_FLAGS(url) & URL_Post ){
      g_string_sprintfa(
         query,
         "POST %s HTTP/1.0\r\n"
         "Host: %s%s\r\n"
         "User-Agent: Dillo/%s\r\n"
         "Content-type: application/x-www-form-urlencoded\r\n"
         "Content-length: %ld\r\n"
         "\r\n"
         "%s",
         full_path->str, URL_HOST(url), s_port->str, VERSION,
         (glong)strlen(URL_DATA(url)), URL_DATA(url));

   } else {
      g_string_sprintfa(
         query, 
         "GET %s HTTP/1.0\r\n"
         "%s"
         "Host: %s%s\r\n"
         "User-Agent: Dillo/%s\r\n"
         "\r\n",
         full_path->str, 
         (URL_FLAGS(url) & URL_E2EReload) ? 
            "Cache-Control: no-cache\r\nPragma: no-cache\r\n" : "",
         URL_HOST(url), s_port->str, VERSION);
   }

   str = query->str;
   g_string_free(query, FALSE);
   g_string_free(s_port, TRUE);
   g_string_free(full_path, TRUE);
   DEBUG_MSG(4, "Query:\n%s", str);
   return str;
}

/*
 * This function is called after the socket has been successfuly connected,
 * or upon an error condition on the connecting process.
 * Task: use the socket to send the HTTP-query and expect its answer
 */
static gboolean
 Http_use_socket(GIOChannel *src, GIOCondition cond, gpointer data)
{
   ChainLink *Info = data;
   SocketData_t *S = Info->LocalKey;

   DEBUG_MSG(3, "Http_use_socket: %s [errno %d] [GIOcond %d]\n",
             g_strerror(errno), errno, cond);

   if (!Http_socket_valid(S))
      return FALSE;

   if ( cond & G_IO_HUP ) {
      DEBUG_MSG(3, "--Connection broken\n");
      a_Interface_msg(S->Web->bw, "ERROR: unable to connect to remote host");
      a_Chain_fcb(OpAbort, 1, Info, NULL, NULL);
      Http_socket_free(S);
   } else if ( S->Err ) {
      a_Interface_msg(S->Web->bw, "ERROR: %s", g_strerror(S->Err));
      DEBUG_MSG(3, "Http_use_socket ERROR: %s\n", g_strerror(S->Err));
      a_Chain_fcb(OpAbort, 1, Info, NULL, NULL);
      g_io_channel_close(S->GioCh);
      Http_socket_free(S);
   } else if ( cond & G_IO_OUT ) {
      DEBUG_MSG(3, "--Connection established\n");
      g_io_channel_unref(S->GioCh);
      S->GioCh = NULL;
      Http_send_query(Info, S);
      Http_expect_answer(S);
      Http_socket_free(S);
   }
   return FALSE;
}

/*
 * This function gets called after the DNS succeeds solving a hostname.
 * Task: Finish socket setup and start connecting the socket.
 * Return value: 0 on success;  -1 on error.
 */
static int Http_connect_socket(ChainLink *Info)
{
   gint status;
   struct sockaddr_in name;
   SocketData_t *S = Info->LocalKey;

   /* Set remaining parms. */
   name.sin_family = AF_INET;
   name.sin_port = S->port ? htons(S->port) : htons(DILLO_URL_HTTP_PORT);
   name.sin_addr.s_addr = htonl(S->ip_addr);

   S->GioCh = g_io_channel_unix_new(S->SockFD);
   g_io_add_watch(S->GioCh, G_IO_ERR | G_IO_HUP | G_IO_OUT,
                  Http_use_socket, Info);
   status = connect(S->SockFD, (struct sockaddr *)&name, sizeof(name));
   if ( status == -1 && errno != EINPROGRESS ) {
      S->Err = errno;
      return -1;
   }
   return 0; /* Success */
}


/*
 * Create and submit the HTTP query to the IO engine
 */
static void Http_send_query(ChainLink *Info, SocketData_t *S)
{
   IOData_t *io;
   gchar *query;
   void *link;

   /* Create the query */
   query = Http_query(S->Url, S->use_proxy);

   /* send query */
   if ( S->Web->flags & WEB_RootUrl )
      a_Interface_msg(S->Web->bw, 
                         "Sending query to %s...", URL_HOST(S->Url));
   io = a_IO_new(S->SockFD);
   io->Op = IOWrite;
   io->IOVec.iov_base = query;
   io->IOVec.iov_len  = strlen(query);
   io->Flags |= IOFlag_FreeIOVec;
   io->ExtData = (void *) S->Web;
   link = a_Chain_link_new(a_Http_ccc, Info, CCC_FWD, a_IO_ccc);
   a_IO_ccc(OpStart, 1, link, io, NULL);
}

/*
 * Expect the HTTP query's answer
 */
static void Http_expect_answer(SocketData_t *S)
{
   IOData_t *io2;

   /* receive answer */
   io2 = a_IO_new(S->SockFD);
   io2->Op = IORead;
   io2->IOVec.iov_base = g_malloc(IOBufLen_Http);
   io2->IOVec.iov_len  = IOBufLen_Http;
   io2->Flags |= IOFlag_FreeIOVec;
   io2->ExtData = (void *) S->Url;
   a_IO_ccc(OpStart, 2, a_Chain_new(), io2, NULL);
}

/*
 * Asynchronously create a new http connection for 'Url'
 * We'll set some socket parameters; the rest will be set later 
 * when the IP is known.
 * ( Data = Requested Url; ExtraData = Web structure )
 */
void Http_get(ChainLink *Info, void *Data, void *ExtraData)
{
   void *link;
   const DilloUrl *Url = Data;
   SocketData_t *S = Http_sock_new();
   gchar hostname[256], *Host = hostname;

   /* keep track of this socket's data */
   Info->LocalKey = S;

   /* Reference Web data */
   S->Web = ExtraData;

   /* Hacked-in support for proxies */
   if (HTTP_Proxy && !(No_Proxy && strstr(URL_STR(Url), No_Proxy) != NULL)) {
      strncpy(hostname, URL_HOST(HTTP_Proxy), sizeof(hostname));
      S->port = URL_PORT(HTTP_Proxy);
      S->use_proxy = TRUE;
   } else {
      Host = (gchar *)URL_HOST(Url);
      S->port = URL_PORT(Url);
      S->use_proxy = FALSE;
   }

   /* Set more socket parameters */
   S->Url = Url;
   if ( (S->SockFD = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0 ) {
      /* Failed.. clean up */
      Http_socket_free(S);
      DEBUG_MSG(3, "Http_get ERROR: %s\n", g_strerror(errno));
      return;
   }
   /* set NONBLOCKING */
   fcntl(S->SockFD, F_SETFL, O_NONBLOCK | fcntl(S->SockFD, F_GETFL));

   /* Let the user know what we'll do */
   if ( S->Web->flags & WEB_RootUrl )
      a_Interface_msg(S->Web->bw, "DNS solving %s", URL_HOST(S->Url));

   /* Let the DNS engine solve the hostname, and when done,
    * we'll try to connect the socket */
   link = a_Chain_link_new(a_Http_ccc, Info, CCC_FWD, a_Dns_ccc);
   a_Dns_ccc(OpStart, 1, link, Host, NULL);
}

/*
 * CCC function for the HTTP module
 */
void 
 a_Http_ccc(int Op, int Branch, ChainLink *Info, void *Data, void *ExtraData)
{
   SocketData_t *S = Info->LocalKey;

   if ( Branch == 1 ) {
      /* DNS query branch */
      switch (Op) {
      case OpStart:
         Http_get(Info, Data, ExtraData);
         break;
      case OpSend:
         /* Successful DNS answer; save the IP */
         S->ip_addr = *(int *)Data;
         break;
      case OpEnd:
         /* Unlink DNS_Info */
         a_Chain_del_link(Info, CCC_BCK);
         /* start connecting the socket */
         Http_connect_socket(Info);
         break;

      case OpAbort:
         /* DNS wasn't able to resolve the hostname */
         /* Unlink DNS_Info */
         a_Chain_del_link(Info, CCC_BCK);
         a_Interface_msg(S->Web->bw, 
                            "ERROR: Dns can't solve %s", URL_HOST(S->Url));
         /* send abort message to higher-level functions */
         a_Chain_fcb(OpAbort, 1, Info, NULL, NULL);
         Http_socket_free(S);
         break;
      }

   } else if ( Branch == 2 ) {
      /* IO branch */
      IOData_t *io = Data;
      DilloWeb *web = io->ExtData;

      switch (Op) {
      case OpEnd:
         /* finished sending the HTTP query */
         /* unlink IO_Info */
         a_Chain_del_link(Info, CCC_BCK);
         if ( web->flags & WEB_RootUrl )
            a_Interface_msg(web->bw, "Query sent, waiting for reply...");
   
         a_Chain_fcb(OpEnd, 1, Info, NULL, NULL);
         break;
      case OpAbort:
         /* something bad happened... */
         /* unlink IO_Info */
         a_Chain_del_link(Info, CCC_BCK);
         a_Chain_fcb(OpAbort, 1, Info, NULL, NULL);
         break;
      }

   } else if ( Branch == -1 ) {
      /* Backwards abort */
      switch (Op) {
      case OpAbort:
         /* something bad happened... */
         a_Chain_bcb(OpAbort, -1, Info, NULL, NULL);
         Http_socket_free(S);
         g_free(Info);
         break;
      }
   }
}

/*
 * Deallocate memory used by http module
 * (Call this one at exit time)
 */
void a_Http_freeall(void)
{
}


