#ifndef __DW_H__
#define __DW_H__

#include <gdk/gdktypes.h>

void a_Dw_init    (void);
void a_Dw_freeall (void);

/* Needed at several points. */
extern GdkCursor *Dw_cursor_hand;


#endif /* __DW_H__ */
