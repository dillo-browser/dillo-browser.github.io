/*
 * File: commands.c
 *
 * Copyright (C) 1997 Raph Levien <raph@acm.org>
 * Copyright (C) 1999 Sammy Mannaert <nstalkie@tvd.be>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

#include <gtk/gtk.h>
#include <stdio.h>              /* for sprintf */
#include <sys/time.h>           /* for gettimeofday (testing gorp only) */
#include <unistd.h>
#include <string.h>             /* for strcat() */

#include "browser.h"
#include "bookmark.h"
#include "interface.h"
#include "dillo.h"
#include "cache.h"
#include "nav.h"
#include "misc.h"


/* define pi */
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif                          /*  M_PI  */

/* DILLO MENU */

/*
 * ?
 */
void a_Commands_new_callback(GtkWidget *widget, gpointer client_data)
{
   a_Interface_new_browser_window();
}

/*
 * ?
 */
void a_Commands_openfile_callback(GtkWidget *widget, gpointer client_data)
{
   BrowserWindow *bw = (BrowserWindow *) client_data;

   a_Interface_openfile_dialog(bw);
}

/*
 * ?
 */
void a_Commands_openurl_callback(GtkWidget *widget, gpointer client_data)
{
   BrowserWindow *bw = (BrowserWindow *) client_data;

   a_Interface_open_dialog(widget, bw);
}

/*
 * ?
 */
void a_Commands_prefs_callback(GtkWidget *widget, gpointer client_data)
{
}

/*
 * ?
 */
void a_Commands_close_callback(GtkWidget *widget, gpointer client_data)
{
}

/*
 * ?
 */
void a_Commands_exit_callback(GtkWidget *widget, gpointer client_data)
{
#ifdef ASK_REALLY_QUIT
   BrowserWindow *bw = (BrowserWindow *) client_data;

   a_Interface_quit_dialog(bw);
#else
   /* There should be a close command that does this: */
   /* gtk_widget_destroy (bw->main_window); */
   a_Interface_quit_all();
#endif
}


/* DOCUMENT MENU */

/*
 * Show current page's source code. 
 */
void a_Commands_viewsource_callback (GtkWidget *widget, gpointer client_data)
{
   BrowserWindow *bw = (BrowserWindow *) client_data;
   char *buf, url[1024];
   int size;
   static GtkWidget *window = NULL;
   GtkEntry *entry_url;
   GtkWidget *box1;
   GtkWidget *button;
   GtkWidget *scrolled_window;
   GtkWidget *text;
   
   /* -RL :: This code is adapted from testgtk. */
   if ( !window ) {
      window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
      gtk_widget_set_name (window, "text window");
      gtk_widget_set_usize (window, 500, 500);
      gtk_window_set_policy (GTK_WINDOW(window), TRUE, TRUE, FALSE);
      
      gtk_signal_connect (GTK_OBJECT (window), "destroy",
                          GTK_SIGNAL_FUNC(gtk_widget_destroyed),
                          &window);
      
      gtk_window_set_title (GTK_WINDOW (window), "View Source");
      gtk_container_set_border_width (GTK_CONTAINER (window), 0);
      
      box1 = gtk_vbox_new (FALSE, 0);
      gtk_container_add (GTK_CONTAINER (window), box1);
      gtk_widget_show (box1);
            
      scrolled_window = gtk_scrolled_window_new (NULL, NULL);
      gtk_box_pack_start (GTK_BOX (box1), scrolled_window, TRUE, TRUE, 0);
      gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (scrolled_window),
                                      GTK_POLICY_NEVER,
                                      GTK_POLICY_ALWAYS);
      gtk_widget_show (scrolled_window);
  
      text = gtk_text_new (NULL, NULL);
      gtk_text_set_editable (GTK_TEXT (text), FALSE);
      gtk_container_add (GTK_CONTAINER (scrolled_window), text);
      gtk_widget_show (text);
      
      gtk_text_freeze (GTK_TEXT (text));
      
      entry_url = GTK_ENTRY (bw->location);
      strcpy(url, gtk_entry_get_text(entry_url));

      buf = a_Cache_url_read (url, &size);

      gtk_text_insert (GTK_TEXT (text), NULL, NULL,
                       NULL, buf, size);
      gtk_text_thaw (GTK_TEXT (text));
      
      button = gtk_button_new_with_label ("close");
      gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
                                 GTK_SIGNAL_FUNC(gtk_widget_destroy),
                                 GTK_OBJECT (window));
      gtk_box_pack_start (GTK_BOX (box1), button, FALSE, FALSE, 0);
      GTK_WIDGET_SET_FLAGS (button, GTK_CAN_DEFAULT);
      gtk_widget_grab_default (button);
      gtk_widget_show (button);
   }
   
   if (!GTK_WIDGET_VISIBLE (window))
      gtk_widget_show (window);
   else
      gtk_widget_destroy (window);
}

/*
 * ?
 */
void a_Commands_selectall_callback(GtkWidget *widget, gpointer client_data)
{
}

/*
 * ?
 */
void a_Commands_findtext_callback(GtkWidget *widget, gpointer client_data)
{
}

/*
 * Print the page!
 * ('cat page.html | html2ps | lpr -Pcool'   Why bother?  I think providing
 * such an option in a configurable way should cut it  --Jcid)
 */
void a_Commands_print_callback(GtkWidget *widget, gpointer client_data)
{
}


/* BROWSE MENU */

/*
 * Aborts all active FD transfers and bytesink (or imgsink) related stuff
 */
void a_Commands_stop_callback(GtkWidget *widget, gpointer client_data)
{
   a_Nav_cancel_expect((BrowserWindow *) client_data);
   a_Interface_abort_all((BrowserWindow *) client_data);
}

/*
 *  Back to previous page
 */ 
void a_Commands_back_callback(GtkWidget *widget, gpointer client_data)
{
   BrowserWindow *bw = (BrowserWindow *) client_data;

   a_Nav_back(bw);
}

/*
 * Go to the next page in the history buffer
 */
void a_Commands_forw_callback(GtkWidget *widget, gpointer client_data)
{
   BrowserWindow *bw = (BrowserWindow *) client_data;

   a_Nav_forw(bw);
}

/*
 * Start the reload process
 * (This is not working)
 */
void a_Commands_reload_callback(GtkWidget *widget, gpointer client_data)
{
   BrowserWindow *bw = (BrowserWindow *) client_data;

   a_Nav_reload(bw);
}

/*
 * Go home!
 */
void a_Commands_home_callback(GtkWidget *widget, gpointer client_data)
{
   BrowserWindow *bw = (BrowserWindow *) client_data;

   a_Nav_home(bw);
}

/*
 * Bring up the save dialog-widget
 */
void a_Commands_save_callback(GtkWidget *widget, gpointer client_data)
{
   BrowserWindow *bw = (BrowserWindow *) client_data;

   a_Interface_save_dialog(widget, bw);
}


/* BOOKMARKS MENU */

/*
 * Add a bookmark to the current bookmark widget.
 */
void a_Commands_addbm_callback(GtkWidget *widget, gpointer client_data)
{
   a_Bookmarks_add(widget, client_data);
}

#include <stdlib.h>             /* -RL :: HACK - for getenv */
/*
 * Show the bookmarks-file as rendered html
 */
void a_Commands_viewbm_callback(GtkWidget *widget, gpointer client_data)
{
   BrowserWindow *bw = (BrowserWindow *) client_data;
   char *bmfile;
   char *url; 
   char *buf;
        
   bmfile = a_Misc_prepend_user_home (".dillo/bookmarks.html");
   /*  -RL :: strlen ("file:/")  is  6 */
   url = g_malloc (strlen (bmfile) + 6);
   strcpy (url, "file:/");
   strcat (url, bmfile);
        
   /* -RL :: HACK - todo: add a TITLE tag in bookmarks.html */
   buf = g_malloc (strlen (getenv ("USER")) + 20);
   sprintf (buf, "Bookmarks for %s", getenv("USER"));
   a_Interface_set_Page_title (bw, buf);
   g_free (buf);
   /* END HACK*/

   a_Nav_push (bw, url);

   g_free (bmfile);
   g_free (url);
}


/* HELP MENU */

/*
 * This one was intended as a link to help-info on the web site, but
 * currently points to the home page  --Jcid
 */
void a_Commands_helphome_callback(GtkWidget *widget, gpointer client_data)
{
   BrowserWindow *bw = (BrowserWindow *) client_data;

   a_Nav_push(bw, DILLO_HOME);
}

/*
 * ?
 */
void a_Commands_manual_callback(GtkWidget *widget, gpointer client_data)
{
   /* CP: Uncomment this when the feature is implemented. :)
    * BrowserWindow *bw = (BrowserWindow *)client_data;
    * a_Nav_push (bw, "file:/usr/local/man/man1/dillo.man | groff -man");
    */
}


/* RIGHT BUTTON POP-UP MENU */

/*
 * Open link in another browser-window
 */
void a_Commands_open_link_nw_callback(GtkWidget *widget, gpointer client_data)
{
   BrowserWindow *newbw;

   newbw = a_Interface_new_browser_window();
   a_Nav_push(newbw, menu_popup.info.url);
}
 
