#ifndef __DILLO_IMG_SINK_H__
#define __DILLO_IMG_SINK_H__

/* The DilloImgSink data structure and methods. */

#include <gdk/gdk.h>
#include <gtk/gtk.h>
#include "dw.h"
#include "dw_image.h"
#include "dw_page.h"

typedef struct _DilloImgSink DilloImgSink;

typedef enum {
  DILLO_IMG_TYPE_INDEXED,
  DILLO_IMG_TYPE_RGB,
  DILLO_IMG_TYPE_GRAY,
  DILLO_IMG_TYPE_NOTSET    /* Initial value */
} DilloImgType;

struct _DilloImgSink {
  DilloImgSink** Parent;
  DwImage* dw;
  /* parameters of the preview widget */
  gint width;
  gint height;
  /* parameters of the input imgsink */
  gint in_width;
  gint in_height;

  guchar *cmap;
  DilloImgType in_type;

  /* alt goes here if we implement it */
  gint32 bg_color;

  int RefCount;
  void (* write) (DilloImgSink *imgsink,
                  const unsigned char *buf,
                  int x,
                  int y);
  void (* close) (DilloImgSink *imgsink);
  void (* set_parms) (DilloImgSink *imgsink,
                      int width,
                      int height,
                      DilloImgType type);
  void (* set_cmap) (DilloImgSink *imgsink,
                     const unsigned char *cmap,
                     int num_colors,
                     int bg_index);

  void (*close_handler) (void *data, DilloImgSink *imgsink);
  void *close_data;
};


/*
 * Function prototypes (imgsink.c)
 */
DilloImgSink *a_Imgsink_new (DilloImgSink *imgs);
void a_Imgsink_set_parms (DilloImgSink *imgsink,
                          int width,
                          int height,
                          DilloImgType type);
void a_Imgsink_set_cmap  (DilloImgSink *imgsink,
                          const unsigned char *cmap,
                          int num_colors,
                          int bg_index);
void a_Imgsink_write (DilloImgSink *imgsink,
                      const unsigned char *buf,
                      gint x,
                      gint y);
void a_Imgsink_close (DilloImgSink *imgsink);

/* low-tech signal handlers for close and abort signals */
void a_Imgsink_set_close_handler (DilloImgSink *imgsink,
                    void (*close_handler) (void *data, DilloImgSink *imgsink),
                    void *data);



/*
 * Function prototypes (image.c)
 */
DilloImgSink *a_Image_new (gint width,
                           gint height,
                           const char *alt,
                           gint32 bg_color);
void a_Image_set_parms (DilloImgSink *imgsink,
                        gint width,
                        gint height,
                        DilloImgType type);
void _a_Image_write (DilloImgSink *imgsink,
                    const unsigned char* linebuf,
                    gint x0, gint y,
                    DwImage** dws, int NDws);
void a_Image_close (DilloImgSink *imgsink);
void a_Image_set_cmap (DilloImgSink* imgsink,
                       const unsigned char *cmap,
                       gint num_colors,
                       gint bg_index);

/* Note: the imgsink methods are always called in the following order:
   set_parms
   set_cmap, iff type in set_parms call was DILLO_IMG_TYPE_INDEXED
   write, any number of times
   close | abort

   The close and abort methods are responsible for freeing all
   internal state and the imgsink itself. */

#endif /* __DILLO_IMG_SINK__ */
