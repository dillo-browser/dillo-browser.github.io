/*
 * File: dw_border.c
 *
 * Copyright (C) 1997 Raph Levien <raph@acm.org>
 * Copyright (C) 1999 Jorge Arellano Cid <jcid@inf.utfsm.cl>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

#include <gtk/gtk.h>
#include "dw.h"
#include "dw_border.h"

/*
 * ?
 */
static void Dw_border_size_nego_x (Dw *dw, gint width)
{
  gint border;

  border = ((DwBorder *)dw)->border;
  a_Dw_size_nego_x (((DwBorder *)dw)->child, width - border * 2);
  dw->req_height = ((DwBorder *)dw)->child->req_height + border * 2;
  dw->req_ascent = ((DwBorder *)dw)->child->req_ascent + border * 2;
}

/*
 * ?
 */
static void Dw_border_size_nego_y (Dw *dw, DwRect *allocation)
{
  DwRect child_allocation;
  gint border;
  DwRect repaint;

  border = ((DwBorder *)dw)->border;

  /* Request incremental repaints. */
  if (allocation->x0 == dw->allocation.x0 &&
      allocation->y0 == dw->allocation.y0)
    {
      if (allocation->x1 != dw->allocation.x1)
        {
          repaint.x0 = MIN (allocation->x1, dw->allocation.x1) - border;
          repaint.y0 = allocation->y0;
          repaint.x1 = allocation->x1;
          repaint.y1 = allocation->y1;
          a_Dw_request_paint (dw, &repaint);
        }
      if (allocation->y1 != dw->allocation.y1)
        {
          repaint.x0 = allocation->x0;
          repaint.y0 = MIN (allocation->y1, dw->allocation.y1) - border;
          repaint.x1 = allocation->x1;
          repaint.y1 = allocation->y1;
#ifdef VERBOSE
          g_print ("dw_border_size_nego_y: request (%d, %d) - (%d, %d)\n",
                   repaint.x0,
                   repaint.y0,
                   repaint.x1,
                   repaint.y1);
#endif
          a_Dw_request_paint (dw, &repaint);
        }
    }

  dw->allocation = *allocation;
  child_allocation.x0 = allocation->x0 + border;
  child_allocation.x1 = allocation->x1 - border;
  child_allocation.y0 = allocation->y0 + border;
  child_allocation.y1 = allocation->y1 - border;
  a_Dw_size_nego_y (((DwBorder *)dw)->child, &child_allocation);
}

/*
 * ?
 */
static void Dw_border_paint (Dw *dw, DwRect *rect, DwPaint *paint)
{
  GtkWidget *widget;
  DwContainer *container;
  DwRect child_rect;

#ifdef VERBOSE
  g_print ("dw_border_paint (%d, %d) - (%d, %d)",
           rect->x0, rect->y0, rect->x1, rect->y1);
#endif
  container = a_Dw_find_container (dw);
  if (container != NULL)
    {
#ifdef VERBOSE
      g_print (", visible = (%d, %d) - (%d, %d)\n",
               container->visible.x0, container->visible.y0,
               container->visible.x1, container->visible.y1);
#endif
      widget = container->widget;
      a_Dw_paint_to_screen (widget, container, rect, paint);
      a_Dw_rect_intersect (&child_rect, rect,
                          &((DwBorder *)dw)->child->allocation);
      if (!a_Dw_rect_empty (&child_rect))
        {
          a_Dw_paint (((DwBorder *)dw)->child, &child_rect, paint);
          a_Dw_paint_to_screen (widget, container, &child_rect, paint);
        }
      a_Dw_paint_finish_screen (paint);
    }
#ifdef VERBOSE
  else
    g_print ("\n");
#endif
}

/*
 * ?
 */
static void Dw_border_handle_event (Dw *dw, GdkEvent *event)
{
  a_Dw_handle_event (((DwBorder *)dw)->child, event);
}

/*
 * ?
 */
static void Dw_border_gtk_foreach (Dw *dw, 
                                   DwCallback callback, gpointer callback_data,
                                   DwRect *plus, DwRect *minus)
{
  a_Dw_gtk_foreach (((DwBorder *)dw)->child, callback, callback_data,
                   plus, minus);
}

/*
 * ?
 */
static void Dw_border_destroy (Dw *dw)
{
  a_Dw_destroy (((DwBorder *)dw)->child);
  g_free (dw);
}

/*
 * ?
 */
static void Dw_border_request_resize (Dw *dw, Dw *child)
{
  gint border;

  border = ((DwBorder *)dw)->border;
  dw->req_width_min = ((DwBorder *)dw)->child->req_width_min + border * 2;
  dw->req_width_max = ((DwBorder *)dw)->child->req_width_max + border * 2;
  a_Dw_request_parent_resize (dw);
}

/*
 * ?
 */
static const DwClass Dw_border_class =
{
  Dw_border_size_nego_x,
  Dw_border_size_nego_y,
  Dw_border_paint,
  Dw_border_handle_event,
  Dw_border_gtk_foreach,
  Dw_border_destroy,
  Dw_border_request_resize
};

/*
 * ?
 */
Dw *a_Dw_border_new (Dw *child, gint border)
{
  DwBorder *Dw_border;
  DwRect null_rect = {0, 0, 0, 0};

  Dw_border = g_new (DwBorder, 1);
  Dw_border->dw.klass = &Dw_border_class;
  Dw_border->dw.allocation = null_rect;
  Dw_border->dw.req_width_min = child->req_width_min + border * 2;
  Dw_border->dw.req_width_max = child->req_width_max + border * 2;
  Dw_border->dw.flags = child->flags &
    (DW_FLAG_BASELINE | DW_FLAG_GTK_EMBED);
  Dw_border->dw.parent = NULL;
  Dw_border->dw.container = NULL;

  Dw_border->child = child;
  Dw_border->border = border;

  child->parent = (Dw *)Dw_border;

  return (Dw *)Dw_border;
}
