/*
 * File: Url.c
 *
 * Copyright (C) 1997 Raph Levien <raph@acm.org>
 * Copyright (C) 1999 Randall Maas <randym@acm.org>,
 *                    Jorge Arellano Cid <jcid@inf.utfsm.cl>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

/*
 * URL modules  Randall Maas 1999
 */

/* Heavily rearranged by Jcid, Dec 1999. */

#include <glib.h>
#include <stdlib.h>
#include "../list.h"
#include "Url.h"
#include "../prefs.h"

/*
 * Local data
 */
char *HTTP_Proxy = NULL, *No_Proxy = NULL;

static int N_UrlOpeners = 0, Max_UrlOpeners = 8;
static __Open_t *UrlOpeners = NULL;


int N_UrlMethods = 0, Max_UrlMethods = 0;
void *UrlMethods = NULL;

/*
 * Forward declarations
 */
int a_Url_open(const char *url, void *Data);
int Url_add_opener(__Open_t F);
int Url_open(const char *url, void *Data);

/*
 * ?
 */
int Url_add_method(const char *Key, __Open_t Method)
{
   return a_Hdlr_add(&UrlMethods, &N_UrlMethods, &Max_UrlMethods, Key, Method);
}

/*
 * Searches the Url methods list and returns the matching one
 * (UrlMethods list is not the UrlOpeners list. Don't be confused)
 */
__Open_t Url_proto_fetch(const char *Key, size_t Size)
{
   return (__Open_t) a_Hdlr_fetch(UrlMethods, N_UrlMethods, Key, Size);
}

/*
 * This identifies the method specified in the URL.  
 * On success, Method is set to point the start of the method string; it is
 * NOT a zero terminated string.
 * 
 * Return Value:
 *   < 1 on error, otherwise the length of the method string.
 */
ssize_t Url_proto_parse(const char *URL, const char **Method)
{

   char *EPtr = strpbrk(URL, URN_OTHER);

   if (!EPtr || *EPtr != ':')
      return 0;
   *Method = URL;

   return (unsigned long) EPtr - (unsigned long) URL;
}

/*
 * This routine checks to see if the URL passed is of the absolute form, or
 * of the relative form
 * 
 * Return Value:
 *   0 is not absolute, otherwise is absolute
 */
int a_Url_is_absolute(const char *url)
{
   const char *P = strpbrk(url, URN_OTHER);

   return (P && *P == ':');
}

/*
 * Parse "http://a/b#c" into "http://a/b" and "#c".
 * 
 * Return Value:
 *   a pointer to the hash (if any), otherwise NULL.
 */
char* a_Url_parse_hash(const char *URL)
{

   /* todo: I haven't checked this for standards compliance. What's it
    * supposed to do when there are two hashes? */

   return strchr(URL, '#');
}

/*
 * Sets the handler methods for the different protocols supported by Dillo
 */
int a_Url_init(void)
{
   HTTP_Proxy = getenv("http_proxy");
   No_Proxy = getenv("no_proxy");
   if (Url_add_opener(a_Proto_get_url) ||
       Url_add_opener(Url_open) ||
       Url_add_method("file", a_File_get) ||
       Url_add_method("about", a_About_get) ||
       Url_add_method("http", a_Http_get))
      return -1;
   return 0;
}

/*
 * Adds method 'F' to the list of URL openers. 
 * UrlOpeners are called in LIFO order until success.
 * [
 *   - 'F' will be called before any others are attempted.
 *   - 'F' needs to return -1 if it fails;
 *   - 'F' must ensure that it closes the FD_TypeWriter when it's done with it
 * ]
 * Return Value
 *   -1 on error, 0 otherwise
 */
int Url_add_opener(__Open_t F)
{
   a_List_add(UrlOpeners, N_UrlOpeners, sizeof(__Open_t *), Max_UrlOpeners);
   UrlOpeners[N_UrlOpeners] = F;
   N_UrlOpeners++;
   return 0;
}

/*
 * Create a new connection for URL 'url', and asynchronously feed the bytes
 * that come back to bytesink. 
 *
 * Return Value:
 *   < 0 on error, otherwise the file descriptor to get the data from
 */
int Url_open(const char *url, void *Data)
{
   const char *Method;
   ssize_t Size;
   __Open_t MPtr;

   /* Use the method to figure out what to do */
   Method = NULL;
   Size = Url_proto_parse(url, &Method);
   if (Size < 1)
      return -1;

   /* Scan our method tree to see if there is anything. */
   if (!(MPtr = Url_proto_fetch(Method, Size)))
      return -1;
   return MPtr(url, Data);

   return -1;
}

/*
 * Attempt to open the URL.
 * Try to open it using the URL openers in LIFO order.
 * (URL openers are stored in 'UrlOpeners')
 * Return Value:
 *   < 0 on error, otherwise a file descriptor for retrieving data
 * Side effect:
 *   The file descriptor is set to background IO
 */
int a_Url_open(const char *Url, void *Data)
{
   int i, FD;

   /* LIFO search */
   for (i = N_UrlOpeners - 1; i >= 0; i--) {
      FD = (UrlOpeners[i]) (Url, Data);
      if (FD < 0)
         continue;
      return FD;
   }
   return -1;
}

