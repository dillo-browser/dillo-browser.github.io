/*
 * File: proto.c
 *
 * Copyright (C) 1997 Raph Levien <raph@acm.org>
 * Copyright (C) 1999 Jorge Arellano Cid <jcid@inf.utfsm.cl>,
 *                    Luca Rota <drake@freemail.it>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>              /* for errno */
#include <signal.h>

#include <sys/types.h>
#include <sys/wait.h>
#include "../web.h"

/* This module handles the Dillo plug-in api. */

/* todo: get abort to work. */

typedef struct _DilloProto DilloProto;

struct _DilloProto {
   const char *prefix;
   const char *handler;
};

static DilloProto plugins[] = {
   {"test:", "get_test"},
   {"ftp:", "/usr/local/bin/dillo_ftp"}
};

/* 
 * Compares the url's prefix with the plugins' prefix
 */
static int Proto_prefix(const char *url, const char *prefix)
{
   return !strncmp(url, prefix, strlen(prefix));
}

/* 
 * Find the plugin number to handle a given URL, or -1 if there is no
 * plugin for it.
 */
static int Proto_find(const char *url)
{
   int i;

   for (i = 0; i < sizeof(plugins) / sizeof(DilloProto); i++)
      if (Proto_prefix(url, plugins[i].prefix))
         return i;
   return -1;
}

#define MAX_ENV 32

/* 
 * Build a simple environment with PATH and REQUEST_URI for the execle() call
 */
static void Proto_build_env(char **env, const char *url)
{
   char *PATH = getenv("PATH");

   env[0] = g_strconcat("PATH=", PATH, NULL);
   env[1] = g_strconcat("REQUEST_URI=", url, NULL);
   env[2] = NULL;
}

/* 
 * Search the right handler for the given url, and then execute the plugin
 */
int a_Proto_get_url(const char *url, void *Data)
{
   char *env[MAX_ENV];
   pid_t child_pid;
   int filedes[2];
   int proto_num = Proto_find(url);

   if (proto_num < 0)
      return -1;

   Proto_build_env(env, url);

   if (pipe(filedes) != 0)
      return -1;

   if ((child_pid = fork()) < 0)
      return -1;

   if (!child_pid) {
      /* this is the child */

      signal(SIGCHLD, _exit);
      signal(SIGPIPE, _exit);

      /* redirect stdout to the pipe we just created */
      close(filedes[0]);        /* close read end */
      if (filedes[1] != STDOUT_FILENO) {
         if (dup2(filedes[1], STDOUT_FILENO) != STDOUT_FILENO) {
            g_warning("ERROR in dup2 call for stdout\n");
            _exit(-1);
         }
         close(filedes[1]);     /* don't need this after dup2 */
      }

      execle(plugins[proto_num].handler, plugins[proto_num].handler,
             (char *) NULL, env);
      g_warning("Error in exec call\n");
      _exit(-1);
   }
   /* this is the parent */

   /* set nonblocking */
   fcntl(filedes[0], F_SETFL, O_NONBLOCK | fcntl(filedes[0], F_GETFL));

   /* set close-on-exec */
   fcntl(filedes[0], F_SETFD, FD_CLOEXEC | fcntl(filedes[0], F_GETFD));

   close(filedes[1]);           /* close write end */
   g_free(env[0]);
   g_free(env[1]);
   return filedes[0];
}
