#ifndef __DILLO_H__
#define __DILLO_H__

#include "browser.h"
#include "web.h"
#include "MIME/mime.h"

#define Dillo_idle_add(a,b) gtk_idle_add((GtkFunction)a,b)

#define DILLO_HOME "http://academico.inf.utfsm.cl:81/~jcid/Dillo/project.html"

#endif /* __DILLO_H__ */
