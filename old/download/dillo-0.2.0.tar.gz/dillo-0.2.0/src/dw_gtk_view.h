
#ifndef __GTK_DW_VIEW_H__
#define __GTK_DW_VIEW_H__

/* Need to include "dw.h" before this file. */

#include "dw_region.h"

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#define GTK_DW_VIEW(obj)           GTK_CHECK_CAST (obj, Dw_gtk_view_get_type (), GtkDwView)
#define GTK_DW_VIEW_CLASS(klass)   GTK_CHECK_CLASS_CAST (klass, Dw_gtk_view_get_type (), GtkDwViewClass)
#define GTK_IS_DW_VIEW(obj)        GTK_CHECK_TYPE (obj, Dw_gtk_view_get_type ())

typedef struct _GtkDwView        GtkDwView;
typedef struct _GtkDwViewClass   GtkDwViewClass;

struct _GtkDwView {
  GtkContainer container;

  /* stuff borrowed from gtkviewport.h */

  gint shadow_type;
  GdkWindow *main_window; /* same as gtkviewport - probably superfluous! */
  GdkWindow *view_window; /* same as gtkviewport */
  GtkAdjustment *hadjustment;
  GtkAdjustment *vadjustment;

  /* The dw that's contained in this widget. */
  Dw *dw;

  /* The container data structure for this scroller. */
  DwContainer *dw_container;

  /* The region that's requested a repaint. */
  DwRegion *repaint_region;

  gint repaint_idle_tag;
};

struct _GtkDwViewClass
{
  GtkContainerClass parent_class;
};


guint      Dw_gtk_view_get_type  (void);
GtkWidget* a_Dw_gtk_view_new       (GtkAdjustment *hadjustment,
				       GtkAdjustment *vadjustment);
void       a_Dw_gtk_view_set_dw   (GtkDwView *dw_view,
				       Dw *dw);
GtkAdjustment* a_Dw_gtk_view_get_hadjustment (GtkDwView   *dw_view);
GtkAdjustment* a_Dw_gtk_view_get_vadjustment (GtkDwView   *dw_view);


#ifdef __cplusplus
}
#endif /* __cplusplus */


#endif /* __GTK_DW_VIEW_H__ */
