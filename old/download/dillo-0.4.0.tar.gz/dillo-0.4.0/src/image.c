/*
 * File: image.c
 *
 * Copyright (C) 1997 Raph Levien <raph@acm.org>
 * Copyright (C) 1999 James McCollough <jamesm@gtwn.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

/*
 * This file implements image data transfer methods. It handles the transfer
 * of data from an Image to a DwImage widget.
 */

#include <gtk/gtk.h>
#include <stdio.h>
#include <string.h>

#include "image.h"

/*
 * Local data
 */
static size_t linebuf_size = 0;
static guchar *linebuf = NULL;


/*
 * Decode 'buf' (an image line) into RGB format.
 */
static void
 Image_line(DilloImage *Image, const guchar *buf, const guchar *cmap, gint y)
{
   guint x, width, in_width;

   width = Image->width;
   in_width = Image->in_width;

   switch (Image->in_type) {
   case DILLO_IMG_TYPE_INDEXED:
      if (width == in_width) {
         for (x = 0; x < width; x++)
            memcpy(linebuf + x * 3, cmap + buf[x] * 3, 3);
      } else {
         /* could use DDA here if speed were an issue */
         for (x = 0; x < width; x++)
            memcpy(linebuf + x * 3, cmap + buf[x * in_width/width] * 3, 3);
      }
      break;
   case DILLO_IMG_TYPE_GRAY:
      if (width == in_width) {
         for (x = 0; x < width; x++)
            memset(linebuf + x * 3, buf[x], 3);
      } else {
         /* could use DDA here if speed were an issue */
         for (x = 0; x < width; x++)
            memset(linebuf + x * 3, buf[x * in_width/width], 3);
      }
      break;
   case DILLO_IMG_TYPE_RGB:
      if (width == in_width) {
         /* could avoid memcpy here, if clever. For example, return a
          * boolean to indicate whether to use linebuf or the inputbuf. */
         memcpy(linebuf, buf, width * 3);
      } else {
         /* could use DDA here if speed were an issue */
         for (x = 0; x < width; x++)
            memcpy(linebuf + x*3, buf + x * in_width/width * 3, in_width * 3);
      }
      break;
   case DILLO_IMG_TYPE_NOTSET:
      g_warning("ERROR: Image type not set...\n");
      break;
   }
}

/*
 * Implement the write method
 */
void a_Image_write(DilloImage *Image, const guchar *buf, gint x0, guint y)
{
   g_return_if_fail ( y < Image->height );

   /* Decode buf into linebuf */
   Image_line(Image, buf, Image->cmap, y);

   /* Merge linebuf into the image buffer */
   a_Dw_image_draw_row(Image->dw, linebuf, Image->width, Image->height, 0, y);
}

/*
 * Implement the close method
 */
void a_Image_close(DilloImage *Image)
{
   if (Image->alt)
     g_free(Image->alt);
   g_free(Image);
}

/*
 * Set some parameters of the image
 */
void a_Image_set_parms(DilloImage *Image, guint width, guint height,
                       DilloImgType type)
{
   Image->in_type = type;
   Image->in_width = Image->width = width;
   Image->in_height = Image->height = height;
   if (3 * width > linebuf_size) {
      linebuf_size = 3 * width;
      linebuf = g_realloc(linebuf, linebuf_size);
   }
   a_Dw_image_size(Image->dw, width, height);
}

/*
 * Reference the dicache entry color map
 */
void a_Image_set_cmap(DilloImage *Image, const guchar *cmap)
{
   Image->cmap = cmap;
}

/*
 * Create and initialize a new image structure.
 */
DilloImage *
 a_Image_new(gint width, gint height, const char *alt, gint32 bg_color)
{
   DilloImage *Image;

   Image = g_new(DilloImage, 1);
   Image->dw = (DwImage *) a_Dw_image_new(DW_IMAGE_RGB);
   Image->width = Image->in_width = 0;
   Image->height = Image->in_height = 0;
   Image->cmap = NULL;
   Image->in_type = DILLO_IMG_TYPE_NOTSET;
   Image->alt = (alt) ? g_strdup(alt) : NULL;
   Image->bg_color = bg_color;
   Image->ProcessedBytes = 0;

   return Image;
}
