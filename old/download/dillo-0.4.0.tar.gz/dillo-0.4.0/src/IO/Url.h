/*
 * URL methods  Randall Maas  1999
 */

/* Heavily modified by Jcid, Dec 1999 & Jun 2000 */

#ifndef __Url_h__
#define __Url_h__

#include "../../config.h"
#include <glib.h>
#include <stdio.h> /* for sprintf */
#include <ctype.h>
#include <string.h>
#include <unistd.h>
#include "IO.h"

#define URN_OTHER  "()+,-.:=@;$_!*'/%?"

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/* Returns a file descriptor to read data on; meta data is sent on FD_TypeWrite */
typedef gint (*__Open_t) (const char *url, void *data);

/*
 * Module functions
 */
gint  a_Url_init (void);
gint  a_Url_open (const char *url, void* Callback_Data);
gint  a_Url_is_absolute (const char *url);
char* a_Url_parse_hash  (const char *url);
char* a_Url_squeeze(char *str);
gchar* a_Url_resolve_relative(const char *BaseUrl, const char *RelativeUrl);
char* a_Url_parse(const char *url, char *hostname, guint hostname_size,
                  gint *port);


extern char *HTTP_Proxy, *No_Proxy;

/*
 * External functions
 */
extern gint a_Proto_get_url (const char *url, void*);
extern gint a_About_get (const char *url, void*);
extern gint a_File_get  (const char *url, void*);
extern gint a_Http_get  (const char *url, void*);
extern void a_Http_freeall(void);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __Url_h__ */

