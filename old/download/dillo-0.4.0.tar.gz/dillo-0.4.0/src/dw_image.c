/*
 * File: dw_image.c
 *
 * Copyright (C) 2001 Sebastian Geerken  <S.Geerken@ping.de>,
 *                    Jorge Arellano Cid <jcid@inf.utfsm.cl>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

#include <gdk/gdk.h>
#include "dw_image.h"
#include <gtk/gtkwidget.h>
#include "dw_gtk_viewport.h"
#include <stdio.h>

static void Dw_image_init               (DwImage *image);
static void Dw_image_class_init         (DwImageClass *klass);

static void Dw_image_size_request       (DwWidget *widget,
                                         DwRequisition *requisition);
static void Dw_image_draw               (DwWidget *widget,
                                         DwRectangle *area,
                                         GdkEventExpose *event);
gint Dw_image_enter_notify              (DwWidget *widget,
                                         GdkEventMotion *event);
gint Dw_image_leave_notify              (DwWidget *widget,
                                         GdkEventMotion *event);


GtkType a_Dw_image_get_type (void)
{
   static GtkType type = 0;

   if (!type) {
      GtkTypeInfo info = {
         "DwImage",
         sizeof (DwImage),
         sizeof (DwImageClass),
         (GtkClassInitFunc) Dw_image_class_init,
         (GtkObjectInitFunc) Dw_image_init,
         (GtkArgSetFunc) NULL,
         (GtkArgGetFunc) NULL,
      };
      
      type = gtk_type_unique (DW_TYPE_WIDGET, &info);
   }
   
   return type;
}

DwWidget* a_Dw_image_new (DwImageType type)
{
   GtkObject *object;
   
   object = gtk_object_new (DW_TYPE_IMAGE, NULL);
   return DW_WIDGET (object);
}

static void Dw_image_init (DwImage *image)
{
   image->width = 0;
   image->height = 0;
   image->buffer = NULL;
}


static void Dw_image_class_init (DwImageClass *klass)
{
   GtkObjectClass *object_class;
   DwWidgetClass *widget_class;

   object_class = (GtkObjectClass*)klass;

   widget_class = (DwWidgetClass*)klass;
   widget_class->size_request = Dw_image_size_request;
   widget_class->draw = Dw_image_draw;
   widget_class->enter_notify_event = Dw_image_enter_notify;
   widget_class->leave_notify_event = Dw_image_leave_notify;
}


static void Dw_image_size_request (DwWidget *widget,
                                   DwRequisition *requisition)
{
   DwImage *image;

   image = DW_IMAGE (widget);
   requisition->width = image->width;
   requisition->ascent = image->height;
   requisition->descent = 0;
}


static void Dw_image_draw (DwWidget *widget,
                           DwRectangle *area,
                           GdkEventExpose *event)
{
   gint vx, vy;
   gint Width, Height;
   GdkGC *gc;
   DwImage *image = DW_IMAGE (widget);
   gint dw, dh;

   //g_print(">Area x=%d y=%d w=%d h=%d\n", area->x, area->y,
   //        area->width, area->height);

   vx = Dw_widget_x_world_to_viewport (widget, widget->allocation.x);
   vy = Dw_widget_y_world_to_viewport (widget, widget->allocation.y);
   gc = widget->viewport->style->fg_gc[widget->viewport->state];
   Width = widget->allocation.width;
   Height = widget->allocation.ascent + widget->allocation.descent;

   if ( image->buffer && area->x < image->width && area->y < image->height) {
      dw = MIN (area->width, image->width - area->x);
      dh = MIN (area->height, image->height - area->y);

      gdk_draw_rgb_image(
         widget->window, gc, vx + area->x, vy + area->y,
         dw, dh, GDK_RGB_DITHER_MAX,
         image->buffer + (area->y * image->width + area->x) * 3,
         image->width * 3);
   }
}


gint Dw_image_enter_notify (DwWidget *widget,
                            GdkEventMotion *event)
{
// g_print ("Dw_image_enter_notify: %p\n", widget);
   return TRUE;
}


gint Dw_image_leave_notify (DwWidget *widget,
                            GdkEventMotion *event)
{
// g_print ("Dw_image_leave_notify: %p\n", widget);
   return TRUE;
}


/*
 * Set or resize a image.
 */
void a_Dw_image_size(DwImage *image, gint width, gint height)
{
   gint Resize = (image->width != width || image->height != height);

   image->width = width;
   image->height = height;
   if ( Resize )
      Dw_widget_queue_resize(DW_WIDGET (image));
}

/*
 * Copy the RGB line buffer into the full image buffer
 */
void a_Dw_image_draw_row(DwImage *image, guchar *LineBuf,
                         gint Width, gint Height, gint x, gint y)
{
   // g_print("a_Dw_image_draw_row: x=%d y=%d\n", x, y);
   g_return_if_fail (image->buffer != NULL);

   memcpy(image->buffer + (y * Width + x) * 3, LineBuf, Width * 3);
   Dw_widget_queue_draw_area(DW_WIDGET (image), x, y,  Width, 1);
   //g_print("<Area x=%d y=%d w=%d h=%d\n", x, y, Width, Height);
}

/*
 * Set the widget buffer reference the dicache entry buffer
 */
void a_Dw_image_set_buffer(DwImage *image, guchar *ImageBuffer)
{
   image->buffer = ImageBuffer;
}

