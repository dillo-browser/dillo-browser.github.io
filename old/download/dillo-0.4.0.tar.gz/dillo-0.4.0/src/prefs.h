#ifndef __DILLO_RC_H__
#define __DILLO_RC_H__

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#define D_GEOMETRY_DEFAULT_WIDTH   640
#define D_GEOMETRY_DEFAULT_HEIGHT  550

#define DW_COLOR_DEFAULT_GREY   0xd6d6d6
#define DW_COLOR_DEFAULT_BLACK  0x000000
#define DW_COLOR_DEFAULT_BLUE   0x0000ff
#define DW_COLOR_DEFAULT_PURPLE 0x800080
#define DW_COLOR_DEFAULT_BGND   0xd6d6c0

/* define enumeration values to be returned */
enum {
   PARSE_OK = 0,
   FILE_NOT_FOUND
};

/* define enumeration values to be returned for specific symbols */
typedef enum {
   DRC_TOKEN_FIRST = G_TOKEN_LAST,
   DRC_TOKEN_GEOMETRY,
   DRC_TOKEN_PROXY,
   DRC_TOKEN_NOPROXY,
   DRC_TOKEN_LINK_COLOR,
   DRC_TOKEN_VISITED_COLOR,
   DRC_TOKEN_BG_COLOR,
   DRC_TOKEN_ALLOW_WHITE_BG,
   DRC_TOKEN_FORCE_MY_COLORS,
   DRC_TOKEN_TEXT_COLOR,
   DRC_TOKEN_USE_OBLIQUE,
   DRC_TOKEN_HOME,
   DRC_TOKEN_FONT_FACTOR,
   DRC_TOKEN_LAST
} Dillo_Rc_TokenType;

typedef struct _DilloPrefs DilloPrefs;

struct _DilloPrefs {
   gint width;
   gint height;
   char *http_proxy;
   char *no_proxy;
   char *home;
   guint32 link_color;
   guint32 visited_color;
   guint32 bg_color;
   guint32 text_color;
   gboolean allow_white_bg;
   gboolean use_oblique;
   gboolean force_my_colors;
   gdouble font_factor;
};

/* Global Data */
DilloPrefs prefs;

void a_Prefs_init(void);
void a_Prefs_freeall(void);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __DILLO_RC_H__ */
