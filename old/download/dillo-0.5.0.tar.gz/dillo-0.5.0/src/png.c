/*
 * The png decoder for Dillo. It is responsible for decoding PNG data
 * and transferring it to the dicache.
 *
 * Geoff Lane nov 1999 zzassgl@twirl.mcc.ac.uk
 * Luca Rota, Jorge Arellano Cid, Eric Gaudet 2000
 *
 * "PNG: The Definitive Guide" by Greg Roelofs, O'Reilly
 * ISBN 1-56592-542-4
 */

#undef VERBOSE

#include <stdio.h>
#include <string.h>

#include <zlib.h>
#include <png.h>

#include <gtk/gtk.h>
#include "image.h"
#include "web.h"
#include "cache.h"
#include "dicache.h"
#include "prefs.h"

enum prog_state {
   IS_finished, IS_init, IS_nextdata
};

#if defined(VERBOSE)
static char *prog_state_name[] =
{
   "IS_finished", "IS_init", "IS_nextdata"
};
#endif

/*
 * This holds the data that must be saved between calls to this module.
 * Each time it is called it is supplied with a vector of data bytes
 * obtained from the web server. The module can process any amount of the
 * supplied data.  The next time the module is called, the vector may be
 * extended with additional data bytes to be processed.  The module must
 * keep track of the current start and cursor position of the input data
 * vector.  As complete output rasters are determined they are sent out of
 * the module for additional processing.
 *
 * NOTE:  There is no external control of the splitting of the input data
 * vector (only this module understands PNG format data.) This means that
 * the complete state of a PNG image being processed must be held in the
 * structure below so that processing can be suspended or resumed at any
 * point within an input image.
 *
 * In the case of the libpng library, it maintains it's own state in
 * png_ptr and into_ptr so the FSM is very simple - much simpler than the
 * ones for XBM and PNM are.
 */

typedef
struct _DilloPng {
   DilloImage *Image;           /* Image meta data */
   gint DicEntryKey;            /* Primary Key for the dicache */

   double display_exponent;     /* gamma correction */
   gulong width;                /* png image width */
   gulong height;               /* png image height */
   png_structp png_ptr;         /* libpng private data */
   png_infop info_ptr;          /* libpng private info */
   guchar *image_data;          /* decoded image data    */
   guchar **row_pointers;       /* pntr to row starts    */
   jmp_buf jmpbuf;              /* png error processing */
   gint error;                  /* error flag */
   gint rowbytes;               /* No. bytes in image row */
   short passes;
   short channels;              /* No. image channels */

/*
 * 0                                              last byte
 * +-------+-+-----------------------------------+-+
 * |       | |     -- data to be processed --    | |
 * +-------+-+-----------------------------------+-+
 * ^        ^                                     ^
 * ipbuf    ipbufstart                            ipbufsize
 */

   guchar *ipbuf;               /* image data in buffer */
   gint ipbufstart;             /* first valid image byte */
   gint ipbufsize;              /* size of valid data in */

   enum prog_state state;       /* FSM current state  */

   guchar *linebuf;             /* o/p raster data */

} DilloPng;

#define DATASIZE  (png->ipbufsize - png->ipbufstart)
#define BLACK     0
#define WHITE     255

static
void Png_error_handling(png_structp png_ptr, png_const_charp msg)
{
   DilloPng *png;

   g_print("Png_error_handling: %s\n", msg);
   png = png_get_error_ptr(png_ptr);

   png->error = 1;
   png->state = IS_finished;

   longjmp(png->jmpbuf, 1);
}

static void
Png_datainfo_callback(png_structp png_ptr, png_infop info_ptr)
{
   DilloPng *png;
   gint color_type;
   gint bit_depth;
   gint interlace_type;
   guint i;
   double gamma;

#if defined(VERBOSE)
   g_print("Png_datainfo_callback:\n");
#endif

   png = png_get_progressive_ptr(png_ptr);
   g_return_if_fail (png != NULL);

   png_get_IHDR(png_ptr, info_ptr, &png->width, &png->height,
                &bit_depth, &color_type, &interlace_type, NULL, NULL);
#if defined(VERBOSE)
   g_print("Png_datainfo_callback: png->width  = %ld\n", png->width);
   g_print("Png_datainfo_callback: png->height = %ld\n", png->height);
#endif

   /* we need RGB/RGBA in the end */
   if (color_type == PNG_COLOR_TYPE_PALETTE && bit_depth <= 8) {
      /* Convert indexed images to RGB */
      png_set_expand (png_ptr);
   } else if (color_type == PNG_COLOR_TYPE_GRAY && bit_depth < 8) {
      /* Convert grayscale to RGB */
      png_set_expand (png_ptr);
   } else if (png_get_valid (png_ptr, info_ptr, PNG_INFO_tRNS)) {
      /* We have transparency header, convert it to alpha channel */
      png_set_expand(png_ptr);
   } else if (bit_depth < 8) {
      png_set_expand(png_ptr);
   }

   if (bit_depth == 16) {
      png_set_strip_16(png_ptr);
   }

   /* Get and set gamma information. Beware: gamma correction 2.2 will
      only work on PC's. todo: select screen gamma correction for other 
      platforms. */
   if (png_get_gAMA(png_ptr, info_ptr, &gamma))
      png_set_gamma(png_ptr, 2.2, gamma);

   /* Convert gray scale to RGB */
   if (color_type == PNG_COLOR_TYPE_GRAY ||
       color_type == PNG_COLOR_TYPE_GRAY_ALPHA) {
      png_set_gray_to_rgb(png_ptr);
   }

   /* Interlaced */
   if (interlace_type != PNG_INTERLACE_NONE) {
      png->passes = png_set_interlace_handling(png_ptr);
   }

   /* get libpng to update it's state */
   png_read_update_info(png_ptr, info_ptr);

   png_get_IHDR(png_ptr, info_ptr, &png->width, &png->height,
                &bit_depth, &color_type, &interlace_type, NULL, NULL);

   png->rowbytes = png_get_rowbytes(png_ptr, info_ptr);
   png->channels = png_get_channels(png_ptr, info_ptr);

   /* init Dillo specifics */
#if defined(VERBOSE)
   g_print("Png_datainfo_callback: rowbytes = %d\n", png->rowbytes);
   g_print("Png_datainfo_callback: width    = %ld\n", png->width);
   g_print("Png_datainfo_callback: height   = %ld\n", png->height);
#endif

   png->image_data = (guchar *) g_malloc(png->rowbytes * png->height);
   png->row_pointers = (guchar **) g_malloc(png->height * sizeof(guchar *));

   for (i = 0; i < png->height; i++)
      png->row_pointers[i] = png->image_data + (i * png->rowbytes);

   png->linebuf = g_malloc(3 * png->width);

   /* Initialize the dicache-entry here */
   a_Dicache_set_parms(png->DicEntryKey, png->Image,
                       png->width, png->height, DILLO_IMG_TYPE_RGB);
}

static void
 Png_datarow_callback(png_structp png_ptr, png_bytep new_row,
                      png_uint_32 row_num, gint pass)
{
   DilloPng *png;
   guint i;

   if (!new_row)                /* work to do? */
      return;

#if defined(VERBOSE)
   g_print("Png_datarow_callback: row_num = %ld\n", row_num);
#endif

   png = png_get_progressive_ptr(png_ptr);

   png_progressive_combine_row(png_ptr, png->row_pointers[row_num], new_row);

   switch (png->channels) {
   case 3:
      a_Dicache_write(png->Image, png->DicEntryKey,
                      png->image_data + (row_num * png->rowbytes), 0, row_num);
      break;
   case 4:
     {
        /* todo: get the backgound color from the parent 
         * of the image widget -- Livio.                 */
        gint a, bg_red, bg_green, bg_blue;
        guchar *pl = png->linebuf;
        guchar *data = png->image_data + (row_num * png->rowbytes);

        /* todo: maybe change prefs.bg_color to `a_Dw_widget_get_bg_color`,
         * when background colors are correctly implementated */
        bg_blue  = (prefs.bg_color) & 0xFF;
        bg_green = (prefs.bg_color>>8) & 0xFF;
        bg_red   = (prefs.bg_color>>16) & 0xFF;
         
        for (i = 0; i < png->width; i++) {         
           a = *(data+3);
           
           if ( a == 255 ) {
              *(pl++) = *(data++);
              *(pl++) = *(data++);
              *(pl++) = *(data++);
              data++;
           } else if ( a == 0 ) {
              *(pl++) = bg_red;
              *(pl++) = bg_green;
              *(pl++) = bg_blue;
              data += 4;
           } else {
              png_composite(*(pl++), *(data++), a, bg_red);
              png_composite(*(pl++), *(data++), a, bg_green);
              png_composite(*(pl++), *(data++), a, bg_blue);
              data++;
           }
        }
        a_Dicache_write(png->Image, png->DicEntryKey, png->linebuf, 0, row_num);
        break;
     }
   default:
      g_print("Png_datarow_callback: unexpected number of channels = %d\n",
              png->channels);
      abort();
   }
}

static void
 Png_dataend_callback(png_structp png_ptr, png_infop info_ptr)
{
   DilloPng *png;

#if defined(VERBOSE)
   g_print("Png_dataend_callback:\n");
#endif

   png = png_get_progressive_ptr(png_ptr);
   png->state = IS_finished;
}


/*
 * Op:  Operation to perform.
 *   If (Op == 0)
 *      start or continue processing an image if image data exists.
 *   else
 *       terminate processing, cleanup any allocated memory,
 *       close down the decoding process.
 *
 * Client->CbData  : pointer to previously allocated DilloPng work area.
 *  This holds the current state of the image processing and is saved
 *  across calls to this routine.
 * Client->Buf     : Pointer to data start.
 * Client->BufSize : the size of the data buffer.
 *
 * You have to keep track of where you are in the image data and
 * how much has been processed.
 *
 * It's entirely possible that you will not see the end of the data.  The
 * user may terminate transfer via a Stop button or there may be a network
 * failure.  This means that you can't just wait for all the data to be
 * presented before starting conversion and display.
 */
void Png_callback(int Op, CacheClient_t *Client)
{
   DilloPng *png = Client->CbData;

   if ( Op ) {
      /* finished - free up the resources for this image */
      a_Dicache_close(png->DicEntryKey, Client);
      if (png->image_data != NULL)
         g_free(png->image_data);
      if (png->row_pointers != NULL)
         g_free(png->row_pointers);
      if (png->linebuf != NULL)
         g_free(png->linebuf);
      if (setjmp(png->jmpbuf))
         png_destroy_read_struct(&png->png_ptr, &png->info_ptr, NULL);
      g_free(png);
      return;
   }

   /* Let's make some sound if we have been called with no data */
   g_return_if_fail ( Client->Buf != NULL && Client->BufSize > 0 );

#if defined(VERBOSE)
   g_print("Png_callback BufSize = %d\n", Client->BufSize);
#endif

   /* Keep local copies so we don't have to pass multiple args to
    * a number of functions. */
   png->ipbuf = Client->Buf;
   png->ipbufsize = Client->BufSize;

   /* start/resume the FSM here */
   while (png->state != IS_finished && DATASIZE) {
#if defined(VERBOSE)
      g_print("State = %s\n", prog_state_name[png->state]);
#endif
      switch (png->state) {
      case IS_init:
         if (DATASIZE < 8) {
            return;            /* need MORE data */
         }
         /* check the image signature - DON'T update ipbufstart! */
         if (!png_check_sig(png->ipbuf, DATASIZE)) {
            /* you lied to me about it being a PNG image */
            png->state = IS_finished;
            break;
         }
         /* OK, it looks like a PNG image, lets do some set up stuff */
         png->png_ptr = png_create_read_struct(
                           PNG_LIBPNG_VER_STRING,
                           png,
                           (png_error_ptr)Png_error_handling,
                           (png_error_ptr)Png_error_handling);
         g_return_if_fail (png->png_ptr != NULL);
         png->info_ptr = png_create_info_struct(png->png_ptr);
         g_return_if_fail (png->info_ptr != NULL);

         setjmp(png->jmpbuf);
         if(!png->error) {
            png_set_progressive_read_fn(
               png->png_ptr,
               png,
               Png_datainfo_callback,   /* performs local init functions */
               Png_datarow_callback,    /* performs per row action */
               Png_dataend_callback);   /* performs cleanup actions */
            png->state = IS_nextdata;
         }
         break;

      case IS_nextdata:
         if ( setjmp(png->jmpbuf) ) {
            png->state = IS_finished;
         } else if(!png->error) {
            png_process_data( png->png_ptr,
                              png->info_ptr,
                              png->ipbuf + png->ipbufstart,
                              DATASIZE);

            png->ipbufstart += DATASIZE;
         }
         break;

      default:
         g_warning("PNG decoder: bad state = %d\n", png->state);
         abort();
      }
   }
}

/*
 * Create the image state data that must be kept between calls
 */
static DilloPng *Png_new(DilloImage *Image, gint DicEntryKey)
{
   DilloPng *png = g_malloc(sizeof(DilloPng));

   png->Image = Image;
   png->DicEntryKey = DicEntryKey;
   png->state = IS_init;
   png->error = 0;
   png->ipbuf = NULL;
   png->ipbufstart = 0;
   png->ipbufsize = 0;
   png->linebuf = NULL;
   png->linebuf = NULL;
   png->row_pointers = NULL;
   png->image_data = NULL;

   return png;
}

/*
 * MIME handler for "image/png" type
 * (Sets Png_callback or a_Dicache_callback as the cache-client)
 */
DwWidget *a_Png_image(const char *Type, void *Ptr, CA_Callback_t *Call,
                      void **Data)
{
/*
 * Type: MIME type
 * Ptr:  points to a Web structure
 * Call: Dillo calls this with more data/eod
 * Data: raw image data
 */

   DilloWeb *web = Ptr;
   DICacheEntry *DicEntry;

#if defined(VERBOSE)
   g_print("a_Png_image: Type = %s\n", Type);
   g_print("a_Png_image: libpng - Compiled %s; using %s.\n",
           PNG_LIBPNG_VER_STRING, png_libpng_ver);
   g_print("a_Png_image: zlib   - Compiled %s; using %s.\n",
           ZLIB_VERSION, zlib_version);
#endif

   if ( !web->Image )
      web->Image = a_Image_new(0, 0, NULL, prefs.bg_color);

   DicEntry = a_Dicache_get_entry(web->url);
   if ( !DicEntry ) {
      /* Let's create an entry for this image... */
      DicEntry = a_Dicache_entry_new(web->url);
      a_Dicache_add_entry(DicEntry);

      /* ... and let the decoder feed it! */
      *Data = Png_new(web->Image, DicEntry->Key);
      *Call = (CA_Callback_t) Png_callback;
   } else {
      /* Let's feed our client from the dicache */
      *Data = web->Image;
      *Call = (CA_Callback_t) a_Dicache_callback;
   }
   return DW_WIDGET (web->Image->dw);
}
