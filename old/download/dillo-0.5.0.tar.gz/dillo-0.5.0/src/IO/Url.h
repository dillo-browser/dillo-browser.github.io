#ifndef __URL_H__
#define __URL_H__

#include "../../config.h"
#include "../chain.h"
#include <glib.h>
#include <stdio.h> /* for sprintf */
#include <ctype.h>
#include <string.h>
#include <unistd.h>
#include "IO.h"

#define URN_OTHER  "()+,-.:=@;$_!*'/%?"

/*
 * URL opener codes
 */
#define URL_Http
#define URL_File
#define URL_Plugin
#define URL_None


#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/* Returns a file descriptor to read data on; meta data is sent on FD_TypeWrite */
typedef gint (*UrlOpener_t) (const char *url, void *data);

/*
 * Module functions
 */
gint  a_Url_init (void);
gint  a_Url_is_absolute (const char *url);
char* a_Url_parse_hash  (const char *url);
char* a_Url_squeeze(char *str);
gchar* a_Url_resolve_relative(const char *BaseUrl, const char *RelativeUrl);
char* a_Url_parse(const char *url, char *hostname, guint hostname_size,
                  gint *port);
ChainFunction_t a_Url_get_ccc_funct(const char *Url);


extern char *HTTP_Proxy, *No_Proxy;

/*
 * External functions
 */
extern void a_Http_freeall(void);

ChainFunction_t a_Url_get_ccc_funct(const char *Url);
void a_Http_ccc (int Op, int Br, ChainLink *Info, void *Data, void *ExtraData);
void a_File_ccc (int Op, int Br, ChainLink *Info, void *Data, void *ExtraData);
void a_About_ccc(int Op, int Br, ChainLink *Info, void *Data, void *ExtraData);
void a_IO_ccc   (int Op, int Br, ChainLink *Info, void *Data, void *ExtraData);


#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __URL_H__ */

