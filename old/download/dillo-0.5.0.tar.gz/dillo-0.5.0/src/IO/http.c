/*
 * File: http.c
 *
 * Copyright (C) 2000 Jorge Arellano Cid <jcid@inf.utfsm.cl>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

/*
 * HTTP connect functions
 */


#include <unistd.h>
#include <errno.h>              /* for errno */
#include <string.h>             /* for strstr */
#include <stdlib.h>
#include <signal.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <sys/socket.h>         /* for lots of socket stuff */
#include <netinet/in.h>         /* for ntohl and stuff */

#include "Url.h"
#include "IO.h"
#include "../dns.h"
#include "../cache.h"
#include "../web.h"
#include "../interface.h"


/* Every pointer inside this structure is a reference; we just need
 * to free the struct to get rid of it. */
typedef struct {
   gint SockFD;
   const char *Url;    /* reference to original URL */
   char hostname[256];
   char *tail;
   gint port;
   DilloWeb *Web;      /* reference to client's Web structure */
   guint32 ip_addr;
} SocketData_t;


/*
 * Local data
 */
static GSList *SocketList = NULL;


/*
 * Make the http query string
 */
char *Http_query(char *url, const char *hostname, gint port)
{
   char *str;
   GString *s_port = g_string_new(""),
           *query  = g_string_new("");

   /* Sending the default port in the query may cause a 302-answer.  --Jcid */
   g_string_sprintfa(s_port, (port == 80) ? "" : ":%d", port);

   /* Just in case url is not "sane" */
   if ( !url || !*url )
      url = "/";

   str = strstr(url,"?!POST:");
   if ( str ){
      *str = '\0';
      /* strlen("?!POST:") is 7 */
      str += 7;
      g_string_sprintfa(query,
                       "POST %s HTTP/1.0\r\n"
                       "User-Agent: Dillo/%s\r\n"
                       "Host: %s%s\r\n"
                       "Content-type: application/x-www-form-urlencoded\r\n"
                       "Content-length: %ld\r\n"
                       "\r\n"
                       "%s",
                       url, VERSION, hostname, s_port->str,
                       (glong)strlen(str), str);
   } else {
      g_string_sprintfa(query, "GET %s HTTP/1.0\r\n"
                       "User-Agent: Dillo/%s\r\n"
                       "Host: %s%s\r\n\r\n",
                        url, VERSION, hostname, s_port->str);
   }
   str = query->str;
   g_string_free(query, FALSE);
   g_string_free(s_port, TRUE);
   return str;
}

/*
 * This function gets called after the DNS succeeds solving a hostname.
 * Task: Finish socket setup and start connecting the socket.
 * Return value: 0 on success;  -1 on error.
 */
static int Http_connect_socket(SocketData_t *S)
{
   gint status;
   struct sockaddr_in name;

   /* Set remaining parms. */
   name.sin_family = AF_INET;
   name.sin_port = htons(S->port);
   name.sin_addr.s_addr = htonl(S->ip_addr);

   status = connect(S->SockFD, (struct sockaddr *)&name, sizeof(name));
   if ( status == -1 && errno != EINPROGRESS ) {
      a_Interface_status(S->Web->bw, "ERROR: %s", g_strerror(errno));
      g_print("Http_connect_socket ERROR: %s\n", g_strerror(errno));
      return -1;
   }
   return 0; /* Success */
}

/*
 * Create and submit the HTTP query to the IO engine
 */
static void Http_send_query(ChainLink *Info, SocketData_t *S)
{
   IOData_t *io;
   gchar *query;
   void *link;

   /* Create the query */
   query = Http_query(S->tail, S->hostname, S->port);

   /* send query */
   if ( S->Web->flags & WEB_RootUrl )
      a_Interface_status(S->Web->bw, "Sending query to %s...", S->hostname);
   io = g_new(IOData_t, 1);
   io->Op = IOWrite;
   io->IOVec.iov_base = query;
   io->IOVec.iov_len  = strlen(query);
   io->Callback = NULL;
   io->CbData = (void *) S->Web;
   io->FD = S->SockFD;
   link = a_Chain_link_new(a_Http_ccc, Info, CCC_FWD, a_IO_ccc);
   a_IO_ccc(OpStart, 1, link, io, NULL);
}

/*
 * Expect the HTTP query's answer
 */
static void Http_expect_answer(SocketData_t *S)
{
   IOData_t *io2;

   /* receive answer */
   io2 = g_new0(IOData_t, 1);
   io2->Op = IORead;
   io2->IOVec.iov_base = g_malloc(4096);
   io2->IOVec.iov_len  = 4096;
   io2->Callback = a_Cache_callback;
   io2->CbData = (void *) S->Url;
   io2->FD = S->SockFD;
   a_IO_ccc(OpStart, 2, a_Chain_new(), io2, NULL);
}

/*
 * Asynchronously create a new http connection for 'Url'
 * We'll set some socket parameters; the rest will be set later 
 * when the IP is known.
 * ( Data = Requested Url; ExtraData = Web structure )
 */
void Http_get(ChainLink *Info, void *Data, void *ExtraData)
{
   void *link;
   const char *Url = Data;
   SocketData_t *S = g_new(SocketData_t, 1);
   gchar hostname[256], *Host = hostname;

   /* keep track of this socket's data */
   SocketList = g_slist_append(SocketList, S);
   Info->LocalKey = S;

   /* Reference Web data */
   S->Web = ExtraData;
   S->ip_addr = 0;

   /* Hacked-in support for proxies */
   S->port = 80;
   if (HTTP_Proxy && !(No_Proxy && strstr(Url, No_Proxy) != NULL)) {
      a_Url_parse(HTTP_Proxy, hostname, sizeof(hostname), &S->port);
      a_Url_parse(Url, S->hostname, sizeof(S->hostname), NULL);
      S->tail = (char *) Url;
   } else {
      S->tail = a_Url_parse(Url, S->hostname, sizeof(S->hostname), &S->port);
      Host = S->hostname;
   }
   if (!S->tail) {
      g_free(S);
      return;
   }

   /* Set more socket parameters */
   S->Url = Url;
   if ( (S->SockFD = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0 ) {
      /* Failed.. clean up */
      g_free(S);
      g_print("Http_get ERROR: %s\n", g_strerror(errno));
      return;
   }
   /* set NONBLOCKING */
   fcntl(S->SockFD, F_SETFL, O_NONBLOCK | fcntl(S->SockFD, F_GETFL));

   /* Let the user know what we'll do */
   if ( S->Web->flags & WEB_RootUrl )
      a_Interface_status(S->Web->bw, "DNS solving %s", S->hostname);

   /* Let the DNS engine solve the hostname, and when done,
    * we'll try to connect the socket */
   link = a_Chain_link_new(a_Http_ccc, Info, CCC_FWD, a_Dns_ccc);
   a_Dns_ccc(OpStart, 1, link, Host, NULL);
}

/*
 * CCC function for the HTTP module
 */
void 
 a_Http_ccc(int Op, int Branch, ChainLink *Info, void *Data, void *ExtraData)
{
   gint st;
   SocketData_t *S = Info->LocalKey;

   if ( Branch == 1 ) {
      /* DNS query branch */
      switch (Op) {
      case OpStart:
         Http_get(Info, Data, ExtraData);
         break;
      case OpSend:
         /* Successful DNS answer; save the IP */
         S->ip_addr = *(int *)Data;
         break;
      case OpEnd:
         /* Unlink DNS_Info */
         a_Chain_del_link(Info, CCC_BCK);
         /* start connecting the socket */
         if ((st = Http_connect_socket(S)) == 0) {
            /* started connecting... */
            Http_send_query(Info, S);
            Http_expect_answer(S);
         } else {
            /* error connecting the socket, let's abort */
            a_Chain_fcb(OpAbort, 1, Info, NULL, NULL);
         }
         g_free(S);
         break;
      case OpAbort:
         /* DNS wasn't able to resolve the hostname */
         /* Unlink DNS_Info */
         a_Chain_del_link(Info, CCC_BCK);
         a_Interface_status(S->Web->bw, "ERROR: Dns can't solve %s", S->hostname);
         /* send abort message to higher-level functions */
         a_Chain_fcb(OpAbort, 1, Info, NULL, NULL);
         g_free(S);
         break;
      }

   } else if ( Branch == 2 ) {
      /* IO branch */
      IOData_t *io = Data;
      DilloWeb *web = io->CbData;
      char *query = io->IOVec.iov_base;

      switch (Op) {
      case OpEnd:
         /* finished sending the HTTP query */
         /* unlink IO_Info */
         a_Chain_del_link(Info, CCC_BCK);
         g_free(query);
         if ( web->flags & WEB_RootUrl )
            a_Interface_status(web->bw, "Query sent, waiting for reply...");
   
         a_Chain_fcb(OpEnd, 1, Info, NULL, NULL);
         break;
      case OpAbort:
         /* something bad happened... */
         /* unlink IO_Info */
         a_Chain_del_link(Info, CCC_BCK);
         g_free(query);
         a_Chain_fcb(OpAbort, 1, Info, NULL, NULL);
         break;
      }

   } else if ( Branch == -1 ) {
      /* Backwards abort */
      switch (Op) {
      case OpAbort:
         /* something bad happened... */
         /* todo: g_free(S); g_free(query); */
         a_Chain_bcb(OpAbort, -1, Info, NULL, NULL);
         g_free(Info);
         break;
      }
   }
}

/*
 * Deallocate memory used by http module
 * (Call this one at exit time)
 */
void a_Http_freeall(void)
{
}


