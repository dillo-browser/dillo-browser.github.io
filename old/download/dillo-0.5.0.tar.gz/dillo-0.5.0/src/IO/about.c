/*
 * File: about.c
 *
 * Copyright (C) 1997 Raph Levien <raph@acm.org>
 * Copyright (C) 1999 Jorge Arellano Cid <jcid@inf.utfsm.cl>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

#include "Url.h"
#include "../browser.h"
#include "../web.h"
#include "../nav.h"


/*
 * Push the right URL for each supported "about"
 * ( Data = Requested Url; ExtraData = Web structure )
 */
void About_get(ChainLink *Info, void *Data, void *ExtraData)
{
   char *loc;
   const char *tail;
   const char *Url = Data;
   DilloWeb *web = ExtraData;

   tail = Url + 6;              /* strlen ("about:") */
   if (!strcmp(tail, "jwz"))
      loc = "http://www.jwz.org/";
   else if (!strcmp(tail, "raph"))
      loc = "http://www.levien.com/";
   else if (!strcmp(tail, "yosh"))
      loc = "http://yosh.gimp.org/";
   else if (!strcmp(tail, "snorfle"))
      loc = "http://www.snorfle.net/";
   else
      loc = "http://www.google.com/";

   a_Nav_push(web->bw, loc);
}

/*
 * CCC function for the ABOUT module
 */
void
 a_About_ccc(int Op, int Branch, ChainLink *Info, void *Data, void *ExtraData)
{
   if ( Op == OpStart ) {
      About_get(Info, Data, ExtraData);
      a_Chain_fcb(OpAbort, 1, Info, NULL, ExtraData);
   }
}

