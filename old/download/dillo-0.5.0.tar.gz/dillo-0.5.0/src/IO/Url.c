/*
 * File: Url.c
 *
 * Copyright (C) 1997 Raph Levien <raph@acm.org>
 * Copyright (C) 1999 Randall Maas <randym@acm.org>,
 * Copyright (C) 1999, 2000 Jorge Arellano Cid <jcid@inf.utfsm.cl>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

/* Heavily modified by Jcid, Dec 1999 & Jun 2000
 *
 * Two types of functions here:
 *     1.- URL handling for openning URLs
 *     2.- URL parsing (as strings)
 */


#include <glib.h>
#include <stdlib.h>
#include "../list.h"
#include "Url.h"
#include "../prefs.h"
#include "../misc.h"

typedef struct {
   const char *Name;   /* Method name */
   UrlOpener_t Data;   /* Pointer to a function */
} UrlMethod_t;

typedef struct {
   const char *Name;             /* Method name */
   ChainFunction_t cccFunction;  /* Pointer to a CCC function */
} UrlMethod2_t;

/*
 * Local data
 */
char *HTTP_Proxy = NULL, *No_Proxy = NULL;

static gint UrlOpenersSize = 0, UrlOpenersMax = 8;
static UrlOpener_t *UrlOpeners = NULL;

gint UrlMethodsSize = 0, UrlMethodsMax = 8;
static UrlMethod_t *UrlMethods = NULL;

/*
 * Forward declarations
 */
gint Url_add_opener(UrlOpener_t F);


/*
 * Add a method for Url handling
 * (currently we have File, About & Http)
 * -- Currently not used
 */
gint Url_add_method(const char *Name, UrlOpener_t Method)
{
   a_List_add(UrlMethods, UrlMethodsSize, sizeof(*UrlMethods), UrlMethodsMax);
   UrlMethods[UrlMethodsSize].Name = Name;
   UrlMethods[UrlMethodsSize].Data = Method;
   UrlMethodsSize++;
   return 0;
}

/*
 * Adds method 'F' to the list of URL openers.
 * UrlOpeners are called in LIFO order until success.
 * -- Currently not used
 */
gint Url_add_opener(UrlOpener_t F)
{
   a_List_add(UrlOpeners, UrlOpenersSize, sizeof(UrlOpener_t *), UrlOpenersMax);
   UrlOpeners[UrlOpenersSize] = F;
   UrlOpenersSize++;
   return 0;
}

/*
 * This identifies the method specified in the URL.
 * On success, Method is set to point the start of the method string; it is
 * NOT a zero terminated string.
 *
 * Return Value:
 *   < 1 on error, otherwise the length of the method string.
 */
gint Url_proto_parse(const char *URL, const char **Method)
{

   char *EPtr = strpbrk(URL, URN_OTHER);

   if (!EPtr || *EPtr != ':')
      return 0;
   *Method = URL;

   return (EPtr - URL);
}

/*
 * Search the cccList for a matching ccc function.
 */
ChainFunction_t a_Url_get_ccc_funct(const char *Url)
{
   static UrlMethod2_t cccList[3] = { {"http",  a_Http_ccc},
                                      {"file",  a_File_ccc},
                                      {"about", a_About_ccc} };
   const char *Key = NULL;
   gint KeyLen, i, j;

   /* Use the method inside the URL as a Key to decide what cccFunct matches */
   if ( (KeyLen = Url_proto_parse(Url, &Key)) < 1 )
      return NULL;

   for ( i = 0; i < 3; ++i ) {
      for ( j = 0; j < KeyLen; ++j )
         if ( tolower(Key[j]) != cccList[i].Name[j] )
            break;
      if ( j == KeyLen )
         return cccList[i].cccFunction;
   }
   return NULL;
}

/*
 * Sets the handler methods for the different protocols supported by Dillo
 */
gint a_Url_init(void)
{
   HTTP_Proxy = getenv("http_proxy");
   No_Proxy = getenv("no_proxy");
   if (!HTTP_Proxy && prefs.http_proxy)
      HTTP_Proxy = prefs.http_proxy;
   if (!No_Proxy && prefs.no_proxy)
      No_Proxy = prefs.no_proxy;

   return 0;
}



/*
 * URL parsing routines ====================================================
 */

/*
 * This routine checks to see if the URL passed is of the absolute form, or
 * of the relative form
 *
 * Return Value:
 *   0 is not absolute, otherwise is absolute
 */
gint a_Url_is_absolute(const char *url)
{
   const char *P = strpbrk(url, URN_OTHER);

   return (P && *P == ':');
}

/*
 * Parse "http://a/b#c" into "http://a/b" and "#c".
 *
 * Return Value:
 *   a pointer to the last hash (if any), otherwise NULL.
 */
char* a_Url_parse_hash(const char *Url)
{
   /* todo: I haven't checked this for standards compliance. What's it
    * supposed to do when there are two hashes? */
   /* Just use the last #c --MR-- */

   return strrchr(Url, '#');
}

/*
 * Return TRUE if the method matches.
 */
static gint Url_match_method(const char *url, const char *method,
                            size_t Method_Size)
{
   if (g_strncasecmp(url, method, Method_Size))
      return 0;
   return (url[Method_Size] == ':');
}

/*
 * Squeeze an URL (strip /./ and /../ sequences)
 * Return value: squeezed URL.
 *  The funny thing is that I don't know if this is required!
 *  Anyway, it's highly tuned for speed  --Jcid
 */
char *a_Url_squeeze(char *str)
{
   char *s, *p;
   int i, ni, nc;

   s = p = str;
   ni = 0;
   while ( (p = strstr(p, "/.")) != NULL ) {
      if ( p[2] == '.' && (p[3] == '/' || !p[3]) ) { /* "/../" or "/.." */
         nc = p - s;
         for ( i = 0; i <= nc; ++i, ++ni )
            str[ni] = s[i];
         nc = ni > 0 ? --ni : ni;
         while ( ni && str[--ni] != '/' );
         if (!ni || (ni == 6 && !strncmp(str, "http://",7)) )
           ni = nc;   /* parent directory missing, restore value */
         s = p = p + 3;
      } else if ( p[2] == '/' || !p[2] ) {  /* "/./" or "/." */
         nc = p - s;
         for ( i = 0; i < nc; ++i )
            str[ni++] = s[i];
         str[ni] = '/';
         s = p = p + 2;
      } else {                              /* "/.x" */
         p += 2;
      }
   }

   /* Append the rest of 'str' */
   if ( str[ni] == '/' && !*s )  ++ni;
   while ( (str[ni++] = *s++) );
   return str;
}

/*
 * Resolve a "file:" URL
 */
gchar *a_Url_resolve_file(const char *BaseUrl, const char *RelativeUrl)
{
   gchar *slash;
   const char *rel;
   gchar *NewUrl = NULL;

   if ( !BaseUrl || !RelativeUrl )
      return NULL;

   rel = RelativeUrl;
   if ( g_strncasecmp(RelativeUrl, "file:", 5) == 0 ) {
      /* An absolute file-URL! */
      rel = RelativeUrl + 5;
      if ( rel[0] == '/' ) {
         /* It was already solved (todo: squeeze it?) */
         NewUrl = g_strdup(RelativeUrl);
      } else {
         /* File reference to current directory.
          * ("file:" and "file:." show current dir */
         char *cwd = g_get_current_dir();
         if ( (rel[0] == '.' && !rel[1]) )
            ++rel;
         NewUrl = g_strdup_printf("file:%s%s%s", cwd, cwd[1] ? "/" : "", rel);
      }
      return NewUrl;
   } else if ( a_Url_is_absolute(RelativeUrl) ) {
      /* An absolute URL other than "file:" */
      return g_strdup(RelativeUrl);
   }

   /* If we get here, 'BaseUrl' contains "file:" and 'rel' not */

   if ( rel[0] == '/' ) {
      /* Start from root dir */
      NewUrl = g_strdup_printf("file:%s", rel);
   } else if ( rel[0] == '#' ) {
      /* Name reference, add it to BaseUrl. (todo: strip former '#') */
      NewUrl = g_strdup_printf("%s%s", BaseUrl, RelativeUrl);
   } else {
      /* a file relative to BaseUrl */
      slash = strrchr(BaseUrl, '/');
      if ( !slash ) {
         NewUrl = g_strdup_printf("file:%s", RelativeUrl);
      } else if ( a_Misc_stristr(slash, ".htm") ) {
         char *base = g_strndup(BaseUrl, slash - BaseUrl);
         NewUrl = g_strdup_printf("%s/%s", base, RelativeUrl);
         g_free(base);
      } else {
         NewUrl = g_strdup_printf("%s/%s", BaseUrl, RelativeUrl);
      }
   }
   return NewUrl;
}

/*
 * Resolve a relative url into a newly allocated string.
 * This function is relatively tolerant to weird parameters (not 100%) --Jcid
 */
gchar *a_Url_resolve_relative(const char *BaseUrl, const char *RelativeUrl)
{
   gchar *p;
   gint i, path_index;
   gchar *NewUrl = NULL;

   if ( !BaseUrl || !RelativeUrl )
      return NULL;

   /* "file" method here */
   if ( Url_match_method(BaseUrl, "file", 4) ||
        Url_match_method(RelativeUrl, "file", 4) ){
      NewUrl = a_Url_resolve_file(BaseUrl, RelativeUrl);
      // g_print( "FRR New : %s\n", NewUrl);
      return NewUrl;
   }

   if ( a_Url_is_absolute(RelativeUrl) ){
      /* It has the "method:..." form. */
      return g_strdup(RelativeUrl);
   }

   /* Parse method:/[/]name:port/ in BaseUrl
    * e.g. http://hostname:port/ */
   for (i = 0; BaseUrl[i] && BaseUrl[i] != ':'; i++);
   for (i++; BaseUrl[i] && BaseUrl[i] == '/'; i++);
   for (i++; BaseUrl[i] && BaseUrl[i] != '/'; i++);
   path_index = i;

   if ( RelativeUrl[0] == '/' ){
      /* Get host from BaseUrl */
      if ( i && BaseUrl[i] == '/' ) {
         gchar *base = g_strndup(BaseUrl, i);
         NewUrl = g_strdup_printf("%s%s", base, RelativeUrl);
         g_free(base);
      } else {
         NewUrl = g_strdup_printf("%s%s", BaseUrl, RelativeUrl);
      }
   } else if ( RelativeUrl[0] == '#' ) {
      /* Name reference, add it to BaseUrl. (todo: strip former '#') */
      NewUrl = g_strdup_printf("%s%s", BaseUrl, RelativeUrl);
   } else {
      /* Get host and path from BaseUrl */
      if ( BaseUrl[i] && (p = strrchr(BaseUrl, '/')) != NULL ) {
         gchar *base = g_strndup(BaseUrl, p - BaseUrl);
         NewUrl = g_strdup_printf("%s/%s", base, RelativeUrl);
         g_free(base);
      } else {
         NewUrl = g_strdup_printf("%s/%s", BaseUrl, RelativeUrl);
      }
   }
   a_Url_squeeze(NewUrl);
// g_print("URR\n Base: %s\n Rel: %s\n New:%s\n", BaseUrl,RelativeUrl,NewUrl);
   return NewUrl;
}

/*
 * Parse the url, packing the hostname and port into the arguments, and
 * returning the suffix. Return NULL in case of failure.
 */
char *a_Url_parse(const char *url, char *hostname, guint hostname_size,
                  gint *port)
{
   const char *CPtr = strchr(url, ':');
   char *C1Ptr;
   guint Size;

   if (!CPtr || CPtr[1] != '/' || CPtr[2] != '/')
      return NULL;

   CPtr += 3;
   if (!(C1Ptr = strpbrk(CPtr, ":/"))) {
      Size = strlen(CPtr);
      if (!hostname)
         return (char *) CPtr + Size;
      if (Size >= hostname_size)
         return NULL;
      memcpy(hostname, CPtr, Size);
      hostname[Size] = '\0';
      return (char *) CPtr + Size;
   }
   Size = (gulong) C1Ptr - (gulong) CPtr;
   if (hostname) {
      if (Size >= hostname_size)
         return NULL;
      memcpy(hostname, CPtr, Size);
      hostname[Size] = '\0';
   }
   if (*C1Ptr != ':')
      return (char *) C1Ptr;

   if (port)
      *port = strtoul(++C1Ptr, &C1Ptr, 0);

   for (; *C1Ptr && *C1Ptr != '/'; C1Ptr++);
   return C1Ptr;
}


