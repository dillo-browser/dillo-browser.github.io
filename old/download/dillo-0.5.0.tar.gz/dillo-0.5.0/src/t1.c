
#include <stdio.h>
#include <stdlib.h>
#include "bitvec.h"

int main(void)
{
   gint i;
   bitvec_t *bvec = a_Bitvec_new(500);

   a_Bitvec_set_bit(bvec, 1);
   a_Bitvec_set_bit(bvec, 3);
   a_Bitvec_set_bit(bvec, 5);
   a_Bitvec_set_bit(bvec, 19);
   a_Bitvec_set_bit(bvec, 229);

   a_Bitvec_clear_bit(bvec, 5);

   for ( i=0; i < 500; ++i)
      if ( a_Bitvec_get_bit(bvec, i) )
         g_print("bit %d is set\n", i);

   a_Bitvec_free(bvec);

   return 0;
}
