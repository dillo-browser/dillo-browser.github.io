#ifndef __DW_H__
#define __DW_H__

void a_Dw_init    (void);
void a_Dw_freeall (void);

#endif /* __DW_H__ */
