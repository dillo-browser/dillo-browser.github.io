#ifndef __MISC_H__
#define __MISC_H__

char *a_Misc_prepend_user_home(char *file);
char *a_Misc_stristr(char *src, char *str);
char *a_Misc_expand_tabs(const char *str);
gchar *a_Misc_strsep(char **orig, const char *delim);
#define d_strsep a_Misc_strsep

#endif /* __MISC_H__ */

