/*
 * File: misc.c
 *
 * Copyright (C) 1997 Raph Levien <raph@acm.org>
 * Copyright (C) 1999 James McCollough <jamesm@gtwn.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

#include <gtk/gtk.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>


/*
 * Returns the home directory of the user
 * DON'T try to free this one cause it's really a pointer
 * into the environment structure 
 */
static const char *home_dir = "";
static int init = 1;
const char *Misc_user_home(void)
{

   if (init) {
      home_dir = getenv("HOME");
      if (!home_dir)
         home_dir = "";
      init = 0;
   }
   return (home_dir);
}

/* 
 * Prepend the users home-dir to 'file' string i.e,
 * pass in .dillo/bookmarks.html and it will return
 * /home/imain/.dillo/bookmarks.html
 * 
 * Remember to g_free() returned value! 
 */
char *a_Misc_prepend_user_home(const char *file)
{
   char *home_return;

   home_return = g_malloc(strlen(file) + strlen(Misc_user_home()) + 3);

   sprintf(home_return, "%s/%s", Misc_user_home(), file);
   return (home_return);
}

/* 
 * Very similar to above, but adds $HOME/.dillo/ to beginning
 * This is meant to be the most useful version.
 */
char *Misc_file(const char *file)
{
   char *home_return;

   home_return = g_malloc(strlen(file) + strlen(Misc_user_home()) + 16);

   sprintf(home_return, "%s/.dillo/%s", Misc_user_home(), file);
   return (home_return);
}
