/*
 * 
 * The png decoder for Dillo. It is responsible for decoding PNG data in a
 * bytesink and transferring it to an imgsink.
 * 
 * Geoff Lane nov 1999 zzassgl@twirl.mcc.ac.uk
 * 
 * THIS IS ALPHA CODE
 * 
 * There is a image test page available at
 * http://twirl.mcc.ac.uk/gzilla.html
 * 
 * "PNG: The Definitive Guide" by Greg Roelofs, O'Reilly
 * ISBN 1-56592-542-4
 * 
 */

#undef VERBOSE

#include <stdio.h>
#include <string.h>
#include <assert.h>

#include <zlib.h>               /* need to include in configure checks */
#include <png.h>                /* need to include in configure checks */

#include <gtk/gtk.h>
#include "imgsink.h"
#include "web.h"
#include "cache.h"

enum prog_state {
   IS_finished, IS_init, IS_nextdata
};

#if defined(VERBOSE)
static char *prog_state_name[] =
{
   "IS_finished", "IS_init", "IS_nextdata"
};
#endif

/*
 * This holds the data that must be saved between calls to this module.
 * Each time it is called it is supplied with a vector of data bytes
 * obtained from the web server. The module can process any amount of the
 * supplied data.  The next time the module is called, the vector may be
 * extended with additional data bytes to be processed.  The module must
 * keep track of the current start and cursor position of the input data
 * vector.  As complete output rasters are determined they are sent out of
 * the module for additional processing.
 * 
 * NOTE:  There is no external control of the splitting of the input data
 * vector (only this module understands PNG format data.) This means that
 * the complete state of a PNG image being processed must be held in the
 * structure below so that processing can be suspended or resumed at any
 * point within an input image.
 * 
 * In the case of the libpng library, it maintains it's own state in
 * png_ptr and into_ptr so the FSM is very simple - much simpler than the
 * ones for XBM and PNM are.
 * 
 */

typedef
struct _DilloPng {
   DilloImgSink *imgsink;

   double display_exponent;     /* gamma correction */
   unsigned long width;         /* png image width */
   unsigned long height;        /* png image height */
   void *png_ptr;               /* png private data */
   void *info_ptr;              /*  "     "     "  */
   unsigned char *image_data;   /* decoded image data    */
   unsigned char **row_pointers;        /* pntr to row starts    */
   jmp_buf jmpbuf;              /* png error processing */
   int rowbytes;                /* No. bytes in image row */
   short passes;
   short channels;              /* No. image channels */
#if 0
   unsigned char wantBGcolor;
   unsigned char BGred;
   unsigned char BGgreen;
   unsigned char BGblue;
#endif

/*
 * 0                                              last byte
 * +-------+-+-----------------------------------+-+
 * |       | |     -- data to be processed --    | |
 * +-------+-+-----------------------------------+-+
 * ^        ^                                     ^
 * ipbuf    ipbufstart                            ipbufsize
 */

   unsigned char *ipbuf;        /* image data in buffer */
   int ipbufstart;              /* first valid image byte */
   int ipbufsize;               /* size of valid data in */

   enum prog_state state;       /* FSM current state  */

   unsigned char *linebuf;      /* o/p raster data */

} DilloPng;

#define DATASIZE  (png->ipbufsize - png->ipbufstart)
#define SUSPEND   return
#define BLACK     0
#define WHITE     255

#define PROTECT if ( !setjmp(png->jmpbuf) ) {
#define RECOVER } else {
#define ENDPROT }

static
void Png_datainfo_callback(png_structp png_ptr, png_infop info_ptr)
{
   DilloPng *png;
   int color_type;
   int bit_depth;
   double gamma;
   int i;

#if defined(VERBOSE)
   g_print("Png_datainfo_callback:\n");
#endif

   png = png_get_progressive_ptr(png_ptr);
   assert(png != NULL);

   png_get_IHDR(png_ptr, info_ptr, &png->width, &png->height,
                &bit_depth, &color_type, NULL, NULL, NULL);
#if defined(VERBOSE)
   g_print("Png_datainfo_callback: png->width  = %ld\n", png->width);
   g_print("Png_datainfo_callback: png->height = %ld\n", png->height);
#endif

/* set a background if required */
#if 0
   if (png->wantBGcolor &&
       png_get_valid(png_ptr, info_ptr, PNG_INFO_bKGD)) {

      png_color_16p BGColor;

      png_get_bKGD(png_ptr, info_ptr, &BGColor);
      if (bit_depth == 16) {
         png->BGred = BGColor->red >> 8;
         png->BGgreen = BGColor->green >> 8;
         png->BGblue = BGColor->blue >> 8;
      } else if (color_type == (PNG_COLOR_TYPE_GRAY && (bit_depth < 8))) {
         switch (bit_depth) {
         case 1:
            png->BGred =
                png->BGgreen =
                png->BGblue = BGColor->gray ? WHITE : BLACK;
            break;
         case 2:
            png->BGred =
                png->BGgreen =
                png->BGblue = BGColor->gray * (WHITE / 3);
            break;
         case 4:
            png->BGred =
                png->BGgreen =
                png->BGblue = BGColor->gray * (WHITE / 15);
            break;
         default:
            g_print("Png_datainfo_callback: unexpected bit_depth = %d\n", bit_depth);
            abort();
         }
      } else {
         png->BGred = (unsigned char) BGColor->red;
         png->BGgreen = (unsigned char) BGColor->green;
         png->BGblue = (unsigned char) BGColor->blue;
      }
   }
#endif

   /* we need RGB in the end */

   if (color_type == PNG_COLOR_TYPE_PALETTE)
      png_set_expand(png_ptr);
   if (color_type == (PNG_COLOR_TYPE_GRAY && (bit_depth < 8)))
      png_set_expand(png_ptr);
   if (png_get_valid(png_ptr, info_ptr, PNG_INFO_tRNS))
      png_set_expand(png_ptr);
   if (bit_depth == 16)
      png_set_strip_16(png_ptr);
   if (color_type == PNG_COLOR_TYPE_GRAY ||
       color_type == PNG_COLOR_TYPE_GRAY_ALPHA)
      png_set_gray_to_rgb(png_ptr);

   /* set up gamma correction */

   png_set_gamma(png_ptr, png->display_exponent,
                 (png_get_gAMA(png_ptr, info_ptr, &gamma) ? gamma : 0.4545));

   /* interlaced images ? */
   png->passes = png_set_interlace_handling(png_ptr);

   /* get libpng to update it's state */

   png_read_update_info(png_ptr, info_ptr);
   png->rowbytes = png_get_rowbytes(png_ptr, info_ptr);
   png->channels = png_get_channels(png_ptr, info_ptr);

   /* init Dillo specifics */
#if defined(VERBOSE)
   g_print("Png_datainfo_callback: rowbytes = %d\n", png->rowbytes);
   g_print("Png_datainfo_callback: width    = %ld\n", png->width);
   g_print("Png_datainfo_callback: height   = %ld\n", png->height);
#endif

   png->image_data = (unsigned char *) g_malloc(png->rowbytes * png->height);
   png->row_pointers = (unsigned char **) g_malloc(png->height * 
                                                   sizeof(unsigned char *));

   for (i = 0; i < png->height; i++)
      png->row_pointers[i] = png->image_data + (i * png->rowbytes);

   png->linebuf = g_malloc(3 * png->width);

   /* init Dillo imgsink here */
   a_Imgsink_set_parms(png->imgsink, png->width, png->height, 
                       DILLO_IMG_TYPE_RGB);
}

static
void Png_datarow_callback(png_structp png_ptr, png_bytep new_row,
                      png_uint_32 row_num, int pass)
{
   DilloPng *png;
   int i;

   if (!new_row)                /* work to do? */
      return;

#if defined(VERBOSE)
   g_print("Png_datarow_callback: row_num = %ld\n", row_num);
#endif

   png = png_get_progressive_ptr(png_ptr);

   png_progressive_combine_row(png_ptr, png->row_pointers[row_num], new_row);

   switch (png->channels) {
   case 3:
      a_Imgsink_write(png->imgsink,
                           png->image_data + (row_num * png->rowbytes),
                           0, row_num);
      break;
   case 4:
      for (i = 0; i < png->width; i++) {
         int p;

         for (p = 0; p < 3; p++) {
            png->linebuf[3 * i + p] =
                png->image_data[row_num * png->rowbytes + (4 * i + p)];
         }
      /* FIXME use alpha channel */
      }
      a_Imgsink_write(png->imgsink, png->linebuf, 0, row_num);
      break;
   default:
      g_print("Png_datarow_callback: unexpected number of channels = %d\n",
              png->channels);
      abort();
   }
}

static
void Png_dataend_callback(png_structp png_ptr, png_infop info_ptr)
{
   DilloPng *png;

#if defined(VERBOSE)
   g_print("Png_dataend_callback:\n");
#endif

   png = png_get_progressive_ptr(png_ptr);
   png->state = IS_finished;
}


/*
 * Terminate = TRUE;
 * terminate processing, cleanup any allocated memory,
 * close down the imgsink.
 * 
 * Terminate = FALSE;
 * start or continue processing an image if image data exists.
 * if there is no data source or no data or all the data has
 * been processed or no imgsink then give up without doing
 * anything.
 * 
 * B is a pointer to previously allocated DilloPng work area.
 * This holds the current state of the image processing and is
 * saved across calls to this routine.
 * 
 * Buf     : some or all of the image data to be processed.
 * BufSize : the size of the data buffer (and hence the
 * amount of data that could be processed during this call.)
 * 
 * Successive calls to this routine may provide additional data in
 * Buf.  The last call will be presented with the complete image
 * data.  This means you have to keep track of where you are in the image
 * data and how much has been processed.
 * 
 * It's entirely possible that you will not see the end of the data.  The
 * user may terminate transfer via a Stop button or there may be a network
 * failure.  This means that you can't just wait for all the data to be
 * presented before starting conversion and display (well you could
 * probably do so and put up with no image for a failed or stopped
 * transfer.)
 */
void Png_callback(int Terminate, void *CbData, void *Buf, gint BufSize)
{

   DilloPng *png = CbData;

#if defined(VERBOSE)
   g_print("Png_callback Terminate = %d\n", Terminate);
#endif

   if (Terminate) {
      /* finished - free up the resources for this image */
      a_Imgsink_close(png->imgsink);
      png->imgsink = NULL;
      if (png->image_data != NULL)
         g_free(png->image_data);
      if (png->row_pointers != NULL)
         g_free(png->row_pointers);
      if (png->linebuf != NULL)
         g_free(png->linebuf);
      if (setjmp(png->jmpbuf))
         png_destroy_read_struct(png->png_ptr, png->info_ptr, NULL);
      g_free(png);
      return;
   }
   if ((Buf == NULL) ||         /* no data available */
       (BufSize == 0) ||        /* no data available */
       (png->imgsink == NULL))  /* no image sink to send raster to */
      return;
   /* if there's no parent in the image sink we're in abort mode */
   if (png->imgsink->Parent == NULL)
      abort();

#if defined(VERBOSE)
   g_print("Png_callback BufSize = %d\n", BufSize);
#endif

   /* keep local copies so we don't have to pass multiple args to  */
   /* a number of functions. */
   png->ipbuf = (unsigned char *) Buf;
   png->ipbufsize = BufSize;

   /* start/resume the FSM here */
   while (png->state != IS_finished) {
#if defined(VERBOSE)
      g_print("State = %s\n", prog_state_name[png->state]);
#endif
      switch (png->state) {
      case IS_init:
         if (DATASIZE < 8) {
            SUSPEND;            /* need MORE data */
         }
         /* check the image signature - DONT update ipbufstart! */
         if (!png_check_sig(png->ipbuf, DATASIZE)) {
            /* you lied to me about it being a PNG image */
            png->state = IS_finished;
            break;
         }
         /* OK, it looks like a PNG image, lets do some set up stuff */
         png->png_ptr = png_create_read_struct( PNG_LIBPNG_VER_STRING,
                                                png,
                                                NULL /* FIXME? */ ,
                                                NULL);
         assert(png->png_ptr != NULL);
         png->info_ptr = png_create_info_struct(png->png_ptr);
         assert(png->info_ptr);

         /*
          * the following is extremely barfish - libpng uses longjmp's
          * as part of it's error processing and we cannot rely on
          * jmpbuf data across calls - who knows the state of the
          * stack at each call.  So we have to update jmpbuf before
          * every call to a libpng function... oh hum.
          */

         /* set up a progressive read of the image data */
         PROTECT
             png_set_progressive_read_fn( png->png_ptr,
                                          png,
                                          Png_datainfo_callback,   /* performs local init functions */
                                          Png_datarow_callback,    /* performs per row action */
                                          Png_dataend_callback);   /* performs cleanup actions */
         png->state = IS_nextdata;
         RECOVER
             /* failed for some reason */
             png->state = IS_finished;
         break;
         ENDPROT
             break;

      case IS_nextdata:
         PROTECT
             png_process_data(
                                png->png_ptr,
                                png->info_ptr,
                                png->ipbuf + png->ipbufstart,
                                DATASIZE);
         png->ipbufstart += DATASIZE;
         SUSPEND;
         RECOVER
             /* failed for some reason */
             g_warning("decoding failed for some reason...\n");
             png->state = IS_finished;
         break;
         ENDPROT
             break;

      default:
         g_warning("bad state = %d\n", png->state);
         abort();
      }
   }
}

/*
 * ?
 */
Dw *a_Png_image(const char *Type, void *Ptr, CA_Callback_t *Call, void **Data)
{

/*
 * Type:   text mime type
 * Ptr:    points to window displaying data?
 * Call:   Dillo calls this with more data/eod
 * Data:   raw image data
 */

   Dw *child_dw = NULL;
   DilloWeb *web = Ptr;
   DilloImgSink *imgsink;
   DilloPng *png;

#if defined(VERBOSE)
   g_print("a_Png_image: Type = %s\n", Type);
#endif

   if (web->imgsink) {
      imgsink = web->imgsink;   /* Ah... things already set up previously */
   } else {
      /* create new image sink */
      imgsink = a_Image_new(0, 0, "png", DW_PAINT_DEFAULT_BGND);
   }
   child_dw = (Dw *) imgsink->dw;    /* this is the return value */

#if defined(VERBOSE)
   g_print("a_Png_image: libpng - Compiled %s; using %s.\n",
           PNG_LIBPNG_VER_STRING, png_libpng_ver);
   g_print("a_Png_image: zlib   - Compiled %s; using %s.\n",
           ZLIB_VERSION, zlib_version);
#endif

   /* create the image state data that must be kept between calls */
   png = g_malloc(sizeof(DilloPng));
   png->imgsink = imgsink;
   imgsink->RefCount++;
   imgsink->Parent = &(png->imgsink);
   png->state = IS_init;
   png->ipbuf = NULL;
   png->ipbufstart = 0;
   png->ipbufsize = 0;
   png->linebuf = NULL;
#if 0
   png->wantBGcolor = FALSE;
#endif
   png->linebuf = NULL;
   png->row_pointers = NULL;
   png->image_data = NULL;
   *Data = png;
   /* set up the callback pointer */
   *Call = (CA_Callback_t) Png_callback;

   return child_dw;
}
