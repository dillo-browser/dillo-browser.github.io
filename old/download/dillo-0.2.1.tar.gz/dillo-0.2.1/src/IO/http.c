/*
 * File: http.c
 *
 * Copyright (C) 2000 Jorge Arellano Cid <jcid@inf.utfsm.cl>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

/*
 * HTTP connect functions
 */


#include <unistd.h>
#include <errno.h>              /* for errno */
#include <string.h>             /* for strstr */
#include <stdlib.h>
#include <search.h>
#include <signal.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <sys/socket.h>         /* for lots of socket stuff */
#include <netinet/in.h>         /* for ntohl and stuff */

#include "Url.h"
#include "url.h"
#include "../dns.h"
#include "IO.h"
#include "../cache.h"
#include "../browser.h"


/* Every pointer inside this structure is a reference; we just need
 * to free the struct to get rid of it. */
typedef struct {
   int SockFD;
   const char *Url;
   char hostname[256];
   char *tail;
   int port;

   DilloWeb *Web;  /* Reference to client's Web structure */
                    
} SocketData_t;


/*
 * Make the http query string
 */
char *Http_query(char *url, const char *hostname, int port)
{
   char *str;
   GString *s_port = g_string_new(""),
           *query  = g_string_new("");

   /* Sending the default port in the query may cause a 302-answer.  --Jcid */
   g_string_sprintfa(s_port, (port == 80) ? "" : ":%d", port);

   /* Just in case url is not "sane" */
   if ( !url || !*url )
      url = "/";

   str = strstr(url,"?!POST:");
   if ( str ){
      *str = '\0';
      /* strlen("?!POST:") is 7 */
      str += 7;
      g_string_sprintfa(query,
                       "POST %s HTTP/1.0\r\n"
                       "User-Agent: Dillo/%s\r\n"
                       "Host: %s%s\r\n"
                       "Content-type: application/x-www-form-urlencoded\r\n"
                       "Content-length: %d\r\n"
                       "\r\n"
                       "%s",
                       url, VERSION, hostname, s_port->str, strlen(str), str);
   } else {
      g_string_sprintfa(query, "GET %s HTTP/1.0\r\n"
                       "User-Agent: Dillo/%s\r\n"
                       "Host: %s%s\r\n\r\n",
                        url, VERSION, hostname, s_port->str);
   }
   str = query->str;
   g_string_free(query, FALSE);
   g_string_free(s_port, TRUE);
   return str;
}

/*
 * Callback for http query sending
 *  - Free the query string
 *  - Free IOData_t structure
 */
void Http_query_callback(int Op, void *ptr)
{
   IOData_t *io = ptr;
   DilloWeb *web = io->CbData;
   char *query = io->IOVec.iov_base;

   if ( Op == IOClose ) {
      if ( web->flags & WEB_RootUrl )
         a_Interface_status(web->bw, "");
      g_free(query);
      g_free(io);
   } else {
      a_Interface_status(web->bw, "ERROR, %s", g_strerror(-io->Status));
      g_print("Http_query_callback IO_ERROR: %s\n", g_strerror(-io->Status));
      g_print("Http_query_callback ERROR: unhandled operation, Op = %d\n", Op);
   }
}

/* 
 * (This function gets called, by the DNS engine, after solving a hostname)
 * If DNS succeeded, try to connect the socket
 * If DNS failed, abort current conection.
 */
static void Http_dns_callback(int Op, guint32 ip_addr, void *CbData)
{
   char *query;
   IOData_t *io, *io2;
   int status;
   struct sockaddr_in name;
   SocketData_t *S = CbData;

   if ( Op ) {
      /* DNS failed */
      /* todo: send abort message to higher-level functions */
      a_Interface_status(S->Web->bw, "ERROR: Dns can't solve %s", S->hostname);
      g_free(S);
      return;
   } 

   /* DNS succeeded, let's finish socket setup and
    * start connecting the socket */

   /* Set remaining parms. */
   name.sin_family = AF_INET;
   name.sin_port = htons (S->port);
   name.sin_addr.s_addr = htonl(ip_addr);

   status = connect(S->SockFD, (struct sockaddr *)&name, sizeof(name));
   if ( status == -1 && errno != EINPROGRESS ) {
      a_Interface_status(S->Web->bw, "ERROR: %s", g_strerror(errno));
      g_print("Http_dns_callback ERROR: %s\n", g_strerror(errno));
      g_free(S);
      return;
   } 

   /* Create the query */
   query = Http_query (S->tail, S->hostname, S->port);
   // g_print("Query: %s", query);

   /* send query */
   if ( S->Web->flags & WEB_RootUrl )
      a_Interface_status(S->Web->bw, "Sending query to %s...", S->hostname);
   io = g_new(IOData_t, 1);
   io->Op = IOWrite;
   io->IOVec.iov_base = query;
   io->IOVec.iov_len  = strlen(query);
   io->Callback = Http_query_callback;
   io->CbData = (void *) S->Web;
   io->FD = S->SockFD;
   a_IO_submit(io);

   /* receive answer */
   io2 = g_new(IOData_t, 1);
   io2->Op = IORead;
   io2->IOVec.iov_base = g_malloc(4096);
   io2->IOVec.iov_len  = 4096;
   io2->Callback = a_Cache_callback;
   io2->CbData = (void *) S->Url;
   io2->FD = S->SockFD;
   a_IO_submit(io2);

   /* Free SocketData_t structure */
   g_free(S);
}

/*
 * Asynchronously create a new http connection for 'Url'
 * We'll set some socket parameters; the rest will be set by Http_dns_callback
 * when the IP is known.
 */
int a_Http_get(const char *Url, void *Data)
{
   int fd;
   SocketData_t *S = g_new(SocketData_t, 1);

   /* Reference Web data */
   S->Web = Data; 

   /* Hacked-in support for proxies, inspired by Olivier Aubert */
   S->port = 80;
   if (HTTP_Proxy && !(No_Proxy && strstr(Url, No_Proxy) != NULL)) {
      a_Url_parse(HTTP_Proxy, S->hostname, sizeof(S->hostname), &S->port);
      S->tail = (char *) Url;
   } else {
      S->tail = a_Url_parse(Url, S->hostname, sizeof(S->hostname), &S->port);
   }
   if (!S->tail) {
      g_free(S);
      return -1;
   }

   /* Set more socket parameters */
   S->Url = Url;
   if ( (S->SockFD = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0 ) {
      /* Failed.. clean up */
      g_free(S);
      g_print("a_Http_get ERROR: %s\n", g_strerror(errno));
      return -1;
   }
   /* set NONBLOCKING */
   fcntl(S->SockFD, F_SETFL, O_NONBLOCK | fcntl(S->SockFD, F_GETFL));
 

   /* Let the user know what we'll do */
   if ( S->Web->flags & WEB_RootUrl )
      a_Interface_status(S->Web->bw, "DNS solving %s", S->hostname);

   /* Let the DNS engine solve the hostname, and when done,
    * we'll try to connect the socket */
   fd = S->SockFD;
   a_Dns_lookup (S->hostname, Http_dns_callback, (void *) S);
   /* Http_dns_callback() frees 'S', so if it finishes before this function
    * resumes, S->SockFD is lost; that's why we use 'fd' instead.  --Jcid */
   return fd;
}


/*
 * Deallocate memory used by http module
 * (Call this one at exit time)
 */
void a_Http_freeall(void) 
{
}

