/*
 * MIME type mapper  Randall Maas 1999
 */

/*
 *  Rearranged to a new structure by Jcid, Dec 1999
 *  (added some comments also...)
 */

#include "mime.h"


/*
 *  Local data
 */
void *MIME_type_Items, *MIME_mtype_Items;
int MIME_type_NItems, MIME_type_NAlloc, MIME_mtype_NItems, MIME_mtype_NAlloc;

/*
 * NULL viewer (For unhandled content-types)
 */
Dw *Mime_null_viewer(const char *Type,void *P,CA_Callback_t *Call,void **Data)
{
   return NULL;
}

/*
 * Add a specific MIME type (as "image/png") to our viewer list
 * 'Key' is the content-type string that identifies the MIME type
 * 'Method' is the function that handles it
 */
int Mime_add_minor_type(const char *Key, Viewer_t Method)
{
   return a_Hdlr_add((void *) &MIME_type_Items, &MIME_type_NItems, 
                     &MIME_type_NAlloc, Key, Method);
}

/*
 * Add a mayor MIME type (as "text") to our viewer list
 * 'Key' is the content-type string that identifies the MIME type
 * 'Method' is the function that handles it
 */
int Mime_add_mayor_type(const char *Key, Viewer_t Method)
{
   return a_Hdlr_add((void **) &MIME_mtype_Items, &MIME_mtype_NItems,
                     &MIME_mtype_NAlloc, Key, Method);
}

/*
 * Search the list of specific MIME viewers, for a Method that matches 'Key'
 * 'Key' is the content-type string that identifies the MIME type
 */
Viewer_t Mime_minor_type_fetch(const char *Key, size_t Size)
{
   return (Viewer_t)a_Hdlr_fetch(MIME_type_Items, MIME_type_NItems, Key, Size);
}

/*
 * Search the list of mayor MIME viewers, for a Method that matches 'Key'
 * 'Key' is the content-type string that identifies the MIME type
 */
Viewer_t Mime_mayor_type_fetch(const char *Key, size_t Size)
{
   return (Viewer_t)a_Hdlr_fetch(MIME_mtype_Items,MIME_mtype_NItems,Key,Size);
}


/*
 * Initializes Mime module and, sets the supported Mime types.
 */
void a_Mime_init()
{
   MIME_type_Items = NULL;
   MIME_mtype_Items = NULL;
   MIME_type_NItems = 0;
   MIME_type_NAlloc = 0;
   MIME_mtype_NItems = 0;
   MIME_mtype_NAlloc = 0;

   Mime_add_minor_type("image/gif", a_Gif_image);
   Mime_add_minor_type("image/jpeg", a_Jpeg_image);
   Mime_add_minor_type("image/jpg", a_Jpeg_image);
   Mime_add_minor_type("image/png", a_Png_image);
   Mime_add_minor_type("text/html", a_Html_text);

   /* Add a major type to handle all the text stuff */
   Mime_add_mayor_type("text", a_Dw_plain);
}


/*
 * Call the handler for the MIME type to set Call and Data as appropriate
 * 
 * Return Value:
 *   A new Dw on success, otherwise NULL
 */
Dw *a_Mime_set_viewer(const char *content_type, void *Ptr,
                      CA_Callback_t *Call, void **Data)
{

   Viewer_t VPtr;
   size_t Size = 0, Size1 = 0;
   int SeenSlash = 0;
   const char *CPtr = content_type;

   while (*CPtr && *CPtr != ' ' && *CPtr != ';') {
      Size++;
      if (!SeenSlash && *CPtr != '/')
         Size1++;
      if (*CPtr == '/')
         SeenSlash++;
      CPtr++;
   }

   /* Try explicit type */
   VPtr = Mime_minor_type_fetch(content_type, Size);
   if (VPtr)
      return VPtr(content_type, Ptr, Call, Data);

   /* Try parent type */
   VPtr = Mime_mayor_type_fetch(content_type, Size1);
   if (VPtr)
      return VPtr(content_type, Ptr, Call, Data);

   /* Fail */
   g_print("yecky <%s>\n", content_type);
   *Call = a_Cache_null_client;
   return NULL;
}
