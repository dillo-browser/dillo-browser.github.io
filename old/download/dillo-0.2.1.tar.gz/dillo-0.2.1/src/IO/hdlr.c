/*
 * Generic handlers Randall Maas 1999
 */

/* Rearranged by Jcid. Dec, 1999 */


#include <stdio.h>
#include <string.h>
#include <glib.h>

typedef struct {
   const char *Name;
   void *Data;
} _Hdlr_t;

typedef struct {
   const char *Name;
   void (*Data) ();
} _Hdlr2_t;


/*
 * Description
 * This procedure inserts an item 'Item' into a table '*(_IPtr)'.
 * The table itself has a number of items '*NItems', this number will
 * be incremented to reflect the additional item.  '*NAlloc' is the
 * number of slots in the table that had been preallocated to store items.
 * 
 * If there are no free slots in the table, the table will be resized,
 * and '*(_IPtr)' will be changed.
 * 
 * Return Value:
 *    -1 on error, 0 on success.
 */
int a_Hdlr_add(void **_IPtr, int *NItems, int *NAlloc, const char *Name, int *Data)
{
   _Hdlr_t **IPtr = (_Hdlr_t **) _IPtr;

   /* Resize the table if it has not been allocated yet, or if there are no
    * free items.  The number of free items is equal to
    * the Number Allocated '*NAlloc' - Number Used '*NItems'.
    */
   if (!*IPtr || *NItems >= *NAlloc) {
      int N = *NAlloc ? ((*NAlloc) << 1) : 8;
      void *NIPtr;

      NIPtr = g_realloc(*IPtr, N * sizeof(_Hdlr_t));
      if (!NIPtr) {
         return -1;
      }
      *IPtr = NIPtr;
      *NAlloc = N;
   }
   (*IPtr)[*NItems].Name = Name;
   (*IPtr)[*NItems].Data = Data;
   *NItems += 1;
   return 0;
#ifdef realsoonnow
   g_cache_new(New,, NULL, NULL, Hdlr_cmp);
#endif
}

/*
 * ???
 */
int Hdlr_cmp(_Hdlr2_t * IPtr, const char *Key, size_t Size)
{
   return strncasecmp(Key, IPtr->Name, Size) || IPtr->Name[Size];
}

/*
 * Get a handler by name from a table
 */
void *a_Hdlr_fetch(void *_IPtr, int NItems, const char *Key, size_t Size)
{  
   int I;
   _Hdlr2_t *IPtr = _IPtr;

   for (I = 0; I < NItems; I++, IPtr++) {
      if (Hdlr_cmp(IPtr, Key, Size))
         continue;
      return IPtr->Data;
   }
   return NULL;
}

