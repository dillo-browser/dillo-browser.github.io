/*
 * File: IO.c
 *
 * Copyright (C) 2000 Jorge Arellano Cid <jcid@inf.utfsm.cl>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */
 
/*
 * Dillo's signal driven IO engine
 */

#include <stdio.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/uio.h>
#include <sys/socket.h>
#include <glib.h>
#include <gdk/gdk.h>
#include "IO.h"

/*
 * Symbolic defines for shutdown() function
 * (Not defined in the same header file, for all distros --Jcid)
 */
#define IO_StopRd   0
#define IO_StopWr   1
#define IO_StopRdWr 2

# define DILLO_TEMP_FAILURE_RETRY(expression)     \
    ({ long int __result;                         \
       do __result = (long int) (expression);     \
       while (__result == -1L && errno == EINTR); \
       __result; })


/*
 * IO module data
 */
GSList *IOFDs = NULL;    /* Active FDs list. It holds pointers to IOData_t
                          * structures. */


/*
 * Close an open FD.
 * (This function is called when the operation on the FD had
 *  completed succesfuly. For error conditions we use a_IO_abort)
 */
void IO_close(IOData_t *io, int CloseCode)
{
   struct stat st;

   /* Remove gdk_input watch function */
   gdk_input_remove(io->GdkTag);

   /* Close the FD  -- If it's not a socket, just close the FD */
   if ( fstat(io->FD, &st) == 0 ) {
      if ( S_ISSOCK(st.st_mode) ){
         if ( CloseCode != IO_StopWr ) 
            shutdown(io->FD, CloseCode);
      } else
         DILLO_TEMP_FAILURE_RETRY (close(io->FD));
   }
/*
   if ( shutdown(io->FD, CloseCode) == -1 && errno == ENOTSOCK ) 
      DILLO_TEMP_FAILURE_RETRY (close(io->FD));
*/
   /* Remove this IOData_t reference, from our active FDs list 
    * We don't deallocate it here, just remove from the list.*/
   IOFDs = g_slist_remove(IOFDs, (gpointer) io);
   /* Let the Callback know we finished the Op and closed the FD */
   if ( io->Callback )
      io->Callback(IOClose, io);
}

/*
 * Abort an open FD.
 * (This function is called to abort a FD connection, either on 
 *  an error condition or just because we don't want it anymore!)
 * todo: set SO_LINGER socket options on a_IO_submit.
 */
void a_IO_abort(IOData_t *io)
{
   /* Remove gdk_input watch function */
   gdk_input_remove(io->GdkTag);
   /* Close the FD */
   if ( shutdown(io->FD, IO_StopRdWr) != 0 )
      DILLO_TEMP_FAILURE_RETRY (close(io->FD));
   /* Remove this IOData_t reference, from our active FDs list 
    * We don't deallocate it here, just remove from the list.*/
   IOFDs = g_slist_remove(IOFDs, (gpointer) io);
   /* Let the Callback know we finished the Op and aborted the FD */
   if ( io->Callback )
      io->Callback(IOAbort, io);
}

/*
 * Read data from a file descriptor into a specific buffer
 * Return value:
 *   0 if EOF,
 *   the number of bytes Read (if successful) or
 *   -errno if it fails.
 *
 * todo: handle EAGAIN
 */
int IO_read(IOData_t *io)
{
   int st;

   st = DILLO_TEMP_FAILURE_RETRY( readv(io->FD, &io->IOVec, 1) );
   if ( st == -1 ){
      st = -errno;
      g_print("IO_read ERROR: %s\n", g_strerror(errno));
   }

   io->Status = st;

   if ( st == 0 ) {
      /* All data read (EOF) */
      IO_close(io, IO_StopRd);
   } else if ( st > 0 ) {
      /* We have new data */
      io->Callback(IORead, io);
   } else {
      /* Error condition */
      a_IO_abort(io);
   }
   return st;
}

/*
 * Write data, from a specific buffer, into a file descriptor
 * Return value:
 *   the number of bytes Written (if successful) or
 *   -errno if it fails.
 *
 * todo: handle EAGAIN
 */
int IO_write(IOData_t *io)
{
   int st;

   if ( io->IOVec.iov_base == NULL ) {
      /* This is how we'll finish a IOWrites Op */
      IO_close(io, IO_StopWr);
      return 0;
   }

   st = DILLO_TEMP_FAILURE_RETRY( writev(io->FD, &io->IOVec, 1) );
   if ( st == -1 )
      st = -errno;
   io->Status = st;

   if ( st < 0 ) {
      /* Error condition */
      a_IO_abort(io);
   } else if ( st > 0 && io->IOVec.iov_len > st ) {
      /* Not all data written */
      io->IOVec.iov_len  -= st;
      io->IOVec.iov_base += st;
   } else if ( st == io->IOVec.iov_len ) {
      /* All data in buffer written */
      if ( io->Op == IOWrite ) {
         /* Single write */
         IO_close(io, IO_StopWr);
      } else if ( io->Op == IOWrites ) {
         /* Writing in small chunks */
         gdk_input_remove(io->GdkTag);
         IOFDs = g_slist_remove(IOFDs, (gpointer) io);
         io->Callback(IOWrites, io);
      }
   }
   return st;
}

/*
 * Handle background IO for a given FD (reads | writes)
 * (This function gets called by GDK when there's activity in the FD)
 */
static void IO_callback(gpointer data, gint FD, GdkInputCondition cond)
{
   IOData_t *io = (IOData_t *) data;
   int status;
                                                
   if ( cond == GDK_INPUT_READ ) {               /* Read  */
      status = IO_read(io);
   } else if ( cond == GDK_INPUT_WRITE ) {       /* Write */
      status = IO_write(io);
   }
}

/*
 * Receive an IO request (IORead | IOWrite | IOWrites),
 * set GDK signals and let it flow!
 */
void a_IO_submit(IOData_t *req)
{
   /* Set FD to background and to generate signals */
   fcntl(req->FD, F_SETFL, O_NONBLOCK | fcntl(req->FD, F_GETFL) );

   if ( req->Op == IORead )
      req->GdkTag = gdk_input_add(req->FD, GDK_INPUT_READ, IO_callback, req);
   else if ( req->Op == IOWrite || req->Op == IOWrites )
      req->GdkTag = gdk_input_add(req->FD, GDK_INPUT_WRITE, IO_callback, req);

   /* Add a reference pointer to this request */
   IOFDs = g_slist_append(IOFDs, (gpointer) req);
}


