#ifndef __DW_BULLET_H__
#define __DW_BULLET_H__

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

typedef struct _DwBullet DwBullet;

typedef enum {
  DW_BULLET_DISC,
  DW_BULLET_CIRCLE,
  DW_BULLET_SQUARE
} DwBulletType;

struct _DwBullet {
  Dw dw;

  DwBulletType type;
};

Dw *a_Dw_bullet_new (DwBulletType type);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __DW_BULLET_H__ */
