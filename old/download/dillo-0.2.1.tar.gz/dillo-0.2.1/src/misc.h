#ifndef __DILLO_MISC_H__
#define __DILLO_MISC_H__

char *Misc_user_home(void);
char *a_Misc_prepend_user_home(char *file);
char *Misc_file(char *file);

#endif /* __DILLO_MISC_H__ */

