/*
 * File: web.c
 *
 * Copyright 2000 Jorge Arellano Cid <jcid@inf.utfsm.cl>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

#include <stdio.h>
#include <stdlib.h>
#include <gtk/gtk.h>

#include "web.h"
#include "IO/IO.h"
#include "cache.h"
#include "html.h"
#include "interface.h"

#include "dw.h"
#include "dw_embedgtk.h"
#include "IO/mime.h"
#include "dillo.h"
#include "nav.h"
#include "prefs.h"


/*
 * Given the MIME content type, and a fd to read it from,
 * this function connects the proper MIME viewer to it.
 */
Dw* a_Web_dispatch_by_type (const char *Type, DilloWeb *Web,
                            CA_Callback_t *Call, void **Data)
{
   Dw *dw;

   if (!Web->bw) return NULL;

   dw = a_Mime_set_viewer(Type, Web, Call, Data);

   if ( Web->url && Web->child_linkblock ) {
      if ( Web->child_linkblock->base_url )
         g_free(Web->child_linkblock->base_url);
      Web->child_linkblock->base_url = g_strdup(Web->url);
   }
   
   if ( dw && !(Web->flags & WEB_Image) ) {
      /* This is NOT an image */
      a_Nav_expect_done(Web->bw, dw);
      /* -RL :: Set the background color for pages without a <BODY> tag */
      a_Dw_set_color(dw, prefs.bg_color);
      /* -RL :: Set the title bar for pages without a <TITLE> tag */
      a_Interface_set_Page_title(Web->bw, "");
   }

   return dw;
}

/*
 * Deallocate a DilloWeb structure
 */
void a_Web_free(DilloWeb *web)
{
   if (!web) return;
   if (web->url)
      g_free(web->url);
   g_free(web);
}

/*
 * Allocate and set safe values for a DilloWeb structure
 */
DilloWeb* a_Web_new(const char *url)
{
   DilloWeb *web= g_new(DilloWeb, 1);
 
   web->url = g_strdup(url);

   web->bw = NULL;
   web->dw = NULL;
   web->child_linkblock = NULL;
   web->flags = 0;

   web->imgsink = NULL;
   web->stream  = NULL;

   return web;
}

