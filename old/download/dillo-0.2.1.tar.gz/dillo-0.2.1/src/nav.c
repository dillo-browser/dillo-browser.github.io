/*
 * File: nav.c
 *
 * Copyright (C) 1999 James McCollough <jamesm@gtwn.net>
 * Copyright (C) 2000 Jorge Arellano Cid <jcid@inf.utfsm.cl>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

#include <stdio.h>
#include <gtk/gtk.h>
#include "IO/IO.h"
#include "cache.h"
#include "browser.h"
#include "menu.h"
#include "dillo.h"
#include "interface.h"

#include "list.h"
#include "dw.h"
#include "web.h"
#include "dicache.h"
#include "dillo.h"
#include "IO/url.h"
#include "progressbar.h"
#include "dw_border.h"
#include "prefs.h"

/* Support for a navigation stack */

/* 
 * Initialize the navigation structure with safe values
 */
void a_Nav_init(BrowserWindow *bw)
{
   bw->nav_stack_size = 0;
   bw->nav_stack_size_max = 16;
   bw->nav_stack = NULL;
   bw->nav_stack_ptr = -1;
   bw->nav_expecting = FALSE;
   bw->nav_expect.url = NULL;
   bw->nav_expect.title = NULL;
}

/*
 * Create a DilloWeb structure for 'url' and ask the cache to fetch it.
 *  - Also set a few things related to the browser window.
 * This function requests the page's root-URL; images and related stuff
 * is fetched via a_Cache_open_url.
 */
static void Nav_open_url(BrowserWindow *bw, const char *Url)
{
   char *url, *hash;
   int FD;
   GdkCursor *regCursor;
   DilloWeb *web;

   a_Interface_set_button_sens(bw);
   a_Interface_abort_all(bw);

   if (!bw->nav_expecting) 
      gtk_entry_set_text(GTK_ENTRY(bw->location),
                         bw->nav_stack[bw->nav_stack_ptr].url);

   /* todo: scroll to the name in the url_tail */
   url = g_strdup(Url);
   if ( (hash = a_Url_parse_hash(url)) != NULL )
      *hash = '\0';

   web = a_Web_new(url);
   web->bw = bw;
   web->flags |= WEB_RootUrl;
   FD = a_Cache_open_url(url, NULL, web);
   g_free(url);

   if (FD >= 0) {
      /* Reset progress bars */
      a_Progressbar_update(bw->progress, "", 1);
      a_Progressbar_update(bw->imgprogress, "", 1);

      regCursor = gdk_cursor_new(GDK_LEFT_PTR);
      a_Interface_add_bytesink(bw, FD);
      gdk_window_set_cursor(bw->docwin->window, regCursor);
   }
}

/* 
 * Cancel the last expected nav structure if present. The responsibility
 * for actually aborting the data stream remains with the caller.
 */
void a_Nav_cancel_expect(BrowserWindow *bw)
{
   if (bw->nav_expecting) {
      if (bw->nav_expect.url)
         bw->nav_expect.url = NULL;
      if (bw->nav_expect.title)
         bw->nav_expect.title = NULL;
      bw->nav_expecting = FALSE;
   }
}

/* 
 * We have an answer! Set things accordingly.
 */
void a_Nav_expect_done(BrowserWindow *bw, Dw *dw)
{
   gint i;

   a_Dw_gtk_scroller_set_dw(GTK_DW_SCROLLER(bw->docwin),
                            a_Dw_border_new(dw, 5));
   if ( bw->nav_expecting ) {
      ++bw->nav_stack_ptr;
      if ( bw->nav_stack_ptr == bw->nav_stack_size ) {
         a_List_add(bw->nav_stack, bw->nav_stack_size, sizeof(*bw->nav_stack),
                    bw->nav_stack_size_max);
         ++bw->nav_stack_size;
      } else {
         /* Free from the next one to the top of the navigation stack */
         for (i = bw->nav_stack_ptr; i < bw->nav_stack_size; ++i ) {
            if (bw->nav_stack[i].url)
               g_free(bw->nav_stack[i].url);
            if (bw->nav_stack[i].title)
               g_free(bw->nav_stack[i].title);
         }
         bw->nav_stack_size = bw->nav_stack_ptr + 1;
      }

      i = bw->nav_stack_ptr;
      bw->nav_stack[i].url = bw->nav_expect.url;
      gtk_entry_set_text(GTK_ENTRY(bw->location), bw->nav_expect.url);
      bw->nav_expect.url = NULL;
      bw->nav_stack[i].title = bw->nav_expect.title;
      bw->nav_expect.title = NULL;
      bw->nav_expecting = FALSE;
      a_Interface_set_button_sens(bw);
   }
}

/* 
 * Remove top-URL from the navigation stack.
 * (Used to remove URLs that force redirection)
 */
void a_Nav_remove_top_url(BrowserWindow *bw, const char *url)
{
   if (!bw || !url)
      return;

   /* Deallocate the URL a the top of the stack */
   if ( bw->nav_expecting == FALSE && bw->nav_stack_size > 0 ) {
      gint top = --bw->nav_stack_size;

      if ( bw->nav_stack_ptr == top )
         --bw->nav_stack_ptr;
      if (bw->nav_stack[top].url)
         g_free(bw->nav_stack[top].url);
      if (bw->nav_stack[top].title)
         g_free(bw->nav_stack[top].title);
   }
}

/* 
 * Make 'url' the current browsed page (upon data arrival)
 * - Set bw to expect the URL data
 * - Ask the cache to feed back the requested URL (via Nav_open_url)
 */
void a_Nav_push(BrowserWindow *bw, const char *Url)
{
   char *p, *url;

   if (!bw)
      return;

   url = g_strdup(Url);
   if ( (p = strstr(url, "?!POST")) != NULL )
      *p = '\0';

   a_Nav_cancel_expect(bw);
   bw->nav_expect.url = g_strdup(url);
   bw->nav_expect.title = NULL;
   bw->nav_expecting = TRUE;
   Nav_open_url(bw, Url);
   g_free(url);
}

/* 
 * Wraps a_Nav_push to match 'DwPage->link' function type
 */
void a_Nav_vpush(void *vbw, const char *url)
{
   a_Nav_push(vbw, url);
}

/* 
 * Send the browser back to previous page
 */
void a_Nav_back(BrowserWindow *bw)
{
   a_Nav_cancel_expect(bw);
   if ( bw->nav_stack_ptr > 0 ){
      bw->nav_stack_ptr--;
      Nav_open_url(bw, bw->nav_stack[bw->nav_stack_ptr].url);
   }
}

/* 
 * Send the browser to next page in the history list
 */
void a_Nav_forw(BrowserWindow *bw)
{
   a_Nav_cancel_expect(bw);
   if (bw->nav_stack_ptr < bw->nav_stack_size - 1) {
      bw->nav_stack_ptr++;
      Nav_open_url(bw, bw->nav_stack[bw->nav_stack_ptr].url);
   }
}

/* 
 * Redirect the browser to DILLO_HOME!
 */
void a_Nav_home(BrowserWindow *bw)
{
   a_Nav_push(bw, prefs.home);
} 

/* 
 * Implement the RELOAD button functionality.
 * (We haven't defined it yet ;)
 */
void a_Nav_reload(BrowserWindow *bw)
{
   a_Nav_cancel_expect(bw);
   if ( bw->nav_stack_size ){
      a_Cache_remove_entry(bw->nav_stack[bw->nav_stack_ptr].url);
      /* todo: should remove url from dicache too, so images can be reloaded.
       * Anyway, it would be interesting to make it an option.  --Jcid */
      Nav_open_url(bw, bw->nav_stack[bw->nav_stack_ptr].url);
   }
}


