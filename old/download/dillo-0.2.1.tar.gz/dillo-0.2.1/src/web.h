#ifndef __GTK_WEB_H__
#define __GTK_WEB_H__

#include <gtk/gtk.h>
#include "IO/Url.h"
#include "imgsink.h"
#include "interface.h"
typedef struct _DilloWeb DilloWeb;
typedef struct _DilloLinkBlock DilloLinkBlock;

#include "dw.h"
#include "dw_gtk_scroller.h"
#include "browser.h"
#include "cache.h"

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/*
 * Flag defines
 */
#define WEB_RootUrl  1
#define WEB_Image    2
#define WEB_Download 4   /* To be implemented... */


struct _DilloLinkBlock {
  struct _BrowserWindow* bw;
  char *base_url;
};

struct _DilloWeb {
  char *url;                         /* Requested URL */
  BrowserWindow *bw;                 /* The requesting browser window */
  Dw *dw;                            /* Dillo widget for 'url' */
  DilloLinkBlock *child_linkblock;   /* ? */
  int flags;                         /* Aditional info */

  DilloImgSink *imgsink;             /* imgsink for image urls */
  FILE *stream;                      /* file stream for local saving */
};


DilloWeb* a_Web_new (const char* url);
void a_Web_free (DilloWeb*);
Dw* a_Web_dispatch_by_type (const char *Type, DilloWeb *web,
                            CA_Callback_t *Call, void **Data);

#ifdef __cplusplus
}
#endif /* __cplusplus */
#endif /* __GTK_WEB_H__ */
