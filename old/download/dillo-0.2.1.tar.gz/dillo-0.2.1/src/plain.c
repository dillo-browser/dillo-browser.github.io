/*
 * File: plain.c
 *
 * Copyright (C) 1997 Raph Levien <raph@acm.org>
 * Copyright (C) 1999 James McCollough <jamesm@gtwn.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

/*
 * A bytesink for decoding a text/plain object into a gtk_page widget. 
 */

#include <string.h>             /* for memcpy and memmove */

#include <gtk/gtk.h>
#include "dw.h"
#include "dw_page.h"
#include "cache.h"

typedef struct _DilloPlain 
{
  Dw *dw;
  size_t Start_Next;  /* Offset of where to start reading next */
  int attr;
} DilloPlain;


/*
 * Forward declarations
 */
static void Plain_update (DilloPlain *plain, void *Buf, gint BufSize);
static void Plain_callback(int Op, void *CbData, void *Buf, gint BufSize);


/*
 * ?
 */
static void Plain_page(DilloPlain* plain)
{
  Dw *page;
  DwPageFont font;
  DwPageAttr attr;

   if (plain->dw) return;
  page = a_Dw_page_new (&plain->dw);
  plain->dw = page;

  /* Create the font and attribute for the page. */
#if 0
  font.font = NULL;
#endif
  font.name = "courier";
  font.size = 12;
  font.bold = FALSE;
  font.italic = FALSE;

  a_Dw_page_init_attr ((DwPage *)page, &attr);
  attr.font = a_Dw_page_find_font ((DwPage *)page, &font);

  plain->attr = a_Dw_page_find_attr ((DwPage *)page, &attr);

}

/*
 * ?
 */
Dw* a_Dw_plain(const char*type, void* d, CA_Callback_t* Call, void** Data)
{
  DilloPlain *plain = g_malloc(sizeof(*plain));

   /* todo: this should probably be a function of dw_page */
   *Call = (CA_Callback_t)Plain_callback;
   *Data = (void*)plain;
  plain->Start_Next = 0;
  plain->dw=NULL;

  Plain_page(plain);
  return plain->dw;
}

/*
 * ?
 */
static void Plain_callback(int Op, void *CbData, void *Buf, gint BufSize)
{
  DilloPlain *plain= CbData;
  DwPage *page;

  Plain_page(plain);

  page = (DwPage *)plain->dw;
  a_Dw_page_update_begin (page);

  if (Op) {
     /* Do the last line: */
     if (plain->Start_Next < BufSize) {
        char *S = g_malloc(BufSize - plain->Start_Next + 1);
        strncpy(S, ((char*)Buf) + plain->Start_Next,
                BufSize - plain->Start_Next);
        a_Dw_page_add_text ((DwPage *)plain->dw,S, plain->attr);
        a_Dw_page_linebreak ((DwPage *)plain->dw);
     }
     page->Parent=NULL;
     g_free(plain);
  } else {
     Plain_update(plain, Buf, BufSize);
  }

  a_Dw_page_update_end (page);
}

/*
 * ?
 */
static void Plain_update (DilloPlain *plain, void *Buf, gint BufSize)
{
   char *Start = ((char*)Buf) + plain->Start_Next, 
        *End = Start;
   size_t MaxScan = BufSize - plain->Start_Next;
   int Inc=0;
 
   for (; MaxScan>0; MaxScan--,End++,Inc++) {
      char C;
      if (*End !='\r' && *End!='\n' && *End) continue;

      /* Display the line */
      C=End[0];
      End[0]=0;
/* BUG: We /have/ to duplicate the string...  */
      a_Dw_page_add_text ((DwPage *)plain->dw, g_strdup(Start), plain->attr);
      a_Dw_page_linebreak ((DwPage *)plain->dw);
      End[0]=C;
      plain->Start_Next+=Inc+1;
      if (!*End) break;
      Inc=-1;
      Start=End+1; /* Skip past the end of line marker */
      if (C=='\r' && *Start=='\n') 
         {Start++; plain->Start_Next++;End++; MaxScan--;}

      /* Skip past DOSish junk */
      while (MaxScan>1&&*Start=='\r')
         {Start++; plain->Start_Next++;End++;MaxScan--;}
   }
}
