/*
 * File: cache.c
 *
 * Copyright 2000 Jorge Arellano Cid <jcid@inf.utfsm.cl>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

/*
 * Dillo's cache module
 */

#include <ctype.h>              /* for tolower */
#include <sys/types.h>

#include <sys/stat.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>

#include "config.h"
#include "list.h"
#include "IO/Url.h"
#include "IO/url.h"
#include "IO/IO.h"
#include "cache.h" 
#include "web.h"
#include "nav.h"


/*
 *  Local data types
 */

typedef struct {
   const char *Url;     /* Cached Url. Url is used as a primary Key */
   const char *Type;     /* MIME type string */
   GString *Header;      /* HTTP header */
   const char *Location; /* New URI for redirects */
   void *Data;           /* Pointer to raw data */
   size_t ValidSize,     /* Actually size of valid range */
          TotalSize,     /* Goal size of the whole data (0 if unknown) */
          BuffSize;      /* Buffer Size for unknown length transfers */
   unsigned Flags;       /* Look Flag Defines above */
   IOData_t *io;         /* Pointer to IO data */
} CacheData_t;

typedef struct {
   const char *Url;         /* Pointer to a cache entry Url */
   CA_Callback_t Callback;  /* Client function */
   void *CbData;            /* Client function data */
   size_t SentBytes;        /* Count of bytes already sent to client */
   DilloWeb *Web;           /* Pointer to the Web structure of our client */
} CacheClient_t;


/*
 *  Local data
 */
/* A list for cached data */
static CacheData_t *CacheList = NULL;
static gint CacheListSize = 0, CacheListMax = 32;

/* A list for cache clients.
 * Although implemented as a list, we'll call it ClientQueue  --Jcid */
static CacheClient_t *ClientQueue = NULL;
static gint ClientQueueSize = 0, ClientQueueMax = 16;


/*
 *  Forward declarations
 */
void Cache_process_queue(CacheData_t *entry);

/*
 * Function substitutes (todo: implement this function)
 */
void a_Cache_freeall(void) {};


/*
 * Set safe values for a new cache entry
 */
void Cache_init_entry(CacheData_t *NewEntry, const char *Url)
{
   NewEntry->Url = g_strdup(Url);
   NewEntry->Type = NULL;
   NewEntry->Header = g_string_new("");
   NewEntry->Location = NULL;
   NewEntry->Data = NULL;
   NewEntry->ValidSize = 0;
   NewEntry->TotalSize = 0;
   NewEntry->BuffSize = 4096;
   NewEntry->Flags = 0;
   NewEntry->io = NULL;
}

/*
 * Allocate and set a new entry in the cache list
 */
CacheData_t *Cache_add_entry(const char *Url)
{
   /* Allocate memory */
   a_List_add(CacheList, CacheListSize, sizeof(*CacheList), CacheListMax);
   /* Set safe values */
   Cache_init_entry(&CacheList[CacheListSize], Url);
   return &CacheList[CacheListSize++];
}

/*
 * Add a client to ClientQueue.
 *  - Every client-camp is just a reference. There's nothing to deallocate
 *  - If 'Callback' is NULL, it will be set when processing the Queue
 *  - When this function gets called, CbData points to a Web structure;
 *    that changes later, so we keep a pointer to it.
 */
void 
 Cache_enqueue_client(const char *Url, CA_Callback_t Callback, void *CbData)
{
   /* Ensure memory size */
   a_List_add(ClientQueue, ClientQueueSize, sizeof(*ClientQueue),
              ClientQueueMax);

   ClientQueue[ClientQueueSize].Url = Url;
   ClientQueue[ClientQueueSize].Callback = Callback;
   ClientQueue[ClientQueueSize].CbData = CbData;
   ClientQueue[ClientQueueSize].Web    = CbData;
   ClientQueue[ClientQueueSize].SentBytes = 0;
   ++ClientQueueSize;
}

/*
 * Get the data structure for a cached URL (using 'Url' as the search key)
 * If 'Url' isn't cached, return NULL
 * (We search backwards to speed up the process)
 */
CacheData_t *Cache_search(const char *Url)
{
   int i;

   for ( i = CacheListSize - 1; i >= 0; --i )
      if ( strcmp(Url, CacheList[i].Url) == 0 )
         return (CacheList + i);
   return NULL;
}

/*
 * Get the data structure for a cached URL 
 * If 'Url' isn't cached, return NULL
 * ===> 'Url' must a be a pointer to entry->Url <===
 */
CacheData_t *Cache_fast_search(const char *Url)
{
   int i;

   for ( i = CacheListSize - 1; i >= 0; --i )
      if ( Url == CacheList[i].Url )
         return (CacheList + i);
   return NULL;
}

/*
 * Try finding the url in the cache. If it hits, send the cache contents
 * from there. If it misses, set up a new connection.
 * This function sets the proper callback function for processing the data;
 * - It makes the binding based on content/type info and 'Web' data
 * - CbData is a Web structure with the 'bw' camp set; images also have
 *   'imgsink' camp set.
 *
 * Return value: A FD. (Currently used by the dicache)
 */
int a_Cache_open_url(const char *Url, CA_Callback_t Call, void *CbData)
{
   CacheData_t *entry = Cache_search(Url);

   g_print("a_Cache_open_url: %s\n", Url);

   if ( !entry ) {
      /* URL not cached: create an entry, send our client to the queue,
       * and open a new connection */
      entry = Cache_add_entry(Url);
      Cache_enqueue_client(entry->Url, Call, CbData);
      return a_Url_open(entry->Url, CbData);
   } else {
      /* Feed our client with cached data */
      Cache_enqueue_client(entry->Url, Call, CbData);
      Cache_process_queue(entry);
   }
   /* todo: set this function void */
   return -1; 
}

/*
 * Return the pointer to URL 'Data' in the cache.
 * (We also return its size in 'Size')
 */
char *a_Cache_url_read (const char *Url, int *Size)
{
   CacheData_t *entry = Cache_search(Url);

   if ( !entry ) {
      *Size = 0;
      return NULL;
   }
   if ( entry->Flags & CA_Redirect && entry->Location ) 
      return a_Cache_url_read(entry->Location, Size);

   *Size = entry->ValidSize;
   return (char *) entry->Data;
}

/*
 * Extract a single field from the header, allocating and storing the value
 * in 'field'. ('fieldname' must not include the trailing ':')
 * Return a new string with the field-content if found (NULL on error)
 * (This function expects a '\r' stripped header)
 */
char *Cache_parse_field (const char *header, const char *fieldname)
{
   char *field;
   int i, j;

   for ( i = 0; header[i]; i++ ) {
      /* Search fieldname */
      for (j = 0; fieldname[j]; j++)
        if ( tolower(fieldname[j]) != tolower(header[i + j]))
           break;
      if ( fieldname[j] ) {
         /* skip to next line */
         for ( i += j; header[i] != '\n'; i++);
         continue;
      }

      i += j;
      while (header[i] == ' ') i++;
      if (header[i] == ':' ) {
        /* Field found! */
        while (header[++i] == ' ');
        for (j = 0; header[i + j] != '\n'; j++);
        field = (char *) g_malloc(j + 1);
        strncpy(field, header + i, j);
        field[j] = '\0';
        return field;
      }
   }
   return NULL;
}

/*
 * Scan, allocate, and set things according to header info.
 * (This function needs the whole header to work)
 */
void Cache_parse_header(CacheData_t *entry, IOData_t *io, int HdrLen)
{
   char *header = entry->Header->str;
   char *Length, *Type;

   /* Get Content-Type */
   Type = Cache_parse_field(header, "Content-Type");
   entry->Type = Type ? Type : "application/octet-stream";

   if ( header[9] == '3' && header[10] == '0' ) {
      /* 30x: URL redirection */
      entry->Flags |= CA_Redirect;
      if ( header[11] == '1' ) 
         /* 301 Moved Permanently */
         entry->Flags |= CA_ForceRedirect;
      entry->Location = Cache_parse_field(header, "Location");
   }

   if ( (Length = Cache_parse_field(header, "Content-Length")) != NULL ) {
      entry->TotalSize = atol(Length); 
      g_free(Length);
      entry->Data = g_malloc(entry->TotalSize);
      memcpy(entry->Data, io->IOVec.iov_base + HdrLen, io->Status - HdrLen);
      entry->ValidSize = io->Status - HdrLen;
      /* Prepare next read */
      g_free(io->IOVec.iov_base);
      io->IOVec.iov_base = entry->Data + entry->ValidSize;
      io->IOVec.iov_len  = entry->TotalSize - entry->ValidSize;
      /* Now that we have it set, let's update our clients */
      Cache_process_queue(entry);
   } else {
      /* We don't know the size of the transfer; A lazy server? ;) */
      entry->ValidSize = io->Status - HdrLen;
      entry->Data = g_malloc(entry->ValidSize + entry->BuffSize);
      memcpy(entry->Data, io->IOVec.iov_base + HdrLen, entry->ValidSize);
      /* Prepare next read */
      g_free(io->IOVec.iov_base);
      io->IOVec.iov_base = entry->Data + entry->ValidSize;
      io->IOVec.iov_len  = entry->BuffSize;
      /* Now that we have it set, let's update our clients */
      Cache_process_queue(entry);
   }
}

/*
 * Consume bytes until the whole header is got (up to a "\r\n\r\n" sequence)
 * (Also strip '\r' chars from header)
 */
int Cache_get_header(IOData_t *io, CacheData_t *entry)
{
   int N, i;
   GString *hdr = entry->Header;
   guchar *data = io->IOVec.iov_base;

   /* Header finishes when N = 2 */
   N = (hdr->len && hdr->str[hdr->len - 1] == '\n');
   for ( i = 0; i < io->Status && N < 2; ++i ) {
      if ( data[i] == '\r' || !data[i] )
         continue;
      N = (data[i] == '\n') ? N + 1 : 0;
      g_string_append_c(hdr, data[i]);
   }

   if ( N == 2 ){
      /* Got whole header */
      g_string_append_c(hdr, '\0');
      entry->Flags |= CA_GotHeader;
      /* Return original-header length */
      return i;
   }
   return 0;
}

/*
 * Receive new data, update the reception buffer (for next read), update the
 * cache, and service the client queue.
 *
 * This function gets called by the IO whenever new data arrives.
 *  'Op' is the operation to perform
 *  'VPtr' is a (void) pointer to the IO control structure
 */
void a_Cache_callback(int Op, void *VPtr)
{
   IOData_t *io = VPtr;
   const char *Url = io->CbData;
   CacheData_t *entry = Cache_fast_search(Url);
   int Status, len;

   if ( Op == IOClose ) {
      entry->Flags |= CA_GotData;
      entry->TotalSize = entry->ValidSize;
      /* Free IOData_t structure */
      g_free(io);
      Cache_process_queue(entry);
      return;
   } else if ( Op == IOAbort ) {
      /* todo: implement Abort
       * Eliminate io struct, cache entry and anything related */
      g_print("a_Cache_callback Op = IOAbort; not implemented yet\n");
      g_free(io);
      return;
   }

   if ( !(entry->Flags & CA_GotHeader) ) {
      /* Haven't got the whole header yet */
      len = Cache_get_header(io, entry);
      if ( entry->Flags & CA_GotHeader ) {
         /* Let's scan, allocate, and set things according to header info */
         Cache_parse_header(entry, io, len);
      }
      return;
   }

   Status = io->Status;
   entry->ValidSize += Status;
   if ( Status < io->IOVec.iov_len ) {
      /* An incomplete buffer; update buffer & size */
      io->IOVec.iov_len  -= Status;
      io->IOVec.iov_base += Status;
   } else if ( Status == io->IOVec.iov_len ) {
      /* A full buffer! */
      if ( !entry->TotalSize ) {
         /* We are receiving in small chunks... */
         entry->Data = g_realloc(entry->Data,entry->ValidSize+entry->BuffSize);
         io->IOVec.iov_base = entry->Data + entry->ValidSize;
         io->IOVec.iov_len  = entry->BuffSize;
      } else {
         /* We have a preallocated buffer! */
         io->IOVec.iov_len  -= Status;
         io->IOVec.iov_base += Status;
      }
   }
   Cache_process_queue(entry);
}

/*
 * Process redirections (HTTP 30x answers)
 * (This is a work in progress --not finished yet)
 */
int Cache_redirect(CacheData_t *entry, int Flags, BrowserWindow *bw)
{
   if ( ((entry->Flags & CA_Redirect) && entry->Location) &&
        ((entry->Flags & CA_ForceRedirect) || !entry->ValidSize ||
         entry->ValidSize < 1024 ) ) {

      g_print(">>>Redirect from: %s\n to %s\n", entry->Url, entry->Location);
      g_print("%s", entry->Header->str);

      if ( Flags & WEB_RootUrl ) {
         /* Redirection of the main page */
         a_Nav_remove_top_url(bw, entry->Url);
         a_Nav_push(bw, entry->Location);
      } else {
         /* Sub entity redirection (most probably an image) */
         if ( !entry->ValidSize ) {
            g_print(">>>Image redirection without entity-content<<<\n");
         } else {
            g_print(">>>Image redirection with entity-content<<<\n");
         }
      }
   }
   return 0;
}

/*
 * Do nothing, but let the cache fill the entry.
 * (Currently used to ignore image redirects  --Jcid)
 */
void a_Cache_null_client(int Op, void *CbData, void *Buf, gint BufSize)
{
 return;
}

/*
 * Update cache clients for a single cache-entry
 * Tasks:
 *   - Set the client function (if not already set)
 *   - Look if new data is available and pass it to client functions
 *   - Remove clients when done
 *   - Call redirect handler
 *
 * todo: Implement CA_Abort Op in client callback
 */
void Cache_process_queue(CacheData_t *entry)
{
   const char *Url = entry->Url;
   CacheClient_t *Client;
   int i;
   void *Buf;
   gint BufSize;

   if ( !(entry->Flags & CA_GotHeader) )
      return; 

   for ( i = 0; i < ClientQueueSize; ++i ) {
      if ( ClientQueue[i].Url == Url ) {
         Client = ClientQueue + i;

         /* Don't follow non RootUrl redirections */
         if ( (entry->Flags & CA_Redirect) && 
              !(Client->Web->flags & WEB_RootUrl) ) 
            Client->Callback = a_Cache_null_client;

         /* Set client function */
         if ( !Client->Callback )
            a_Web_dispatch_by_type(entry->Type, Client->Web,
                                   &Client->Callback, &Client->CbData);
         /* Send data to our client */
         if ( (BufSize = entry->ValidSize - Client->SentBytes) > 0) {
            Buf = entry->Data + Client->SentBytes;
            (Client->Callback)(CA_Send, Client->CbData, Buf, BufSize);
         }
         /* Remove client when done */
         if ( (entry->Flags & CA_GotData) ) {
            /* Copy Client data to local vars */
            void *bw = Client->Web->bw;
            int flags = Client->Web->flags;
            /* We finished sending data, let the client know */
            (Client->Callback)(CA_Close, Client->CbData, NULL, 0);
            a_Web_free(Client->Web);
            a_List_remove(ClientQueue, i, ClientQueueSize); --i;
            if ( entry->Flags & CA_Redirect ) 
                 Cache_redirect(entry, flags, bw);
         }
      }
   } /* for */
   g_print("QueueSize ====> %d\n", ClientQueueSize);
}

/*
 * Remove the url from the CacheList
 * todo: Handle running clients on an entry (currently avoided).
 *       That must be implemented after the IO abort mechanism. --Jcid
 */
void a_Cache_remove_entry (char *url)
{
   int i;
   CacheData_t *entry;

   if ( (entry = Cache_search(url)) != NULL ) {
      /* Check for a running client on the cache entry */
      for ( i = 0; i < ClientQueueSize; ++i ) {
         if ( strcmp(ClientQueue[i].Url, entry->Url) == 0 )
            return;
      }
      a_List_remove(CacheList, entry - CacheList, CacheListSize);
   }
}
