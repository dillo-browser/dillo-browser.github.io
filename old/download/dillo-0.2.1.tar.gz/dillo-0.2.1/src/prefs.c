/*
 * Preferences for dillo
 * 
 * Copyright (C) 2000 Luca Rota <lrota@cclinf.polito.it>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <glib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "prefs.h"
#include "colors.h"
#include "dillo.h"
#include "misc.h"

/* symbol array */
static const struct {
   gchar *name;
   guint  token;
} symbols[] = {
   { "http_proxy", DRC_TOKEN_PROXY, },
   { "no_proxy", DRC_TOKEN_NOPROXY, },
   { "link_color", DRC_TOKEN_LINK_COLOR, },
   { "bg_color", DRC_TOKEN_BG_COLOR, },
   { "allow_white_bg", DRC_TOKEN_ALLOW_WHITE_BG, },
   { "text_color", DRC_TOKEN_TEXT_COLOR, },
   { "home", DRC_TOKEN_HOME }
};

static const guint n_symbols = sizeof (symbols) / sizeof (symbols[0]);

static guint Prefs_parser (GScanner *scanner)
{
   guint symbol;

   /* expect a valid symbol */
   g_scanner_get_next_token (scanner);
   symbol = scanner->token;
   if (symbol < DRC_TOKEN_FIRST ||
       symbol > DRC_TOKEN_LAST )
      return G_TOKEN_SYMBOL;

   /* expect '=' */
   g_scanner_get_next_token (scanner);
   if (scanner->token != G_TOKEN_EQUAL_SIGN)
      return G_TOKEN_EQUAL_SIGN;

   /* expect a string */
   g_scanner_get_next_token (scanner);
   if (scanner->token != G_TOKEN_STRING)
      return G_TOKEN_STRING;

   /* assign value and exit successfully */
   switch (symbol) {
   case DRC_TOKEN_PROXY:
      prefs.http_proxy = g_strdup(scanner->value.v_string);
      break;
   case DRC_TOKEN_NOPROXY:
      prefs.no_proxy = g_strdup(scanner->value.v_string);
      break;
   case DRC_TOKEN_LINK_COLOR:
      prefs.link_color = a_Color_parse (scanner->value.v_string,
                                        prefs.link_color);
      break;
   case DRC_TOKEN_TEXT_COLOR:
      prefs.text_color = a_Color_parse (scanner->value.v_string,
                                        prefs.text_color);
      break;
   case DRC_TOKEN_BG_COLOR:
      prefs.bg_color = a_Color_parse (scanner->value.v_string,
                                      prefs.bg_color);
      break;
   case DRC_TOKEN_ALLOW_WHITE_BG:
      prefs.allow_white_bg = (strcmp(scanner->value.v_string, "YES") == 0);
      break;
   case DRC_TOKEN_HOME:
      prefs.home = g_strdup(scanner->value.v_string);
      break;
   default:
      /* Not reached */
   }

   return G_TOKEN_NONE;
}

gint Prefs_load(void)
{
   GScanner *scanner;
   gint i, fd;
   guint expected_token;
   gchar *file;

   /* Here we load and set the bookmarks */
   file = a_Misc_prepend_user_home (".dillo/dillorc");
   fd = open (file, O_RDONLY);
   if (fd < 0)
      return FILE_NOT_FOUND;
   g_free (file);
   
   scanner = g_scanner_new (NULL);

   /* Adjust lexing behaviour to suit our needs */
   /* Specifies the chars which can be used in identifiers */
   scanner->config->cset_identifier_nth = (
      G_CSET_a_2_z
      "~_:/.0123456789"
      G_CSET_A_2_Z
      G_CSET_LATINS   /*??? I don't know if we need these two */
      G_CSET_LATINC   /*??? */
   );
   /* Specifies the chars which can start identifiers */
   scanner->config->cset_identifier_first = (
      G_CSET_a_2_z
      "_0"
      G_CSET_A_2_Z
   );
   /* Don't return G_TOKEN_SYMBOL, but the symbol's value */
   scanner->config->symbol_2_token = TRUE;
   /* Don't return G_TOKEN_IDENTIFIER, but convert it to string */
   scanner->config->identifier_2_string = TRUE;
   
   /* load symbols into the scanner */
   g_scanner_freeze_symbol_table (scanner);
   for (i = 0; i < n_symbols; i++)
      g_scanner_add_symbol (scanner, symbols[i].name, GINT_TO_POINTER (symbols[i].token));
   g_scanner_thaw_symbol_table (scanner);

   /* feed in the text */
   g_scanner_input_file (scanner, fd);

   /* give the error handler an idea on how the input is named */
   scanner->input_name = "dillorc";

   /* 
    * Scanning loop, we parse the input untill it's end is reached,
    * the scanner encountered a lexing error, or our sub routine came
    * across invalid syntax
    */
   do {
      expected_token = Prefs_parser (scanner);
      g_scanner_peek_next_token (scanner);
   } while (expected_token == G_TOKEN_NONE &&
            scanner->next_token != G_TOKEN_EOF &&
            scanner->next_token != G_TOKEN_ERROR);

   /* give an error message upon syntax errors */
   if (expected_token != G_TOKEN_NONE)
      g_scanner_unexp_token (scanner, expected_token, NULL, "symbol", NULL, 
                             NULL, TRUE);

   /* finish parsing */
   g_scanner_destroy (scanner);
   return PARSE_OK;
}

void a_Prefs_init(void)
{
   prefs.link_color = DW_COLOR_DEFAULT_BLUE;
   prefs.bg_color = DW_COLOR_DEFAULT_BGND;
   prefs.text_color = DW_COLOR_DEFAULT_BLACK;
   prefs.home = DILLO_HOME;
   prefs.allow_white_bg = FALSE;
   Prefs_load();
}

/*
 *  Preferences memory-deallocation
 *  (Call this one at exit time)
 */
void a_Prefs_freeall(void)
{
   if (prefs.http_proxy)
      g_free (prefs.http_proxy);
   if (prefs.no_proxy)
      g_free (prefs.no_proxy);
   g_free(prefs.home);
}
