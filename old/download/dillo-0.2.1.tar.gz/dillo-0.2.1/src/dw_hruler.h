#ifndef __DW_HRULER_H__
#define __DW_HRULER_H__

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

typedef struct _DwHruler DwHruler;

struct _DwHruler {
  Dw dw;
  int width;
};

Dw *a_Dw_hruler_new(int width);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __DW_HRULER_H__ */
