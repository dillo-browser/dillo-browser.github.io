/*
 * File: imgsink.c
 *
 * Copyright (C) 1997 Raph Levien <raph@acm.org>
 * Copyright (C) 1999 James McCollough <jamesm@gtwn.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

#include <gtk/gtk.h>

#include <stdio.h>
#include "imgsink.h"

#undef DISABLE_ALL_IMGSINK

/*
 * Create or initialize a new imgsink (with safe values)
 * If 'imgs' is NULL then return a newly allocated imgsink
 * If 'imgs' is allocated then initialize that imgsink
 */
DilloImgSink *a_Imgsink_new(DilloImgSink *imgs)
{
   DilloImgSink *imgsink;

   imgsink = (imgs) ? imgs : g_new(DilloImgSink, 1);
   imgsink->Parent = NULL;
   imgsink->dw = (DwImage *) a_Dw_image_new(DW_IMAGE_RGB);
   imgsink->width = imgsink->in_width = 0;
   imgsink->height = imgsink->in_height = 0;
   imgsink->cmap = NULL;
   imgsink->in_type = DILLO_IMG_TYPE_NOTSET;  /* set_parms will set this */
   imgsink->bg_color = DW_PAINT_DEFAULT_BGND;
   imgsink->RefCount = 0;
   imgsink->close_handler = NULL;
   imgsink->close_data = NULL;
   return imgsink;
}

/*
 * Set operational parameters of the imgsink
 */
void a_Imgsink_set_parms(DilloImgSink *imgsink,
                         gint width,
                         gint height,
                         DilloImgType type)
{
#ifdef DISABLE_ALL_IMGSINK
   return;
#endif
   if (imgsink->set_parms)
      imgsink->set_parms(imgsink, width, height, type);
   else
      g_print("set_parms error (method not set)\n");
}

/*
 * When image type is DILLO_IMG_TYPE_INDEXED, set the color map
 */
void a_Imgsink_set_cmap(DilloImgSink *imgsink,
                        const unsigned char *cmap,
                        gint num_colors,
                        gint bg_index)
{
#ifdef DISABLE_ALL_IMGSINK
   return;
#endif
   imgsink->set_cmap(imgsink, cmap, num_colors, bg_index);
}

/*
 * Call the imgsink's write method
 */
void a_Imgsink_write (DilloImgSink *imgsink,
                      const unsigned char *buf,
                      gint x,
                      gint y)
{
#ifdef DISABLE_ALL_IMGSINK
  return;
#endif
  if (imgsink)
     imgsink->write (imgsink, buf, x, y);
  else {
     g_warning("Attempt to write to a NULL imgsink...\n");
     abort();
  }
}

/*
 * Call the close handler and also
 * free the imgsink internal state, and allocated memory
 */
void a_Imgsink_close(DilloImgSink *imgsink) {
#ifdef DISABLE_ALL_IMGSINK
   return;
#endif
   if (!imgsink) /* || imgsink->RefCount-- > 1  --Jcid */
      return;
   if (imgsink->close_handler != NULL)
      (*imgsink->close_handler) (imgsink->close_data, imgsink);
   imgsink->close(imgsink);
}


/*
 * Set a closing function for the imgsink.
 * a_Imgsink_close will call this function and, after that, perform
 * the normal cleanup of the imgsink
 */
void a_Imgsink_set_close_handler(DilloImgSink *imgsink,
          void (*close_handler) (void *data, DilloImgSink *imgsink),
          void *data)
{
   if ( imgsink->close_handler ) 
      g_print("###### Bug: Overlapped imgsink close-handler ######\n");
   imgsink->close_handler = close_handler;
   imgsink->close_data = data;
}
