/*
 * File: interface.c
 *
 * Copyright (C) 1997 Raph Levien <raph@acm.org>
 * Copyright (C) 1999 Sammy Mannaert <nstalkie@tvd.be>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

#include <stdio.h>
#include <gtk/gtk.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <fcntl.h>

#include "list.h"
#include "dillo.h"
#include "web.h"
#include "IO/Url.h"
#include "IO/IO.h"
#include "cache.h"
#include "interface.h"
#include "nav.h"
#include "browser.h"
#include "commands.h"
#include "menu.h"
#include "config.h"
#include "bookmark.h"

#include "dw.h"
#include "dw_gtk_scroller.h"
#include "dw_gtk_view.h"
#include "dw_border.h"
#include "dw_gtk_statuslabel.h"
#include "progressbar.h"

#include "pixmaps.h"
#include <gdk/gdkkeysyms.h>

#undef VERBOSE
#undef OLD_TOOLBAR

/*
 * Forward declarations
 */
static gint Interface_handle_key_event (GtkWidget *widget, GdkEventKey *event,
                                        gpointer data);


/*
 * Local Data
 */
/* BrowserWindow holds all the widgets (and perhaps more)
 * for each new_browser.*/
BrowserWindow **browser_window;
gint num_bw, num_bw_max;


/*
 * Initialize global data
 */
void a_Interface_init(void)
{
   num_bw = 0;
   num_bw_max = 16;
   browser_window = NULL;
}

/*
 * Stop all active connections in the browser window (except downloads)
 */
void a_Interface_stop(BrowserWindow *bw)
{
   gint i;

   /* Remove root clients */
   while ( bw->NumRootClients ) {
      a_Cache_disable_client(bw->RootClients[0]);
      a_List_remove(bw->RootClients, 0, bw->NumRootClients);
   }
   /* Remove image clients */
   while ( bw->NumImageClients ) {
      a_Cache_disable_client(bw->ImageClients[0]);
      a_List_remove(bw->ImageClients, 0, bw->NumImageClients);
   }

   /* Stop cache entries
   for (i = 0; i < bw->NumPageUrls; i++) {
      if ( !(bw->PageUrls[i].Flags & WEB_Download) )
         a_Cache_stop_entry(bw->PageUrls[i].Url);
   }
   */

   a_Interface_status(bw, "Stopped");
}

/*
 * Empty RootClients, ImageClients and PageUrls lists and
 * reset progress bar data.
 */
void a_Interface_clean(BrowserWindow *bw)
{
   g_return_if_fail ( bw != NULL );

   while ( bw->NumRootClients )
      a_List_remove(bw->RootClients, 0, bw->NumRootClients);

   while ( bw->NumImageClients )
      a_List_remove(bw->ImageClients, 0, bw->NumImageClients);

   while ( bw->NumPageUrls ) {
      g_free(bw->PageUrls[0].Url);
      a_List_remove(bw->PageUrls, 0, bw->NumPageUrls);
   }

   /* Zero image-progressbar data */
   bw->NumImages = 0;
   bw->NumImagesGot = 0;
}

/* --- Managing Browser Window Dependencies --------------------------------------- */
/* 
 * Remove the cache-client from the bw list
 * (client can be a image or a html page)
 */
void a_Interface_close_client(BrowserWindow *bw, gint ClientKey)
{
   gint i;
   gchar numstr[32];

   for ( i = 0; i < bw->NumRootClients; ++i)
      if ( bw->RootClients[i] == ClientKey ) {
         a_List_remove(bw->RootClients, i, bw->NumRootClients);
         break;
      }

   for ( i = 0; i < bw->NumImageClients; ++i)
      if ( bw->ImageClients[i] == ClientKey ) {
         a_List_remove(bw->ImageClients, i, bw->NumImageClients);
         bw->NumImagesGot++;
         break;
      }

   a_Interface_set_button_sens(bw);

   /* --Progress bars stuff-- */
   sprintf(numstr,"Images: %d of %d", bw->NumImagesGot, bw->NumImages);
   a_Progressbar_update(bw->imgprogress, numstr, 
                        (bw->NumImagesGot == bw->NumImages) ? 0 : 1 );
}

/*
 * Set the sensitivity on back/forw buttons and menu entries.
 */
static gint Interface_sens_idle_func(BrowserWindow *bw)
{
   gboolean back_sensitive, forw_sensitive, stop_sensitive;

   /* Stop button */
   stop_sensitive = (bw->NumRootClients > 0);
   gtk_widget_set_sensitive(bw->stop_button, stop_sensitive);
   gtk_widget_set_sensitive(bw->stop_menuitem, stop_sensitive);
   if ( !stop_sensitive ) 
      a_Interface_status(bw, "");

   /* Back and Forward buttons */
   back_sensitive = bw->nav_stack_ptr > 0;
   gtk_widget_set_sensitive(bw->back_button, back_sensitive);
   gtk_widget_set_sensitive(bw->back_menuitem, back_sensitive);
   forw_sensitive = (bw->nav_stack_ptr < bw->nav_stack_size - 1 &&
                     !bw->nav_expecting);
   gtk_widget_set_sensitive(bw->forw_button, forw_sensitive);
   gtk_widget_set_sensitive(bw->forw_menuitem, forw_sensitive);

   bw->sens_idle_tag = 0;
   return FALSE;
}

/*
 * Set the sensitivity on back/forw buttons and menu entries.
 */
void a_Interface_set_button_sens(BrowserWindow *bw)
{
   if (bw->sens_idle_tag != 0)
      return;
   bw->sens_idle_tag = gtk_idle_add
       ((GtkFunction) Interface_sens_idle_func, bw);
}

/*
 * Add a reference to the cache-client in the browser window's list.
 * This helps us keep track of which are active in the window so that it's
 * possible to abort them.
 * (Root: Flag, whether a Root URL or not)
 */
void a_Interface_add_client(BrowserWindow *bw, gint Key, gint Root)
{
   gint nc;
   char numstr[32];

   g_return_if_fail ( bw != NULL );

   if ( Root ) {
      nc = bw->NumRootClients;
      a_List_add(bw->RootClients, nc, sizeof(*bw->RootClients),
                 bw->MaxRootClients);
      bw->RootClients[nc] = Key;
      bw->NumRootClients++;
      a_Interface_set_button_sens(bw);
   } else {
      nc = bw->NumImageClients;
      a_List_add(bw->ImageClients, nc, sizeof(*bw->ImageClients),
                 bw->MaxImageClients);
      bw->ImageClients[nc] = Key;
      bw->NumImageClients++;
      bw->NumImages++;
      a_Interface_set_button_sens(bw);
   
      /* --Progress bar stuff-- */
      sprintf(numstr,"Images: %d of %d", bw->NumImagesGot, bw->NumImages);
      a_Progressbar_update(bw->imgprogress, numstr, 1);
   }
}

/*
 * Add an URL to the browser window's list.
 * This helps us keep track of page requested URLs so that it's
 * possible to stop, abort and reload them.)
 *   Flags: Chosen from {BW_Root, BW_Image, BW_Download}
 */
void a_Interface_add_url(BrowserWindow *bw, char *Url, gint Flags)
{
   gint nu, i;
   gboolean found = FALSE;

   g_return_if_fail ( bw != NULL && Url != NULL );

   nu = bw->NumPageUrls;
   for ( i = 0; i < nu; i++ ) {
      if ( strcmp(Url, bw->PageUrls[i].Url) == 0 ) {
         found = TRUE;
         break;
      }
   }
   if ( !found ) {
      a_List_add(bw->PageUrls, nu, sizeof(*bw->PageUrls), bw->MaxPageUrls);
      bw->PageUrls[nu].Url = g_strdup(Url);
      bw->PageUrls[nu].Flags = Flags;
      bw->NumPageUrls++;
   }

   /* test:
   g_print("Urls:\n");
   for (i = 0; i < bw->NumPageUrls; i++) 
      g_print("%s\n", bw->PageUrls[i].Url);
   g_print("---\n");
   */
}
                       
/*
 * Remove a browser window. This includes destroying all open windows
 * (except for the main browser window, which is presumed to be
 * destroyed in the caller), freeing all resources associated with the
 * browser window, and exiting gtk if no windows are left.
 */
static gboolean Interface_quit(GtkWidget *widget, BrowserWindow *bw)
{
   gint i;

   /* todo: should probably abort any open connections. */
   if (bw->open_dialog_window != NULL)
      gtk_widget_destroy(bw->open_dialog_window);
   if (bw->openfile_dialog_window != NULL)
      gtk_widget_destroy(bw->openfile_dialog_window);
   if (bw->quit_dialog_window != NULL)
      gtk_widget_destroy(bw->quit_dialog_window);

   if (bw->sens_idle_tag)
      gtk_idle_remove(bw->sens_idle_tag);

   for (i = 0; i < num_bw; i++)
      if (browser_window[i] == bw) {
         browser_window[i] = browser_window[--num_bw];
         break;
      }
   for (i = 0; i < bw->nav_stack_size; i++) {
      g_free(bw->nav_stack[i].url);
      if (bw->nav_stack[i].title != NULL)
         g_free(bw->nav_stack[i].title);
   }
   g_free(bw->nav_stack);
   g_free(bw->ImageClients);
   g_free(bw);
   if (num_bw == 0)
      gtk_main_quit();

   return FALSE;
}

/*
 * Clear a text entry
 */
void Interface_entry_clear(GtkEntry *entry)
{
   gtk_entry_set_text(entry, "");
   gtk_widget_grab_focus(GTK_WIDGET(entry));
}

/*
 * Creates a pixmap and returns it.
 */
GtkWidget *Interface_new_pixmap(GtkWidget *parent, gchar **data)
{
   GtkWidget *pixmapwid;
   GdkPixmap *pixmap;
   GdkBitmap *mask;
   GtkStyle *style;

   style = gtk_widget_get_style(parent);

   pixmap = gdk_pixmap_create_from_xpm_d(parent->window, &mask,
                                     &style->bg[GTK_STATE_NORMAL], data);

   pixmapwid = gtk_pixmap_new(pixmap, mask);

   return (pixmapwid);
}


/*
 * Creates a new browser window and returns the browser
 * window struct. 
 */
BrowserWindow *a_Interface_new_browser_window(void)
{
   /* used to create new windows - index into browser_window[] 
    * not really implemented. */

   GtkWidget *toolbar;
   GtkWidget *box1;
   GtkWidget *box2;
   GtkWidget *box3;
   GtkWidget *progbox;
   GtkWidget *toolbarbox;
   GtkWidget *handlebox;
   GtkWidget *menubar;
   GtkWidget *pixmap;
   BrowserWindow *bw;

   char buf[256];

   /* We use g_malloc0() to zero the memory */
   bw = g_malloc0(sizeof(BrowserWindow));
   bw->save_dialog_window = NULL;

   a_List_add(browser_window, num_bw, sizeof(*browser_window), num_bw_max);
   browser_window[num_bw++] = bw;

   /* initialize nav_stack struct in browser_window struct */
   a_Nav_init(bw);

   bw->main_window = gtk_window_new(GTK_WINDOW_TOPLEVEL);

   gtk_window_set_policy(GTK_WINDOW(bw->main_window), TRUE, TRUE, FALSE);
   gtk_signal_connect(GTK_OBJECT(bw->main_window), "delete_event",
                      GTK_SIGNAL_FUNC(gtk_object_destroy), bw);
   gtk_signal_connect(GTK_OBJECT(bw->main_window), "destroy",
                      GTK_SIGNAL_FUNC(Interface_quit), bw);
   gtk_container_border_width(GTK_CONTAINER(bw->main_window), 0);

   gtk_window_set_wmclass(GTK_WINDOW(bw->main_window), "dillo", "Dillo");

   /* -RL :: I must realize the window to see it correctly */
   gtk_widget_realize(bw->main_window);

   /* set window title */
   sprintf(buf, "Version %s", VERSION);
   a_Interface_set_Page_title(bw, buf);

   box1 = gtk_vbox_new(FALSE, 0);

   /* setup the menus */
   handlebox = gtk_handle_box_new();
   gtk_box_pack_start(GTK_BOX(box1), handlebox, FALSE, FALSE, 0);
   menubar = a_Menu_mainbar_new(bw);
   gtk_container_add(GTK_CONTAINER(handlebox), menubar);
  
   menu_popup.menu = a_Menu_popup_new(bw);
   menu_popup.menu_over_link = a_Menu_popup_ol_new(bw);

   gtk_widget_show(menubar);
   gtk_widget_show(handlebox);
   gtk_window_add_accel_group (GTK_WINDOW (bw->main_window), bw->accel_group);
 
   bw->sens_idle_tag = 0;

   /* We'll put the toolbar into the handle box so that it can be
    * detached from the main window */
   handlebox = gtk_handle_box_new();
   gtk_box_pack_start(GTK_BOX(box1), handlebox, FALSE, FALSE, 0);
   toolbarbox = gtk_hbox_new(FALSE, 0);
   toolbar = gtk_toolbar_new(GTK_ORIENTATION_HORIZONTAL, GTK_TOOLBAR_BOTH);
   gtk_container_set_border_width(GTK_CONTAINER(handlebox), 5);
   gtk_toolbar_set_button_relief(GTK_TOOLBAR(toolbar), GTK_RELIEF_NONE);

   /* back button */
   bw->back_button = gtk_toolbar_append_item(GTK_TOOLBAR(toolbar),
                           "Back", "Go to previous page", "Toolbar/Back",
                    Interface_new_pixmap(bw->main_window, leftarrow_xpm),
                           (GtkSignalFunc) a_Commands_back_callback, bw);

   gtk_widget_set_sensitive(bw->back_button, FALSE);
   gtk_widget_set_sensitive(bw->back_menuitem, FALSE);

   /* forward button */
   bw->forw_button = gtk_toolbar_append_item(GTK_TOOLBAR(toolbar),
                         "Forward", "Go to next page", "Toolbar/Forward",
                    Interface_new_pixmap(bw->main_window, rightarrow_xpm),
                           (GtkSignalFunc) a_Commands_forw_callback, bw);

   gtk_widget_set_sensitive(bw->forw_button, FALSE);
   gtk_widget_set_sensitive(bw->forw_menuitem, FALSE);

   /* home button */
   gtk_toolbar_append_item(GTK_TOOLBAR(toolbar),
                           "Home", "Go to the Home page", "Toolbar/Home",
                         Interface_new_pixmap(bw->main_window, home_xpm),
                           (GtkSignalFunc) a_Commands_home_callback, bw);

   /* reload button */
   gtk_toolbar_append_item(GTK_TOOLBAR(toolbar),
                           "Reload", "Reload this page", "Toolbar/Reload",
                       Interface_new_pixmap(bw->main_window, reload_xpm),
                         (GtkSignalFunc) a_Commands_reload_callback, bw);

   /* save button */
   gtk_toolbar_append_item(GTK_TOOLBAR(toolbar),
                           "Save", "Save this page", "Toolbar/Save",
                         Interface_new_pixmap(bw->main_window, save_xpm),
                           (GtkSignalFunc) a_Commands_save_callback, bw);

   /* stop button */
   bw->stop_button = gtk_toolbar_append_item(GTK_TOOLBAR(toolbar),
                     "Stop", "Stop the current transfer", "Toolbar/Stop",
                         Interface_new_pixmap(bw->main_window, stop_xpm),
                           (GtkSignalFunc) a_Commands_stop_callback, bw);


   gtk_widget_set_sensitive(bw->stop_button, FALSE);
   gtk_widget_set_sensitive(bw->stop_menuitem, FALSE);

   gtk_box_pack_start(GTK_BOX(toolbarbox), toolbar, TRUE, TRUE, 2);
   gtk_widget_show(toolbar);

   /* progress bars */
   gdk_color_alloc(gdk_colormap_get_system(), &imgbar_color);
   gdk_color_alloc(gdk_colormap_get_system(), &txtbar_color);
   progbox = gtk_vbox_new(FALSE, 0);
   bw->imgprogress = a_Progressbar_new("",imgbar_color,pbar_font);
   bw->progress = a_Progressbar_new( "", txtbar_color, pbar_font);
   gtk_box_pack_start(GTK_BOX(progbox), bw->imgprogress, TRUE, TRUE, 0);
   gtk_widget_show(bw->imgprogress);
   gtk_box_pack_start(GTK_BOX(progbox), bw->progress, TRUE, TRUE, 0);
   gtk_widget_show(bw->progress);
   gtk_box_pack_start(GTK_BOX(toolbarbox), progbox, FALSE, FALSE, 0);
   gtk_widget_show(progbox);
   gtk_container_add(GTK_CONTAINER(handlebox), toolbarbox);

   gtk_widget_show(toolbarbox);
   gtk_widget_show(handlebox);

   gtk_container_add(GTK_CONTAINER(bw->main_window), box1);

   /* location entry */
   handlebox = gtk_handle_box_new();

   box2 = gtk_hbox_new(FALSE, 0);
   bw->location = gtk_entry_new();
   gtk_signal_connect(GTK_OBJECT (bw->location), "key_press_event", 
                      GTK_SIGNAL_FUNC (Interface_handle_key_event), bw);
   gtk_signal_connect(GTK_OBJECT(bw->location), "activate",
                      (GtkSignalFunc) a_Interface_entry_open_url, bw);

   bw->location_button = gtk_button_new();
   gtk_signal_connect_object(GTK_OBJECT(bw->location_button), "clicked",
                             GTK_SIGNAL_FUNC (Interface_entry_clear),
                             GTK_OBJECT(bw->location));
   pixmap = Interface_new_pixmap(bw->main_window, new_xpm);
   gtk_container_add(GTK_CONTAINER(bw->location_button), pixmap);
   gtk_widget_show(pixmap);
   gtk_box_pack_start(GTK_BOX(box2), bw->location_button, FALSE, TRUE, 0);
   gtk_widget_show(bw->location_button);
   gtk_box_pack_start(GTK_BOX(box2), bw->location, TRUE, TRUE, 0);
   gtk_widget_show(bw->location);
   gtk_container_add(GTK_CONTAINER(handlebox), box2);
   gtk_widget_show(box2);
   gtk_box_pack_start(GTK_BOX(box1), handlebox, FALSE, FALSE, 0);
   gtk_widget_show(handlebox);

   /* the main document window */
   bw->docwin = a_Dw_gtk_scroller_new(NULL, NULL);
   a_Dw_gtk_scroller_set_policy(GTK_DW_SCROLLER(bw->docwin),
                                GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);
   gtk_box_pack_start(GTK_BOX(box1), bw->docwin, TRUE, TRUE, 0);
   gtk_widget_show(bw->docwin);

   bw->RootClients = NULL;
   bw->NumRootClients = 0;
   bw->MaxRootClients = 8;

   bw->ImageClients = NULL;
   bw->NumImageClients = 0;
   bw->MaxImageClients = 8;
   bw->NumImages = 0;
   bw->NumImagesGot = 0;

   bw->PageUrls = NULL;
   bw->NumPageUrls = 0;
   bw->MaxPageUrls = 8;

   /* -RL :: Maybe I'd change _widget_set_usize in 
    * _window_default_set_size so the user can resize the window 
    * with a --geometry command line switch when a command line 
    * control will be implemented */
   gtk_widget_set_usize(bw->main_window, 640, 550);

   /* status widget */
   bw->status = a_Dw_gtk_statuslabel_new("");
   gtk_misc_set_alignment(GTK_MISC(bw->status), 0.0, 0.5);
   box3 = gtk_hbox_new(FALSE, 0);

   gtk_box_pack_start(GTK_BOX(box3), bw->status, TRUE, TRUE, 2);
   gtk_widget_show(bw->status);

   gtk_box_pack_start(GTK_BOX(box1), box3, FALSE, FALSE, 2);
   gtk_widget_show(box3);

   gtk_widget_show(bw->main_window);
   gtk_widget_show(box1);

   /* Zero out a bunch of stuff in the bw struct. */
   bw->open_dialog_window = NULL;
   bw->openfile_dialog_window = NULL;
   bw->quit_dialog_window = NULL;
   return bw;
}

/*
 * Set the title of the browser window to start with "Dillo: "
 * prepended to it. Also set the page_title member of the current
 * nav_stack structure for use with the bookmarks. 
 */
void a_Interface_set_Page_title(BrowserWindow *bw, char *title)
{
   GString *buf;
   gint top;

   g_return_if_fail (bw != NULL);

   /* free previously allocated string */
   if ( bw->nav_stack_size ) {
      top = bw->nav_stack_ptr;
      if (bw->nav_stack[top].title)
         g_free(bw->nav_stack[top].title);
      bw->nav_stack[top].title = g_strdup(title);
   }
   buf = g_string_new("");
   g_string_sprintfa(buf, "Dillo: %s", title);
   gtk_window_set_title(GTK_WINDOW(bw->main_window), buf->str);
   g_string_free(buf, TRUE);
}

/*
 * Reset images and text progress bars
 */
void a_Interface_reset_progress_bars(BrowserWindow *bw)
{
   a_Progressbar_update(bw->progress, "", 0);
   a_Progressbar_update(bw->imgprogress, "", 0);
}

/*
 * Set the status string on the bottom of the dillo window.
 */
void a_Interface_status(BrowserWindow *bw, const char *format, ... )
{
static char msg[1024];
va_list argp;

   if ( bw ) {
      va_start(argp, format);
      vsnprintf(msg, 1024, format, argp);
      va_end(argp);
      gtk_label_set(GTK_LABEL(bw->status), msg);
   }
}

/*
 * hmm.. have to see where this is from 
 */
void Interface_destroy_window(GtkWidget *widget, GtkWidget **window)
{
   *window = NULL;
}


/*
 * ?
 */
void a_Interface_quit_all(void)
{
   BrowserWindow **bws;
   gint i, n_bw;

   n_bw = num_bw;
   bws = g_malloc(sizeof(BrowserWindow *) * n_bw);

   /* we copy into a new list because destroying the main window can
    * modify the browser_window array. */
   for (i = 0; i < n_bw; i++)
      bws[i] = browser_window[i];

   for (i = 0; i < n_bw; i++)
      gtk_widget_destroy(bws[i]->main_window);

   g_free(bws);

#ifdef VERBOSE
   g_print("dillo_quit_all: exit\n");
#endif
}


/*
 * ?
 */
static void 
Interface_openfile_ok_callback(GtkWidget *widget, BrowserWindow *bw)
{
   char *fn;
   char url[1024];

#ifdef VERBOSE
   g_print("openfile_ok_callback: %s\n", fn);
#endif
   fn = gtk_file_selection_get_filename
       (GTK_FILE_SELECTION(bw->openfile_dialog_window));
   if (strlen(fn) + 6 <= sizeof(url)) {
      sprintf(url, "file:%s", fn);
      a_Nav_push(bw, url);
   }
   gtk_widget_destroy(bw->openfile_dialog_window);
}



/*
 * Open an URL specified in the location entry, or in the open URL dialog.
 * The URL is not sent as it is; a_Url_resolve_relative() processes it.
 */
void a_Interface_entry_open_url(GtkWidget *widget, BrowserWindow *bw)
{
   gchar *url;
   GtkEntry *entry;

   /* Find which entry to get the URL from. This is a bit of a hack. */

   if (widget == bw->location)
      entry = GTK_ENTRY(bw->location);
   else
      entry = GTK_ENTRY(bw->open_dialog_entry);
#ifdef VERBOSE
   g_print("entry_open_url %s\n", gtk_entry_get_text(entry));
#endif
   url = a_Url_resolve_relative("http:/", gtk_entry_get_text(entry));
   if ( url ) {
      a_Nav_push(bw, url);
      g_free(url);
   }
   if (bw->open_dialog_window != NULL)
      gtk_widget_destroy(bw->open_dialog_window);
   /* todo: pull focus away from location widget probably by focusing
    * to the page, but at the time this todo was added, the gtk_page
    * widget wasn't really focusable. */
}


/*
 * ?
 */
void a_Interface_openfile_dialog(BrowserWindow *bw)
{
   if (!bw->openfile_dialog_window) {
      bw->openfile_dialog_window = gtk_file_selection_new("Open File");
      gtk_window_set_wmclass(GTK_WINDOW(bw->openfile_dialog_window), 
                             "openfile_dialog", "Dillo");
      gtk_signal_connect(GTK_OBJECT(bw->openfile_dialog_window), "destroy",
                         (GtkSignalFunc) Interface_destroy_window, &(bw->openfile_dialog_window));
      gtk_signal_connect(GTK_OBJECT(GTK_FILE_SELECTION
                                (bw->openfile_dialog_window)->ok_button),
          "clicked", (GtkSignalFunc) Interface_openfile_ok_callback, bw);
      gtk_signal_connect_object(GTK_OBJECT(GTK_FILE_SELECTION
                            (bw->openfile_dialog_window)->cancel_button),
                              "clicked", (GtkSignalFunc) gtk_widget_hide,
                                GTK_OBJECT(bw->openfile_dialog_window));
   }
   if (!GTK_WIDGET_VISIBLE(bw->openfile_dialog_window))
      gtk_widget_show(bw->openfile_dialog_window);
   else
      gtk_widget_destroy(bw->openfile_dialog_window);
}

/*
 * ?
 */
void a_Interface_open_dialog(GtkWidget *widget, BrowserWindow *bw)
{
   GtkWidget *button;
   GtkWidget *box1;
   GtkWidget *box2;
   GtkWidget *entry;

   if (!bw->open_dialog_window) {
      bw->open_dialog_window = gtk_window_new(GTK_WINDOW_DIALOG);
      gtk_window_set_wmclass(GTK_WINDOW(bw->open_dialog_window), 
                             "open_dialog", "Dillo");
      gtk_signal_connect(GTK_OBJECT(bw->open_dialog_window), "destroy",
                         (GtkSignalFunc) Interface_destroy_window, &(bw->open_dialog_window));
      gtk_window_set_title(GTK_WINDOW(bw->open_dialog_window),
                           "Dillo: Open URL");
      gtk_container_border_width(GTK_CONTAINER(bw->open_dialog_window), 5);

      box1 = gtk_vbox_new(FALSE, 5);
      gtk_container_add(GTK_CONTAINER(bw->open_dialog_window), box1);
      gtk_widget_show(box1);

      entry = gtk_entry_new();
      bw->open_dialog_entry = entry;
      gtk_widget_set_usize(entry, 250, 0);
      gtk_box_pack_start(GTK_BOX(box1), entry, FALSE, FALSE, 0);
      gtk_widget_show(entry);

      gtk_signal_connect(GTK_OBJECT(entry), "activate", (GtkSignalFunc)
                         a_Interface_entry_open_url, bw);

      box2 = gtk_hbox_new(TRUE, 5);
      gtk_box_pack_start(GTK_BOX(box1), box2, FALSE, FALSE, 0);
      gtk_widget_show(box2);

      button = gtk_button_new_with_label("OK");
      gtk_signal_connect(GTK_OBJECT(button), "clicked", (GtkSignalFunc)
                         a_Interface_entry_open_url, bw);
      GTK_WIDGET_SET_FLAGS(button, GTK_CAN_DEFAULT);
      gtk_box_pack_start(GTK_BOX(box2), button, FALSE, TRUE, 0);
      gtk_widget_grab_default(button);
      gtk_widget_show(button);
      gtk_signal_connect_object(GTK_OBJECT(entry), "focus_in_event",
            (GtkSignalFunc) gtk_widget_grab_default, GTK_OBJECT(button));

      button = gtk_button_new_with_label("Clear");
      gtk_signal_connect_object(GTK_OBJECT(button), "clicked",
               (GtkSignalFunc) Interface_entry_clear, GTK_OBJECT(entry));
      GTK_WIDGET_SET_FLAGS(button, GTK_CAN_DEFAULT);
      gtk_box_pack_start(GTK_BOX(box2), button, FALSE, TRUE, 0);
      gtk_widget_show(button);

      button = gtk_button_new_with_label("Cancel");
      gtk_signal_connect_object(GTK_OBJECT(button), "clicked",
                                (GtkSignalFunc) gtk_widget_destroy,
                                GTK_OBJECT(bw->open_dialog_window));
      GTK_WIDGET_SET_FLAGS(button, GTK_CAN_DEFAULT);
      gtk_box_pack_start(GTK_BOX(box2), button, FALSE, TRUE, 0);
      gtk_widget_show(button);

      gtk_widget_grab_focus(entry);

   }
   /* todo: hiding vs. destroying leaves two problems open. First, the
    * entry is not focussed when it's re-shown. Second, closing the
    * window (from the window manager) really does destroy the contents.
    * 
    * Perhaps a better solution is to keep a spare copy of the entry
    * text around (updated only when the Ok button is clicked), and use
    * it to initialize the entry. Also delete rather than hide the
    * window.
    * 
    * But it's ok for now.
    */
   /* if you take a look at the "OK" button, it calls 
    * a_Interface_entry_open_url which calls gtk_destroy_widget on your
    * open_dialog_window.. Maybe this is what's recking it for you ? -Ian
    */

   if (!GTK_WIDGET_VISIBLE(bw->open_dialog_window))
      gtk_widget_show(bw->open_dialog_window);
   else
      gtk_widget_hide(bw->open_dialog_window);
}


/*
 * Receive data from the cache and save it to a local file
 */
void Interface_save_callback(int Op, CacheClient_t *Client)
{
   DilloWeb *Web = Client->Web;
   gint Bytes;

   if ( Op ){
      struct stat st;

      fflush(Web->stream);
      fstat(fileno(Web->stream), &st);
      fclose(Web->stream);
      a_Interface_status(Web->bw, "File saved (%d Bytes)", st.st_size);
   } else {
      if ( (Bytes = Client->BufSize - Web->SavedBytes) > 0 ) {
         Bytes = fwrite(Client->Buf + Web->SavedBytes, 1, Bytes, Web->stream);
         Web->SavedBytes += Bytes;
      }
   }
}

/*
 * Save current page to a local file
 */
void Interface_entry_save_url(GtkWidget *widget, BrowserWindow *bw)
{
   const char *url, *name;
   GtkEntry *entry, *entry_url;
   FILE *out;

   entry = GTK_ENTRY(bw->save_dialog_entry);
   entry_url = GTK_ENTRY(bw->location);
   name = gtk_entry_get_text(entry);
   url  = gtk_entry_get_text(entry_url);

   if ( strlen(name) && (out = fopen(name, "w")) != NULL ) {
      DilloWeb *Web = a_Web_new(url);
      Web->bw = bw;
      Web->stream = out;
      /* todo: keep track of this client */
      a_Cache_open_url(url, Interface_save_callback, Web);
   }

   if (bw->save_dialog_window != NULL)
      gtk_widget_destroy(bw->save_dialog_window);
}

/*
 * Scan current URL and build a local-filename suggestion for saving 
 */
void Interface_make_save_name(BrowserWindow *bw, char *name)
{
   const char *url, *ptr;
   gint i, len;

   url = gtk_entry_get_text(GTK_ENTRY(bw->location));
   len = strlen(url);
   for (i = len; i > 0; --i)    /* search for last '/' caracter in url */
      if (url[i] == '/') {
         ++i;
         break;
      }
   ptr = url + i;
   if (strlen(ptr) < 64)        /* Common sense limit (I prefer 32 ;) */
      strcpy(name, ptr);
   else
      *name = '\0';             /* No suggested name */
}

/*
 * Show the dialog interface for saving an URL
 */
void a_Interface_save_dialog(GtkWidget *widget, BrowserWindow *bw)
{
   GtkWidget *button;
   GtkWidget *box1;
   GtkWidget *box2;
   GtkWidget *entry;
   char suggested_name[1024];   /* Suggested save name */

   if (!bw->save_dialog_window) {
      bw->save_dialog_window = gtk_window_new(GTK_WINDOW_DIALOG);
      gtk_window_set_wmclass(GTK_WINDOW(bw->save_dialog_window), 
                             "save_dialog", "Dillo");
      gtk_signal_connect(GTK_OBJECT(bw->save_dialog_window), "destroy",
                         (GtkSignalFunc) Interface_destroy_window,
                         &(bw->save_dialog_window));

      gtk_window_set_title(GTK_WINDOW(bw->save_dialog_window),
                           "Dillo: Save URL as file");
      gtk_container_border_width(GTK_CONTAINER(bw->save_dialog_window), 5);

      box1 = gtk_vbox_new(FALSE, 5);
      gtk_container_add(GTK_CONTAINER(bw->save_dialog_window), box1);
      gtk_widget_show(box1);

      entry = gtk_entry_new();
      gtk_widget_set_usize(entry, 250, 0);

      Interface_make_save_name(bw, suggested_name);
      gtk_entry_set_text(GTK_ENTRY(entry), suggested_name);
      gtk_widget_grab_focus(GTK_WIDGET(entry));
      gtk_box_pack_start(GTK_BOX(box1), entry, FALSE, FALSE, 0);
      bw->save_dialog_entry = GTK_WIDGET(entry);
      gtk_widget_show(entry);

      gtk_signal_connect(GTK_OBJECT(entry), "activate",
                         (GtkSignalFunc) Interface_entry_save_url,
                         bw);

      box2 = gtk_hbox_new(TRUE, 5);
      gtk_box_pack_start(GTK_BOX(box1), box2, FALSE, FALSE, 0);
      gtk_widget_show(box2);

      button = gtk_button_new_with_label("OK");
      gtk_signal_connect(GTK_OBJECT(button), "clicked",
                         (GtkSignalFunc) Interface_entry_save_url,
                         bw);
      GTK_WIDGET_SET_FLAGS(button, GTK_CAN_DEFAULT);
      gtk_box_pack_start(GTK_BOX(box2), button, FALSE, TRUE, 0);
      gtk_widget_grab_default(button);
      gtk_widget_show(button);
      gtk_signal_connect_object(GTK_OBJECT(entry), "focus_in_event",
                                (GtkSignalFunc) gtk_widget_grab_default,
                                GTK_OBJECT(button));

      button = gtk_button_new_with_label("Clear");
      gtk_signal_connect_object(GTK_OBJECT(button), "clicked",
                                (GtkSignalFunc) Interface_entry_clear,
                                GTK_OBJECT(entry));
      GTK_WIDGET_SET_FLAGS(button, GTK_CAN_DEFAULT);
      gtk_box_pack_start(GTK_BOX(box2), button, FALSE, TRUE, 0);
      gtk_widget_show(button);

      button = gtk_button_new_with_label("Cancel");
      gtk_signal_connect_object(GTK_OBJECT(button), "clicked",
                                (GtkSignalFunc) gtk_widget_destroy,
                                GTK_OBJECT(bw->save_dialog_window));
      GTK_WIDGET_SET_FLAGS(button, GTK_CAN_DEFAULT);
      gtk_box_pack_start(GTK_BOX(box2), button, FALSE, TRUE, 0);
      gtk_widget_show(button);

      gtk_widget_grab_focus(entry);

   }
   if (!GTK_WIDGET_VISIBLE(bw->save_dialog_window))
      gtk_widget_show(bw->save_dialog_window);
   else
      gtk_widget_hide(bw->save_dialog_window);
}


/* shouldn't all this stuff go in menu.c or something ? 
 * why do we need global window GtkWidgets for the windows ?? 
 * I see you use it in the destroy() function, but I don't 
 * really grasp it's use just yet :) */

/* The way gimp does it is to have a menus.c for the menus themselves
 * and a commands.c for the *_cmd callbacks. They also have an
 * interface.c where most of the interface stuff happens. We should
 * probably follow their lead.
 * 
 * We have globals for the windows so I can destroy all windows before
 * quitting. Some window managers (including fvwm2-95) really like
 * this. -Raph
 */

/* funny you say that, cause if you look at the quit_dialog_window I made, I
 * just gtk_destroy_widget(main_window).. it seems to work ok, but should we
 * change it? -Ian
 */

/* No, the way it is now is fine. When you destroy the main window,
 * that invokes the destroy signal handler, which destroys all of the
 * other windows cleanly. 
 * 
 * Anyway, I wrote the above explanation before we had multiple
 * windows. Another reason to do it this way is that when you close
 * one of several main windows, its various subsidiary windows go away
 * too. -Raph */


/*
 * ?
 */
void a_Interface_quit_dialog(BrowserWindow *bw)
{
   GtkWidget *button;
   GtkWidget *label;

   if (!bw->quit_dialog_window) {
      bw->quit_dialog_window = gtk_dialog_new();
      gtk_signal_connect(GTK_OBJECT(bw->quit_dialog_window), "destroy",
                         (GtkSignalFunc) Interface_destroy_window, &(bw->quit_dialog_window));
      gtk_window_set_title(GTK_WINDOW(bw->quit_dialog_window),
                           "Really Quit ?");
      gtk_container_border_width(GTK_CONTAINER(bw->quit_dialog_window), 0);

      label = gtk_label_new("Really Quit Dillo ?");
      gtk_misc_set_padding(GTK_MISC(label), 10, 10);
      gtk_box_pack_start(GTK_BOX(GTK_DIALOG(bw->quit_dialog_window)->vbox),
                         label, TRUE, TRUE, 0);
      gtk_widget_show(label);

      button = gtk_button_new_with_label("OK");
      /* they said OK, is there some cleanup we have to do before
       * destroying the main window ? - set it to call
       * a_Interface_quit_all which cleans things up a bit..
       * hopefuly an improvement. -Ian
       */
      gtk_signal_connect(GTK_OBJECT(button), "clicked",
                         (GtkSignalFunc) a_Interface_quit_all, NULL);
      GTK_WIDGET_SET_FLAGS(button, GTK_CAN_DEFAULT);
      gtk_box_pack_start(GTK_BOX(GTK_DIALOG
          (bw->quit_dialog_window)->action_area), button, TRUE, TRUE, 0);
      gtk_widget_grab_default(button);
      gtk_widget_show(button);

      button = gtk_button_new_with_label("Cancel");
      gtk_signal_connect_object(GTK_OBJECT(button), "clicked",
                                (GtkSignalFunc) gtk_widget_destroy,
                                GTK_OBJECT(bw->quit_dialog_window));
      GTK_WIDGET_SET_FLAGS(button, GTK_CAN_DEFAULT);
      gtk_box_pack_start(GTK_BOX(GTK_DIALOG
          (bw->quit_dialog_window)->action_area), button, TRUE, TRUE, 0);
      gtk_widget_show(button);
   }
   if (!GTK_WIDGET_VISIBLE(bw->quit_dialog_window))
      gtk_widget_show(bw->quit_dialog_window);
   else
      gtk_widget_destroy(bw->quit_dialog_window);
   /* I much prefer it not to retain the last thing I typed in there
    * you know that :)  I always have to clear  the  dumb netscape
    * one.. I find it rather nice this way. */
}


/*
 * ?
 */
static gint Interface_handle_key_event (GtkWidget *widget, GdkEventKey *event, 
                                        gpointer client_data)
{
   gint return_val = FALSE;
   BrowserWindow *bw = (BrowserWindow *)client_data;
   GtkDwScroller *dw_scroller = (GtkDwScroller *)(bw->docwin);
   GtkDwView *dw_view = (GtkDwView *)(dw_scroller->viewport);
    
   switch (event->keyval) {
   case GDK_Down:
   case GDK_Up:
   case GDK_Page_Up:
   case GDK_Page_Down:
      gtk_signal_emit_by_name (GTK_OBJECT (dw_view), "key_press_event",
                               event, &return_val);
      break;
   default:
      break;
   }
   if (return_val)
      gtk_signal_emit_stop_by_name (GTK_OBJECT (widget), "key_press_event");

   return return_val;
}
