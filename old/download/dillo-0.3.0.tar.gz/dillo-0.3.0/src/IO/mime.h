/*
    MIME type handlers
    Randall Maas
    1999
*/
#ifndef __MIME_h
#define __MIME_h
#include <stddef.h>
#include <gtk/gtk.h>
#include "../dw.h"
#include "../cache.h"
#include "../IO/Url.h"

typedef Dw* (*Viewer_t) (const char*, void*, CA_Callback_t*, void**);

/* 
 * Function prototypes defined elsewhere
 */
Dw* a_Html_text (const char *Type,void *web, CA_Callback_t *Call, void **Data);
Dw* a_Plain_text(const char *Type,void *web, CA_Callback_t *Call, void **Data);
Dw* a_Jpeg_image(const char *Type,void *web, CA_Callback_t *Call, void **Data);
Dw* a_Png_image (const char *Type,void *web, CA_Callback_t *Call, void **Data);
Dw* a_Gif_image (const char *Type,void *web, CA_Callback_t *Call, void **Data);

/* 
 * Functions defined inside Mime module
 */
void a_Mime_init(void);
Dw* a_Mime_set_viewer(const char *content_type, void *Ptr,
                      CA_Callback_t *Call, void **Data);

#endif
