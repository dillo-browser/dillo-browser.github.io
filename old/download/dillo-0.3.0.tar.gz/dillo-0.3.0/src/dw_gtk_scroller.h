/* GTK - The GIMP Toolkit
 * Copyright (C) 1995-1997 Peter Mattis, Spencer Kimball and Josh MacDonald
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#ifndef __GTK_DW_SCROLLER_H__
#define __GTK_DW_SCROLLER_H__


#include <gdk/gdk.h>
#include <gtk/gtkhscrollbar.h>
#include <gtk/gtkvscrollbar.h>

#include "dw.h"
#include "dw_gtk_view.h"

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */


#define GTK_DW_SCROLLER(obj)          GTK_CHECK_CAST (obj, Dw_gtk_scroller_get_type (), GtkDwScroller)
#define GTK_DW_SCROLLER_CLASS(klass)  GTK_CHECK_CLASS_CAST (klass, Dw_gtk_scroller_get_type (), GtkDwScrollerClass)
#define GTK_IS_DW_SCROLLER(obj)       GTK_CHECK_TYPE (obj, Dw_gtk_scroller_get_type ())


typedef struct _GtkDwScroller       GtkDwScroller;
typedef struct _GtkDwScrollerClass  GtkDwScrollerClass;

struct _GtkDwScroller
{
  GtkContainer container;

  GtkWidget *viewport;
  GtkWidget *hscrollbar;
  GtkWidget *vscrollbar;

  guint8 hscrollbar_policy;
  guint8 vscrollbar_policy;

   /* This is used to catch user scrolling
    * Look at Dw_gtk_scroller_adjustment_value_changed. */
   int old_vadjustment_value;

   /* The requested anchor. NULL if not used or already found.
    * It is also used by DwPage. */
   gchar *anchor;
  
   /* The DwPage module sets this (-1 if not used) */
   volatile int anchor_pos;

   /* Timeout function running? May be set to FALSE from outside. */
   volatile int timeout_flag;
   
   /* The id returned by gtk_timeout_add, or -1 if no timeout is running.
    * Used to remove all timeout functions carefully. */
   int timeout_id;
};

struct _GtkDwScrollerClass
{
  GtkContainerClass parent_class;
};


guint          Dw_gtk_scroller_get_type        (void);
GtkWidget*     a_Dw_gtk_scroller_new             (GtkAdjustment     *hadjustment,
                                                 GtkAdjustment     *vadjustment);
GtkAdjustment* Dw_gtk_scroller_get_hadjustment (GtkDwScroller *dw_scroller);
GtkAdjustment* Dw_gtk_scroller_get_vadjustment (GtkDwScroller *dw_scroller);
void           a_Dw_gtk_scroller_set_policy      (GtkDwScroller *dw_scroller,
                                                 GtkPolicyType      hscrollbar_policy,
                                                 GtkPolicyType      vscrollbar_policy);
void    a_Dw_gtk_scroller_set_dw                (GtkDwScroller *dw_scroller,
                                                 Dw *dw);

void   a_Dw_gtk_scroller_set_anchor            (GtkDwScroller *dw_scroller,
                                                gchar *anchor);
void   a_Dw_gtk_scroller_queue_anchor          (GtkDwScroller *dw_scroller);
void   a_Dw_gtk_scroller_jump_anchor           (GtkDwScroller *dw_scroller);

#ifdef __cplusplus
}
#endif /* __cplusplus */


#endif /* __GTK_DW_SCROLLER_H__ */
