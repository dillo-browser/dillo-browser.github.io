/*
 * File: dw_bullet.c
 *
 * Copyright (C) 1997 Raph Levien <raph@acm.org>
 * Copyright (C) 1999 Luca Rota <drake@freemail.it>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

#include <gtk/gtk.h>
#include "dw.h"
#include "dw_bullet.h"

/*
 * ?
 */
static void Dw_bullet_size_nego_y(Dw *dw, DwRect *allocation)
{
   dw->allocation = *allocation;
}

/*
 * ?
 */
static void Dw_bullet_paint(Dw *dw, DwRect *rect, DwPaint *paint)
{
   GtkWidget *widget;
   DwContainer *container;
   gint x, y;

#ifdef VERBOSE
   g_print("dw_bullet_paint (%d, %d) - (%d, %d)",
           rect->x0, rect->y0, rect->x1, rect->y1);
#endif
   container = a_Dw_find_container(dw);
   if (container != NULL) {
#ifdef VERBOSE
      g_print(", visible = (%d, %d) - (%d, %d)",
              container->visible.x0, container->visible.y0,
              container->visible.x1, container->visible.y1);
#endif
      widget = container->widget;
      a_Dw_paint_to_screen(widget, container, rect, paint);
      x = dw->allocation.x0 + container->x_offset;
      y = dw->allocation.y0 + container->y_offset;
      switch (((DwBullet *) dw)->type) {
      case DW_BULLET_DISC:
         gdk_draw_arc(widget->window,
                      widget->style->fg_gc[widget->state],
                      TRUE, x + 2, y + 1, 4, 4, 0, 360 * 64);
         gdk_draw_arc(widget->window,
                      widget->style->fg_gc[widget->state],
                      FALSE, x + 2, y + 1, 4, 4, 0, 360 * 64);
         break;
      case DW_BULLET_CIRCLE:
         gdk_draw_arc(widget->window,
                      widget->style->fg_gc[widget->state],
                      FALSE, x + 1, y, 6, 6, 0, 360 * 64);
         break;
      case DW_BULLET_SQUARE:
         gdk_draw_rectangle(widget->window,
                            widget->style->fg_gc[widget->state],
                            FALSE, x + 1, y, 6, 6);
         break;
      }
      a_Dw_paint_finish_screen(paint);
   }
#ifdef VERBOSE
   g_print("\n");
#endif
}

/*
 * ?
 */
static void Dw_bullet_destroy(Dw *dw)
{
   g_free(dw);
}

static const DwClass Dw_bullet_class = {
   NULL,                        /* size_nego_x not needed */
   Dw_bullet_size_nego_y,
   Dw_bullet_paint,
   NULL,                        /* handle event not used */
   NULL,                        /* gtk_foreach not used */
   Dw_bullet_destroy,
   NULL                         /* request_resize is not used */
};

/*
 * ?
 */
Dw *a_Dw_bullet_new(DwBulletType type)
{
   DwBullet *dw_bullet;
   DwRect null_rect = { 0, 0, 0, 0 };

   dw_bullet = g_new(DwBullet, 1);
   dw_bullet->dw.klass = &Dw_bullet_class;
   dw_bullet->dw.allocation = null_rect;
   dw_bullet->dw.req_width_min = 8;
   dw_bullet->dw.req_width_max = 8;

   dw_bullet->dw.req_height = 8;
   dw_bullet->dw.req_ascent = 0;

   dw_bullet->dw.flags = 0;
   dw_bullet->dw.parent = NULL;
   dw_bullet->dw.container = NULL;

   dw_bullet->type = type;

   return (Dw *) dw_bullet;
}
