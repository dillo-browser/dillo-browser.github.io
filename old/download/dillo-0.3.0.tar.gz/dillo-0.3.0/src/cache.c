/*
 * File: cache.c
 *
 * Copyright 2000 Jorge Arellano Cid <jcid@inf.utfsm.cl>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

/*
 * Dillo's cache module
 */

#include <ctype.h>              /* for tolower */
#include <sys/types.h>

#include <sys/stat.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>

#include "config.h"
#include "list.h"
#include "IO/Url.h"
#include "IO/IO.h"
#include "cache.h" 
#include "dicache.h"
#include "web.h"
#include "nav.h"


/*
 *  Local data types
 */

typedef struct {
   const char *Url;      /* Cached Url. Url is used as a primary Key */
   const char *Type;     /* MIME type string */
   GString *Header;      /* HTTP header */
   const char *Location; /* New URI for redirects */
   void *Data;           /* Pointer to raw data */
   size_t ValidSize,     /* Actually size of valid range */
          TotalSize,     /* Goal size of the whole data (0 if unknown) */
          BuffSize;      /* Buffer Size for unknown length transfers */
   guint Flags;          /* Look Flag Defines in cache.h */
   IOData_t *io;         /* Pointer to IO data */
} CacheData_t;


/*
 *  Local data
 */
/* A list for cached data */
static CacheData_t *CacheList = NULL;
static gint CacheListSize = 0, CacheListMax = 32;

/* A list for cache clients.
 * Although implemented as a list, we'll call it ClientQueue  --Jcid */
static CacheClient_t *ClientQueue = NULL;
static gint ClientQueueSize = 0, ClientQueueMax = 16;


/*
 *  Forward declarations
 */
void Cache_process_queue(CacheData_t *entry);
void Cache_delayed_process_queue(CacheData_t *entry);

/*
 * Function substitutes (todo: implement this function)
 */
void a_Cache_freeall(void) { return; }


/*
 * Set safe values for a new cache entry
 */
void Cache_init_entry(CacheData_t *NewEntry, const char *Url)
{
   NewEntry->Url = g_strdup(Url);
   NewEntry->Type = NULL;
   NewEntry->Header = g_string_new("");
   NewEntry->Location = NULL;
   NewEntry->Data = NULL;
   NewEntry->ValidSize = 0;
   NewEntry->TotalSize = 0;
   NewEntry->BuffSize = 4096;
   NewEntry->Flags = 0;
   NewEntry->io = NULL;
}

/*
 * Allocate and set a new entry in the cache list
 */
CacheData_t *Cache_add_entry(const char *Url)
{
   /* Allocate memory */
   a_List_add(CacheList, CacheListSize, sizeof(*CacheList), CacheListMax);
   /* Set safe values */
   Cache_init_entry(&CacheList[CacheListSize], Url);
   return &CacheList[CacheListSize++];
}

/*
 * Make a unique primary-key for cache clients
 */
gint a_Cache_make_client_key(void)
{
   static gint ClientKey = 0; /* Provide a primary key for each client */

   if ( ++ClientKey < 0 ) ClientKey = 0;
   return ClientKey;
}

/*
 * Add a client to ClientQueue.
 *  - Every client-camp is just a reference. There's nothing to deallocate
 *  - If 'Callback' is NULL, it will be set when processing the Queue
 *  - When this function gets called, CbData points to a Web structure;
 *    that changes later, so we keep a pointer to it.
 *  - Return a unique number for identifying the client.
 */
gint
 Cache_enqueue_client(const char *Url, CA_Callback_t Callback, void *CbData)
{
   gint ClientKey;

   /* Ensure memory size */
   a_List_add(ClientQueue, ClientQueueSize, sizeof(*ClientQueue),
              ClientQueueMax);

   ClientKey = a_Cache_make_client_key();
   ClientQueue[ClientQueueSize].Key = ClientKey;
   ClientQueue[ClientQueueSize].Url = Url;
   ClientQueue[ClientQueueSize].Buf = NULL;
   ClientQueue[ClientQueueSize].BufSize = 0;
   ClientQueue[ClientQueueSize].Callback = Callback;
   ClientQueue[ClientQueueSize].CbData = CbData;
   ClientQueue[ClientQueueSize].Web    = CbData;
   ++ClientQueueSize;

   return ClientKey;
}

/*
 * Get the data structure for a cached URL (using 'Url' as the search key)
 * If 'Url' isn't cached, return NULL
 * (We search backwards to speed up the process)
 */
CacheData_t *Cache_search(const char *Url)
{
   gint i;

   for ( i = CacheListSize - 1; i >= 0; --i )
      if ( strcmp(Url, CacheList[i].Url) == 0 )
         return (CacheList + i);
   return NULL;
}

/*
 * Get the data structure for a cached URL 
 * If 'Url' isn't cached, return NULL
 * ===> 'Url' must a be a pointer to entry->Url <===
 */
CacheData_t *Cache_fast_search(const char *Url)
{
   gint i;

   for ( i = CacheListSize - 1; i >= 0; --i )
      if ( Url == CacheList[i].Url )
         return (CacheList + i);
   return NULL;
}

/*
 * Try finding the url in the cache. If it hits, send the cache contents
 * from there. If it misses, set up a new connection.
 * - If the callback function is NULL, it will get set later
 *   based on content/type and 'Web' data.
 * - CbData is a Web structure with the 'bw' camp set; images also have
 *   'Image' camp set.
 *
 * Return value: A primary key for identifying the client.
 */
gint Cache_open_url(const char *Url, CA_Callback_t Call, void *CbData)
{
   gint ClientKey;
   CacheData_t *entry = Cache_search(Url);

   if ( !entry ) {
      /* URL not cached: create an entry, send our client to the queue,
       * and open a new connection */
      entry = Cache_add_entry(Url);
      ClientKey = Cache_enqueue_client(entry->Url, Call, CbData);
      a_Url_open(entry->Url, CbData);
   } else {
      /* Feed our client with cached data */
      ClientKey = Cache_enqueue_client(entry->Url, Call, CbData);
      Cache_delayed_process_queue(entry);
   }
   return ClientKey;
}

/*
 * Try finding the url in the cache. If it hits, send the cache contents
 * from there. If it misses, set up a new connection.
 * Return value: A primary key for identifying the client.
 */
gint a_Cache_open_url(const char *Url, CA_Callback_t Call, void *CbData)
{
   gint ClientKey;
   DICacheEntry *DicEntry;
   CacheData_t *entry;

   //g_print("a_Cache_open_url: %s\n", Url);

   if ( Call ) {
      /* This is a verbatim request */
      ClientKey = Cache_open_url(Url, Call, CbData);

   } else if ( (DicEntry = a_Dicache_get_entry(Url)) != NULL ) {
      /* We have it in the Dicache! */
      entry = Cache_search(Url);
      ClientKey = Cache_enqueue_client(entry->Url, Call, CbData);
      Cache_delayed_process_queue(entry);

   } else {
      /* It can be anything; let's request it and decide what to do
         when we get more info... */
      ClientKey = Cache_open_url(Url, Call, CbData);
   }

   return ClientKey;
}

/*
 * Return the pointer to URL 'Data' in the cache.
 * (We also return its size in 'Size')
 */
char *a_Cache_url_read(const char *Url, gint *Size)
{
   CacheData_t *entry = Cache_search(Url);

   if ( !entry ) {
      *Size = 0;
      return NULL;
   }
   if ( entry->Flags & CA_Redirect && entry->Location ) 
      return a_Cache_url_read(entry->Location, Size);

   *Size = entry->ValidSize;
   return (char *) entry->Data;
}

/*
 * Extract a single field from the header, allocating and storing the value
 * in 'field'. ('fieldname' must not include the trailing ':')
 * Return a new string with the field-content if found (NULL on error)
 * (This function expects a '\r' stripped header)
 */
char *Cache_parse_field(const char *header, const char *fieldname)
{
   char *field;
   gint i, j;

   for ( i = 0; header[i]; i++ ) {
      /* Search fieldname */
      for (j = 0; fieldname[j]; j++)
        if ( tolower(fieldname[j]) != tolower(header[i + j]))
           break;
      if ( fieldname[j] ) {
         /* skip to next line */
         for ( i += j; header[i] != '\n'; i++);
         continue;
      }

      i += j;
      while (header[i] == ' ') i++;
      if (header[i] == ':' ) {
        /* Field found! */
        while (header[++i] == ' ');
        for (j = 0; header[i + j] != '\n'; j++);
        field = g_strndup(header + i, j);
        return field;
      }
   }
   return NULL;
}

/*
 * Scan, allocate, and set things according to header info.
 * (This function needs the whole header to work)
 */
void Cache_parse_header(CacheData_t *entry, IOData_t *io, gint HdrLen)
{
   char *header = entry->Header->str;
   char *Length, *Type;

   /* Get Content-Type */
   Type = Cache_parse_field(header, "Content-Type");
   entry->Type = Type ? Type : "application/octet-stream";

   if ( header[9] == '3' && header[10] == '0' ) {
      /* 30x: URL redirection */
      entry->Flags |= CA_Redirect;
      if ( header[11] == '1' ) 
         /* 301 Moved Permanently */
         entry->Flags |= CA_ForceRedirect;
      entry->Location = Cache_parse_field(header, "Location");

   } else if ( strncmp(header + 9, "404", 3) == 0 ) {
      entry->Flags |= CA_NotFound;
   }

   if ( (Length = Cache_parse_field(header, "Content-Length")) != NULL ) {
      entry->TotalSize = atol(Length); 
      g_free(Length);
      entry->Data = g_malloc(entry->TotalSize);
      memcpy(entry->Data, (char*)io->IOVec.iov_base+HdrLen, io->Status-HdrLen);
      entry->ValidSize = io->Status - HdrLen;
      /* Prepare next read */
      g_free(io->IOVec.iov_base);
      io->IOVec.iov_base = (char *)entry->Data + entry->ValidSize;
      io->IOVec.iov_len  = entry->TotalSize - entry->ValidSize;
      /* Now that we have it set, let's update our clients */
      Cache_process_queue(entry);
   } else {
      /* We don't know the size of the transfer; A lazy server? ;) */
      entry->ValidSize = io->Status - HdrLen;
      entry->Data = g_malloc(entry->ValidSize + entry->BuffSize);
      memcpy(entry->Data, (char *)io->IOVec.iov_base+HdrLen, entry->ValidSize);
      /* Prepare next read */
      g_free(io->IOVec.iov_base);
      io->IOVec.iov_base = (char *)entry->Data + entry->ValidSize;
      io->IOVec.iov_len  = entry->BuffSize;
      /* Now that we have it set, let's update our clients */
      Cache_process_queue(entry);
   }
}

/*
 * Consume bytes until the whole header is got (up to a "\r\n\r\n" sequence)
 * (Also strip '\r' chars from header)
 */
gint Cache_get_header(IOData_t *io, CacheData_t *entry)
{
   gint N, i;
   GString *hdr = entry->Header;
   guchar *data = io->IOVec.iov_base;

   /* Header finishes when N = 2 */
   N = (hdr->len && hdr->str[hdr->len - 1] == '\n');
   for ( i = 0; i < io->Status && N < 2; ++i ) {
      if ( data[i] == '\r' || !data[i] )
         continue;
      N = (data[i] == '\n') ? N + 1 : 0;
      g_string_append_c(hdr, data[i]);
   }

   if ( N == 2 ){
      /* Got whole header */
      g_string_append_c(hdr, '\0');
      entry->Flags |= CA_GotHeader;
      /* Return original-header length */
      return i;
   }
   return 0;
}

/*
 * Receive new data, update the reception buffer (for next read), update the
 * cache, and service the client queue.
 *
 * This function gets called by the IO whenever new data arrives.
 *  'Op' is the operation to perform
 *  'VPtr' is a (void) pointer to the IO control structure
 */
void a_Cache_callback(int Op, void *VPtr)
{
   IOData_t *io = VPtr;
   const char *Url = io->CbData;
   CacheData_t *entry = Cache_fast_search(Url);
   gint Status, len;

   /* Keep track of this entry's io */
   entry->io = io;

   if ( Op == IOClose ) {
      entry->Flags |= CA_GotData;
      entry->TotalSize = entry->ValidSize;
      entry->io = NULL;
      /* Free IOData_t structure */
      g_free(io);
      Cache_process_queue(entry);
      return;
   } else if ( Op == IOAbort ) {
      /* todo: implement Abort
       * (eliminate io struct, cache entry and anything related) */
      g_print("a_Cache_callback Op = IOAbort; not implemented yet\n");
      entry->io = NULL;
      g_free(io);
      return;
   }

   if ( !(entry->Flags & CA_GotHeader) ) {
      /* Haven't got the whole header yet */
      len = Cache_get_header(io, entry);
      if ( entry->Flags & CA_GotHeader ) {
         /* Let's scan, allocate, and set things according to header info */
         Cache_parse_header(entry, io, len);
      }
      return;
   }

   Status = io->Status;
   entry->ValidSize += Status;
   if ( Status < io->IOVec.iov_len ) {
      /* An incomplete buffer; update buffer & size */
      io->IOVec.iov_len  -= Status;
      io->IOVec.iov_base = (char *)io->IOVec.iov_base + Status;
   } else if ( Status == io->IOVec.iov_len ) {
      /* A full buffer! */
      if ( !entry->TotalSize ) {
         /* We are receiving in small chunks... */
         entry->Data = g_realloc(entry->Data,entry->ValidSize+entry->BuffSize);
         io->IOVec.iov_base = (char *)entry->Data + entry->ValidSize;
         io->IOVec.iov_len  = entry->BuffSize;
      } else {
         /* We have a preallocated buffer! */
         io->IOVec.iov_len  -= Status;
         io->IOVec.iov_base = (char *)io->IOVec.iov_base + Status;
      }
   }
   Cache_process_queue(entry);
}

/*
 * Process redirections (HTTP 30x answers)
 * (This is a work in progress --not finished yet)
 */
gint Cache_redirect(CacheData_t *entry, gint Flags, BrowserWindow *bw)
{
   gchar *NewUrl;

   if ( ((entry->Flags & CA_Redirect) && entry->Location) &&
        ((entry->Flags & CA_ForceRedirect) || !entry->ValidSize ||
         entry->ValidSize < 1024 ) ) {

      g_print(">>>Redirect from: %s\n to %s\n", entry->Url, entry->Location);
      g_print("%s", entry->Header->str);

      if ( Flags & WEB_RootUrl ) {
         /* Redirection of the main page */
         a_Nav_remove_top_url(bw, entry->Url);
         NewUrl = a_Url_resolve_relative(entry->Url, entry->Location);
         a_Nav_push(bw, NewUrl);
         g_free(NewUrl);
      } else {
         /* Sub entity redirection (most probably an image) */
         if ( !entry->ValidSize ) {
            g_print(">>>Image redirection without entity-content<<<\n");
         } else {
            g_print(">>>Image redirection with entity-content<<<\n");
         }
      }
   }
   return 0;
}

/*
 * Do nothing, but let the cache fill the entry.
 * (Currently used to ignore image redirects  --Jcid)
 */
void a_Cache_null_client(int Op, CacheClient_t *Client)
{
 return;
}

/*
 * Update cache clients for a single cache-entry
 * Tasks:
 *   - Set the client function (if not already set)
 *   - Look if new data is available and pass it to client functions
 *   - Remove clients when done
 *   - Call redirect handler
 *
 * todo: Implement CA_Abort Op in client callback
 */
void Cache_process_queue(CacheData_t *entry)
{
   static gboolean Busy = FALSE;
   const char *Url = entry->Url;
   gint i;

   if ( Busy ) {
      g_print("*** >>>> Cache_process_queue Caught busy!!!\n");
   } else
      Busy = TRUE;

   if ( !(entry->Flags & CA_GotHeader) ) {
      Busy = FALSE;
      return; 
   }

   for ( i = 0; i < ClientQueueSize; ++i ) {
      if ( ClientQueue[i].Url == Url ) {
         CacheClient_t *Client = ClientQueue + i;
         DilloWeb *ClientWeb = Client->Web; /* It was a (void*) */

         /* For non root URLs, ignore redirections and 404 answers */
         if ( !(ClientWeb->flags & WEB_RootUrl) &&
              (entry->Flags & CA_Redirect || entry->Flags & CA_NotFound) )
            Client->Callback = a_Cache_null_client;

         /* Set client function */
         if ( !Client->Callback )
            a_Web_dispatch_by_type(entry->Type, ClientWeb,
                                   &Client->Callback, &Client->CbData);
         /* Send data to our client */
         if ( (Client->BufSize = entry->ValidSize) > 0) {
            Client->Buf = (guchar *)entry->Data;
            (Client->Callback)(CA_Send, Client);
         }
         /* Remove client when done */
         if ( (entry->Flags & CA_GotData) ) {
            /* Copy Client data to local vars */
            void *bw = ClientWeb->bw;
            gint flags = ClientWeb->flags;
            /* We finished sending data, let the client know */
            if (!Client->Callback)
               g_print("Client Callback is NULL");
            else
               (Client->Callback)(CA_Close, Client);
            a_Web_free(ClientWeb);
            a_List_remove(ClientQueue, i, ClientQueueSize); --i;
            if ( entry->Flags & CA_Redirect ) 
               Cache_redirect(entry, flags, bw);
         }
      }
   } /* for */
   Busy = FALSE;
   // g_print("QueueSize ====> %d\n", ClientQueueSize);
}

/*
 * Callback function for Cache_delayed_process_queue.
 */
gint Cache_delayed_process_queue_callback(gpointer *data)
{
   Cache_process_queue( (CacheData_t *)data );
   return FALSE;
}

/*
 * Call Cache_process_queue from the gtk_main cycle
 */
void Cache_delayed_process_queue(CacheData_t *entry)
{
   gtk_timeout_add(1,(GtkFunction)Cache_delayed_process_queue_callback, entry);
}

/*
 * Remove the url from the CacheList
 * todo: Handle running clients on an entry (currently avoided).
 *       That must be implemented after the IO abort mechanism. --Jcid
 */
void a_Cache_remove_entry(char *url)
{
   gint i;
   CacheData_t *entry;

   if ( (entry = Cache_search(url)) != NULL ) {
      /* Check for a running client on the cache entry */
      for ( i = 0; i < ClientQueueSize; ++i ) {
         if ( strcmp(ClientQueue[i].Url, entry->Url) == 0 )
            return;
      }
      a_List_remove(CacheList, entry - CacheList, CacheListSize);
      /* MUST remove it from dicache too */
      a_Dicache_remove(url, -1);
   }
}

/*
 * Remove a client from the client queue
 * (It keeps feeding the cache, but nothing else)
 * todo: This is a transitory function before Abort gets implemented   --Jcid
 */
void a_Cache_disable_client(gint Key)
{
   gint i;

   for ( i = 0; i < ClientQueueSize; ++i ) {
      if ( ClientQueue[i].Key == Key ) {
         a_Web_free(ClientQueue[i].Web);
         a_List_remove(ClientQueue, i, ClientQueueSize);
         break;
      }
   }
}

/*
 * If the entry has no client, abort its io and set the CA_Stopped flag
 */
void a_Cache_stop_entry(gchar *Url)
{
   gint i;
   gboolean found = FALSE;
   CacheData_t *entry = Cache_search(Url);

   if ( entry && entry->io && !(entry->Flags & CA_GotData) ) {
      /* An incomplete entry... */
      for ( i = 0; i < ClientQueueSize; ++i ) {
         if ( strcmp(Url, ClientQueue[i].Url) == 0 ) {
            found = TRUE;
            break;
         }
      }
      if ( !found ) {
         /* No clients for this entry */
         if ( entry->io )
            a_IO_abort(entry->io);
         entry->Flags |= CA_Stopped;
      }
   }
}

