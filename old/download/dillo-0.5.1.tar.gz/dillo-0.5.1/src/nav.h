#ifndef __DILLO_NAV_H__
#define __DILLO_NAV_H__


#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

void a_Nav_push(BrowserWindow *bw, const DilloUrl *url);
void a_Nav_vpush(void *vbw, const DilloUrl *url);
void a_Nav_back(BrowserWindow *bw);
void a_Nav_forw(BrowserWindow *bw);
void a_Nav_home(BrowserWindow *bw);
void a_Nav_reload(BrowserWindow *bw);
void a_Nav_init(BrowserWindow *bw);
void a_Nav_cancel_expect (BrowserWindow *bw);
void a_Nav_expect_done(BrowserWindow *bw, DwWidget *dw);
void a_Nav_remove_top_url(BrowserWindow *bw, const DilloUrl *url);


#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __DILLO_NAV_H__ */


