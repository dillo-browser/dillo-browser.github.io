/*
 * File: pixmaps.h
 *
 * Copyright (C) 2000 Jorge Arellano Cid <jcid@inf.utfsm.cl>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

/* XPM */
static char * leftarrow_xpm[] = {
"20 15 5 1",
"       c None",
".      c #000000000000",
"X      c #9658A289BEFB",
"o      c #FFFFFFFF0000",
"O      c #FFFF9A690000",
"                    ",
"       ..           ",
"      .X.           ",
"     .XX.           ",
"    .XXX...... oOoO ",
"   .XXXXXXXXX. oOoO ",
"  .XXXXXXXXXX. oOoO ",
" .XXXXXXXXXXX. oOoO ",
"  .XXXXXXXXXX. oOoO ",
"   .XXXXXXXXX. oOoO ",
"    .XXX...... oOoO ",
"     .XX.           ",
"      .X.           ",
"       ..           ",
"                    "};
/* XPM */
static char * rightarrow_xpm[] = {
"20 15 5 1",
"       c None",
".      c #000000000000",
"X      c #9658A289BEFB",
"o      c #FFFF9A690000",
"O      c #FFFFFFFF0000",
"                    ",
"           ..       ",
"           .X.      ",
"           .XX.     ",
" oOoO ......XXX.    ",
" oOoO .XXXXXXXXX.   ",
" oOoO .XXXXXXXXXX.  ",
" oOoO .XXXXXXXXXXX. ",
" oOoO .XXXXXXXXXX.  ",
" oOoO .XXXXXXXXX.   ",
" oOoO ......XXX.    ",
"           .XX.     ",
"           .X.      ",
"           ..       ",
"                    "};
/* XPM */
static char * home_xpm[] = {
"21 15 7 1",
"       c None",
".      c #9658A289BEFB",
"X      c #000000000000",
"o      c #FFFF0000FFFF",
"O      c #FFFF9A690000",
"+      c #FFFF00000000",
"@      c #FFFFFFFFFFFF",
"          .          ",
"         XXX         ",
"        XXXXX        ",
"       XXXoXXX       ",
"      XXXoXoXXX      ",
"     XXXXXXXXXXX     ",
"    XXXXXXXXXXXXX    ",
"       XOOOOOX       ",
"      XOOOOOOOX      ",
"      XOOOXXOOX      ",
"      XOOX+oXOX      ",
"      XOOXo@XOX      ",
"    . XOOXo@XOX  .   ",
" .....XOOXo@XOX..... ",
"......XXXXXXXXX......"};
/* XPM */
static char * reload_xpm[] = {
"20 15 4 1",
"       c None",
".      c #000000000000",
"X      c #9658A289BEFB",
"o      c #FFFF9A690000",
"        .   ..      ",
"     ...X. .oo.     ",
"    .XXXXX..ooo.    ",
"   .XXXXXX. .oo.    ",
"   .XX..X.  .oo.    ",
"   .XX. .  .oooo.   ",
"    ..      .oo.    ",
"     ..      ..     ",
"    .oo.      ..    ",
"   .oooo.  . .XX.   ",
"    .oo.  .X..XX.   ",
"    .oo. .XXXXXX.   ",
"    .ooo..XXXXX.    ",
"     .oo. .X...     ",
"      ..   .        "};
/* XPM */
static char * save_xpm[] = {
"21 15 5 1",
"       c None",
".      c #000000000000",
"X      c #9658A289BEFB",
"o      c #FFFFFFFFFFFF",
"O      c #FFFF9A690000",
"   ...............   ",
"   ..XXXXXXXXXXXX.   ",
"   .X...........X.   ",
"   .X.ooooooooo.X.   ",
"   .X...........X.   ",
"   .X.ooooooooo.X.   ",
"   .X...........X.   ",
"   .XXXXXXXXXXXXX.   ",
"   .XXXXXXXXXXXXX.   ",
"   .XX........XXX.   ",
"   .XX.OOOOOOO.XX.   ",
"   .XX.O...OOO.XX.   ",
"   .XX.O. .OOO.XX.   ",
"    .............    ",
"                     "};
/* XPM */
static char * stop_xpm[] = {
"21 15 4 1",
"       c None",
".      c #000000000000",
"X      c #9658A289BEFB",
"o      c #FFFF9A690000",
"                     ",
"       .......       ",
"      .XXX.XXX.      ",
"     .XXX.o.XXX.     ",
"    .XXXX.o.XXXX.    ",
"    .XXXX.o.XXXX.    ",
"    .XXXX.o.XXXX.    ",
"    .XXXX.o.XXXX.    ",
"    .XXXXX.XXXXX.    ",
"    .XXXXXXXXXXX.    ",
"    .XXXXX.XXXXX.    ",
"     .XXX.o.XXX.     ",
"      .XXX.XXX.      ",
"       .......       ",
"                     "};
/* XPM */
static char * new_xpm[] = {
"10 10 2 1",
"       c None",
"X      c #9658A289BEFB",
"XX      XX",
" XX X  XX ",
"  XX  XX  ",
"          ",
" X  XX X  ",
"  X XX  X ",
"          ",
"  XX  XX  ",
" XX  X XX ",
"XX      XX"};

