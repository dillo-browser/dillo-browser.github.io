/*
 * File: interface.c
 *
 * Copyright (C) 1997 Raph Levien <raph@acm.org>
 * Copyright (C) 1999 Sammy Mannaert <nstalkie@tvd.be>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

#include <stdio.h>
#include <gtk/gtk.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <fcntl.h>

#include "list.h"
#include "dillo.h"
#include "web.h"
#include "IO/Url.h"
#include "IO/IO.h"
#include "cache.h"
#include "interface.h"
#include "nav.h"
#include "browser.h"
#include "commands.h"
#include "menu.h"
#include "config.h"
#include "bookmark.h"
#include "prefs.h"
#include "url.h"

#include "dw_widget.h"
#include "dw_gtk_scrolled_window.h"
#include "dw_gtk_viewport.h"
#include "dw_gtk_statuslabel.h"
#include "dw_page.h"                  /* for a_Dw_page_find_text */
#include "progressbar.h"

#include "pixmaps.h"
#include <gdk/gdkkeysyms.h>

#define DEBUG_LEVEL 0
#include "debug.h"


/*
 * Local Data
 */
/* BrowserWindow holds all the widgets (and perhaps more)
 * for each new_browser.*/
BrowserWindow **browser_window;
gint num_bw, num_bw_max;


/*
 * Initialize global data
 */
void a_Interface_init(void)
{
   num_bw = 0;
   num_bw_max = 16;
   browser_window = NULL;
}

/*
 * Stop all active connections in the browser window (except downloads)
 */
void a_Interface_stop(BrowserWindow *bw)
{
   DEBUG_MSG(3, "a_Interface_stop: hi!\n");

   /* Remove root clients */
   while ( bw->NumRootClients ) {
      a_Cache_disable_client(bw->RootClients[0]);
      a_List_remove(bw->RootClients, 0, bw->NumRootClients);
   }
   /* Remove image clients */
   while ( bw->NumImageClients ) {
      a_Cache_disable_client(bw->ImageClients[0]);
      a_List_remove(bw->ImageClients, 0, bw->NumImageClients);
   }
}

/*
 * Empty RootClients, ImageClients and PageUrls lists and
 * reset progress bar data.
 */
void a_Interface_clean(BrowserWindow *bw)
{
   g_return_if_fail ( bw != NULL );

   while ( bw->NumRootClients )
      a_List_remove(bw->RootClients, 0, bw->NumRootClients);

   while ( bw->NumImageClients )
      a_List_remove(bw->ImageClients, 0, bw->NumImageClients);

   while ( bw->NumPageUrls ) {
      a_Url_free(bw->PageUrls[0].Url);
      a_List_remove(bw->PageUrls, 0, bw->NumPageUrls);
   }

   /* Zero image-progressbar data */
   bw->NumImages = 0;
   bw->NumImagesGot = 0;
}

/*=== Browser Window Interface Updating =====================================*/
/*
 * Remove the cache-client from the bw list
 * (client can be a image or a html page)
 */
void a_Interface_remove_client(BrowserWindow *bw, gint ClientKey)
{
   gint i;
   gboolean Found = FALSE;

   for ( i = 0; !Found && i < bw->NumRootClients; ++i)
      if ( bw->RootClients[i] == ClientKey ) {
         a_List_remove(bw->RootClients, i, bw->NumRootClients);
         Found = TRUE;
      }

   for ( i = 0; !Found && i < bw->NumImageClients; ++i)
      if ( bw->ImageClients[i] == ClientKey ) {
         a_List_remove(bw->ImageClients, i, bw->NumImageClients);
         bw->NumImagesGot++;
         Found = TRUE;
      }

   a_Interface_set_button_sens(bw);
}

/*
 * Remove the cache-client from the bw list
 * (client can be a image or a html page)
 */
void a_Interface_close_client(BrowserWindow *bw, gint ClientKey)
{
   gchar numstr[32];

   a_Interface_remove_client(bw, ClientKey);

   /* --Progress bars stuff-- */
   sprintf(numstr,"%s%d of %d", PBAR_ISTR(prefs.panel_size == 1),
           bw->NumImagesGot, bw->NumImages);
   a_Progressbar_update(bw->imgprogress, numstr,
                        (bw->NumImagesGot == bw->NumImages) ? 0 : 1 );
}

/*
 * Set the sensitivity on back/forw buttons and menu entries.
 */
static gint Interface_sens_idle_func(BrowserWindow *bw)
{
   gboolean back_sensitive, forw_sensitive, stop_sensitive;

   /* Stop button */
   stop_sensitive = (bw->NumRootClients > 0);
   gtk_widget_set_sensitive(bw->stop_button, stop_sensitive);

   /* Back and Forward buttons */
   back_sensitive = bw->nav_stack_ptr > 0;
   gtk_widget_set_sensitive(bw->back_button, back_sensitive);
   forw_sensitive = (bw->nav_stack_ptr < bw->nav_stack_size - 1 &&
                     !bw->nav_expecting);
   gtk_widget_set_sensitive(bw->forw_button, forw_sensitive);

   bw->sens_idle_tag = 0;
   return FALSE;
}

/*
 * Set the sensitivity on back/forw buttons and menu entries.
 */
void a_Interface_set_button_sens(BrowserWindow *bw)
{
   if (bw->sens_idle_tag != 0)
      return;
   bw->sens_idle_tag = gtk_idle_add(
                          (GtkFunction)Interface_sens_idle_func, bw);
}

/*
 * Add a reference to the cache-client in the browser window's list.
 * This helps us keep track of which are active in the window so that it's
 * possible to abort them.
 * (Root: Flag, whether a Root URL or not)
 */
void a_Interface_add_client(BrowserWindow *bw, gint Key, gint Root)
{
   gint nc;
   char numstr[32];

   g_return_if_fail ( bw != NULL );

   if ( Root ) {
      nc = bw->NumRootClients;
      a_List_add(bw->RootClients, nc, sizeof(*bw->RootClients),
                 bw->MaxRootClients);
      bw->RootClients[nc] = Key;
      bw->NumRootClients++;
      a_Interface_set_button_sens(bw);
   } else {
      nc = bw->NumImageClients;
      a_List_add(bw->ImageClients, nc, sizeof(*bw->ImageClients),
                 bw->MaxImageClients);
      bw->ImageClients[nc] = Key;
      bw->NumImageClients++;
      bw->NumImages++;
      a_Interface_set_button_sens(bw);

      /* --Progress bar stuff-- */
      sprintf(numstr,"%s%d of %d", PBAR_ISTR(prefs.panel_size == 1),
              bw->NumImagesGot, bw->NumImages);
      a_Progressbar_update(bw->imgprogress, numstr, 1);
   }
}

/*
 * Add an URL to the browser window's list.
 * This helps us keep track of page requested URLs so that it's
 * possible to stop, abort and reload them.)
 *   Flags: Chosen from {BW_Root, BW_Image, BW_Download}
 */
void a_Interface_add_url(BrowserWindow *bw, const DilloUrl *Url, gint Flags)
{
   gint nu, i;
   gboolean found = FALSE;

   g_return_if_fail ( bw != NULL && Url != NULL );

   nu = bw->NumPageUrls;
   for ( i = 0; i < nu; i++ ) {
      if ( !a_Url_cmp(Url, bw->PageUrls[i].Url) ) {
         found = TRUE;
         break;
      }
   }
   if ( !found ) {
      a_List_add(bw->PageUrls, nu, sizeof(*bw->PageUrls), bw->MaxPageUrls);
      bw->PageUrls[nu].Url = a_Url_dup(Url);
      bw->PageUrls[nu].Flags = Flags;
      bw->NumPageUrls++;
   }

   /* test:
   g_print("Urls:\n");
   for (i = 0; i < bw->NumPageUrls; i++)
      g_print("%s\n", bw->PageUrls[i].Url);
   g_print("---\n");
   */
}

/*
 * Remove a browser window. This includes destroying all open windows
 * (except for the main browser window, which is presumed to be
 * destroyed in the caller), freeing all resources associated with the
 * browser window, and exiting gtk if no windows are left.
 */
static gboolean Interface_quit(GtkWidget *widget, BrowserWindow *bw)
{
   gint i;

   /* todo: should probably abort any open connections. */
   if (bw->open_dialog_window != NULL)
      gtk_widget_destroy(bw->open_dialog_window);
   if (bw->openfile_dialog_window != NULL)
      gtk_widget_destroy(bw->openfile_dialog_window);
   if (bw->quit_dialog_window != NULL)
      gtk_widget_destroy(bw->quit_dialog_window);
   if (bw->findtext_dialog_window != NULL)
      gtk_widget_destroy(bw->findtext_dialog_window);

   if (bw->sens_idle_tag)
      gtk_idle_remove(bw->sens_idle_tag);

   for (i = 0; i < num_bw; i++)
      if (browser_window[i] == bw) {
         browser_window[i] = browser_window[--num_bw];
         break;
      }
   for (i = 0; i < bw->nav_stack_size; i++) {
      a_Url_free(bw->nav_stack[i].url);
      if (bw->nav_stack[i].title)
         g_free(bw->nav_stack[i].title);
   }
   g_free(bw->nav_stack);
   g_free(bw->ImageClients);
   g_free(bw->PageUrls);
   g_free(bw);
   if (num_bw == 0)
      gtk_main_quit();

   return FALSE;
}


/*=== Browser Window Interface Construction =================================*/
/*
 * Clear a text entry
 */
void Interface_entry_clear(GtkEntry *entry)
{
   gtk_entry_set_text(GTK_ENTRY (entry), "");
   gtk_widget_grab_focus(GTK_WIDGET(entry));
}

/*
 * Create a pixmap and return it.
 */
GtkWidget *Interface_pixmap_new(GtkWidget *parent, gchar **data)
{
   GtkWidget *pixmapwid;
   GdkPixmap *pixmap;
   GdkBitmap *mask;
   GtkStyle *style;

   style = gtk_widget_get_style(parent);

   pixmap = gdk_pixmap_create_from_xpm_d(parent->window, &mask,
                                         &style->bg[GTK_STATE_NORMAL], data);

   pixmapwid = gtk_pixmap_new(pixmap, mask);

   return (pixmapwid);
}

/*
 * Set the bw's cursor type
 */
void a_Interface_set_cursor(BrowserWindow *bw, GdkCursorType CursorType)
{
   GdkCursor *cursor;

   if ( bw->CursorType != CursorType ) {
      cursor = gdk_cursor_new(CursorType);
      gdk_window_set_cursor(bw->docwin->window, cursor);
      gdk_cursor_destroy(cursor);
      bw->CursorType = CursorType;
   }
}

/*
 * Create the "NEW" button and its location-entry.
 */
GtkWidget *Interface_locbar_new(BrowserWindow *bw)
{
   GtkWidget *hbox, *toolbar, *item;

   hbox = gtk_hbox_new(FALSE, 0);

   /* location entry */
   bw->location = gtk_entry_new();
   gtk_signal_connect(GTK_OBJECT(bw->location), "activate",
                      (GtkSignalFunc) a_Interface_entry_open_url, bw);
   toolbar = gtk_toolbar_new(GTK_ORIENTATION_HORIZONTAL, GTK_TOOLBAR_BOTH);
   gtk_toolbar_set_button_relief(GTK_TOOLBAR(toolbar), GTK_RELIEF_NONE);
   GTK_WIDGET_UNSET_FLAGS (toolbar, GTK_CAN_FOCUS);

   /* This is really a mistery to me; I had to set the callback with
    * gtk_signal_connect_object, bacause with gtk_toolbar_append_item,
    * it simply fails!!!  --Jcid */
   item = gtk_toolbar_append_item(
             GTK_TOOLBAR(toolbar),
             NULL, "Clear the url-box!", "Toolbar/New",
             Interface_pixmap_new(bw->main_window, s_new_xpm),
             NULL, NULL);
   gtk_signal_connect_object(GTK_OBJECT(item), "clicked",
                             GTK_SIGNAL_FUNC (Interface_entry_clear),
                             GTK_OBJECT(bw->location));

   gtk_box_pack_start(GTK_BOX(hbox), toolbar, FALSE, FALSE, 0);
   gtk_widget_show(toolbar);
   gtk_box_pack_start(GTK_BOX(hbox), bw->location, TRUE, TRUE, 0);
   gtk_widget_show(bw->location);
   gtk_widget_show(hbox);
   return (hbox);
}

/*
 * Create a new toolbar (Back, Forward, Home, Reload, Save and Stop buttons)
 */
GtkWidget *Interface_toolbar_new(BrowserWindow *bw, gint label)
{
   GtkWidget *toolbar;
   gboolean s = prefs.small_icons;

   toolbar = gtk_toolbar_new(GTK_ORIENTATION_HORIZONTAL, GTK_TOOLBAR_BOTH);
   gtk_toolbar_set_button_relief(GTK_TOOLBAR(toolbar), GTK_RELIEF_NONE);

   /* back button */
   bw->back_button = gtk_toolbar_append_item(
                        GTK_TOOLBAR(toolbar),
                        label ? "Back" : NULL,
                        "Go to previous page", "Toolbar/Back",
                        Interface_pixmap_new(bw->main_window, 
                                             s ? s_left_xpm : left_xpm),
                        (GtkSignalFunc) a_Commands_back_callback, bw);
   gtk_widget_set_sensitive(bw->back_button, FALSE);

   /* forward button */
   bw->forw_button = gtk_toolbar_append_item(
                        GTK_TOOLBAR(toolbar),
                        label ? "Forward" : NULL,
                        "Go to next page", "Toolbar/Forward",
                        Interface_pixmap_new(bw->main_window,
                                             s ? s_right_xpm : right_xpm),
                        (GtkSignalFunc) a_Commands_forw_callback, bw);
   gtk_widget_set_sensitive(bw->forw_button, FALSE);

   /* home button */
   gtk_toolbar_append_item(GTK_TOOLBAR(toolbar),
                           label ? "Home" : NULL,
                           "Go to the Home page", "Toolbar/Home",
                           Interface_pixmap_new(bw->main_window,
                                                s ? s_home_xpm : home_xpm),
                           (GtkSignalFunc) a_Commands_home_callback, bw);

   /* reload button */
   gtk_toolbar_append_item(GTK_TOOLBAR(toolbar),
                           label ? "Reload" : NULL,
                           "Reload this page", "Toolbar/Reload",
                           Interface_pixmap_new(bw->main_window,
                                                s ? s_reload_xpm : reload_xpm),
                           (GtkSignalFunc) a_Commands_reload_callback, bw);

   /* save button */
   gtk_toolbar_append_item(GTK_TOOLBAR(toolbar),
                           label ? "Save" : NULL,
                           "Save this page", "Toolbar/Save",
                           Interface_pixmap_new(bw->main_window,
                                                s ? s_save_xpm : save_xpm),
                           (GtkSignalFunc) a_Commands_save_callback, bw);
   /* stop button */
   bw->stop_button = gtk_toolbar_append_item(
                        GTK_TOOLBAR(toolbar),
                        label ? "Stop" : NULL,
                        "Stop the current transfer", "Toolbar/Stop",
                        Interface_pixmap_new(bw->main_window,
                                             s ? s_stop_xpm : stop_xpm),
                        (GtkSignalFunc) a_Commands_stop_callback, bw);
   gtk_widget_set_sensitive(bw->stop_button, FALSE);

   gtk_widget_show(toolbar);
   return toolbar;
}

/*
 * Create the progressbar's box
 */
GtkWidget *Interface_progressbox_new(BrowserWindow *bw, gint vertical)
{
   GtkWidget *progbox;

   progbox = vertical ? gtk_vbox_new(FALSE, 0) : gtk_hbox_new(FALSE, 0);
   bw->imgprogress = a_Progressbar_new();
   bw->progress = a_Progressbar_new();
   gtk_box_pack_start(GTK_BOX(progbox), bw->imgprogress, TRUE, TRUE, 0);
   gtk_widget_show(bw->imgprogress);
   gtk_box_pack_start(GTK_BOX(progbox), bw->progress, TRUE, TRUE, 0);
   gtk_widget_show(bw->progress);
   return (progbox);
}

/*
 * Create a new browser window and return it.
 */
BrowserWindow *a_Interface_new_browser_window(gint width, gint height)
{
   /* used to create new windows - index into browser_window[]
    * not really implemented. */

   GtkWidget *box1;
   GtkWidget *box2;
   GtkWidget *progbox;
   GtkWidget *toolbar;
   GtkWidget *handlebox;
   GtkWidget *menubar;
   GtkWidget *locbox;
   GtkWidget *hbox;
   BrowserWindow *bw;
   char buf[256];

   /* We use g_malloc0() to zero the memory */
   bw = g_malloc0(sizeof(BrowserWindow));
   bw->save_dialog_window = NULL;

   a_List_add(browser_window, num_bw, sizeof(*browser_window), num_bw_max);
   browser_window[num_bw++] = bw;

   /* initialize nav_stack struct in browser_window struct */
   a_Nav_init(bw);

   bw->main_window = gtk_window_new(GTK_WINDOW_TOPLEVEL);

   gtk_window_set_policy(GTK_WINDOW(bw->main_window), TRUE, TRUE, FALSE);
   gtk_signal_connect(GTK_OBJECT(bw->main_window), "delete_event",
                      GTK_SIGNAL_FUNC(gtk_object_destroy), bw);
   gtk_signal_connect(GTK_OBJECT(bw->main_window), "destroy",
                      GTK_SIGNAL_FUNC(Interface_quit), bw);
   gtk_container_border_width(GTK_CONTAINER(bw->main_window), 0);

   gtk_window_set_wmclass(GTK_WINDOW(bw->main_window), "dillo", "Dillo");

   /* -RL :: I must realize the window to see it correctly */
   gtk_widget_realize(bw->main_window);

   /* set window title */
   sprintf(buf, "Version %s", VERSION);
   a_Interface_set_Page_title(bw, buf);

   box1 = gtk_vbox_new(FALSE, 0);

   /* setup the control panel */
   if (prefs.panel_size == 1) {
      handlebox = gtk_handle_box_new();
      hbox = gtk_hbox_new(FALSE, 0);
      /* Control Buttons */
      toolbar = Interface_toolbar_new(bw, 0);
      /* Menus */
      menubar = a_Menu_mainbar_new(bw, 1);
      /* Location entry */
      locbox = Interface_locbar_new(bw);
      /* progress bars */
      progbox = Interface_progressbox_new(bw, 0);

      gtk_box_pack_start(GTK_BOX(hbox), toolbar, FALSE, FALSE, 0);
      gtk_widget_show(toolbar);
      gtk_box_pack_start(GTK_BOX(hbox), menubar, FALSE, FALSE, 0);
      gtk_widget_show(menubar);
      gtk_box_pack_start(GTK_BOX(hbox), locbox, TRUE, TRUE, 0);
      gtk_widget_show(locbox);
      gtk_box_pack_start(GTK_BOX(hbox), progbox, FALSE, FALSE, 0);
      gtk_widget_show(progbox);
      gtk_container_add(GTK_CONTAINER(handlebox), hbox);
      gtk_widget_show(hbox);
      gtk_box_pack_start(GTK_BOX(box1), handlebox, FALSE, FALSE, 0);
      gtk_widget_show(handlebox);

   } else if (prefs.panel_size == 2) {
      handlebox = gtk_handle_box_new();
      hbox = gtk_hbox_new(FALSE, 0);
      menubar = a_Menu_mainbar_new(bw, 0);
      locbox = Interface_locbar_new(bw);
      gtk_box_pack_start(GTK_BOX(hbox), menubar, FALSE, FALSE, 0);
      gtk_widget_show(menubar);
      gtk_box_pack_start(GTK_BOX(hbox), locbox, TRUE, TRUE, 0);
      gtk_widget_show(locbox);
      gtk_container_add(GTK_CONTAINER(handlebox), hbox);
      gtk_widget_show(hbox);
      gtk_box_pack_start(GTK_BOX(box1), handlebox, FALSE, FALSE, 0);
      gtk_widget_show(handlebox);

      handlebox = gtk_handle_box_new();
      gtk_container_set_border_width(GTK_CONTAINER(handlebox), 4);
      hbox = gtk_hbox_new(FALSE, 0);
      toolbar = Interface_toolbar_new(bw, 1);
      progbox = Interface_progressbox_new(bw, 1);
      gtk_box_pack_start(GTK_BOX(hbox), toolbar, TRUE, TRUE, 0);
      gtk_widget_show(toolbar);
      gtk_box_pack_start(GTK_BOX(hbox), progbox, FALSE, FALSE, 0);
      gtk_widget_show(progbox);
      gtk_container_add(GTK_CONTAINER(handlebox), hbox);
      gtk_widget_show(hbox);
      gtk_box_pack_start(GTK_BOX(box1), handlebox, FALSE, FALSE, 0);
      gtk_widget_show(handlebox);

   } else {
      handlebox = gtk_handle_box_new();
      menubar = a_Menu_mainbar_new(bw, 0);
      gtk_container_add(GTK_CONTAINER(handlebox), menubar);
      gtk_widget_show(menubar);
      gtk_box_pack_start(GTK_BOX(box1), handlebox, FALSE, FALSE, 0);
      gtk_widget_show(handlebox);

      handlebox = gtk_handle_box_new();
      gtk_container_set_border_width(GTK_CONTAINER(handlebox), 4);
      hbox = gtk_hbox_new(FALSE, 0);
      toolbar = Interface_toolbar_new(bw, 1);
      progbox = Interface_progressbox_new(bw, 1);
      gtk_box_pack_start(GTK_BOX(hbox), toolbar, TRUE, TRUE, 0);
      gtk_widget_show(toolbar);
      gtk_box_pack_start(GTK_BOX(hbox), progbox, FALSE, FALSE, 0);
      gtk_widget_show(progbox);
      gtk_container_add(GTK_CONTAINER(handlebox), hbox);
      gtk_widget_show(hbox);
      gtk_box_pack_start(GTK_BOX(box1), handlebox, FALSE, FALSE, 0);
      gtk_widget_show(handlebox);

      handlebox = gtk_handle_box_new();
      locbox = Interface_locbar_new(bw);
      gtk_container_add(GTK_CONTAINER(handlebox), locbox);
      gtk_widget_show(locbox);
      gtk_box_pack_start(GTK_BOX(box1), handlebox, FALSE, FALSE, 0);
      gtk_widget_show(handlebox);
   }

   /* This is here, because a_Menu_mainbar_new sets the bw->accel_group */
   gtk_window_add_accel_group (GTK_WINDOW (bw->main_window), bw->accel_group);

   bw->menu_popup.menu = a_Menu_popup_new(bw);
   bw->menu_popup.menu_over_link = a_Menu_popup_ol_new(bw);
   bw->sens_idle_tag = 0;

   /* Add box1 */
   gtk_container_add(GTK_CONTAINER(bw->main_window), box1);

   /* Now the main document window */
   bw->docwin = a_Dw_gtk_scrolled_window_new();
   gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(bw->docwin),
                                  GTK_POLICY_AUTOMATIC, GTK_POLICY_ALWAYS);
   gtk_box_pack_start(GTK_BOX(box1), bw->docwin, TRUE, TRUE, 0);
   gtk_widget_show(bw->docwin);

   gtk_widget_set_usize(bw->main_window, width, height);

   /* status widget */
   bw->status = a_Dw_gtk_statuslabel_new("");
   gtk_misc_set_alignment(GTK_MISC(bw->status), 0.0, 0.5);
   box2 = gtk_hbox_new(FALSE, 0);

   gtk_box_pack_start(GTK_BOX(box2), bw->status, TRUE, TRUE, 2);
   gtk_widget_show(bw->status);

   gtk_box_pack_start(GTK_BOX(box1), box2, FALSE, FALSE, 2);
   gtk_widget_show(box2);

   gtk_widget_show(bw->main_window);
   gtk_widget_show(box1);

   /* Initialize the rest of the bw's data. */
   bw->CursorType = -1;

   bw->RootClients = NULL;
   bw->NumRootClients = 0;
   bw->MaxRootClients = 8;

   bw->ImageClients = NULL;
   bw->NumImageClients = 0;
   bw->MaxImageClients = 8;
   bw->NumImages = 0;
   bw->NumImagesGot = 0;

   bw->PageUrls = NULL;
   bw->NumPageUrls = 0;
   bw->MaxPageUrls = 8;

   bw->findtext_dialog_window = NULL;
   bw->open_dialog_window = NULL;
   bw->openfile_dialog_window = NULL;
   bw->quit_dialog_window = NULL;
   return bw;
}

/*
 * Set the title of the browser window to start with "Dillo: "
 * prepended to it. Also set the page_title member of the current
 * nav_stack structure for use with the bookmarks.
 */
void a_Interface_set_Page_title(BrowserWindow *bw, char *title)
{
   GString *buf;
   gint top;

   g_return_if_fail (bw != NULL);

   /* free previously allocated string */
   if ( bw->nav_stack_size ) {
      top = bw->nav_stack_ptr;
      if (bw->nav_stack[top].title)
         g_free(bw->nav_stack[top].title);
      bw->nav_stack[top].title = g_strdup(title);
   }
   buf = g_string_new("");
   g_string_sprintfa(buf, "Dillo: %s", title);
   gtk_window_set_title(GTK_WINDOW(bw->main_window), buf->str);
   g_string_free(buf, TRUE);
}

/*
 * Reset images and text progress bars
 */
void a_Interface_reset_progress_bars(BrowserWindow *bw)
{
   a_Progressbar_update(bw->progress, "", 0);
   a_Progressbar_update(bw->imgprogress, "", 0);
}

/*
 * Set the status string on the bottom of the dillo window.
 */
void a_Interface_status(BrowserWindow *bw, const char *format, ... )
{
static char msg[1024];
va_list argp;

   if ( bw ) {
      va_start(argp, format);
      vsnprintf(msg, 1024, format, argp);
      va_end(argp);
      gtk_label_set(GTK_LABEL(bw->status), msg);
   }
}

/*
 * hmm.. have to see where this is from
 */
void Interface_destroy_window(GtkWidget *widget, GtkWidget **window)
{
   *window = NULL;
}


/*
 * ?
 */
void a_Interface_quit_all(void)
{
   BrowserWindow **bws;
   gint i, n_bw;

   n_bw = num_bw;
   bws = g_malloc(sizeof(BrowserWindow *) * n_bw);

   /* we copy into a new list because destroying the main window can
    * modify the browser_window array. */
   for (i = 0; i < n_bw; i++)
      bws[i] = browser_window[i];

   for (i = 0; i < n_bw; i++)
      gtk_widget_destroy(bws[i]->main_window);

   g_free(bws);
}


/*
 * Get the file URL from the widget and push it to the browser window.
 */
static void
 Interface_openfile_ok_callback(GtkWidget *widget, BrowserWindow *bw)
{
   char *fn;
   DilloUrl *url;
   GString *UrlStr = g_string_sized_new(1024);

   fn = gtk_file_selection_get_filename(
           GTK_FILE_SELECTION(bw->openfile_dialog_window));

   g_string_sprintf(UrlStr, "file:%s", fn);
   url = a_Url_new(UrlStr->str, NULL, 0, 0);
   a_Nav_push(bw, url);
   g_string_free(UrlStr, TRUE);
   a_Url_free(url);

   gtk_widget_destroy(bw->openfile_dialog_window);
}

/*
 * Open an URL specified in the location entry, or in the open URL dialog.
 * The URL is not sent as it is; a_Url_resolve_relative() processes it.
 */
void a_Interface_entry_open_url(GtkWidget *widget, BrowserWindow *bw)
{
   gchar *text;
   DilloUrl *url;
   GtkEntry *entry;

   /* Find which entry to get the URL from. This is a bit of a hack. */

   if (widget == bw->location)
      entry = GTK_ENTRY(bw->location);
   else
      entry = GTK_ENTRY(bw->open_dialog_entry);
   text = gtk_entry_get_text(entry);

   DEBUG_MSG(1, "entry_open_url %s\n", text);

   if ( text && *text ) {
      url = a_Url_new(text, "http:/", 0, 0);
      if ( url ) {
         a_Nav_push(bw, url);
         a_Url_free(url);
      }
   }
   if (bw->open_dialog_window != NULL)
      gtk_widget_destroy(bw->open_dialog_window);
   /* todo: pull focus away from location widget probably by focusing
    * to the page, but at the time this todo was added, the gtk_page
    * widget wasn't really focusable. */
}

/*
 * Create and show the "Open File" dialog
 */
void a_Interface_openfile_dialog(BrowserWindow *bw)
{
   if (!bw->openfile_dialog_window) {
      bw->openfile_dialog_window = gtk_file_selection_new("Open File");
      gtk_window_set_wmclass(GTK_WINDOW(bw->openfile_dialog_window),
                             "openfile_dialog", "Dillo");
      gtk_signal_connect(
         GTK_OBJECT(bw->openfile_dialog_window), "destroy",
         GTK_SIGNAL_FUNC (Interface_destroy_window), 
         &(bw->openfile_dialog_window));
      gtk_signal_connect(
         GTK_OBJECT(GTK_FILE_SELECTION(bw->openfile_dialog_window)->ok_button),
         "clicked", GTK_SIGNAL_FUNC (Interface_openfile_ok_callback), bw);
      gtk_signal_connect_object(
         GTK_OBJECT(GTK_FILE_SELECTION(
            bw->openfile_dialog_window)->cancel_button),
         "clicked", (GtkSignalFunc) gtk_widget_hide,
         GTK_OBJECT(bw->openfile_dialog_window));
   }
   if (!GTK_WIDGET_VISIBLE(bw->openfile_dialog_window))
      gtk_widget_show(bw->openfile_dialog_window);
   else
      gtk_widget_destroy(bw->openfile_dialog_window);
}

/*
 * Make a dialog interface with three buttons and a text entry
 */
void
 Interface_make_dialog(GtkWidget **DialogWindow, char *WmName, char *WmClass,
   char *WTitle, GtkWidget **DialogEntry, char *EntryStr,
   char *B1Label, GtkSignalFunc B1CallBack, void *B1CbData)
{
   GtkWidget *button, *box1, *box2, *entry;

   *DialogWindow = gtk_window_new(GTK_WINDOW_DIALOG);
   gtk_window_set_wmclass(GTK_WINDOW(*DialogWindow), WmName, WmClass);
   gtk_signal_connect(GTK_OBJECT(*DialogWindow), "destroy",
                      (GtkSignalFunc) Interface_destroy_window, DialogWindow);

   gtk_window_set_title(GTK_WINDOW(*DialogWindow), WTitle);
   gtk_container_border_width(GTK_CONTAINER(*DialogWindow), 5);

   box1 = gtk_vbox_new(FALSE, 5);
   gtk_container_add(GTK_CONTAINER(*DialogWindow), box1);
   gtk_widget_show(box1);

   entry = gtk_entry_new();
   gtk_widget_set_usize(entry, 250, 0);

   gtk_entry_set_text(GTK_ENTRY(entry), EntryStr);
   gtk_widget_grab_focus(GTK_WIDGET(entry));
   gtk_box_pack_start(GTK_BOX(box1), entry, FALSE, FALSE, 0);
   *DialogEntry = GTK_WIDGET(entry);
   gtk_widget_show(entry);

   gtk_signal_connect(GTK_OBJECT(entry), "activate", B1CallBack, B1CbData);

   box2 = gtk_hbox_new(TRUE, 5);
   gtk_box_pack_start(GTK_BOX(box1), box2, FALSE, FALSE, 0);
   gtk_widget_show(box2);

   button = gtk_button_new_with_label(B1Label);
   gtk_signal_connect(GTK_OBJECT(button), "clicked", B1CallBack, B1CbData);
   GTK_WIDGET_SET_FLAGS(button, GTK_CAN_DEFAULT);
   gtk_box_pack_start(GTK_BOX(box2), button, FALSE, TRUE, 0);
   gtk_widget_grab_default(button);
   gtk_widget_show(button);
   gtk_signal_connect_object(GTK_OBJECT(entry), "focus_in_event",
                             (GtkSignalFunc) gtk_widget_grab_default,
                             GTK_OBJECT(button));

   button = gtk_button_new_with_label("Clear");
   gtk_signal_connect_object(GTK_OBJECT(button), "clicked",
                             (GtkSignalFunc) Interface_entry_clear,
                             GTK_OBJECT(entry));
   GTK_WIDGET_SET_FLAGS(button, GTK_CAN_DEFAULT);
   gtk_box_pack_start(GTK_BOX(box2), button, FALSE, TRUE, 0);
   gtk_widget_show(button);

   button = gtk_button_new_with_label("Cancel");
   gtk_signal_connect_object(GTK_OBJECT(button), "clicked",
                             (GtkSignalFunc) gtk_widget_destroy,
                             GTK_OBJECT(*DialogWindow));
   GTK_WIDGET_SET_FLAGS(button, GTK_CAN_DEFAULT);
   gtk_box_pack_start(GTK_BOX(box2), button, FALSE, TRUE, 0);
   gtk_widget_show(button);

   gtk_widget_grab_focus(entry);
}

/*
 * Create and show the open URL dialog
 */
void a_Interface_open_dialog(GtkWidget *widget, BrowserWindow *bw)
{
   if (!bw->open_dialog_window) {
      Interface_make_dialog(&(bw->open_dialog_window),
         "open_dialog", "Dillo", "Dillo: Open URL",
         &(bw->open_dialog_entry), "",
         "OK", (GtkSignalFunc) a_Interface_entry_open_url, (void *)bw);
   }

   if (!GTK_WIDGET_VISIBLE(bw->open_dialog_window))
      gtk_widget_show(bw->open_dialog_window);
   else
      gtk_widget_hide(bw->open_dialog_window);
}


/*
 * Receive data from the cache and save it to a local file
 */
void Interface_save_callback(int Op, CacheClient_t *Client)
{
   DilloWeb *Web = Client->Web;
   gint Bytes;

   if ( Op ){
      struct stat st;

      fflush(Web->stream);
      fstat(fileno(Web->stream), &st);
      fclose(Web->stream);
      a_Interface_status(Web->bw, "File saved (%d Bytes)", st.st_size);
   } else {
      if ( (Bytes = Client->BufSize - Web->SavedBytes) > 0 ) {
         Bytes = fwrite(Client->Buf + Web->SavedBytes, 1, Bytes, Web->stream);
         Web->SavedBytes += Bytes;
      }
   }
}

/*
 * Save current page to a local file
 */
void Interface_entry_save_url(GtkWidget *widget, BrowserWindow *bw)
{
   const char *url_str, *name;
   GtkEntry *entry, *entry_url;
   DilloUrl *url;
   FILE *out;

   entry = GTK_ENTRY(bw->save_dialog_entry);
   entry_url = GTK_ENTRY(bw->location);
   name = gtk_entry_get_text(entry);
   url_str = gtk_entry_get_text(entry_url);
   url = a_Url_new(url_str, NULL, 0, 0);
   
   if ( strlen(name) && (out = fopen(name, "w")) != NULL ) {
      DilloWeb *Web = a_Web_new(url);
      Web->bw = bw;
      Web->stream = out;
      Web->flags |= WEB_Download;
      /* todo: keep track of this client */
      a_Cache_open_url(url, Interface_save_callback, Web);
   }
   a_Url_free(url);

   if (bw->save_dialog_window != NULL)
      gtk_widget_destroy(bw->save_dialog_window);
}

/*
 * Save the link-URL to a local file
 */
void Interface_entry_save_link(GtkWidget *widget, BrowserWindow *bw)
{
   const gchar *name;
   const DilloUrl *url;
   FILE *out;

   name = gtk_entry_get_text(GTK_ENTRY(bw->save_link_dialog_entry));
   url  = bw->menu_popup.info.url;

   if ( strlen(name) && (out = fopen(name, "w")) != NULL ) {
      DilloWeb *Web = a_Web_new(url);
      Web->bw = bw;
      Web->stream = out;
      Web->flags |= WEB_Download;
      /* todo: keep track of this client */
      a_Cache_open_url(url, Interface_save_callback, Web);
   }

   if (bw->save_link_dialog_window != NULL)
      gtk_widget_destroy(bw->save_link_dialog_window);
}

/*
 * Scan Url and return a local-filename suggestion for saving
 */
char *Interface_make_save_name(const DilloUrl *url)
{
   gchar *FileName;

   if (URL_PATH(url) && (FileName = strrchr(URL_PATH(url), '/')))
      return g_strndup(++FileName, MIN(strlen(FileName), 64));
   return g_strdup("");
}

/*
 * Show the dialog interface for saving an URL
 */
void a_Interface_save_dialog(GtkWidget *widget, BrowserWindow *bw)
{
   gchar *SuggestedName;   /* Suggested save name */
   DilloUrl* url;   

   if (!bw->save_dialog_window) {
      url = a_Url_new(gtk_entry_get_text(GTK_ENTRY(bw->location)), NULL, 0, 0);
      SuggestedName = Interface_make_save_name(url);
      Interface_make_dialog(&(bw->save_dialog_window), "save_dialog", "Dillo",
         "Dillo: Save URL as file", &(bw->save_dialog_entry), SuggestedName,
         "OK", (GtkSignalFunc) Interface_entry_save_url, (void *)bw);
      g_free(SuggestedName);
   }

   if (!GTK_WIDGET_VISIBLE(bw->save_dialog_window))
      gtk_widget_show(bw->save_dialog_window);
   else
      gtk_widget_hide(bw->save_dialog_window);
}

/*
 * Show the dialog interface for saving a link
 */
void a_Interface_save_link_dialog(GtkWidget *widget, BrowserWindow *bw)
{
   char *SuggestedName;   /* Suggested save name */

   if (!bw->save_link_dialog_window) {
      SuggestedName = Interface_make_save_name(bw->menu_popup.info.url);
      Interface_make_dialog(&(bw->save_link_dialog_window),
         "save_link_dialog", "Dillo", "Dillo: Save link as file",
         &(bw->save_link_dialog_entry), SuggestedName,
         "OK", (GtkSignalFunc) Interface_entry_save_link, (void *)bw);
      g_free(SuggestedName);
   }

   if (!GTK_WIDGET_VISIBLE(bw->save_link_dialog_window))
      gtk_widget_show(bw->save_link_dialog_window);
   else
      gtk_widget_hide(bw->save_link_dialog_window);
}

/*
 * Scroll to an occurence of a string in the open page
 */
void Interface_entry_search(GtkWidget *widget, BrowserWindow* bw)
{
   DwWidget *page;
   char *search_string;

   page = a_Dw_gtk_scrolled_window_get_dw(GTK_DW_SCROLLED_WINDOW(bw->docwin));
   search_string = gtk_entry_get_text( (GtkEntry*)bw->findtext_dialog_entry );

   a_Dw_page_find_text(DW_PAGE(page), search_string);
}

/*
 * Show the dialog interface for finding text in a page
 */
void a_Interface_findtext_dialog(BrowserWindow *bw)
{
   if (!bw->findtext_dialog_window) {
      Interface_make_dialog(&(bw->findtext_dialog_window),
         "findtext_dialog", "Dillo", "Dillo: Find text in page",
         &(bw->findtext_dialog_entry), "",
         "Find", (GtkSignalFunc) Interface_entry_search, (void *)bw);
   }

   if (!GTK_WIDGET_VISIBLE(bw->findtext_dialog_window))
      gtk_widget_show(bw->findtext_dialog_window);
   else
      gtk_widget_hide(bw->findtext_dialog_window);
}


/* shouldn't all this stuff go in menu.c or something ?
 * why do we need global window GtkWidgets for the windows ??
 * I see you use it in the destroy() function, but I don't
 * really grasp it's use just yet :) */

/* The way gimp does it is to have a menus.c for the menus themselves
 * and a commands.c for the *_cmd callbacks. They also have an
 * interface.c where most of the interface stuff happens. We should
 * probably follow their lead.
 *
 * We have globals for the windows so I can destroy all windows before
 * quitting. Some window managers (including fvwm2-95) really like
 * this. -Raph
 */

/* funny you say that, cause if you look at the quit_dialog_window I made, I
 * just gtk_destroy_widget(main_window).. it seems to work ok, but should we
 * change it? -Ian
 */

/* No, the way it is now is fine. When you destroy the main window,
 * that invokes the destroy signal handler, which destroys all of the
 * other windows cleanly.
 *
 * Anyway, I wrote the above explanation before we had multiple
 * windows. Another reason to do it this way is that when you close
 * one of several main windows, its various subsidiary windows go away
 * too. -Raph */


