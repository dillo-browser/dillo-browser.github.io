/*
 * File : url.h - Dillo
 *
 * Copyleft (C) 2001 Livio Baldini Soares <livio@linux.ime.usp.br>
 *              2001 Jorge Arellano Cid   <jcid@users.sourceforge.net>
 *
 * Parse and normalize all URL's inside Dillo.
 */

#ifndef __DILLO_URL_H__
#define __DILLO_URL_H__

#define DILLO_URL_HTTP_PROTOCOL    "http"
#define DILLO_URL_HTTPS_PROTOCOL   "https"
#define DILLO_URL_ABOUT_PROTOCOL   "about"
#define DILLO_URL_FILE_PROTOCOL    "file"
#define DILLO_URL_FTP_PROTOCOL     "ftp"
#define DILLO_URL_MAILTO_PROTOCOL  "mailto"
#define DILLO_URL_NEWS_PROTOCOL    "news"
#define DILLO_URL_TELNET_PROTOCOL  "telnet"
#define DILLO_URL_GOPHER_PROTOCOL  "gopher"

#define DILLO_URL_HTTP_PORT        80
#define DILLO_URL_HTTPS_PORT       443
#define DILLO_URL_FTP_PORT         21
#define DILLO_URL_MAILTO_PORT      25
#define DILLO_URL_NEWS_PORT        119
#define DILLO_URL_TELNET_PORT      23
#define DILLO_URL_GOPHER_PORT      70

#define URN_OTHER  "()+,-.:=@;$_!*'/%?"

/* 
 * Values for DilloUrl->flags.
 * Specifies which which action to perform with this URL.
 */
#define URL_Get                 0x00000001
#define URL_Post                0x00000002
#define URL_ISindex             0x00000004
#define URL_RealmAccess         0x00000008

#define URL_P2PReload           0x00000010
#define URL_ReloadImages        0x00000020
#define URL_ReloadPage          0x00000040
#define URL_ReloadFromCache     0x00000080

#define URL_ReloadIncomplete    0x00000100

/* Access methods to access fields inside DilloURL */
#define URL_PROTO(u)    u->protocol
#define URL_HOST(u)     u->hostname
#define URL_PATH(u)     u->path
#define URL_ANCHOR(u)   u->anchor
#define URL_PORT(u)     u->port
#define URL_FLAGS(u)    u->flags
#define URL_DATA(u)     u->data
#define URL_POS(u)      u->scrolling_position
#define URL_STR(u)      u->parsed_string

typedef struct _DilloUrl DilloUrl;

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

struct _DilloUrl {
   const gchar *parsed_string;
   const gchar *protocol;
   const gchar *hostname;
   const gchar *path;
   const gchar *anchor; 
   gint port;
   gint flags;
   const gchar *data;              /* POST */
   gint scrolling_position;        /* remeber position for history stack */
};

DilloUrl* a_Url_new(const gchar *url_str, const gchar *base_url, 
                    gint flags, gint pos);

void a_Url_free(DilloUrl *u);
DilloUrl* a_Url_dup(const DilloUrl *u);
gint a_Url_cmp(const DilloUrl* A, const DilloUrl* B);
gchar* a_Url_string_no_anchor(const DilloUrl *url);
void a_Url_set_flags(DilloUrl *u, gint flags);
void a_Url_set_data(DilloUrl *u, gchar *data);
void a_Url_set_pos(DilloUrl *u, gint pos);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __DILLO_URL_H__ */
