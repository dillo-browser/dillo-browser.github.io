/*
 * File: about.c
 *
 * Copyright (C) 1997 Raph Levien <raph@acm.org>
 * Copyright (C) 1999 Jorge Arellano Cid <jcid@inf.utfsm.cl>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

#include <pthread.h>

#include "Url.h"
#include "../browser.h"
#include "../web.h"
#include "../nav.h"

typedef struct _SplashInfo SplashInfo_t;

struct _SplashInfo {
   gint SplashPipe[2];
   pthread_t ThreadId;
};


/*
 * HTML text for startup screen
 */
static char *Splash=
"Content-type: text/html\n
\n\
<!doctype html public \"-//w3c//dtd html 4.0 transitional//en\">\n\
<html>\n\
<head>\n\
 <meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-1\">\n\
</head>\n\
<hr>\n\
 <h1>Dillo project<br>\n\
     <h3>Version 0.5.1<BR> <EM>(this is alpha code)</EM> </h3></h1>\n\
<hr>\n\
<h4> License </h4>\n\
<p>\n\
    This program is free software; you can redistribute it and/or modify\n\
    it under the terms of the GNU General Public License as published by\n\
    the Free Software Foundation; either version 2 of the License, or\n\
    (at your option) any later version.\n\
<p>\n\
    This program is distributed in the hope that it will be useful,\n\
    but WITHOUT ANY WARRANTY; without even the implied warranty of\n\
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n\
    GNU General Public License for more details.\n\
\n\
<hr>\n\
<h4> Release </h4>\n\
<BLOCKQUOTE>\n\
 This release, introduces a new URL handling scheme (internal), a \n\
new  customizable  interface  (options in dillorc), better memory \n\
management (leak fixes) and some minor improvements. \n\
</BLOCKQUOTE><BLOCKQUOTE>\n\
 Remember that dillo project uses a release model where every new\n\
browser is expected to be better than the former.\n\
<EM>Keep up with the latest one!</EM>\n\
</BLOCKQUOTE>\n\
<hr>\n\
<h4>NOTES:</h4>\n\
<p> \n\
<ul>\n\
<li> There's a <STRONG>dillorc</STRONG> file within the tarball; \n\
<STRONG>copy it</STRONG> to <CODE>~/.dillo/</CODE> directory.\n\
<li>If you set <code>force_my_colors=YES</code>, inside dillorc,\n\
slashdot will get readable!</li>
<li> There's developer documentation in the /doc dir within the tarball, and\n\
you can find directions on everything else at the home page. </li>\n\
<li> Dillo behaves very nice when browsing local files, images, and HTML.\n\
It's also very good for Internet searching (try www.google.com). Test it!</li>\n\
<li> Tables and frames are not supported yet.</li>\n\
<li> Dillo has context sensitive menus on the right-mouse-button (pages and links)</li>\n\
<li> Files can be downloaded with <cite>Save-link-as</cite> (only HTTP)</li>\n\
<li> Frame-based pages will not render. You can note them cause the progress\n\
bar will show content, but no rendering will be done. Check the page source\n\
(right-mouse-button menu) to get sure. </li>\n\
<li> This release is intended <strong>for developers</strong>.</li>\n\
</ul>\n\
<hr>\n\
<h4>Notes to Xfce users:</h4>\n\
<P> Please bear in mind that dillo is alpha code; it is not ready for\n\
end users yet. Anyway, local browsing (files and local HTTP) is quite stable\n\
and chances are you'll not be disappointed.<BR>\n\
<P> TABLES, FRAMES, Java, and Javascript are not supported.\n\
<hr>\n\
<hr>\n\
</body>\n\
</html>\n\
";


/*
 * Write Splash screen through a pipe
 * (This function runs on its own thread)
 */
static void *About_write_splash(void *data)
{
   SplashInfo_t *SpInfo = data;

   pthread_detach(SpInfo->ThreadId);
   write(SpInfo->SplashPipe[1], Splash, strlen(Splash));
   close(SpInfo->SplashPipe[1]);
   g_free(SpInfo);
   return NULL;
}

/*
 * Send the splash screen through a pipe from a pthread.
 */
static void About_send_splash(DilloUrl *Url)
{
   IOData_t *io;
   SplashInfo_t *SpInfo = g_new(SplashInfo_t, 1);

   if (pipe(SpInfo->SplashPipe))
      return;

   /* receive answer */
   io = a_IO_new();
   io->Op = IORead;
   io->IOVec.iov_base = g_malloc(4096);
   io->IOVec.iov_len  = 4096;
   io->FreeIOVec = 1;
   io->Callback = a_Cache_callback;
   io->CbData = (void *) Url;
   io->FD = SpInfo->SplashPipe[0];
   a_IO_ccc(OpStart, 2, a_Chain_new(), io, NULL);

   pthread_create(&SpInfo->ThreadId, NULL, About_write_splash, SpInfo);
}


/*
 * Push the right URL for each supported "about"
 * ( Data = Requested URL; ExtraData = Web structure )
 */
gint About_get(ChainLink *Info, void *Data, void *ExtraData)
{
   char *loc;
   const char *tail;
   DilloUrl *Url = Data;
   DilloWeb *web = ExtraData;
   DilloUrl *LocUrl;

   tail = URL_PATH(Url) ? URL_PATH(Url) : "";

   if (!strcmp(tail, "splash")) {
      About_send_splash(Url);
      return 1;
   }
   if (!strcmp(tail, "jwz"))
      loc = "http://www.jwz.org/";
   else if (!strcmp(tail, "raph"))
      loc = "http://www.levien.com/";
   else if (!strcmp(tail, "yosh"))
      loc = "http://yosh.gimp.org/";
   else if (!strcmp(tail, "snorfle"))
      loc = "http://www.snorfle.net/";
   else if (!strcmp(tail, "dillo"))
      loc = "http://dillo.sourceforge.net/";
   else
      loc = "http://www.google.com/";

   LocUrl = a_Url_new(loc, NULL, 0, 0);
   a_Nav_push(web->bw, LocUrl);
   a_Url_free(LocUrl);
   return 0;
}

/*
 * CCC function for the ABOUT module
 */
void
 a_About_ccc(int Op, int Branch, ChainLink *Info, void *Data, void *ExtraData)
{
   if ( Op == OpStart ) {
      if (About_get(Info, Data, ExtraData))
         a_Chain_fcb(OpEnd, 1, Info, NULL, ExtraData);
      else
         a_Chain_fcb(OpAbort, 1, Info, NULL, ExtraData);
   }
}

