/*
 * File: url.c
 *
 * Copyleft (C) 2001 Livio Baldini Soares <livio@linux.ime.usp.br>
 *              2001 Jorge Arellano Cid   <jcid@users.sourceforge.net>
 *
 * Parse and normalize all URL's inside Dillo.
 */

#include <glib.h>
#include <string.h>  
#include <stdlib.h>  /* for strtol() */

#include "url.h"

/* protocol array */
gchar *known_protocols[] = {
   DILLO_URL_HTTP_PROTOCOL,
   DILLO_URL_HTTPS_PROTOCOL,
   DILLO_URL_ABOUT_PROTOCOL,
   DILLO_URL_FILE_PROTOCOL,
   DILLO_URL_FTP_PROTOCOL,
   DILLO_URL_MAILTO_PROTOCOL,
   DILLO_URL_NEWS_PROTOCOL,
   DILLO_URL_TELNET_PROTOCOL,
   DILLO_URL_GOPHER_PROTOCOL
};

gint known_ports[] = {
   DILLO_URL_HTTP_PORT,
   DILLO_URL_HTTPS_PORT,
   0,
   0,
   DILLO_URL_FTP_PORT,
   DILLO_URL_MAILTO_PORT,
   DILLO_URL_NEWS_PORT,
   DILLO_URL_TELNET_PORT,
   DILLO_URL_GOPHER_PORT  
};
    

/*
 * Local data
 */
static const guint n_known_protocols = sizeof (known_protocols) / 
                                       sizeof(known_protocols[0]);

/*
 * Forward declarations
 */
static gchar *Url_str_squeeze(char *str);
static gint Url_gstr_parse_hash(GString *url);
static gint Url_str_is_absolute(const char *url_str);
static GString* Url_to_gstring(const DilloUrl *u, gint anchor);

/*
 *  Initialize the URL structure
 */
static void Url_init(DilloUrl *url)
{
   url->url_string         = NULL;
   url->protocol           = NULL;
   url->hostname           = NULL;
   url->path               = NULL;
   url->anchor             = NULL;
   url->port               = 0;
   url->flags              = 0;
   url->data               = NULL;
   url->alt                = NULL;
   url->ismap_url_len      = 0;
   url->ismap_path_len     = 0;
   url->scrolling_position = 0;
}

/*
 *  Given an URL string which is _not_ an absolute URL, and a base url,
 *  return the absolute version of the relative URL.
 *  Should satisfy RFC 2396 (Uniform Resource Identifiers (URI), see Section 5)
 */
static gchar *
 Url_str_resolve_relative(const gchar *urlstring, const gchar *BaseUrl)
{
   gint idx;
   guint i, base_protocol_index;
   gchar *ptr, *tmp;
   GString *NewUrl;

   //g_print("Url_str_resolve_relative: \n Rel: %s\n Base: %s\n",
   //        urlstring, BaseUrl);

   for (i = 0; BaseUrl[i] && BaseUrl[i] != ':'; i++);
   for (i++; BaseUrl[i] && BaseUrl[i] == '/'; i++);
   base_protocol_index = i;
   if (g_strncasecmp(DILLO_URL_FILE_PROTOCOL, BaseUrl, 4))
      for (i++; BaseUrl[i] && BaseUrl[i] != '/'; i++);
   else
      --i;
   
   NewUrl = g_string_new(BaseUrl);
   if ((idx = Url_gstr_parse_hash(NewUrl)) >= 0)
      g_string_truncate(NewUrl, idx);

   if (urlstring[0] == '/' ) {
      if (urlstring[1] == '/') {
         g_string_truncate(NewUrl, base_protocol_index);
         g_string_append(NewUrl, urlstring+2);
      } else {
         if (i && NewUrl->len > i)
            g_string_truncate(NewUrl, i);
         g_string_append(NewUrl, urlstring);
      }

   } else if (urlstring[0] == '#') {
         g_string_append(NewUrl, urlstring);

   } else {
      if ( (ptr = strrchr(NewUrl->str, '/')) && ptr[-1] != '/' )
         g_string_truncate(NewUrl, ptr - NewUrl->str);
      g_string_append_c(NewUrl, '/');
      g_string_append(NewUrl, urlstring);
   }

   tmp = NewUrl->str;
   g_string_free(NewUrl, FALSE);
   return tmp;
}

/*
 * Try to find protocol from the string, must be something like,
 * `prot://' or `prot:/', or even just `prot:'
 * We compare with the 'known_protocols' list to verify this.
 */
static gchar *Url_str_get_protocol(const gchar *urlstring, DilloUrl *url)
{
   guint i;
   gchar *ptr;

   /* Every protocol must have a ':' after it
    * it must not be port specification          */
   if ( (ptr = strchr(urlstring,  ':')) ) {
      for (i = 0; i < n_known_protocols; i++)
         if (!g_strncasecmp(urlstring, known_protocols[i], ptr - urlstring)) {
            url->protocol = g_strdup(known_protocols[i]);
            ptr++;
            break;
         }
      if (url->protocol && g_strcasecmp(url->protocol,DILLO_URL_FILE_PROTOCOL))
         for (; *ptr == '/'; ptr++);
   }
   return ptr;
}

/*
 * Now try to find hostname, must be before the first '/'
 * Unless it's a file:/ or about: protocol, then we don't have
 * a hostname.
 */
static gchar *Url_str_get_hostname(gchar *urlstring, DilloUrl *url)
{
   gchar *ptr, *ptr2;

   /* File and About methods don't require a hostname in their URL */
   if (url->protocol && g_strcasecmp(url->protocol, DILLO_URL_FILE_PROTOCOL) &&
       g_strcasecmp(url->protocol, DILLO_URL_ABOUT_PROTOCOL)) {

      ptr  = strchr(urlstring, '/');  /* start of path */
      ptr2 = strchr(urlstring, ':');  /* port number specification */

      if (ptr2 && ( !ptr || (ptr2 < ptr) ) )
         ptr = ptr2;
     
      if (ptr)
         url->hostname = g_strndup(urlstring, ptr - urlstring);
      else {
         url->hostname = g_strdup(urlstring);
         ptr = NULL;
      }
      return ptr;
   }
   
   return urlstring;
}

/*
 * Get the port number (if present)
 */
static gchar *Url_str_get_port(gchar *urlstring, DilloUrl *url)
{
   /* Now check for port */
   if (urlstring && *urlstring == ':') 
      url->port = strtol(urlstring+1, &urlstring, 10);

   return urlstring;
}

/*
 *  Gets remaining path from the string,
 *  setting the anchor field if needs be.
 */
static gchar* Url_str_get_path(gchar *urlstring, DilloUrl *url)
{
   gint idx;
   
   if (urlstring && urlstring[0]) {
      urlstring = Url_str_squeeze(urlstring);
      url->path = g_string_new(urlstring);
      if ((idx = Url_gstr_parse_hash(url->path)) >= 0) {
         url->anchor = g_strdup(url->path->str + idx);
         g_string_truncate(url->path, idx);
      }
   }

   if ( url->path && url->path->len == 0 ) {
      g_string_free(url->path, TRUE);
      url->path = NULL;
   }

   return urlstring;
}

/*
 * Squeeze an URL (strip /./ and /../ sequences)
 * Return value: squeezed URL.
 *  The funny thing is that I don't know if this is required!
 *  Anyway, it's highly tuned for speed  --Jcid
 * Changed it a bit, now `str' contains only the path --Livio
 */
static gchar *Url_str_squeeze(char *str)
{
   char *s, *p;
   int i, ni, nc;

   s = p = str;
   ni = 0;
   while ( (p = strstr(p, "/.")) != NULL ) {
      if ( p[2] == '.' && (p[3] == '/' || !p[3]) ) { /* "/../" or "/.." */
         nc = p - s;
         for ( i = 0; i <= nc; ++i, ++ni )
            str[ni] = s[i];
         nc = ni > 0 ? --ni : ni;
         while ( ni && str[--ni] != '/' );
         s = p = p + 3;
      } else if ( p[2] == '/' || !p[2] ) {  /* "/./" or "/." */
         nc = p - s;
         for ( i = 0; i < nc; ++i )
            str[ni++] = s[i];
         str[ni] = '/';
         s = p = p + 2;
      } else {                              /* "/.x" */
         p += 2;
      }
   }

   /* Append the rest of 'str' */
   if ( str[ni] == '/' && !*s )  ++ni;
   while ( str[ni+1] && (str[ni++] = *s++) );
   return str;
}

/*
 * Parse "http://a/b#c" into "http://a/b" and "#c".
 *
 * Return Value:
 *   An index to the hash in a name refrence (if any), otherwise NULL.
 */
static gint Url_gstr_parse_hash(GString *url)
{
   gint idx = url->len;
   while ( --idx >= 0 && url->str[idx] != '/' && url->str[idx] != '#' );
   return (idx >= 0 && url->str[idx] == '#') ? idx : -1;
}


/*
 * This routine checks to see if the URL passed is of the absolute form, or
 * of the relative form
 *
 * Return Value:
 *   0 is not absolute, otherwise is absolute
 */
static gint Url_str_is_absolute(const char *url_str)
{
   const gchar *ptr = strpbrk(url_str, URN_OTHER);

   return (ptr && *ptr == ':');
}

/*
 *  Transform an URL string into the respective DilloURL.
 *  If we have an URL string =  "http://dillo.sourceforge.net:8080/index.html"
 *  Then the resulting DilloURL should be:
 *  DilloURL = { 
 *     original_url       = "http://dillo.sourceforge.net:8080/index.html"
 *     protocol           = "http"
 *     hostname           = "dillo.sourceforge.net"
 *     path               = "/index.html"
 *     anchor             = NULL
 *     port               = 8080
 *     flags              = URL_Get
 *     data               = NULL
 *     alt                = NULL
 *     ismap_url_len      = 0
 *     ismap_path_len     = 0
 *     scrolling_position = 0
 *  }
 *
 *  Return NULL if URL is badly formed, i.e. doesn't have a `hostname'.
 */   
DilloUrl* a_Url_new(const gchar *url_str, const gchar *base_url, 
                    gint flags, gint pos)
{
   DilloUrl *url;
   gchar *urlstring, *tmp, *urlptr;

   if (!url_str)
      return NULL;

   url  = g_new(DilloUrl, 1);
   Url_init(url);

   /* remove leading & trailing whitespaces */
   tmp = urlstring = g_strstrip(g_strdup(url_str));

   /* figure out relative URL */
   if (base_url && !Url_str_is_absolute(urlstring)) {
      tmp = Url_str_resolve_relative(urlstring, base_url);
      g_free(urlstring);
      urlstring = tmp;
   }

   urlptr = Url_str_get_protocol(urlstring, url);  /* Get protocol */
   urlptr = Url_str_get_hostname(urlptr, url);     /* Get hostname */
   urlptr = Url_str_get_port(urlptr, url);         /* Get port no. */
   urlptr = Url_str_get_path(urlptr, url);         /* Get path */
   g_free(tmp);
   
   url->flags = flags;
   url->scrolling_position = pos;
   url->url_string = Url_to_gstring(url, 1);

   return url;
}

/*
 *  Free DilloUrl structure
 */
void a_Url_free(DilloUrl *url)
{
   if (url) {
      if (url->url_string)
         g_string_free(url->url_string, TRUE);
      g_free((gchar *)url->protocol);
      g_free((gchar *)url->hostname);
      if (url->path)
         g_string_free(url->path, TRUE);
      g_free((gchar *)url->anchor);
      g_free((gchar *)url->data);
      g_free((gchar *)url->alt);
      g_free(url);
   }
}

/*
 * Transform a DilloUrl into a string (for viewing purposes).
 * If we have the following DilloUrl structure:
 *  DilloURL = { 
 *     original_url       = "/index.php"
 *     protocol           = "http"
 *     hostname           = "dillo.sourceforge.net"
 *     path               = "/index.html"
 *     anchor             = "#testing"
 *     port               = 0
 *     flags              = URL_Get
 *     data               = NULL
 *     alt                = NULL
 *     ismap_url_len      = 0
 *     ismap_path_len     = 0
 *     scrolling_position = 0
 *  }
 * 
 * The result string will be "http://dillo.sourceforge.net/index.php#testing"
 * An alternative could be to use DilloUrl->original_url, but can be
 * wrong in cases like relative URL's.
 *
 * Return: new allocated GString. Caller must free it after use!
 */
static GString* Url_to_gstring(const DilloUrl *u, gint anchor)
{
   gchar *protocol, *slash, *port_str;
   GString *gstr;

   g_return_val_if_fail(u, NULL);

   protocol = u->protocol ? (gchar *)u->protocol : "";

   /* Protocols with 2 slashes */
   slash = u->protocol ? 
      ( (!g_strcasecmp(u->protocol, DILLO_URL_HTTP_PROTOCOL)   ||
            !g_strcasecmp(u->protocol, DILLO_URL_HTTPS_PROTOCOL)  ||
            !g_strcasecmp(u->protocol, DILLO_URL_FTP_PROTOCOL)    ||
            !g_strcasecmp(u->protocol, DILLO_URL_TELNET_PROTOCOL) ||
            !g_strcasecmp(u->protocol, DILLO_URL_GOPHER_PROTOCOL) )
        ? "://" : ":") : "";

   port_str = u->port ? g_strdup_printf(":%d", u->port) : "";

   gstr = g_string_sized_new(32);

   g_string_sprintf(gstr, "%s%s%s%s%s%s%s",
      protocol, slash, (u->hostname) ? u->hostname : "",
      port_str, (u->path) ? u->path->str : "",
      (anchor && u->anchor) ? u->anchor : "", 
      (u->data) ? u->data : "");

   if (*port_str)
      g_free(port_str);

   return gstr;
}


/* 
 *  Duplicate a Url structure
 */
DilloUrl* a_Url_dup(const DilloUrl *ori)
{
   DilloUrl *url = g_new(DilloUrl, 1);
   Url_init(url);

   url->url_string         = ori->url_string ?
                                g_string_new(ori->url_string->str) : NULL;
   url->protocol           = g_strdup(ori->protocol);
   url->hostname           = g_strdup(ori->hostname);
   url->path               = ori->path ? g_string_new(ori->path->str) : NULL;
   url->anchor             = g_strdup(ori->anchor); 
   url->port               = ori->port;
   url->flags              = ori->flags;
   url->data               = g_strdup(ori->data);
   url->alt                = g_strdup(ori->alt);
   url->ismap_url_len      = ori->ismap_url_len;
   url->ismap_path_len     = ori->ismap_path_len;
   url->scrolling_position = ori->scrolling_position;        

   return url;
}

/* 
 *  Compare two Url's to check if they are the same.
 *  The fields which are compared here are:
 *  PROTOCOL, HOSTNAME, PORT, PATH and POST
 *  Other fields are left for the caller to check
 *
 *  Return value: 0 is equal, 1 otherwise
 */
gint a_Url_cmp(const DilloUrl *A, const DilloUrl *B)
{
   if (!A || !B)
      return 1;

   if (A == B ||
       (URL_STRCAMP_I_EQ(A->protocol, B->protocol) &&
        URL_STRCAMP_I_EQ(A->hostname, B->hostname) &&
        URL_GSTRCAMP_EQ(A->path, B->path) &&
        URL_STRCAMP_EQ(A->data, B->data) &&
        A->port == B->port))
      return 0;

   return 1;
}

/*
 * Set DilloUrl flags
 */
void a_Url_set_flags(DilloUrl *u, gint flags)
{
   if (u)
      u->flags = flags;
}

/*
 * Set DilloUrl data (like POST info, etc.)
 */
void a_Url_set_data(DilloUrl *u, gchar *data)
{
   if (u) {
      g_free((gchar *)u->data);
      u->data = g_strdup(data);
   }
}

/*
 * Set DilloUrl alt (alternate text to the URL. Used by image maps)
 */
void a_Url_set_alt(DilloUrl *u, gchar *alt)
{
   if (u) {
      if (u->alt)
         g_free((gchar *)u->alt);
      u->alt = g_strdup(alt);
   }
}

/*
 * Set DilloUrl scrolling position
 */
void a_Url_set_pos(DilloUrl *u, gint pos)
{
   if (u)
      u->scrolling_position = pos;
}

/*
 * Set DilloUrl ismap coordinates
 * (this is optimized for not hogging the CPU)
 */
void a_Url_set_ismap_coords(DilloUrl *u, gchar *coord_str)
{
   g_return_if_fail(u && coord_str);

   if ( !u->ismap_url_len ) {
      /* Save base-url length (without coords) */
      u->ismap_url_len  = (u->url_string) ? u->url_string->len : 0;
      u->ismap_path_len = (u->path) ? u->path->len : 0;
      a_Url_set_flags(u, URL_FLAGS(u) | URL_Ismap);
   }
   if (u->url_string) {
      g_string_truncate(u->url_string, u->ismap_url_len);
      g_string_append(u->url_string, coord_str);
   }
   if (u->path) {
      g_string_truncate(u->path, u->ismap_path_len);
      g_string_append(u->path, coord_str);
   }
}

/*
 * Given an hex octet (e3, 2F, 20), return the corresponding 
 * character if the octet is valid, and -1 otherwise
 */
static int Url_parse_hex_octet(const gchar *s)
{
   gint hex_value;
   gchar *tail, hex[3];

   if ( (hex[0] = s[0]) && (hex[1] = s[1]) ) {
      hex[2] = 0;
      hex_value = strtol(hex, &tail, 16);
      if (tail - hex == 2)
        return hex_value;
   }
   return -1;
}

/*
 * Parse possible hexadecimal octets in the URI path
 * Returns new allocated string.
 */
gchar *a_Url_parse_hex_path(const DilloUrl *u)
{
   gchar *new_uri, *dest, *src;
   int i, val;
   
   if ( !u || !u->path || !u->path->len)
      return NULL;

   /* most cases won't have hex octets */
   if (!strchr(u->path->str, '%'))
      return g_strdup(u->path->str);

   src = u->path->str;
   dest = new_uri = g_new(gchar, u->path->len + 1);

   for (i = 0; src[i]; i++) {
      *dest++ = (src[i] == '%' && (val = Url_parse_hex_octet(src+i+1)) >= 0) ?
                val + !(i+=2) : src[i];
   }
   *dest++ = 0;

   new_uri = g_realloc(new_uri, sizeof(gchar)*(dest-new_uri));
   return new_uri;
}
